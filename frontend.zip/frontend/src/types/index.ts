// Core Types for Code Mentor AI Platform

// ============================================
// USER & AUTH TYPES
// ============================================

export interface User {
  id: string
  email: string
  name: string
  avatar?: string
  role: 'student' | 'admin'
  xp: number
  streak: number
  createdAt: string
  lastActiveAt: string
}

export interface Student extends User {
  role: 'student'
  enrolledCourses: string[]
  completedCourses: string[]
  currentCourseId?: string
  learningGaps: LearningGap[]
  badges: Badge[]
}

export interface Admin extends User {
  role: 'admin'
  permissions: string[]
}

export interface LoginCredentials {
  email: string
  password: string
  mfaCode?: string
}

export interface RegisterCredentials {
  email: string
  password: string
  name: string
  agreeToTerms: boolean
}

export interface AuthResponse {
  user: User
  token: string
  refreshToken: string
}

// ============================================
// COURSE TYPES
// ============================================

export type Difficulty = 'Beginner' | 'Intermediate' | 'Advanced' | 'Expert'

// The API returns the database enum in upper case; lower case is kept for older callers.
export type CourseStatus = 'draft' | 'published' | 'archived' | 'DRAFT' | 'PUBLISHED' | 'ARCHIVED'

export interface Course {
  id: string
  name: string
  slug: string
  description: string
  thumbnail?: string
  difficulty: Difficulty
  estimatedDuration: number // in hours
  totalXP: number
  status: CourseStatus
  modules: Module[]
  enrolledCount: number
  averageRating: number
  createdAt: string
  updatedAt: string
}

export interface Module {
  id: string
  courseId: string
  title: string
  description: string
  order: number
  estimatedDuration: number // in hours
  topics: Topic[]
}

export interface Topic {
  id: string
  moduleId: string
  title: string
  description: string
  order: number
  estimatedDuration: number // in minutes
  subtopics: Subtopic[]
  isCompleted?: boolean
  isLocked?: boolean
}

export interface Subtopic {
  id: string
  topicId: string
  title: string
  order: number
  contentType: 'video' | 'notes' | 'practice' | 'coding' | 'quiz' | 'assignment'
  contentId?: string
  estimatedDuration: number // in minutes
  isCompleted?: boolean
  isLocked?: boolean
}

// ============================================
// CONTENT TYPES
// ============================================

export interface Video {
  id: string
  title: string
  description?: string
  url: string
  thumbnail?: string
  duration: number // in seconds
  languages: VideoLanguage[]
  order: number
  subtopicId: string
}

export interface VideoLanguage {
  code: 'en' | 'hi'
  label: string
  url: string
}

export interface Notes {
  id: string
  title: string
  content: string // Markdown content
  subtopicId: string
  order: number
  highlights?: string[]
  commonMistakes?: string[]
  interviewPoints?: string[]
  examPoints?: string[]
}

export interface Example {
  id: string
  title: string
  description?: string
  code: string
  language: string
  output?: string
  explanation?: string
}

// ============================================
// PRACTICE & ASSESSMENT TYPES
// ============================================

export type QuestionType = 
  | 'mcq'
  | 'multiple-choice'
  | 'coding'
  | 'output-prediction'
  | 'debugging'
  | 'sql'
  | 'algorithm'
  | 'dsa'
  | 'short-answer'
  | 'technical'

export interface Question {
  id: string
  type: QuestionType
  content: string
  options?: Option[]
  correctAnswer: string | string[]
  explanation?: string
  difficulty: Difficulty
  tags: string[]
  courseId: string
  moduleId?: string
  topicId?: string
  estimatedTime: number // in seconds
  marks: number
  negativeMarks?: number
}

export interface Option {
  id: string
  content: string
  isCorrect: boolean
}

export interface Practice {
  id: string
  title: string
  description: string
  questions: Question[]
  difficulty: Difficulty
  estimatedDuration: number
  passingScore: number
  subtopicId: string
}

export interface Quiz {
  id: string
  title: string
  description: string
  questions: Question[]
  difficulty: Difficulty
  estimatedDuration: number
  passingScore: number
  subtopicId: string
  isTimed: boolean
}

export interface Test {
  id: string
  title: string
  description: string
  questions: Question[]
  difficulty: Difficulty
  duration: number // in minutes
  passingScore: number
  totalMarks: number
  negativeMarking: boolean
  randomizeQuestions: boolean
  showResults: boolean
  moduleId?: string
  courseId: string
}

export interface Assessment {
  id: string
  title: string
  type: 'diagnostic' | 'topic' | 'module' | 'course' | 'final'
  description: string
  questions: Question[]
  difficulty: Difficulty
  duration: number
  passingScore: number
  totalMarks: number
  courseId: string
  moduleId?: string
  topicId?: string
}

// ============================================
// CODING TYPES
// ============================================

export type ProgrammingLanguage = 'c' | 'cpp' | 'java' | 'python' | 'javascript' | 'sql'

export interface CodingProblem {
  id: string
  title: string
  description: string
  examples: CodingExample[]
  constraints: string[]
  hints?: string[]
  testCases: TestCase[]
  starterCode: Record<ProgrammingLanguage, string>
  difficulty: Difficulty
  tags: string[]
  courseId: string
  moduleId?: string
  topicId?: string
  estimatedTime: number
  marks: number
}

export interface CodingExample {
  input: string
  output: string
  explanation?: string
}

export interface TestCase {
  id: string
  input: string
  expectedOutput: string
  isHidden: boolean
  marks: number
}

export interface CodeSubmission {
  id: string
  problemId: string
  code: string
  language: ProgrammingLanguage
  status: 'pending' | 'running' | 'accepted' | 'wrong-answer' | 'time-limit' | 'runtime-error' | 'compile-error'
  testResults: TestResult[]
  submittedAt: string
  executionTime?: number
  memoryUsed?: number
}

export interface TestResult {
  testCaseId: string
  status: 'passed' | 'failed' | 'error'
  input?: string
  expectedOutput?: string
  actualOutput?: string
  executionTime?: number
  memoryUsed?: number
  error?: string
}

// ============================================
// ASSIGNMENT TYPES
// ============================================

export interface Assignment {
  id: string
  title: string
  description: string
  instructions: string[]
  dueDate: string
  estimatedDuration: number
  totalMarks: number
  courseId: string
  moduleId?: string
  topicId?: string
  attachments?: Attachment[]
  rubric?: RubricCriteria[]
}

export interface Attachment {
  id: string
  name: string
  url: string
  type: string
  size: number
}

export interface RubricCriteria {
  id: string
  description: string
  maxMarks: number
}

export interface AssignmentSubmission {
  id: string
  assignmentId: string
  studentId: string
  status: 'not-started' | 'in-progress' | 'submitted' | 'evaluated' | 'completed'
  submittedAt?: string
  files?: Attachment[]
  comments?: string
  marks?: number
  feedback?: string
  evaluatedAt?: string
  evaluatedBy?: string
}

// ============================================
// PROGRESS & XP TYPES
// ============================================

export interface Progress {
  id: string
  studentId: string
  courseId: string
  moduleId?: string
  topicId?: string
  subtopicId?: string
  contentType: 'video' | 'notes' | 'practice' | 'coding' | 'quiz' | 'test' | 'assignment' | 'assessment'
  contentId: string
  status: 'not-started' | 'in-progress' | 'completed'
  score?: number
  xpEarned: number
  startedAt: string
  completedAt?: string
  attempts?: number
}

export interface CourseProgress {
  courseId: string
  studentId: string
  overallProgress: number // percentage
  modulesProgress: ModuleProgress[]
  totalXP: number
  xpEarned: number
  startedAt: string
  completedAt?: string
  estimatedCompletionDate?: string
  predictedPerformance?: number
}

export interface ModuleProgress {
  moduleId: string
  progress: number // percentage
  topicsProgress: TopicProgress[]
}

export interface TopicProgress {
  topicId: string
  progress: number // percentage
  subtopicsProgress: SubtopicProgress[]
}

export interface SubtopicProgress {
  subtopicId: string
  status: 'not-started' | 'in-progress' | 'completed'
  attempts?: number
  score?: number
}

export interface XP {
  id: string
  studentId: string
  amount: number
  source: 'video' | 'notes' | 'practice' | 'coding' | 'quiz' | 'test' | 'assignment' | 'assessment' | 'streak' | 'badge'
  sourceId?: string
  description: string
  createdAt: string
}

export interface XPHistory {
  date: string
  totalXP: number
  earnedToday: number
  history: XP[]
}

export interface Streak {
  currentStreak: number
  longestStreak: number
  lastActiveDate: string
  streakHistory: StreakDay[]
}

export interface StreakDay {
  date: string
  xpEarned: number
  activitiesCompleted: number
}

export interface Badge {
  id: string
  name: string
  description: string
  icon: string
  requirement: string
  xpBonus: number
  earnedAt?: string
}

// ============================================
// LEARNING GAP TYPES
// ============================================

export type GapSeverity = 'critical' | 'moderate' | 'minor' | 'improved' | 'resolved'

export interface LearningGap {
  id: string
  studentId: string
  courseId: string
  moduleId?: string
  topicId?: string
  concept: string
  description: string
  gapScore: number // 0-100, higher = bigger gap
  severity: GapSeverity
  detectedAt: string
  improvedAt?: string
  resolvedAt?: string
  recommendedActions: Recommendation[]
  relatedQuestions: string[]
  relatedVideos: string[]
  relatedNotes: string[]
}

export interface GapAnalysis {
  totalGaps: number
  critical: number
  moderate: number
  minor: number
  improved: number
  resolved: number
  gaps: LearningGap[]
}

// ============================================
// RECOMMENDATION TYPES
// ============================================

export type RecommendationType = 
  | 'continue-learning'
  | 'revise-topic'
  | 'watch-video'
  | 'practice'
  | 'take-quiz'
  | 'complete-assignment'
  | 'take-assessment'
  | 'coding-practice'
  | 'review-notes'
  | 'address-gap'

export interface Recommendation {
  id: string
  studentId: string
  type: RecommendationType
  priority: 'high' | 'medium' | 'low'
  title: string
  description: string
  courseId?: string
  moduleId?: string
  topicId?: string
  contentId?: string
  contentType?: 'video' | 'notes' | 'practice' | 'coding' | 'quiz' | 'assignment' | 'assessment'
  estimatedDuration?: number
  xpReward?: number
  reason: string
  createdAt: string
  expiresAt?: string
  isCompleted: boolean
  completedAt?: string
}

// ============================================
// ANALYTICS TYPES
// ============================================

export interface StudentAnalytics {
  studentId: string
  performanceTrend: PerformanceDataPoint[]
  courseProgress: CourseProgress[]
  accuracyByType: AccuracyByType[]
  timeSpent: TimeSpentData
  quizPerformance: QuizPerformance[]
  codingPerformance: CodingPerformance[]
  assessmentPerformance: AssessmentPerformance[]
  xpTrend: XPDataPoint[]
  learningGaps: GapAnalysis
  studyActivity: ActivityDataPoint[]
  strengths: string[]
  weaknesses: string[]
}

export interface PerformanceDataPoint {
  date: string
  score: number
  accuracy: number
  attempts: number
}

export interface AccuracyByType {
  type: QuestionType
  accuracy: number
  attempts: number
  averageTime: number
}

export interface TimeSpentData {
  totalMinutes: number
  byCourse: { courseId: string; minutes: number }[]
  byContentType: { contentType: string; minutes: number }[]
  dailyAverage: number
  weeklyAverage: number
}

export interface QuizPerformance {
  quizId: string
  title: string
  score: number
  accuracy: number
  timeTaken: number
  attempts: number
  bestScore: number
}

export interface CodingPerformance {
  problemId: string
  title: string
  attempts: number
  acceptanceRate: number
  averageTime: number
  languagesUsed: string[]
}

export interface AssessmentPerformance {
  assessmentId: string
  title: string
  type: string
  score: number
  accuracy: number
  percentile?: number
}

export interface XPDataPoint {
  date: string
  totalXP: number
  earnedToday: number
}

export interface ActivityDataPoint {
  date: string
  activitiesCompleted: number
  minutesSpent: number
  xpEarned: number
}

// ============================================
// EXAM TYPES
// ============================================

export type ExamStatus = 'draft' | 'scheduled' | 'active' | 'completed' | 'cancelled'

export interface Exam {
  id: string
  title: string
  description: string
  instructions: string[]
  courseId: string
  moduleId?: string
  questions: Question[]
  duration: number // in minutes
  totalMarks: number
  passingScore: number
  negativeMarking: boolean
  randomizeQuestions: boolean
  randomizeOptions: boolean
  showResults: boolean
  proctoringEnabled: boolean
  maxAttempts: number
  allowedAttempts: number
  scheduledStart: string
  scheduledEnd: string
  status: ExamStatus
  createdAt: string
  updatedAt: string
}

export interface ExamAttempt {
  id: string
  examId: string
  studentId: string
  status: 'in-progress' | 'submitted' | 'auto-submitted' | 'flagged'
  answers: ExamAnswer[]
  startedAt: string
  submittedAt?: string
  score?: number
  percentile?: number
  timeSpent: number
  warnings: ProctoringWarning[]
  flaggedReasons?: string[]
}

export interface ExamAnswer {
  questionId: string
  answer: string | string[]
  isCorrect?: boolean
  timeSpent: number
  markedForReview: boolean
}

// ============================================
// PROCTORING TYPES
// ============================================

export interface ProctoringSession {
  id: string
  examAttemptId: string
  studentId: string
  status: 'active' | 'paused' | 'completed' | 'flagged'
  cameraEnabled: boolean
  microphoneEnabled: boolean
  screenShareEnabled: boolean
  warnings: ProctoringWarning[]
  events: ProctoringEvent[]
  startedAt: string
  endedAt?: string
}

export interface ProctoringWarning {
  id: string
  type: 'multiple-faces' | 'no-face' | 'phone-detected' | 'looking-away' | 'suspicious-activity' | 'tab-switch'
  severity: 'low' | 'medium' | 'high'
  message: string
  timestamp: string
  evidence?: string // screenshot URL
  isReviewed: boolean
  reviewedBy?: string
  reviewNotes?: string
}

export interface ProctoringEvent {
  id: string
  type: string
  description: string
  timestamp: string
  metadata?: Record<string, any>
}

// ============================================
// AI TUTOR TYPES
// ============================================

export interface AIChatMessage {
  id: string
  role: 'user' | 'assistant' | 'system'
  content: string
  timestamp: string
  context?: AIContext
}

export interface AIContext {
  courseId?: string
  moduleId?: string
  topicId?: string
  subtopicId?: string
  questionId?: string
  problemId?: string
  code?: string
  error?: string
}

export interface AIQuickAction {
  id: string
  label: string
  icon: string
  prompt: string
}

export interface AIResponse {
  content: string
  suggestions?: string[]
  relatedTopics?: string[]
  code?: string
  examples?: Example[]
}

// ============================================
// NOTIFICATION TYPES
// ============================================

export type NotificationType = 
  | 'info'
  | 'success'
  | 'warning'
  | 'error'
  | 'assignment-due'
  | 'exam-reminder'
  | 'achievement'
  | 'recommendation'

export interface Notification {
  id: string
  userId: string
  type: NotificationType
  title: string
  message: string
  link?: string
  isRead: boolean
  createdAt: string
  expiresAt?: string
}

// ============================================
// ADMIN TYPES
// ============================================

export interface AdminDashboard {
  totalStudents: number
  activeStudents: number
  totalCourses: number
  totalContent: number
  averagePerformance: number
  learningGaps: GapAnalysis
  highRiskStudents: Student[]
  pendingExamReviews: number
  proctoringAlerts: number
  lowPerformingTopics: TopicPerformance[]
  unpublishedContent: number
  aiTutorUsage: AIUsageStats
}

export interface TopicPerformance {
  topicId: string
  title: string
  courseId: string
  averageScore: number
  attempts: number
  failureRate: number
  averageTime: number
}

export interface AIUsageStats {
  totalQueries: number
  uniqueUsers: number
  averageQueriesPerUser: number
  topTopics: string[]
  satisfactionScore: number
}

export interface AuditLog {
  id: string
  userId: string
  action: string
  resource: string
  resourceId: string
  details: Record<string, any>
  ipAddress: string
  userAgent: string
  timestamp: string
}

export interface SecurityEvent {
  id: string
  type: 'login' | 'logout' | 'failed-login' | 'mfa' | 'password-change' | 'suspicious'
  userId: string
  details: Record<string, any>
  ipAddress: string
  timestamp: string
  isResolved: boolean
}

// ============================================
// API RESPONSE TYPES
// ============================================

export interface ApiResponse<T> {
  data: T
  message?: string
  success: boolean
}

export interface PaginatedResponse<T> {
  data: T[]
  pagination: {
    page: number
    limit: number
    total: number
    totalPages: number
  }
}

export interface ApiError {
  message: string
  code: string
  details?: Record<string, any>
}

// ============================================
// COMPONENT PROPS TYPES
// ============================================

export interface ButtonProps {
  variant?: 'default' | 'secondary' | 'outline' | 'ghost' | 'link' | 'destructive'
  size?: 'sm' | 'md' | 'lg'
  isLoading?: boolean
  disabled?: boolean
  onClick?: () => void
  children: React.ReactNode
  className?: string
}

export interface CardProps {
  title?: string
  description?: string
  children: React.ReactNode
  className?: string
  onClick?: () => void
}

export interface ProgressProps {
  value: number
  max?: number
  showLabel?: boolean
  size?: 'sm' | 'md' | 'lg'
  className?: string
}

export interface BadgeProps {
  variant?: 'default' | 'secondary' | 'outline' | 'success' | 'warning' | 'destructive'
  size?: 'sm' | 'md' | 'lg'
  children: React.ReactNode
  className?: string
}

export interface TableProps<T> {
  data: T[]
  columns: Column<T>[]
  onRowClick?: (row: T) => void
  className?: string
}

export interface Column<T> {
  key: string
  header: string
  render?: (row: T) => React.ReactNode
  sortable?: boolean
}

export interface ModalProps {
  isOpen: boolean
  onClose: () => void
  title: string
  description?: string
  children: React.ReactNode
  footer?: React.ReactNode
}

export interface InputProps {
  label?: string
  type?: 'text' | 'email' | 'password' | 'number' | 'search'
  placeholder?: string
  value: string
  onChange: (value: string) => void
  error?: string
  disabled?: boolean
  className?: string
}

export interface SelectProps {
  label?: string
  options: SelectOption[]
  value: string
  onChange: (value: string) => void
  placeholder?: string
  error?: string
  disabled?: boolean
  className?: string
}

export interface SelectOption {
  value: string
  label: string
  icon?: React.ReactNode
}

export interface TabsProps {
  tabs: Tab[]
  activeTab: string
  onChange: (tabId: string) => void
  className?: string
}

export interface Tab {
  id: string
  label: string
  icon?: React.ReactNode
  badge?: string
}

export interface EmptyStateProps {
  icon?: React.ReactNode
  title: string
  description?: string
  action?: React.ReactNode
  className?: string
}

export interface LoadingStateProps {
  message?: string
  size?: 'sm' | 'md' | 'lg'
  className?: string
}

export interface ErrorStateProps {
  title: string
  message?: string
  onRetry?: () => void
  className?: string
}

export interface SkeletonProps {
  className?: string
  variant?: 'text' | 'card' | 'table' | 'avatar'
}
