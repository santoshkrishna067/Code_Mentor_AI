import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react'
import { setAccessToken, refreshAccessToken } from '@/lib/apiClient'
import { authService, type AuthUser } from '@/services/auth.service'

interface AuthContextValue {
  user: AuthUser | null
  isLoading: boolean
  isAuthenticated: boolean
  login: (email: string, password: string, mfaCode?: string) => Promise<{ mfaRequired: boolean; challengeToken?: string }>
  completeMfaLogin: (challengeToken: string, code: string) => Promise<void>
  loginWithGoogle: (idToken: string) => Promise<{ mfaRequired: boolean; challengeToken?: string }>
  register: (email: string, password: string, name: string) => Promise<void>
  logout: () => Promise<void>
  refreshUser: () => Promise<void>
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  // On first load there is no access token in memory (it's never persisted
  // to localStorage — see apiClient.ts). Try the httpOnly refresh cookie
  // first; only if that fails is the user actually logged out.
  useEffect(() => {
    let cancelled = false
    ;(async () => {
      const token = await refreshAccessToken()
      if (token) {
        try {
          const me = await authService.me()
          if (!cancelled) setUser(me)
        } catch {
          if (!cancelled) setUser(null)
        }
      }
      if (!cancelled) setIsLoading(false)
    })()
    return () => {
      cancelled = true
    }
  }, [])

  const login = useCallback(async (email: string, password: string, mfaCode?: string) => {
    const result = await authService.login({ email, password, mfaCode })
    if (result.mfaRequired) {
      return { mfaRequired: true, challengeToken: result.challengeToken }
    }
    setAccessToken(result.accessToken!)
    setUser(result.user!)
    return { mfaRequired: false }
  }, [])

  const loginWithGoogle = useCallback(async (idToken: string) => {
    const result = await authService.loginWithGoogle(idToken)
    if (result.mfaRequired) return { mfaRequired: true, challengeToken: result.challengeToken }
    setAccessToken(result.accessToken!)
    setUser(result.user!)
    return { mfaRequired: false }
  }, [])

  const completeMfaLogin = useCallback(async (challengeToken: string, code: string) => {
    const result = await authService.completeMfaLogin(challengeToken, code)
    setAccessToken(result.accessToken)
    setUser(result.user)
  }, [])

  const register = useCallback(async (email: string, password: string, name: string) => {
    const result = await authService.register({ email, password, name, agreeToTerms: true })
    setAccessToken(result.accessToken)
    setUser(result.user)
  }, [])

  const logout = useCallback(async () => {
    await authService.logout()
    setAccessToken(null)
    setUser(null)
  }, [])

  const refreshUser = useCallback(async () => {
    const me = await authService.me()
    setUser(me)
  }, [])

  return (
    <AuthContext.Provider
      value={{ user, isLoading, isAuthenticated: !!user, login, completeMfaLogin, loginWithGoogle, register, logout, refreshUser }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider')
  return ctx
}
