import axios, { AxiosError, type InternalAxiosRequestConfig } from 'axios'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:4000/api'

// Matches the backend's ApiError shape exactly (see backend src/utils/apiResponse.ts).
export interface ApiErrorBody {
  message: string
  code: string
  details?: Record<string, unknown>
}

export class ApiRequestError extends Error {
  code: string
  status: number
  details?: Record<string, unknown>
  constructor(status: number, body: ApiErrorBody) {
    super(body.message)
    this.status = status
    this.code = body.code
    this.details = body.details
  }
}

// Access token is kept in memory (not localStorage) to reduce XSS exposure;
// the refresh token lives in an httpOnly cookie set by the backend
// (see backend src/modules/auth/auth.routes.ts setRefreshCookie), so a page
// reload re-authenticates silently via /auth/refresh rather than needing the
// access token persisted client-side at all.
let accessToken: string | null = null
export function setAccessToken(token: string | null) {
  accessToken = token
}
export function getAccessToken() {
  return accessToken
}

export const apiClient = axios.create({
  baseURL: API_URL,
  withCredentials: true, // send/receive the httpOnly refresh cookie
})

apiClient.interceptors.request.use((config: InternalAxiosRequestConfig) => {
  if (accessToken) {
    config.headers = config.headers ?? {}
    config.headers.Authorization = `Bearer ${accessToken}`
  }
  return config
})

// Single-flight refresh: if multiple requests 401 at once, only one
// /auth/refresh call is made and the rest wait on it.
let refreshPromise: Promise<string | null> | null = null

async function refreshAccessToken(): Promise<string | null> {
  if (!refreshPromise) {
    refreshPromise = axios
      .post(`${API_URL}/auth/refresh`, {}, { withCredentials: true })
      .then((res) => {
        const token = res.data?.data?.accessToken ?? null
        setAccessToken(token)
        return token
      })
      .catch(() => {
        setAccessToken(null)
        return null
      })
      .finally(() => {
        refreshPromise = null
      })
  }
  return refreshPromise
}

apiClient.interceptors.response.use(
  (res) => res,
  async (error: AxiosError<ApiErrorBody>) => {
    const original = error.config as (InternalAxiosRequestConfig & { _retried?: boolean }) | undefined

    if (error.response?.status === 401 && original && !original._retried && !original.url?.includes('/auth/')) {
      original._retried = true
      const newToken = await refreshAccessToken()
      if (newToken) {
        original.headers = original.headers ?? {}
        original.headers.Authorization = `Bearer ${newToken}`
        return apiClient(original)
      }
      // Refresh failed — genuinely logged out. Let the AuthContext's
      // bootstrap/401 handling redirect to /login; don't force a hard
      // redirect here so this module has no React/router dependency.
    }

    const body: ApiErrorBody = error.response?.data ?? { message: error.message, code: 'NETWORK_ERROR' }
    return Promise.reject(new ApiRequestError(error.response?.status ?? 0, body))
  }
)

export { refreshAccessToken }
