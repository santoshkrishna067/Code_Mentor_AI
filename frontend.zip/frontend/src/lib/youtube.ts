/**
 * Turns the many YouTube link shapes found in the course spreadsheets into a
 * URL that can be shown inside an <iframe>. The old code only handled
 * "watch?v=", so playlist links (the Hindi tracks) and youtu.be links showed a
 * blank player.
 */
export function toEmbedUrl(raw: string | undefined | null): string | null {
  if (!raw) return null
  let url: URL
  try {
    url = new URL(raw.trim())
  } catch {
    return null
  }
  const host = url.hostname.replace(/^www\./, '').replace(/^m\./, '')

  const start = parseStart(url.searchParams.get('t') || url.searchParams.get('start'))
  const list = url.searchParams.get('list')
  let id: string | null = null

  if (host === 'youtu.be') id = url.pathname.slice(1).split('/')[0] || null
  else if (host === 'youtube.com' || host === 'youtube-nocookie.com') {
    if (url.pathname === '/watch') id = url.searchParams.get('v')
    else if (url.pathname.startsWith('/embed/')) id = url.pathname.split('/')[2] || null
    else if (url.pathname.startsWith('/shorts/') || url.pathname.startsWith('/live/')) id = url.pathname.split('/')[2] || null
    else if (url.pathname === '/playlist' && list) {
      return `https://www.youtube.com/embed/videoseries?list=${encodeURIComponent(list)}`
    }
  } else if (host === 'vimeo.com') {
    const vid = url.pathname.split('/').filter(Boolean)[0]
    return vid && /^\d+$/.test(vid) ? `https://player.vimeo.com/video/${vid}` : null
  } else if (host === 'drive.google.com') {
    const m = url.pathname.match(/\/file\/d\/([^/]+)/)
    return m ? `https://drive.google.com/file/d/${m[1]}/preview` : null
  } else {
    return null
  }

  if (!id) return null
  const params = new URLSearchParams()
  if (start) params.set('start', String(start))
  if (list) params.set('list', list)
  params.set('rel', '0')
  return `https://www.youtube.com/embed/${encodeURIComponent(id)}?${params.toString()}`
}

// "90", "90s", "1m30s", "1h2m3s" -> seconds
function parseStart(t: string | null): number {
  if (!t) return 0
  if (/^\d+$/.test(t)) return Number(t)
  const m = t.match(/^(?:(\d+)h)?(?:(\d+)m)?(?:(\d+)s)?$/)
  if (!m) return 0
  return Number(m[1] || 0) * 3600 + Number(m[2] || 0) * 60 + Number(m[3] || 0)
}

// A direct link to a video file (played with the browser's own player).
export function isDirectVideo(raw: string | undefined | null): boolean {
  if (!raw) return false
  try {
    return /\.(mp4|webm|ogg|mov|m4v)$/i.test(new URL(raw.trim()).pathname)
  } catch {
    return false
  }
}
