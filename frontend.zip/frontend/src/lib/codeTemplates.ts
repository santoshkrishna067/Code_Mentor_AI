// Languages offered by the code editors and the starter program for each.
export const LANGUAGES = [
  { id: 'python', label: 'Python', monaco: 'python' },
  { id: 'javascript', label: 'JavaScript', monaco: 'javascript' },
  { id: 'java', label: 'Java', monaco: 'java' },
  { id: 'c', label: 'C', monaco: 'c' },
  { id: 'cpp', label: 'C++', monaco: 'cpp' },
  { id: 'sql', label: 'SQL', monaco: 'sql' },
]

export const PLAYGROUND_STARTER: Record<string, string> = {
  python: 'name = input("Your name: ")\nprint("Hello,", name)\n',
  javascript: 'const lines = require("fs").readFileSync(0, "utf8").split("\\n");\nconsole.log("Hello,", lines[0] || "world");\n',
  java: 'import java.util.*;\n\npublic class Main {\n    public static void main(String[] args) {\n        Scanner sc = new Scanner(System.in);\n        String name = sc.hasNextLine() ? sc.nextLine() : "world";\n        System.out.println("Hello, " + name);\n    }\n}\n',
  c: '#include <stdio.h>\n\nint main() {\n    char name[100] = "world";\n    scanf("%99s", name);\n    printf("Hello, %s\\n", name);\n    return 0;\n}\n',
  cpp: '#include <iostream>\n#include <string>\nusing namespace std;\n\nint main() {\n    string name = "world";\n    cin >> name;\n    cout << "Hello, " << name << endl;\n    return 0;\n}\n',
  sql: "-- Each run starts with an empty database.\nCREATE TABLE student (id INTEGER PRIMARY KEY, name TEXT, marks INTEGER);\nINSERT INTO student VALUES (1, 'Asha', 82), (2, 'Ravi', 67), (3, 'Meena', 91);\n\nSELECT name, marks FROM student WHERE marks > 70 ORDER BY marks DESC;\n",
}

// Map a course slug to the language its practice editor should open with.
export function defaultLanguageForCourse(slug?: string): string {
  const s = (slug ?? '').toLowerCase()
  if (s.includes('python')) return 'python'
  if (s.includes('java') && !s.includes('javascript')) return 'java'
  if (s.includes('cpp') || s.includes('c++')) return 'cpp'
  if (s.includes('rdbms') || s.includes('sql') || s.includes('database')) return 'sql'
  if (s.includes('c-') || s === 'c' || s.endsWith('-in-c') || s.includes('c-programming')) return 'c'
  return 'python'
}

// Map the language names used in note examples to editor language ids.
export function normaliseExampleLanguage(lang?: string): string {
  const l = (lang ?? '').toLowerCase().trim()
  if (['py', 'python', 'python3'].includes(l)) return 'python'
  if (['js', 'javascript', 'node'].includes(l)) return 'javascript'
  if (l === 'java') return 'java'
  if (l === 'c') return 'c'
  if (['cpp', 'c++', 'cxx'].includes(l)) return 'cpp'
  if (['sql', 'sqlite', 'mysql'].includes(l)) return 'sql'
  return 'python'
}
