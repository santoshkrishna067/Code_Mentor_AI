export default function FeaturesPage() {
  return (
    <div className="container py-12">
      <h1 className="text-4xl font-bold mb-8">Features</h1>
      <p className="text-lg text-muted-foreground mb-12">
        Discover all the powerful features that make Code Mentor AI the best platform for learning programming.
      </p>
      <div className="grid md:grid-cols-2 gap-8">
        <div className="space-y-4">
          <h2 className="text-2xl font-bold">AI-Powered Learning</h2>
          <p className="text-muted-foreground">
            Our AI analyzes your learning patterns and creates personalized study plans optimized for your success.
          </p>
        </div>
        <div className="space-y-4">
          <h2 className="text-2xl font-bold">Interactive Coding</h2>
          <p className="text-muted-foreground">
            Practice coding directly in your browser with instant feedback and intelligent hints.
          </p>
        </div>
        <div className="space-y-4">
          <h2 className="text-2xl font-bold">Learning Gap Analysis</h2>
          <p className="text-muted-foreground">
            Identify and address knowledge gaps with targeted recommendations and practice exercises.
          </p>
        </div>
        <div className="space-y-4">
          <h2 className="text-2xl font-bold">Progress Analytics</h2>
          <p className="text-muted-foreground">
            Track your improvement with detailed analytics and performance insights.
          </p>
        </div>
      </div>
    </div>
  )
}
