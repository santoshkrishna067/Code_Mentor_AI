import { Link } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Bookmark, Loader2, Trash2 } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { bookmarksService } from '@/services/bookmarks.service'

export default function BookmarksPage() {
  const qc = useQueryClient()
  const { data, isLoading } = useQuery({ queryKey: ['bookmarks', 'list'], queryFn: () => bookmarksService.list() })
  const remove = useMutation({
    mutationFn: (subtopicId: string) => bookmarksService.toggle(subtopicId),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['bookmarks'] }),
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Bookmarks</h1>
        <p className="text-muted-foreground">Lessons you saved to come back to. Use the bookmark button on any lesson.</p>
      </div>

      {isLoading && <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto my-16" />}

      {!isLoading && (data?.length ?? 0) === 0 && (
        <div className="text-center py-16 space-y-3">
          <Bookmark className="h-12 w-12 mx-auto text-muted-foreground" />
          <p className="text-muted-foreground">Nothing bookmarked yet.</p>
          <Link to="/courses">
            <Button>Open a course</Button>
          </Link>
        </div>
      )}

      <div className="space-y-3">
        {data?.map((b) => (
          <Card key={b.id}>
            <CardContent className="py-4 flex items-center justify-between gap-4">
              <Link to={`/courses/${b.courseSlug}/topics/${b.subtopicId}`} className="min-w-0 flex-1">
                <p className="font-medium truncate">{b.subtopicTitle}</p>
                <p className="text-sm text-muted-foreground truncate">{b.courseName}</p>
              </Link>
              <Button variant="ghost" size="icon" title="Remove bookmark" onClick={() => remove.mutate(b.subtopicId)}>
                <Trash2 className="h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
