import { Link } from 'react-router-dom'
import { useQuery, useQueries } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Clock, Calendar, Loader2 } from 'lucide-react'
import { coursesService } from '@/services/courses.service'
import { examsService } from '@/services/exams.service'

function statusVariant(status: string): 'success' | 'warning' | 'secondary' {
  if (status === 'completed') return 'success'
  if (status === 'active') return 'warning'
  return 'secondary'
}

export default function ExamsPage() {
  const { data: enrollments, isLoading: enrollmentsLoading } = useQuery({
    queryKey: ['courses', 'my-enrollments'],
    queryFn: () => coursesService.myEnrollments(),
  })

  const examQueries = useQueries({
    queries: (enrollments ?? []).map((e) => ({
      queryKey: ['exams', 'course', e.courseId],
      queryFn: () => examsService.listForCourse(e.courseId),
      enabled: !!enrollments,
    })),
  })

  const isLoading = enrollmentsLoading || examQueries.some((q) => q.isLoading)
  const allExams = examQueries.flatMap((q, i) => (q.data ?? []).map((exam) => ({ ...exam, courseName: enrollments?.[i]?.course.name })))

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Exams</h1>
        <p className="text-muted-foreground">Upcoming and open exams for your courses</p>
      </div>

      {isLoading && (
        <div className="flex justify-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      )}

      {!isLoading && allExams.length === 0 && <p className="text-center text-muted-foreground py-16">No exams open right now.</p>}

      <div className="space-y-4">
        {allExams.map((exam) => (
          <Link key={exam.id} to={`/exams/${exam.id}`}>
            <Card className="hover:border-primary/50 transition-colors">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle>{exam.title}</CardTitle>
                    <CardDescription>{exam.courseName}</CardDescription>
                  </div>
                  <Badge variant={statusVariant(exam.status)}>{exam.status}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-6 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    {new Date(exam.scheduledStart).toLocaleDateString()}
                  </div>
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    {exam.duration} min
                  </div>
                  {exam.questionCount !== undefined && <div>{exam.questionCount} questions</div>}
                </div>
                <div className="mt-4">
                  <Button variant="outline" size="sm">
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}
