import { useNavigate } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Bell, Loader2, CheckCheck } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { notificationsService, type NotificationDto } from '@/services/notifications.service'

export default function NotificationsPage() {
  const navigate = useNavigate()
  const qc = useQueryClient()
  const { data, isLoading } = useQuery({ queryKey: ['notifications', 'all'], queryFn: () => notificationsService.list({ limit: 50 }) })

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['notifications'] })
  }
  const readAll = useMutation({ mutationFn: () => notificationsService.markAllRead(), onSuccess: refresh })
  const open = useMutation({
    mutationFn: (n: NotificationDto) => (n.isRead ? Promise.resolve(n) : notificationsService.markRead(n.id)),
    onSuccess: (n) => {
      refresh()
      if (n.link) navigate(n.link)
    },
  })

  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Notifications</h1>
          <p className="text-muted-foreground">{data?.unreadCount ?? 0} unread</p>
        </div>
        <Button variant="outline" onClick={() => readAll.mutate()} disabled={!data?.unreadCount}>
          <CheckCheck className="h-4 w-4 mr-2" />
          Mark all read
        </Button>
      </div>

      {isLoading && <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto my-16" />}
      {!isLoading && (data?.data.length ?? 0) === 0 && (
        <div className="text-center py-16 space-y-2">
          <Bell className="h-12 w-12 mx-auto text-muted-foreground" />
          <p className="text-muted-foreground">You're all caught up.</p>
        </div>
      )}

      <div className="space-y-2">
        {data?.data.map((n) => (
          <Card key={n.id} className={n.isRead ? 'opacity-70' : 'border-primary/40'}>
            <CardContent className="py-4 cursor-pointer" onClick={() => open.mutate(n)}>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="font-medium">{n.title}</p>
                  <p className="text-sm text-muted-foreground">{n.message}</p>
                </div>
                <p className="text-xs text-muted-foreground whitespace-nowrap">{new Date(n.createdAt).toLocaleString()}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
