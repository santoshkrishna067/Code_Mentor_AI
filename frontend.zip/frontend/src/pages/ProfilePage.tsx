import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { LogOut, ShieldCheck, KeyRound } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '@/context/AuthContext'
import { authService } from '@/services/auth.service'
import { useToast } from '@/components/ui/use-toast'
import { ApiRequestError } from '@/lib/apiClient'

export default function ProfilePage() {
  const { user, logout } = useAuth()
  const navigate = useNavigate()
  const { toast } = useToast()
  const [current, setCurrent] = useState('')
  const [next, setNext] = useState('')
  const [saving, setSaving] = useState(false)

  if (!user) return null

  const handleLogout = async () => {
    await logout()
    navigate('/login')
  }

  const changePassword = async () => {
    setSaving(true)
    try {
      await authService.changePassword(current, next)
      toast({ title: 'Password changed', description: 'Use your new password next time you sign in.' })
      setCurrent('')
      setNext('')
    } catch (e) {
      toast({ title: 'Could not change password', description: e instanceof ApiRequestError ? e.message : 'Try again.', variant: 'destructive' })
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="max-w-2xl space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Profile</h1>
        <p className="text-muted-foreground">Your account details.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{user.name}</CardTitle>
          <CardDescription>{user.email}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary">{user.role}</Badge>
            <Badge variant="outline">{user.xp.toLocaleString()} XP</Badge>
            <Badge variant="outline">🔥 {user.streak} day streak</Badge>
            {user.mfaEnabled && (
              <Badge variant="success">
                <ShieldCheck className="h-3 w-3 mr-1" />
                Two-factor on
              </Badge>
            )}
          </div>
          <p className="text-sm text-muted-foreground">Member since {new Date(user.createdAt).toLocaleDateString()}</p>
          <Button variant="destructive" onClick={handleLogout}>
            <LogOut className="h-4 w-4 mr-2" />
            Log out
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <KeyRound className="h-5 w-5" />
            Change password
          </CardTitle>
          <CardDescription>If you signed up with Google you can set a password with “Forgot password” on the login page.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Input type="password" placeholder="Current password" value={current} onChange={(e) => setCurrent(e.target.value)} />
          <Input type="password" placeholder="New password (min 8 characters)" value={next} onChange={(e) => setNext(e.target.value)} />
          <Button onClick={changePassword} isLoading={saving} disabled={!current || next.length < 8}>
            Update password
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
