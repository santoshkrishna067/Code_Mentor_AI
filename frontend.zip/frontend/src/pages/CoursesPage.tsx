import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Loader2 } from 'lucide-react'
import { coursesService } from '@/services/courses.service'
import { useAuth } from '@/context/AuthContext'

export default function CoursesPage() {
  const { isAuthenticated, user } = useAuth()
  const { data, isLoading, isError } = useQuery({
    queryKey: ['courses', 'list'],
    queryFn: () => coursesService.list({ limit: 50 }),
  })

  return (
    <div className="container py-12">
      <h1 className="text-4xl font-bold mb-4">All Courses</h1>
      <p className="text-lg text-muted-foreground mb-12">
        Choose from our comprehensive collection of programming courses
      </p>

      {isLoading && (
        <div className="flex justify-center py-24">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      )}

      {isError && <p className="text-center text-destructive py-12">Could not load courses. Please try again later.</p>}

      {!isLoading && !isError && data?.data.length === 0 && (
        <p className="text-center text-muted-foreground py-12">No courses are published yet.</p>
      )}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {data?.data.map((course) => (
          <Card key={course.id} className="flex flex-col">
            <CardHeader>
              <CardTitle>{course.name}</CardTitle>
              <CardDescription className="line-clamp-2">{course.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-1">
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Level</span>
                  <Badge variant="secondary">{course.difficulty}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Duration</span>
                  <span>{course.estimatedDuration} hours</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">XP</span>
                  <span className="text-primary">{course.totalXP.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Enrolled</span>
                  <span>{course.enrolledCount.toLocaleString()}</span>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              {isAuthenticated && user?.role === 'student' ? (
                <Link to={`/courses/${course.slug}`} className="w-full">
                  <Button className="w-full">View Course</Button>
                </Link>
              ) : (
                <Link to="/login" className="w-full">
                  <Button className="w-full" variant="outline">
                    Sign in to enroll
                  </Button>
                </Link>
              )}
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}
