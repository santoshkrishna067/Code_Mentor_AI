import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { Loader2, Clock, HelpCircle, CheckCircle2 } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { learningService, type AvailableItem } from '@/services/learning.service'

type Kind = 'quizzes' | 'tests' | 'assessments'

const META: Record<Kind, { title: string; subtitle: string; singular: string; base: string; empty: string }> = {
  quizzes: {
    title: 'Quizzes',
    subtitle: 'Short quizzes attached to individual lessons.',
    singular: 'quiz',
    base: '/quiz',
    empty: 'No quizzes have been published for your courses yet. Your instructor adds them from the admin Question Bank.',
  },
  tests: {
    title: 'Tests',
    subtitle: 'Timed, course-level tests.',
    singular: 'test',
    base: '/test',
    empty: 'No tests have been published for your courses yet. Your instructor adds them from the admin panel.',
  },
  assessments: {
    title: 'Assessments',
    subtitle: 'Module and course assessments.',
    singular: 'assessment',
    base: '/assessment',
    empty: 'No assessments have been published for your courses yet. Your instructor adds them from the admin panel.',
  },
}

/** One list page used by /quizzes, /tests and /assessments. */
export default function ContentListPage({ kind }: { kind: Kind }) {
  const meta = META[kind]
  const { data, isLoading } = useQuery({ queryKey: ['learning', 'available'], queryFn: () => learningService.available() })
  const items: AvailableItem[] = data?.[kind] ?? []

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">{meta.title}</h1>
        <p className="text-muted-foreground">{meta.subtitle}</p>
      </div>

      {isLoading && <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto my-16" />}

      {!isLoading && data?.enrolledCourses === 0 && (
        <div className="text-center py-16 space-y-3">
          <p className="text-muted-foreground">You are not enrolled in any course yet — {meta.title.toLowerCase()} appear here for the courses you join.</p>
          <Link to="/courses">
            <Button>Browse courses</Button>
          </Link>
        </div>
      )}

      {!isLoading && (data?.enrolledCourses ?? 0) > 0 && items.length === 0 && <p className="text-center text-muted-foreground py-16 max-w-xl mx-auto">{meta.empty}</p>}

      <div className="grid md:grid-cols-2 gap-4">
        {items.map((item) => (
          <Card key={item.id} className="flex flex-col">
            <CardHeader>
              <div className="flex items-start justify-between gap-3">
                <CardTitle className="text-lg">{item.title}</CardTitle>
                <Badge variant="secondary">{item.difficulty.toLowerCase()}</Badge>
              </div>
              <CardDescription>
                {item.courseName}
                {item.context ? ` · ${item.context}` : ''}
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col justify-between gap-4">
              <p className="text-sm text-muted-foreground">{item.description}</p>
              <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                <span className="inline-flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  {item.durationMinutes} min
                </span>
                <span className="inline-flex items-center gap-1">
                  <HelpCircle className="h-4 w-4" />
                  {item.questionCount} questions
                </span>
                <span>Pass: {item.passingScore}%</span>
                {item.attempted && (
                  <span className="inline-flex items-center gap-1 text-green-600">
                    <CheckCircle2 className="h-4 w-4" />
                    {item.score !== undefined ? `Last score ${Math.round(item.score)}%` : 'Attempted'}
                  </span>
                )}
              </div>
              <Link to={`${meta.base}/${item.id}`}>
                <Button className="w-full">{item.attempted ? `Retake ${meta.singular}` : `Start ${meta.singular}`}</Button>
              </Link>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
