import { useState, useEffect, useMemo } from 'react'
import { useParams, Link } from 'react-router-dom'
import { useQuery, useMutation } from '@tanstack/react-query'
import Editor from '@monaco-editor/react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { CheckCircle, XCircle, Loader2, Play, TerminalSquare, ChevronLeft, FlaskConical } from 'lucide-react'
import { codingService, type RunResult } from '@/services/coding.service'
import { useToast } from '@/components/ui/use-toast'
import { ApiRequestError } from '@/lib/apiClient'
import { LANGUAGES, PLAYGROUND_STARTER } from '@/lib/codeTemplates'

function difficultyVariant(d: string): 'success' | 'warning' | 'destructive' {
  const x = d.toUpperCase()
  return x === 'BEGINNER' ? 'success' : x === 'INTERMEDIATE' ? 'warning' : 'destructive'
}

// ---------------------------------------------------------------------------
// Problem browser
// ---------------------------------------------------------------------------
function ProblemList() {
  const { data, isLoading } = useQuery({ queryKey: ['coding', 'list'], queryFn: () => codingService.list() })
  const [course, setCourse] = useState<string>('all')

  const courses = useMemo(() => [...new Set((data ?? []).map((p) => p.courseName))].sort(), [data])
  const shown = (data ?? []).filter((p) => course === 'all' || p.courseName === course)
  const solvedCount = (data ?? []).filter((p) => p.solved).length

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Coding</h1>
          <p className="text-muted-foreground">
            Write code in the editor, press <b>Run</b> to see its output, and <b>Submit</b> to be graded against hidden test cases.
            {data && data.length > 0 && ` Solved ${solvedCount} of ${data.length}.`}
          </p>
        </div>
        <Link to="/coding/playground">
          <Button variant="outline">
            <TerminalSquare className="h-4 w-4 mr-2" />
            Open free playground
          </Button>
        </Link>
      </div>

      {courses.length > 1 && (
        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant={course === 'all' ? 'default' : 'outline'} onClick={() => setCourse('all')}>
            All
          </Button>
          {courses.map((c) => (
            <Button key={c} size="sm" variant={course === c ? 'default' : 'outline'} onClick={() => setCourse(c)}>
              {c}
            </Button>
          ))}
        </div>
      )}

      {isLoading && <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto my-16" />}

      {!isLoading && (data?.length ?? 0) === 0 && (
        <Card>
          <CardContent className="py-10 text-center space-y-2">
            <p className="font-medium">No coding problems have been added yet.</p>
            <p className="text-sm text-muted-foreground">
              Ask the person running the backend to run <code>npm run seed:coding</code>, or use the free playground meanwhile.
            </p>
          </CardContent>
        </Card>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        {shown.map((p) => (
          <Link key={p.id} to={`/coding/${p.id}`}>
            <Card className="h-full hover:border-primary/50 transition-colors">
              <CardHeader>
                <div className="flex items-start justify-between gap-3">
                  <CardTitle className="text-lg">{p.title}</CardTitle>
                  {p.solved && <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />}
                </div>
                <CardDescription>{p.courseName}</CardDescription>
              </CardHeader>
              <CardContent className="flex flex-wrap gap-2">
                <Badge variant={difficultyVariant(p.difficulty)}>{p.difficulty.toLowerCase()}</Badge>
                <Badge variant="outline">{p.estimatedTime} min</Badge>
                {p.tags.slice(0, 3).map((t) => (
                  <Badge key={t} variant="secondary">
                    {t}
                  </Badge>
                ))}
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}

// ---------------------------------------------------------------------------
// Output panel
// ---------------------------------------------------------------------------
function OutputPanel({ run, running }: { run?: RunResult; running: boolean }) {
  return (
    <Card>
      <CardHeader className="py-3">
        <CardTitle className="text-sm flex items-center justify-between">
          <span>Output</span>
          {run && (
            <span className="text-xs font-normal text-muted-foreground">
              {run.timedOut ? 'Time limit exceeded' : `exit ${run.exitCode}`} · {run.executionTimeMs} ms
            </span>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        {running ? (
          <Loader2 className="h-5 w-5 animate-spin text-primary" />
        ) : !run ? (
          <p className="text-sm text-muted-foreground">Press Run to see your program's output here.</p>
        ) : (
          <div className="space-y-2">
            {run.stdout && <pre className="text-sm bg-muted rounded p-3 whitespace-pre-wrap overflow-auto max-h-48">{run.stdout}</pre>}
            {run.stderr && <pre className="text-sm bg-red-50 text-red-700 rounded p-3 whitespace-pre-wrap overflow-auto max-h-48">{run.stderr}</pre>}
            {!run.stdout && !run.stderr && <p className="text-sm text-muted-foreground">(no output)</p>}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

// ---------------------------------------------------------------------------
// Editor workspace: used for graded problems and for the free playground.
// ---------------------------------------------------------------------------
function Workspace({ problemId }: { problemId?: string }) {
  const { toast } = useToast()
  const isPlayground = !problemId
  const [language, setLanguage] = useState('python')
  const [code, setCode] = useState(isPlayground ? PLAYGROUND_STARTER.python : '')
  const [stdin, setStdin] = useState('')

  const { data: problem, isLoading } = useQuery({
    queryKey: ['coding', 'attempt', problemId],
    queryFn: () => codingService.getForAttempt(problemId!),
    enabled: !!problemId,
  })

  // Start from the first sample test case so Run works immediately.
  useEffect(() => {
    if (problem) {
      setCode(problem.starterCode[language] || Object.values(problem.starterCode)[0] || '')
      if (!stdin && problem.visibleTestCases[0]) setStdin(problem.visibleTestCases[0].input)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [problem])

  const starterFor = (lang: string) => (isPlayground ? PLAYGROUND_STARTER[lang] : problem?.starterCode[lang]) ?? ''

  const runMutation = useMutation({
    mutationFn: () => codingService.run(code, language, stdin),
    onError: (error) =>
      toast({ title: 'Could not run code', description: error instanceof ApiRequestError ? error.message : 'Please try again.', variant: 'destructive' }),
  })

  const submitMutation = useMutation({
    mutationFn: () => codingService.submit(problemId!, code, language),
    onSuccess: (result) => {
      const allPassed = result.status === 'accepted'
      toast({
        title: allPassed ? 'All test cases passed!' : 'Some test cases failed',
        description: allPassed ? `+${result.xpEarned} XP earned` : `${result.results.filter((r) => r.passed).length}/${result.results.length} passed`,
        variant: allPassed ? 'default' : 'destructive',
      })
    },
    onError: (error) =>
      toast({ title: 'Submission failed', description: error instanceof ApiRequestError ? error.message : 'Code execution is unavailable.', variant: 'destructive' }),
  })

  if (!isPlayground && isLoading) return <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto my-24" />
  if (!isPlayground && !problem) return <p className="text-center text-muted-foreground py-24">Problem not found.</p>

  const monacoLang = LANGUAGES.find((l) => l.id === language)?.monaco ?? 'plaintext'
  const submitResult = submitMutation.data

  const editorPane = (
    <div className="flex flex-col gap-3 min-w-0">
      <div className="flex items-center justify-between gap-2">
        <Select
          value={language}
          onValueChange={(lang) => {
            setLanguage(lang)
            const s = starterFor(lang)
            if (s) setCode(s)
          }}
        >
          <SelectTrigger className="w-[160px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {LANGUAGES.map((l) => (
              <SelectItem key={l.id} value={l.id}>
                {l.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => setCode(starterFor(language))}>
            Reset
          </Button>
          <Button variant="secondary" size="sm" onClick={() => runMutation.mutate()} isLoading={runMutation.isPending}>
            <Play className="h-4 w-4 mr-2" />
            Run
          </Button>
          {!isPlayground && (
            <Button size="sm" onClick={() => submitMutation.mutate()} isLoading={submitMutation.isPending}>
              <CheckCircle className="h-4 w-4 mr-2" />
              Submit
            </Button>
          )}
        </div>
      </div>

      <div className="border rounded-md overflow-hidden h-[360px]">
        <Editor
          height="100%"
          language={monacoLang}
          value={code}
          onChange={(v) => setCode(v ?? '')}
          theme="vs-dark"
          options={{ fontSize: 14, minimap: { enabled: false }, scrollBeyondLastLine: false, automaticLayout: true, tabSize: 4 }}
          loading={<Loader2 className="h-6 w-6 animate-spin text-primary" />}
        />
      </div>

      <div>
        <label className="text-sm font-medium">Input (stdin)</label>
        <textarea
          value={stdin}
          onChange={(e) => setStdin(e.target.value)}
          placeholder="Type the input your program reads, one value per line or separated by spaces"
          className="mt-1 w-full min-h-[70px] p-2 border rounded-md font-mono text-sm bg-background"
          spellCheck={false}
        />
      </div>

      <OutputPanel run={runMutation.data} running={runMutation.isPending} />

      {submitResult && (
        <Card>
          <CardHeader className="py-3">
            <CardTitle className="text-base">Submission — {submitResult.scorePercent}%</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 pt-0">
            {submitResult.results.map((r, idx) => (
              <div key={r.testCaseId} className="flex items-center gap-2 text-sm">
                {r.passed ? <CheckCircle className="h-4 w-4 text-green-500" /> : <XCircle className="h-4 w-4 text-destructive" />}
                <span>
                  Test case {idx + 1}
                  {r.isHidden ? ' (hidden)' : ''}
                </span>
                {r.stderr && <span className="text-muted-foreground text-xs truncate">{r.stderr}</span>}
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  )

  if (isPlayground) {
    return (
      <div className="space-y-4 max-w-4xl">
        <Link to="/coding" className="text-sm text-primary hover:underline inline-flex items-center">
          <ChevronLeft className="h-4 w-4" />
          All problems
        </Link>
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <FlaskConical className="h-7 w-7" />
            Playground
          </h1>
          <p className="text-muted-foreground">Write any program, give it input, and run it. Nothing here is graded.</p>
        </div>
        {editorPane}
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <Link to="/coding" className="text-sm text-primary hover:underline inline-flex items-center">
        <ChevronLeft className="h-4 w-4" />
        All problems
      </Link>
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="space-y-4 min-w-0">
          <div>
            <h1 className="text-2xl font-bold">{problem!.title}</h1>
            <div className="flex gap-2 mt-2">
              <Badge variant={difficultyVariant(problem!.difficulty)}>{problem!.difficulty.toLowerCase()}</Badge>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Description</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground whitespace-pre-wrap">{problem!.description}</p>
            </CardContent>
          </Card>

          {problem!.visibleTestCases.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Sample test cases</CardTitle>
                <CardDescription>Click “Use as input” then Run. Hidden test cases are used when you Submit.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                {problem!.visibleTestCases.map((tc, i) => (
                  <div key={tc.id} className="p-3 bg-muted rounded text-sm space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">Case {i + 1}</span>
                      <Button size="sm" variant="ghost" onClick={() => setStdin(tc.input)}>
                        Use as input
                      </Button>
                    </div>
                    <pre className="text-xs whitespace-pre-wrap">Input:{'\n'}{tc.input}</pre>
                    <pre className="text-xs whitespace-pre-wrap">Expected:{'\n'}{tc.expectedOutput}</pre>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {problem!.constraints?.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Constraints</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                  {problem!.constraints.map((c, idx) => (
                    <li key={idx}>{c}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}

          {problem!.hints && problem!.hints.length > 0 && (
            <details className="text-sm border rounded-md p-3">
              <summary className="cursor-pointer font-medium">Need a hint?</summary>
              <ul className="list-disc list-inside mt-2 text-muted-foreground">
                {problem!.hints.map((h, i) => (
                  <li key={i}>{h}</li>
                ))}
              </ul>
            </details>
          )}
        </div>

        {editorPane}
      </div>
    </div>
  )
}

export default function CodingPage() {
  const { problemId } = useParams<{ problemId: string }>()
  if (!problemId) return <ProblemList />
  if (problemId === 'playground') return <Workspace />
  return <Workspace problemId={problemId} />
}
