import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Target, TrendingUp, CheckCircle, Loader2 } from 'lucide-react'
import { useQuery } from '@tanstack/react-query'
import { learningGapsService } from '@/services/learningGaps.service'

function severityVariant(severity: string): 'destructive' | 'warning' | 'secondary' | 'success' {
  if (severity === 'critical') return 'destructive'
  if (severity === 'moderate') return 'warning'
  if (severity === 'improved' || severity === 'resolved') return 'success'
  return 'secondary'
}

export default function LearningGapsPage() {
  const { data: gaps, isLoading } = useQuery({
    queryKey: ['learning-gaps', 'me'],
    queryFn: () => learningGapsService.myGaps(),
  })

  const critical = gaps?.filter((g) => g.severity === 'critical').length ?? 0
  const moderate = gaps?.filter((g) => g.severity === 'moderate').length ?? 0
  const improving = gaps?.filter((g) => g.severity === 'improved').length ?? 0

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Learning Gaps</h1>
        <p className="text-muted-foreground">Identify and address areas that need improvement</p>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Target className="h-8 w-8 text-red-500" />
              <div>
                <p className="text-2xl font-bold">{critical}</p>
                <p className="text-sm text-muted-foreground">Critical</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <TrendingUp className="h-8 w-8 text-yellow-500" />
              <div>
                <p className="text-2xl font-bold">{moderate}</p>
                <p className="text-sm text-muted-foreground">Moderate</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <CheckCircle className="h-8 w-8 text-green-500" />
              <div>
                <p className="text-2xl font-bold">{improving}</p>
                <p className="text-sm text-muted-foreground">Improving</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {isLoading && (
        <div className="flex justify-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      )}

      {!isLoading && (!gaps || gaps.length === 0) && (
        <p className="text-center text-muted-foreground py-16">No open learning gaps detected. Nice work!</p>
      )}

      <div className="space-y-4">
        {gaps?.map((g) => (
          <Card key={g.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle>{g.concept}</CardTitle>
                  <CardDescription>{g.courseName}{g.topicName ? ` • ${g.topicName}` : ''}</CardDescription>
                </div>
                <div className="text-right">
                  <Badge variant={severityVariant(g.severity)}>{g.severity}</Badge>
                  <p className="text-sm mt-1">Gap: {Math.round(g.gapScore)}%</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">{g.description}</p>
              <p className="text-xs text-muted-foreground mb-3">
                Detected via {g.detectionSource}{g.confidence ? ` · ${Math.round(g.confidence * 100)}% confidence` : ''}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
