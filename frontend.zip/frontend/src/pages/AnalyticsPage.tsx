import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Loader2 } from 'lucide-react'
import { analyticsService } from '@/services/analytics.service'

export default function AnalyticsPage() {
  const { data: overview, isLoading } = useQuery({
    queryKey: ['analytics', 'me'],
    queryFn: () => analyticsService.myOverview(),
  })
  const { data: activity } = useQuery({
    queryKey: ['analytics', 'me', 'activity'],
    queryFn: () => analyticsService.myActivity(),
  })

  if (isLoading) {
    return (
      <div className="flex justify-center py-24">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  const stats = [
    { label: 'Overall Accuracy', value: `${overview?.averageScore ?? 0}%` },
    { label: 'Items Completed', value: `${overview?.contentItemsCompleted ?? 0}` },
    { label: 'Current Streak', value: `${overview?.currentStreak ?? 0} days` },
    { label: 'Longest Streak', value: `${overview?.longestStreak ?? 0} days` },
  ]

  const maxXp = Math.max(1, ...(activity ?? []).map((d) => d.xpEarned))

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Analytics</h1>
        <p className="text-muted-foreground">Track your learning progress and performance</p>
      </div>
      <div className="grid md:grid-cols-4 gap-4">
        {stats.map((s) => (
          <Card key={s.label}>
            <CardContent className="pt-6">
              <p className="text-sm text-muted-foreground">{s.label}</p>
              <p className="text-2xl font-bold mt-2">{s.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Daily Activity (XP earned)</CardTitle>
        </CardHeader>
        <CardContent>
          {!activity || activity.length === 0 ? (
            <p className="text-muted-foreground text-center py-16">No activity recorded yet.</p>
          ) : (
            <div className="flex items-end gap-1 h-48">
              {activity.map((day) => (
                <div key={day.date} className="flex-1 flex flex-col items-center justify-end gap-1" title={`${day.date}: ${day.xpEarned} XP`}>
                  <div
                    className="w-full bg-primary rounded-t"
                    style={{ height: `${Math.max(4, (day.xpEarned / maxXp) * 100)}%` }}
                  />
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {overview && (overview.strengths.length > 0 || overview.weaknesses.length > 0) && (
        <div className="grid md:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Strengths</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {overview.strengths.length === 0 && <p className="text-sm text-muted-foreground">Not enough graded data yet.</p>}
              {overview.strengths.map((s) => (
                <div key={s.courseId} className="flex justify-between text-sm">
                  <span>{s.courseName}</span>
                  <Badge variant="success">{s.averageScore}%</Badge>
                </div>
              ))}
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Needs Improvement</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {overview.weaknesses.length === 0 && <p className="text-sm text-muted-foreground">No weak areas detected.</p>}
              {overview.weaknesses.map((w) => (
                <div key={w.courseId} className="flex justify-between text-sm">
                  <span>{w.courseName}</span>
                  <Badge variant="warning">{w.averageScore}%</Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
