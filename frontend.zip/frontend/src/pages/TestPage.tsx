import { useParams } from 'react-router-dom'
import { GradedAttemptRunner } from '@/components/GradedAttemptRunner'
import { testsService } from '@/services/tests.service'

export default function TestPage() {
  const { testId } = useParams<{ testId: string }>()
  if (!testId) return null
  return <GradedAttemptRunner id={testId} service={testsService} backLink="/dashboard" timed queryKeyPrefix="test" />
}
