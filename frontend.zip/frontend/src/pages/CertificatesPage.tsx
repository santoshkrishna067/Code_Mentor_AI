import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { Award, Loader2 } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { certificatesService } from '@/services/certificates.service'

export default function CertificatesPage() {
  const { data, isLoading } = useQuery({ queryKey: ['certificates', 'mine'], queryFn: () => certificatesService.mine() })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Certificates</h1>
        <p className="text-muted-foreground">Earned automatically when you finish 100% of a course.</p>
      </div>

      {isLoading && <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto my-16" />}

      {!isLoading && (data?.length ?? 0) === 0 && (
        <div className="text-center py-16 space-y-3">
          <Award className="h-12 w-12 mx-auto text-muted-foreground" />
          <p className="text-muted-foreground">No certificates yet. Complete every lesson in a course, then claim it from the course page.</p>
          <Link to="/courses">
            <Button>Go to courses</Button>
          </Link>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        {data?.map((c) => (
          <Card key={c.id}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5 text-primary" />
                {c.courseName}
              </CardTitle>
              <CardDescription>Issued {new Date(c.issuedAt).toLocaleDateString()}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-1 text-sm">
              <p className="text-muted-foreground">Verification code</p>
              <p className="font-mono text-base">{c.verificationCode}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
