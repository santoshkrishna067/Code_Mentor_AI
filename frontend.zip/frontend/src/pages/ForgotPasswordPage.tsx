import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Code2 } from 'lucide-react'
import { useToast } from '@/components/ui/use-toast'

export default function ForgotPasswordPage() {
  const { toast } = useToast()
  const [email, setEmail] = useState('')

  // NOTE: the backend does not yet implement an email-based password reset
  // flow (only an in-session "change password" endpoint that requires the
  // current password — see backend src/modules/auth/auth.routes.ts). Rather
  // than fake a success message implying an email was sent, this is honest
  // about the gap. Wiring this up for real needs a reset-token endpoint +
  // an email provider on the backend, which hasn't been built yet.
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    toast({
      title: 'Not available yet',
      description: "Password reset via email isn't wired up yet. Please contact an admin to reset your password for now.",
    })
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <div className="flex items-center gap-2 mb-2">
            <Code2 className="h-6 w-6 text-primary" />
            <span className="font-bold">Code Mentor AI</span>
          </div>
          <CardTitle className="text-2xl">Forgot password?</CardTitle>
          <CardDescription>Enter your email to reset your password</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            <Input placeholder="Email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
            <Button type="submit" className="w-full">
              Send reset link
            </Button>
          </CardContent>
        </form>
        <CardFooter>
          <Link to="/login" className="text-sm text-primary hover:underline w-full text-center">
            Back to login
          </Link>
        </CardFooter>
      </Card>
    </div>
  )
}
