import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'

export default function AboutPage() {
  return (
    <div className="container py-12">
      <h1 className="text-4xl font-bold mb-8">About Code Mentor AI</h1>
      <p className="text-lg text-muted-foreground mb-8">
        Code Mentor AI is a premium technical learning platform designed to help you master programming 
        through AI-powered personalized learning paths, hands-on coding practice, and intelligent assessments.
      </p>
      <div className="grid md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Our Mission</CardTitle>
            <CardDescription>Making quality programming education accessible to everyone</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              We believe everyone should have access to high-quality programming education. Our AI-powered 
              platform personalizes learning to help you succeed.
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Our Vision</CardTitle>
            <CardDescription>Empowering the next generation of developers</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              We envision a world where anyone can learn to code and build amazing things, regardless of 
              their background or location.
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Our Approach</CardTitle>
            <CardDescription>AI-powered, practice-first learning</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">
              Our unique approach combines AI-driven personalization with hands-on practice to ensure 
              you truly master every concept.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
