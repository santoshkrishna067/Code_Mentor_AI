import { useParams } from 'react-router-dom'
import { GradedAttemptRunner } from '@/components/GradedAttemptRunner'
import { assessmentsService } from '@/services/assessments.service'

export default function AssessmentPage() {
  const { assessmentId } = useParams<{ assessmentId: string }>()
  if (!assessmentId) return null
  return <GradedAttemptRunner id={assessmentId} service={assessmentsService} backLink="/dashboard" queryKeyPrefix="assessment" />
}
