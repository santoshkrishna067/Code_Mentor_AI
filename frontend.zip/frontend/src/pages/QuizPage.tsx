import { useParams } from 'react-router-dom'
import { GradedAttemptRunner } from '@/components/GradedAttemptRunner'
import { quizzesService } from '@/services/quizzes.service'

export default function QuizPage() {
  const { quizId } = useParams<{ quizId: string }>()
  if (!quizId) return null
  return <GradedAttemptRunner id={quizId} service={quizzesService} backLink="/dashboard" timed queryKeyPrefix="quiz" />
}
