import { useSearchParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Loader2 } from 'lucide-react'
import { examsService } from '@/services/exams.service'
import { adminService } from '@/services/admin.service'

function ExamReport({ examId }: { examId: string }) {
  const { data, isLoading } = useQuery({ queryKey: ['exams', 'report', examId], queryFn: () => examsService.report(examId) })

  if (isLoading) return <Loader2 className="h-6 w-6 animate-spin text-primary mx-auto my-8" />
  if (!data) return null

  return (
    <Card>
      <CardHeader>
        <CardTitle>{data.title} — Exam Report</CardTitle>
        <CardDescription>
          {data.totalAttempts} attempt(s) · {data.averageScore}% average · {data.passRate}% pass rate
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex gap-3 mb-4">
          <Badge variant="secondary">{data.autoSubmittedCount} auto-submitted</Badge>
          <Badge variant="destructive">{data.flaggedCount} flagged</Badge>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b text-left text-muted-foreground">
              <th className="p-2 font-medium">Student</th>
              <th className="p-2 font-medium">Status</th>
              <th className="p-2 font-medium">Score</th>
              <th className="p-2 font-medium">Warnings</th>
            </tr>
          </thead>
          <tbody>
            {data.attempts.map((a) => (
              <tr key={a.attemptId} className="border-b last:border-0">
                <td className="p-2">{a.studentName}</td>
                <td className="p-2">
                  <Badge variant={a.status === 'flagged' ? 'destructive' : a.status === 'submitted' ? 'success' : 'secondary'}>{a.status}</Badge>
                </td>
                <td className="p-2">{a.score ?? '—'}%</td>
                <td className="p-2">
                  {a.warningCount} {a.highSeverityWarningCount > 0 && <span className="text-destructive">({a.highSeverityWarningCount} high)</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </CardContent>
    </Card>
  )
}

export default function AdminReportsPage() {
  const [searchParams] = useSearchParams()
  const examId = searchParams.get('examId')

  const { data: auditLogs, isLoading: auditLoading } = useQuery({
    queryKey: ['admin', 'audit-logs'],
    queryFn: () => adminService.auditLogs({ limit: 50 }),
    enabled: !examId,
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Reports</h1>
        <p className="text-muted-foreground">{examId ? 'Exam performance report' : 'Recent platform activity'}</p>
      </div>

      {examId ? (
        <ExamReport examId={examId} />
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Full audit trail — go to Exams to view a specific exam's report</CardDescription>
          </CardHeader>
          <CardContent>
            {auditLoading && <Loader2 className="h-6 w-6 animate-spin text-primary mx-auto my-8" />}
            <div className="space-y-2">
              {auditLogs?.data.map((log: any) => (
                <div key={log.id} className="flex items-center justify-between text-sm border-b pb-2 last:border-0">
                  <div>
                    <span className="font-medium">{log.actor?.name ?? 'system'}</span> — {log.action.replace(/_/g, ' ').toLowerCase()} ({log.resource})
                  </div>
                  <span className="text-muted-foreground">{new Date(log.timestamp).toLocaleString()}</span>
                </div>
              ))}
            </div>
            {!auditLoading && auditLogs?.data.length === 0 && <p className="text-center text-muted-foreground py-8">No activity recorded yet.</p>}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
