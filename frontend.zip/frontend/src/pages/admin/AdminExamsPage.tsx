import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Loader2 } from 'lucide-react'
import { coursesService } from '@/services/courses.service'
import { examsService } from '@/services/exams.service'
import { useToast } from '@/components/ui/use-toast'

export default function AdminExamsPage() {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [courseId, setCourseId] = useState<string>('')

  const { data: courses } = useQuery({ queryKey: ['courses', 'list-for-select'], queryFn: () => coursesService.list({ limit: 100 }) })

  const { data: exams, isLoading } = useQuery({
    queryKey: ['admin', 'exams', courseId],
    queryFn: () => examsService.listForCourseAdmin(courseId),
    enabled: !!courseId,
  })

  const publishMutation = useMutation({
    mutationFn: (examId: string) => examsService.publish(examId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'exams', courseId] })
      toast({ title: 'Exam published' })
    },
    onError: (error: any) => toast({ title: 'Could not publish', description: error?.message, variant: 'destructive' }),
  })

  const reconcileMutation = useMutation({
    mutationFn: () => examsService.reconcileExpired(),
    onSuccess: (res) => toast({ title: 'Reconciliation complete', description: `${res.reconciledCount} attempt(s) auto-submitted.` }),
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Exams</h1>
          <p className="text-muted-foreground">Manage exams per course</p>
        </div>
        <Button variant="outline" onClick={() => reconcileMutation.mutate()} isLoading={reconcileMutation.isPending}>
          Reconcile expired attempts
        </Button>
      </div>

      <Select value={courseId} onValueChange={setCourseId}>
        <SelectTrigger className="w-[280px]">
          <SelectValue placeholder="Select a course" />
        </SelectTrigger>
        <SelectContent>
          {courses?.data.map((c) => (
            <SelectItem key={c.id} value={c.id}>
              {c.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {isLoading && (
        <div className="flex justify-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      )}

      {courseId && !isLoading && (!exams || exams.length === 0) && (
        <p className="text-center text-muted-foreground py-12">
          No exams for this course yet. Exam creation (question set + schedule) isn't exposed as a dedicated builder UI in
          this pass — use the backend API (<code>POST /api/exams/courses/:courseId</code>) directly for now.
        </p>
      )}

      <div className="space-y-4">
        {exams?.map((exam) => (
          <Card key={exam.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle>{exam.title}</CardTitle>
                  <CardDescription>{exam.description}</CardDescription>
                </div>
                <Badge variant={exam.status === 'active' ? 'warning' : exam.status === 'completed' ? 'success' : 'secondary'}>{exam.status}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                <span>{exam.duration} min</span>
                <span>{exam.totalMarks} marks</span>
                <span>{exam.questionCount ?? 0} questions</span>
                <span>Max {exam.maxAttempts} attempt(s)</span>
              </div>
              <div className="flex gap-2">
                {exam.status === 'draft' && (
                  <Button size="sm" onClick={() => publishMutation.mutate(exam.id)} isLoading={publishMutation.isPending}>
                    Publish
                  </Button>
                )}
                <Link to={`/admin/reports?examId=${exam.id}`}>
                  <Button size="sm" variant="outline">
                    View Report
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
