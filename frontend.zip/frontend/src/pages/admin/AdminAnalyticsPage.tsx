import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Loader2, Users, BookOpen, GraduationCap, FileCheck, ClipboardList } from 'lucide-react'
import { analyticsService } from '@/services/analytics.service'

export default function AdminAnalyticsPage() {
  const { data, isLoading } = useQuery({
    queryKey: ['analytics', 'platform'],
    queryFn: () => analyticsService.platformOverview(),
  })

  if (isLoading) {
    return (
      <div className="flex justify-center py-24">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  const stats = [
    { label: 'Total Students', value: data?.studentCount ?? 0, icon: Users },
    { label: 'Courses (all statuses)', value: data?.courseCount ?? 0, icon: BookOpen },
    { label: 'Published Courses', value: data?.publishedCourseCount ?? 0, icon: GraduationCap },
    { label: 'Total Enrollments', value: data?.totalEnrollments ?? 0, icon: ClipboardList },
    { label: 'Exam Attempts', value: data?.examAttemptCount ?? 0, icon: FileCheck },
    { label: 'Pending Evaluations', value: data?.pendingEvaluations ?? 0, icon: ClipboardList },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Platform Analytics</h1>
        <p className="text-muted-foreground">Real aggregation from the database — nothing here is estimated</p>
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        {stats.map((s) => (
          <Card key={s.label}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <s.icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{s.value.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">{s.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Per-course and per-student analytics</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            Visit a course from the Courses tab, or a student from the Students tab, for detailed breakdowns
            (average score, completion rate, strengths/weaknesses) powered by <code>/api/analytics/courses/:id</code> and{' '}
            <code>/api/analytics/students/:id</code>.
          </p>
        </CardContent>
      </Card>
    </div>
  )
}
