import { useMemo, useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Loader2, Plus, Trash2, Eye, EyeOff, Info, ListPlus } from 'lucide-react'
import { adminService } from '@/services/admin.service'
import { QuestionForm } from '@/components/QuestionForm'
import { LessonPicker } from '@/components/LessonPicker'
import { useToast } from '@/components/ui/use-toast'
import { ApiRequestError } from '@/lib/apiClient'
import { cn } from '@/utils/cn'

const TYPE_LABEL: Record<string, string> = { MCQ: 'Multiple choice', SHORT_ANSWER: 'Short answer', OUTPUT_PREDICTION: 'Predict the output' }

type Filter = 'all' | 'visible' | 'hidden'

// Puts an existing question into a lesson's Practice tab (so students can see it).
function AttachToLesson({ question, onDone }: { question: any; onDone: () => void }) {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [topicId, setTopicId] = useState('')
  const [subtopicId, setSubtopicId] = useState('')

  const attach = useMutation({
    mutationFn: () => adminService.attachQuestion(question.id, subtopicId),
    onSuccess: () => {
      toast({ title: 'Question added to the lesson', description: 'Students will see it in that lesson → Practice tab.' })
      queryClient.invalidateQueries({ queryKey: ['admin'] })
      queryClient.invalidateQueries({ queryKey: ['syllabus', 'subtopic-content'] })
      onDone()
    },
    onError: (e) => toast({ title: 'Could not add', description: e instanceof ApiRequestError ? e.message : 'Please try again.', variant: 'destructive' }),
  })

  return (
    <div className="rounded-lg border bg-muted/30 p-3 space-y-3">
      <p className="text-sm">
        Choose the lesson (from <b>{question.courseName}</b>) where students should see this question:
      </p>
      <LessonPicker courseId={question.courseId} topicId={topicId} subtopicId={subtopicId} onTopic={setTopicId} onSubtopic={setSubtopicId} />
      <div className="flex gap-2">
        <Button size="sm" onClick={() => attach.mutate()} isLoading={attach.isPending} disabled={!subtopicId}>
          Add to this lesson
        </Button>
        <Button size="sm" variant="ghost" onClick={onDone}>
          Cancel
        </Button>
      </div>
    </div>
  )
}

export default function AdminQuestionsPage() {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [showForm, setShowForm] = useState(false)
  const [filter, setFilter] = useState<Filter>('all')
  const [attachingId, setAttachingId] = useState<string | null>(null)

  const { data, isLoading } = useQuery({ queryKey: ['admin', 'questions'], queryFn: () => adminService.listQuestions({ limit: 100 }) })

  const deleteMutation = useMutation({
    mutationFn: async (q: any) => {
      await adminService.deleteQuestion(q.id)
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'questions'] })
      toast({ title: 'Question deleted' })
    },
    onError: (error) => {
      const message = error instanceof ApiRequestError ? error.message : 'This question is in use and cannot be deleted.'
      toast({ title: 'Cannot delete', description: message + ' Use Courses → Manage content → lesson → Practice to remove it from a lesson.', variant: 'destructive' })
    },
  })

  const all: any[] = data?.data ?? []
  const hiddenCount = useMemo(() => all.filter((q) => !(q.usedIn?.length > 0)).length, [all])
  const shown = all.filter((q) => (filter === 'all' ? true : filter === 'visible' ? q.usedIn?.length > 0 : !(q.usedIn?.length > 0)))

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-bold">Question Bank</h1>
          <p className="text-muted-foreground">Create questions and choose which lesson students see them in.</p>
        </div>
        <Button onClick={() => setShowForm((v) => !v)}>
          <Plus className="h-4 w-4 mr-2" />
          {showForm ? 'Close' : 'New question'}
        </Button>
      </div>

      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="pt-6 flex gap-3 text-sm">
          <Info className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p>
              <b>Where do students see a question?</b> Only in a lesson&apos;s <b>Practice</b> tab (Courses → course → lesson → Practice → “Start practice questions”), or inside a quiz, test, assessment or exam it has been added to.
            </p>
            <p className="text-muted-foreground">
              A question saved with no lesson stays in this bank and is hidden from students. The <Badge variant="success">Visible to students</Badge> / <Badge variant="warning">Hidden</Badge> tag on each question below tells you which is which — use <b>Add to a lesson</b> to publish a hidden one.
            </p>
          </div>
        </CardContent>
      </Card>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>New question</CardTitle>
            <CardDescription>Three quick steps: pick the kind, write it, choose the lesson.</CardDescription>
          </CardHeader>
          <CardContent>
            <QuestionForm onCreated={() => setShowForm(false)} />
          </CardContent>
        </Card>
      )}

      {hiddenCount > 0 && filter !== 'hidden' && (
        <div className="flex flex-wrap items-center gap-3 rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-sm">
          <EyeOff className="h-4 w-4 text-amber-600 dark:text-amber-300" />
          <span>
            <b>{hiddenCount}</b> question(s) are not in any lesson, so students cannot see them.
          </span>
          <Button size="sm" variant="outline" onClick={() => setFilter('hidden')}>
            Show only hidden
          </Button>
        </div>
      )}

      <div className="flex flex-wrap gap-2">
        {([
          ['all', `All (${all.length})`],
          ['visible', `Visible to students (${all.length - hiddenCount})`],
          ['hidden', `Hidden (${hiddenCount})`],
        ] as [Filter, string][]).map(([id, label]) => (
          <button
            key={id}
            onClick={() => setFilter(id)}
            className={cn('rounded-full border px-3.5 py-1.5 text-sm transition-colors', filter === id ? 'bg-primary text-primary-foreground border-primary' : 'hover:bg-muted')}
          >
            {label}
          </button>
        ))}
      </div>

      {isLoading && (
        <div className="flex justify-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      )}

      <div className="space-y-3">
        {shown.map((q: any) => {
          const visible = q.usedIn?.length > 0
          return (
            <Card key={q.id}>
              <CardContent className="pt-6 space-y-3">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0 space-y-2">
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline">{TYPE_LABEL[q.type] ?? q.type}</Badge>
                      <Badge variant="secondary">{q.difficulty.toLowerCase()}</Badge>
                      <Badge variant="outline">{q.courseName}</Badge>
                      {visible ? (
                        <Badge variant="success">
                          <Eye className="h-3 w-3 mr-1" />
                          Visible to students
                        </Badge>
                      ) : (
                        <Badge variant="warning">
                          <EyeOff className="h-3 w-3 mr-1" />
                          Hidden — not in any lesson
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm whitespace-pre-wrap">{q.content}</p>
                    {visible && <p className="text-xs text-muted-foreground">Shown in: {q.usedIn.join(' · ')}</p>}
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <Button variant={visible ? 'ghost' : 'outline'} size="sm" onClick={() => setAttachingId(attachingId === q.id ? null : q.id)}>
                      <ListPlus className="h-4 w-4 mr-1.5" />
                      Add to a lesson
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => deleteMutation.mutate(q)} title="Delete question">
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
                {attachingId === q.id && <AttachToLesson question={q} onDone={() => setAttachingId(null)} />}
              </CardContent>
            </Card>
          )
        })}
        {!isLoading && shown.length === 0 && <p className="text-center text-muted-foreground py-12">{all.length === 0 ? 'No questions yet — press “New question”.' : 'No questions match this filter.'}</p>}
      </div>
    </div>
  )
}
