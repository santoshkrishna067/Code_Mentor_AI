import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Loader2, ShieldCheck } from 'lucide-react'
import { adminService } from '@/services/admin.service'

const SECURITY_ACTIONS = new Set([
  'REGISTER',
  'CHANGE_PASSWORD',
  'MFA_ENABLED',
  'MFA_DISABLED',
  'STUDENT_DEACTIVATED',
  'STUDENT_REACTIVATED',
  'ADMIN_CREATED',
])

function actionVariant(action: string): 'destructive' | 'warning' | 'success' | 'secondary' {
  if (action === 'STUDENT_DEACTIVATED' || action === 'MFA_DISABLED') return 'warning'
  if (action === 'MFA_ENABLED' || action === 'STUDENT_REACTIVATED') return 'success'
  if (action === 'ADMIN_CREATED') return 'destructive'
  return 'secondary'
}

export default function AdminSecurityPage() {
  const { data, isLoading } = useQuery({
    queryKey: ['admin', 'audit-logs', 'security', 'User'],
    queryFn: () => adminService.auditLogs({ resource: 'User', limit: 100 }),
  })

  const securityEvents = data?.data.filter((log: any) => SECURITY_ACTIONS.has(log.action)) ?? []

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Security</h1>
        <p className="text-muted-foreground">Account and authentication activity across the platform</p>
      </div>

      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="pt-6 flex items-start gap-3">
          <ShieldCheck className="h-5 w-5 text-blue-600 mt-0.5" />
          <div className="text-sm text-blue-800">
            <p className="font-medium">Proctoring incidents are reviewed per-exam</p>
            <p>
              There isn't a single cross-exam proctoring feed yet — open a specific exam's report from{' '}
              <span className="font-medium">Admin → Exams</span> to review its flagged attempts and warnings.
            </p>
          </div>
        </CardContent>
      </Card>

      {isLoading && (
        <div className="flex justify-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Account Security Events</CardTitle>
          <CardDescription>Registrations, password changes, MFA changes, account activation/deactivation</CardDescription>
        </CardHeader>
        <CardContent>
          {!isLoading && securityEvents.length === 0 && <p className="text-center text-muted-foreground py-8">No security events recorded yet.</p>}
          <div className="space-y-2">
            {securityEvents.map((log: any) => (
              <div key={log.id} className="flex items-center justify-between text-sm border-b pb-2 last:border-0">
                <div className="flex items-center gap-2">
                  <Badge variant={actionVariant(log.action)}>{log.action.replace(/_/g, ' ')}</Badge>
                  <span>{log.actor?.name ?? 'unknown'} ({log.actor?.email ?? '—'})</span>
                </div>
                <div className="flex items-center gap-3 text-muted-foreground">
                  {log.ipAddress && <span>{log.ipAddress}</span>}
                  <span>{new Date(log.timestamp).toLocaleString()}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
