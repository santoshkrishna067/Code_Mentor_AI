import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Loader2, Search } from 'lucide-react'
import { usersService } from '@/services/users.service'
import { useToast } from '@/components/ui/use-toast'

export default function AdminStudentsPage() {
  const [search, setSearch] = useState('')
  const { toast } = useToast()
  const queryClient = useQueryClient()

  const { data, isLoading } = useQuery({
    queryKey: ['admin', 'students', search],
    queryFn: () => usersService.listStudents({ search: search || undefined, limit: 50 }),
  })

  const toggleActive = useMutation({
    mutationFn: (vars: { studentId: string; isActive: boolean }) => usersService.setStudentActive(vars.studentId, vars.isActive),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'students'] })
      toast({ title: 'Student status updated' })
    },
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Students</h1>
        <p className="text-muted-foreground">Manage student accounts</p>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search by name or email..." className="pl-9" value={search} onChange={(e) => setSearch(e.target.value)} />
      </div>

      {isLoading && (
        <div className="flex justify-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      )}

      <Card>
        <CardContent className="p-0">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b text-left text-muted-foreground">
                <th className="p-4 font-medium">Name</th>
                <th className="p-4 font-medium">Email</th>
                <th className="p-4 font-medium">XP</th>
                <th className="p-4 font-medium">Streak</th>
                <th className="p-4 font-medium">Status</th>
                <th className="p-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {data?.data.map((s: any) => (
                <tr key={s.id} className="border-b last:border-0">
                  <td className="p-4 font-medium">{s.name}</td>
                  <td className="p-4 text-muted-foreground">{s.email}</td>
                  <td className="p-4">{s.xp?.toLocaleString()}</td>
                  <td className="p-4">{s.streak}</td>
                  <td className="p-4">
                    <Badge variant={s.isActive ? 'success' : 'destructive'}>{s.isActive ? 'Active' : 'Inactive'}</Badge>
                  </td>
                  <td className="p-4 text-right">
                    <Button
                      variant="outline"
                      size="sm"
                      isLoading={toggleActive.isPending}
                      onClick={() => toggleActive.mutate({ studentId: s.id, isActive: !s.isActive })}
                    >
                      {s.isActive ? 'Deactivate' : 'Activate'}
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!isLoading && data?.data.length === 0 && <p className="text-center text-muted-foreground py-12">No students found.</p>}
        </CardContent>
      </Card>
    </div>
  )
}
