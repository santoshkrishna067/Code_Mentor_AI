import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Loader2, Mail, Trash2, CheckCircle2, Eye } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { contactService, type ContactMessage } from '@/services/contact.service'
import { useToast } from '@/components/ui/use-toast'

const FILTERS: { label: string; value?: ContactMessage['status'] }[] = [
  { label: 'All' },
  { label: 'New', value: 'NEW' },
  { label: 'Read', value: 'READ' },
  { label: 'Resolved', value: 'RESOLVED' },
]

const variant = (s: ContactMessage['status']) => (s === 'NEW' ? 'destructive' : s === 'READ' ? 'warning' : 'success')

export default function AdminMessagesPage() {
  const [status, setStatus] = useState<ContactMessage['status'] | undefined>()
  const { toast } = useToast()
  const qc = useQueryClient()

  const { data, isLoading } = useQuery({
    queryKey: ['admin', 'messages', status],
    queryFn: () => contactService.list({ status, limit: 50 }),
  })

  const update = useMutation({
    mutationFn: ({ id, s }: { id: string; s: ContactMessage['status'] }) => contactService.setStatus(id, s),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin', 'messages'] }),
  })
  const remove = useMutation({
    mutationFn: (id: string) => contactService.remove(id),
    onSuccess: () => {
      toast({ title: 'Message deleted' })
      qc.invalidateQueries({ queryKey: ['admin', 'messages'] })
    },
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Messages</h1>
        <p className="text-muted-foreground">Messages sent from the public Contact page.</p>
      </div>

      <div className="flex gap-2">
        {FILTERS.map((f) => (
          <Button key={f.label} size="sm" variant={status === f.value ? 'default' : 'outline'} onClick={() => setStatus(f.value)}>
            {f.label}
          </Button>
        ))}
      </div>

      {isLoading && <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto my-12" />}
      {!isLoading && data?.data.length === 0 && <p className="text-center text-muted-foreground py-16">No messages here.</p>}

      <div className="space-y-4">
        {data?.data.map((m) => (
          <Card key={m.id}>
            <CardContent className="pt-6 space-y-3">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="font-semibold">{m.subject}</p>
                  <p className="text-sm text-muted-foreground">
                    {m.name} · <a className="text-primary hover:underline" href={`mailto:${m.email}?subject=Re: ${encodeURIComponent(m.subject)}`}>{m.email}</a> ·{' '}
                    {new Date(m.createdAt).toLocaleString()}
                  </p>
                </div>
                <Badge variant={variant(m.status)}>{m.status.toLowerCase()}</Badge>
              </div>
              <p className="text-sm whitespace-pre-wrap">{m.message}</p>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant="outline" asChild>
                  <a href={`mailto:${m.email}?subject=Re: ${encodeURIComponent(m.subject)}`}>
                    <Mail className="h-4 w-4 mr-2" />
                    Reply by email
                  </a>
                </Button>
                {m.status === 'NEW' && (
                  <Button size="sm" variant="outline" onClick={() => update.mutate({ id: m.id, s: 'READ' })}>
                    <Eye className="h-4 w-4 mr-2" />
                    Mark read
                  </Button>
                )}
                {m.status !== 'RESOLVED' && (
                  <Button size="sm" variant="outline" onClick={() => update.mutate({ id: m.id, s: 'RESOLVED' })}>
                    <CheckCircle2 className="h-4 w-4 mr-2" />
                    Resolve
                  </Button>
                )}
                <Button size="sm" variant="ghost" onClick={() => remove.mutate(m.id)}>
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
