import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Loader2, Users, BookOpen, ClipboardCheck, AlertTriangle, ShieldAlert } from 'lucide-react'
import { adminService } from '@/services/admin.service'

export default function AdminDashboard() {
  const { data, isLoading } = useQuery({
    queryKey: ['admin', 'dashboard'],
    queryFn: () => adminService.dashboard(),
    refetchInterval: 60_000,
  })

  if (isLoading) {
    return (
      <div className="flex justify-center py-24">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  const stats = [
    { label: 'Students', value: data?.studentCount ?? 0, icon: Users, color: 'text-blue-500 bg-blue-500/10' },
    { label: 'Published Courses', value: data?.publishedCount ?? 0, icon: BookOpen, color: 'text-green-500 bg-green-500/10' },
    { label: 'Pending Evaluations', value: data?.pendingEvaluations ?? 0, icon: ClipboardCheck, color: 'text-yellow-500 bg-yellow-500/10' },
    { label: 'Critical Learning Gaps', value: data?.criticalLearningGaps ?? 0, icon: AlertTriangle, color: 'text-red-500 bg-red-500/10' },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <p className="text-muted-foreground">Platform overview and recent activity</p>
      </div>

      <div className="grid md:grid-cols-4 gap-4">
        {stats.map((s) => (
          <Card key={s.label}>
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className={`h-10 w-10 rounded-full flex items-center justify-center ${s.color}`}>
                  <s.icon className="h-5 w-5" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{s.value}</p>
                  <p className="text-sm text-muted-foreground">{s.label}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShieldAlert className="h-5 w-5" />
            Recent Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          {!data?.recentActivity.length && <p className="text-sm text-muted-foreground text-center py-6">No recent activity.</p>}
          <div className="space-y-3">
            {data?.recentActivity.map((a) => (
              <div key={a.id} className="flex items-center justify-between text-sm border-b pb-2 last:border-0">
                <div>
                  <span className="font-medium">{a.actor}</span> — {a.action.replace(/_/g, ' ').toLowerCase()} ({a.resource})
                </div>
                <span className="text-muted-foreground">{new Date(a.timestamp).toLocaleString()}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
