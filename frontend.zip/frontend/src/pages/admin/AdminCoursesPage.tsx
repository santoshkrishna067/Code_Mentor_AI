import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Link } from 'react-router-dom'
import { Loader2, Plus, Layers } from 'lucide-react'
import { coursesService } from '@/services/courses.service'
import { useToast } from '@/components/ui/use-toast'
import { ApiRequestError } from '@/lib/apiClient'

export default function AdminCoursesPage() {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({ name: '', slug: '', description: '', difficulty: 'BEGINNER', estimatedDuration: 10 })

  const { data, isLoading } = useQuery({
    queryKey: ['admin', 'courses', 'draft'],
    queryFn: () => coursesService.list({ limit: 100, status: 'DRAFT' }),
  })
  // Admin needs every status; the backend honors an explicit status filter
  // per-request for admins, so fan out one call per status and merge.
  const { data: published } = useQuery({ queryKey: ['admin', 'courses', 'published'], queryFn: () => coursesService.list({ limit: 100, status: 'PUBLISHED' }) })
  const { data: archived } = useQuery({ queryKey: ['admin', 'courses', 'archived'], queryFn: () => coursesService.list({ limit: 100, status: 'ARCHIVED' }) })

  const allCourses = [...(data?.data ?? []), ...(published?.data ?? []), ...(archived?.data ?? [])]

  const createMutation = useMutation({
    mutationFn: () => coursesService.create({ ...form, difficulty: form.difficulty as any, status: 'DRAFT' as any }),
    onSuccess: () => {
      toast({ title: 'Course created' })
      setShowForm(false)
      setForm({ name: '', slug: '', description: '', difficulty: 'BEGINNER', estimatedDuration: 10 })
      queryClient.invalidateQueries({ queryKey: ['admin', 'courses'] })
    },
    onError: (error) => {
      const message = error instanceof ApiRequestError ? error.message : 'Could not create course.'
      toast({ title: 'Error', description: message, variant: 'destructive' })
    },
  })

  const statusMutation = useMutation({
    mutationFn: (vars: { id: string; status: 'PUBLISHED' | 'ARCHIVED' }) => coursesService.update(vars.id, { status: vars.status as any }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin', 'courses'] })
      toast({ title: 'Course status updated' })
    },
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Courses</h1>
          <p className="text-muted-foreground">Manage the course catalog</p>
        </div>
        <Button onClick={() => setShowForm((v) => !v)}>
          <Plus className="h-4 w-4 mr-2" />
          New Course
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>New Course</CardTitle>
            <CardDescription>Created as a draft — build out its syllabus before publishing.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Input placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <Input placeholder="slug-in-kebab-case" value={form.slug} onChange={(e) => setForm({ ...form, slug: e.target.value })} />
            <Input placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            <div className="flex gap-3">
              <Select value={form.difficulty} onValueChange={(v) => setForm({ ...form, difficulty: v })}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {['BEGINNER', 'INTERMEDIATE', 'ADVANCED', 'EXPERT'].map((d) => (
                    <SelectItem key={d} value={d}>
                      {d}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                type="number"
                placeholder="Hours"
                value={form.estimatedDuration}
                onChange={(e) => setForm({ ...form, estimatedDuration: Number(e.target.value) })}
              />
            </div>
            <Button onClick={() => createMutation.mutate()} isLoading={createMutation.isPending} disabled={!form.name || !form.slug}>
              Create
            </Button>
          </CardContent>
        </Card>
      )}

      {isLoading && (
        <div className="flex justify-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        {allCourses.map((course) => (
          <Card key={course.id}>
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">
                    <Link to={`/admin/courses/${course.id}/content`} className="hover:text-primary hover:underline" title="Open the content manager">
                      {course.name}
                    </Link>
                  </CardTitle>
                  <CardDescription className="line-clamp-1">{course.description}</CardDescription>
                </div>
                <Badge variant={course.status === 'PUBLISHED' ? 'success' : course.status === 'ARCHIVED' ? 'secondary' : 'warning'}>
                  {course.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between text-sm text-muted-foreground mb-3">
                <span>{course.enrolledCount} enrolled</span>
                <span>{course.difficulty}</span>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" asChild>
                  <Link to={`/admin/courses/${course.id}/content`}>
                    <Layers className="h-4 w-4 mr-2" />
                    Manage content (videos, notes, practice, materials)
                  </Link>
                </Button>
                {course.status !== 'PUBLISHED' && (
                  <Button size="sm" variant="outline" onClick={() => statusMutation.mutate({ id: course.id, status: 'PUBLISHED' })}>
                    Publish
                  </Button>
                )}
                {course.status !== 'ARCHIVED' && (
                  <Button size="sm" variant="outline" onClick={() => statusMutation.mutate({ id: course.id, status: 'ARCHIVED' })}>
                    Archive
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
