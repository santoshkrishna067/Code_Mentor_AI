import { useMemo, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ChevronDown, ChevronLeft, ChevronRight, ExternalLink, FileText, Link2, ListChecks, Loader2, Plus, Search, Trash2, Video } from 'lucide-react'
import { coursesService } from '@/services/courses.service'
import { syllabusService } from '@/services/syllabus.service'
import { adminService } from '@/services/admin.service'
import { QuestionForm } from '@/components/QuestionForm'
import { Markdown } from '@/components/Markdown'
import { useToast } from '@/components/ui/use-toast'
import { ApiRequestError } from '@/lib/apiClient'
import { toEmbedUrl, isDirectVideo } from '@/lib/youtube'
import { LANGUAGES } from '@/lib/codeTemplates'
import { cn } from '@/utils/cn'

type Missing = 'all' | 'video' | 'notes' | 'practice'

// Refresh everything that depends on a lesson's content (editor + status dots).
const invalidateContent = (qc: ReturnType<typeof useQueryClient>) => {
  qc.invalidateQueries({ queryKey: ['syllabus', 'subtopic-content'] })
  qc.invalidateQueries({ queryKey: ['admin', 'content-summary'] })
}

const errMsg = (e: unknown) => (e instanceof ApiRequestError ? e.message : 'Something went wrong. Please try again.')
const lines = (s: string) => s.split('\n').map((x) => x.trim()).filter(Boolean)

// ---------------------------------------------------------------------------
// One page to manage everything a lesson contains: video link, notes,
// practice questions and extra materials. Everything is replace-in-place.
// ---------------------------------------------------------------------------
export default function AdminCourseContentPage() {
  const { courseId } = useParams<{ courseId: string }>()
  const [selected, setSelected] = useState<string | null>(null)
  const [openTopics, setOpenTopics] = useState<Record<string, boolean>>({})
  const [search, setSearch] = useState('')
  const [missing, setMissing] = useState<Missing>('all')

  const { data: course, isLoading } = useQuery({
    queryKey: ['courses', 'detail', courseId],
    queryFn: () => coursesService.get(courseId!),
    enabled: !!courseId,
  })

  // Which lessons already have a video / notes / practice questions.
  const { data: summary } = useQuery({
    queryKey: ['admin', 'content-summary', course?.id],
    queryFn: () => adminService.contentSummary(course!.id),
    enabled: !!course?.id,
    staleTime: 0,
  })
  const status = useMemo(() => new Map((summary ?? []).map((l) => [l.id, l])), [summary])
  const totals = useMemo(
    () => ({
      lessons: summary?.length ?? 0,
      video: (summary ?? []).filter((l) => l.hasVideo).length,
      notes: (summary ?? []).filter((l) => l.hasNotes).length,
      practice: (summary ?? []).filter((l) => l.practiceQuestions > 0).length,
    }),
    [summary]
  )

  const topics = useMemo(() => (course?.modules ?? []).flatMap((m: any) => m.topics ?? []), [course])
  const q = search.trim().toLowerCase()
  const lacks = (id: string) => {
    const st = status.get(id)
    if (!st || missing === 'all') return true
    return missing === 'video' ? !st.hasVideo : missing === 'notes' ? !st.hasNotes : st.practiceQuestions === 0
  }
  const filtered = useMemo(
    () =>
      topics
        .map((t: any) => ({
          ...t,
          subtopics: (t.subtopics ?? []).filter((s: any) => (!q || s.title.toLowerCase().includes(q) || t.title.toLowerCase().includes(q)) && lacks(s.id)),
        }))
        .filter((t: any) => t.subtopics.length > 0),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [topics, q, missing, status]
  )

  if (isLoading) return <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto my-24" />
  if (!course) return <p className="text-center text-muted-foreground py-24">Course not found.</p>

  return (
    <div className="space-y-5">
      <div>
        <Link to="/admin/courses" className="text-sm text-primary hover:underline inline-flex items-center">
          <ChevronLeft className="h-4 w-4" /> All courses
        </Link>
        <h1 className="text-3xl font-bold mt-1">{course.name}</h1>
        <p className="text-muted-foreground">Pick a lesson on the left, then change its video, notes, practice questions and materials here.</p>
        {totals.lessons > 0 && (
          <div className="flex flex-wrap gap-2 pt-3 text-xs">
            <Badge variant="secondary">{totals.lessons} lessons</Badge>
            <Badge variant={totals.video === totals.lessons ? 'success' : 'warning'}>{totals.video} with video</Badge>
            <Badge variant={totals.notes === totals.lessons ? 'success' : 'warning'}>{totals.notes} with notes</Badge>
            <Badge variant={totals.practice === totals.lessons ? 'success' : 'warning'}>{totals.practice} with practice questions</Badge>
          </div>
        )}
      </div>

      <div className="grid lg:grid-cols-[320px_1fr] gap-5 items-start">
        {/* Lesson list */}
        <Card className="lg:sticky lg:top-20">
          <CardHeader className="pb-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input className="pl-9" placeholder="Search lessons…" value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
            <div className="flex flex-wrap gap-1.5 pt-2">
              {([
                ['all', 'All'],
                ['video', 'No video'],
                ['notes', 'No notes'],
                ['practice', 'No practice'],
              ] as [Missing, string][]).map(([id, label]) => (
                <button key={id} onClick={() => setMissing(id)} className={cn('rounded-full border px-2.5 py-1 text-xs transition-colors', missing === id ? 'bg-primary text-primary-foreground border-primary' : 'hover:bg-muted')}>
                  {label}
                </button>
              ))}
            </div>
            <p className="text-[11px] text-muted-foreground pt-1">Dots: video · notes · practice (green = added)</p>
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-[calc(100vh-16rem)] overflow-y-auto px-3 pb-3 space-y-1">
              {filtered.map((t: any) => {
                const open = q ? true : openTopics[t.id] ?? false
                return (
                  <div key={t.id}>
                    <button className="w-full flex items-center gap-2 py-2 px-2 rounded-md hover:bg-muted text-left" onClick={() => setOpenTopics((o) => ({ ...o, [t.id]: !open }))}>
                      {open ? <ChevronDown className="h-4 w-4 flex-shrink-0" /> : <ChevronRight className="h-4 w-4 flex-shrink-0" />}
                      <span className="flex-1 text-sm font-medium leading-tight">{t.title}</span>
                      <span className="text-xs text-muted-foreground">{t.subtopics.length}</span>
                    </button>
                    {open && (
                      <div className="ml-4 border-l pl-2 space-y-0.5">
                        {t.subtopics.map((s: any) => (
                          <button
                            key={s.id}
                            onClick={() => setSelected(s.id)}
                            className={cn('w-full text-left py-1.5 px-2 rounded-md text-sm hover:bg-muted', selected === s.id && 'bg-primary/10 text-primary font-medium')}
                          >
                            <span className="flex items-center gap-2">
                              <span className="flex-1 leading-tight">{s.title}</span>
                              {status.get(s.id) && (
                                <span className="flex gap-1 flex-shrink-0" aria-hidden>
                                  <span title="Video" className={cn('h-2 w-2 rounded-full', status.get(s.id)!.hasVideo ? 'bg-emerald-500' : 'bg-muted-foreground/30')} />
                                  <span title="Notes" className={cn('h-2 w-2 rounded-full', status.get(s.id)!.hasNotes ? 'bg-emerald-500' : 'bg-muted-foreground/30')} />
                                  <span title="Practice" className={cn('h-2 w-2 rounded-full', status.get(s.id)!.practiceQuestions > 0 ? 'bg-emerald-500' : 'bg-muted-foreground/30')} />
                                </span>
                              )}
                            </span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )
              })}
              {filtered.length === 0 && <p className="text-sm text-muted-foreground p-3">{missing !== 'all' && !q ? 'Nothing is missing here — every lesson has this.' : 'No lessons match.'}</p>}
            </div>
          </CardContent>
        </Card>

        {/* Editor */}
        {selected ? (
          <LessonEditor key={selected} subtopicId={selected} courseId={course.id} />
        ) : (
          <Card>
            <CardContent className="py-20 text-center text-muted-foreground">Choose a lesson from the list to edit its content.</CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

function LessonEditor({ subtopicId, courseId }: { subtopicId: string; courseId: string }) {
  const { data, isLoading } = useQuery({
    queryKey: ['syllabus', 'subtopic-content', subtopicId],
    queryFn: () => syllabusService.getSubtopicContent(subtopicId),
    staleTime: 0,
  })
  if (isLoading || !data) return <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto my-24" />

  return (
    <Card>
      <CardHeader>
        <p className="text-xs text-muted-foreground">{data.breadcrumb.topicTitle}</p>
        <CardTitle className="text-2xl">{data.subtopic.title}</CardTitle>
        <div className="flex flex-wrap gap-2 pt-1">
          <Badge variant={data.videos.length ? 'success' : 'warning'}>{data.videos.length ? 'Has video' : 'No video'}</Badge>
          <Badge variant={data.notes.length ? 'success' : 'warning'}>{data.notes.length ? 'Has notes' : 'No notes'}</Badge>
          <Badge variant={data.practiceIds.length ? 'success' : 'warning'}>{data.practiceIds.length ? 'Has practice' : 'No practice'}</Badge>
          {data.resources.length > 0 && <Badge variant="secondary">{data.resources.length} material(s)</Badge>}
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="video">
          <TabsList className="flex-wrap h-auto">
            <TabsTrigger value="video"><Video className="h-4 w-4 mr-2" />Video</TabsTrigger>
            <TabsTrigger value="notes"><FileText className="h-4 w-4 mr-2" />Notes</TabsTrigger>
            <TabsTrigger value="practice"><ListChecks className="h-4 w-4 mr-2" />Practice questions</TabsTrigger>
            <TabsTrigger value="materials"><Link2 className="h-4 w-4 mr-2" />Other materials</TabsTrigger>
          </TabsList>
          <TabsContent value="video"><VideoTab subtopicId={subtopicId} data={data} /></TabsContent>
          <TabsContent value="notes"><NotesTab subtopicId={subtopicId} data={data} /></TabsContent>
          <TabsContent value="practice"><PracticeTab subtopicId={subtopicId} courseId={courseId} title={data.subtopic.title} /></TabsContent>
          <TabsContent value="materials"><MaterialsTab subtopicId={subtopicId} data={data} /></TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

type Content = Awaited<ReturnType<typeof syllabusService.getSubtopicContent>>

// ---------------- Video (links only) ----------------
function VideoTab({ subtopicId, data }: { subtopicId: string; data: Content }) {
  const { toast } = useToast()
  const qc = useQueryClient()
  const current = data.videos[0]
  const en = current?.languages.find((l) => l.code === 'en')?.url ?? ''
  const hi = current?.languages.find((l) => l.code === 'hi')?.url ?? ''
  const [enUrl, setEnUrl] = useState(en)
  const [hiUrl, setHiUrl] = useState(hi)
  const [scope, setScope] = useState<'topic' | 'lesson'>('topic')
  const refresh = () => invalidateContent(qc)

  const save = useMutation({
    mutationFn: () => {
      const languages = [
        ...(hiUrl.trim() ? [{ code: 'hi' as const, label: 'Hindi', url: hiUrl.trim() }] : []),
        ...(enUrl.trim() ? [{ code: 'en' as const, label: 'English', url: enUrl.trim() }] : []),
      ]
      return syllabusService.replaceVideo(subtopicId, { scope, languages })
    },
    onSuccess: (r) => {
      toast({ title: 'Video replaced', description: r.lessonsAffected > 1 ? `Updated for ${r.lessonsAffected} lessons that share this video.` : 'Updated for this lesson.' })
      refresh()
    },
    onError: (e) => toast({ title: 'Could not replace video', description: errMsg(e), variant: 'destructive' }),
  })
  const remove = useMutation({
    mutationFn: () => syllabusService.removeVideo(subtopicId),
    onSuccess: () => {
      toast({ title: 'Video removed from this lesson' })
      setEnUrl('')
      setHiUrl('')
      refresh()
    },
    onError: (e) => toast({ title: 'Could not remove', description: errMsg(e), variant: 'destructive' }),
  })

  const preview = toEmbedUrl(enUrl || hiUrl)
  const bad = [enUrl, hiUrl].some((u) => u.trim() && !/^https?:\/\//i.test(u.trim()))
  // A link must be something the platform can actually play, otherwise students get a blank player.
  const unplayable = [enUrl, hiUrl].some((u) => /^https?:\/\//i.test(u.trim()) && !toEmbedUrl(u) && !isDirectVideo(u))

  return (
    <div className="space-y-4 pt-4">
      <p className="text-sm rounded-md border bg-muted/50 p-3">
        <b>Videos are saved as links only</b> (YouTube, for example). Nothing is uploaded, so your database stays small. Saving a new link <b>replaces</b> the old one — the old link is not kept.
      </p>
      <div className="grid md:grid-cols-2 gap-3">
        <div>
          <label className="text-sm font-medium">English video link</label>
          <Input className="mt-1" placeholder="https://www.youtube.com/watch?v=…" value={enUrl} onChange={(e) => setEnUrl(e.target.value)} />
        </div>
        <div>
          <label className="text-sm font-medium">Hindi video link (optional)</label>
          <Input className="mt-1" placeholder="https://www.youtube.com/watch?v=…" value={hiUrl} onChange={(e) => setHiUrl(e.target.value)} />
        </div>
      </div>
      {bad && <p className="text-xs text-destructive">Links must start with http:// or https://</p>}
      {unplayable && (
        <p className="text-xs text-destructive">
          This link can&apos;t be played inside the platform. Use a YouTube (watch, youtu.be or playlist), Vimeo or Google Drive share link, or a direct .mp4 / .webm file link.
        </p>
      )}

      {current && (
        <div className="space-y-2 rounded-md border p-3">
          <p className="text-sm font-medium">Apply the new video to</p>
          <label className="flex items-start gap-2 text-sm cursor-pointer">
            <input type="radio" checked={scope === 'topic'} onChange={() => setScope('topic')} className="mt-1 accent-[hsl(var(--primary))]" />
            <span>
              <b>The whole topic block</b> — every lesson that shares the current video (recommended: that is how this course is organised).
            </span>
          </label>
          <label className="flex items-start gap-2 text-sm cursor-pointer">
            <input type="radio" checked={scope === 'lesson'} onChange={() => setScope('lesson')} className="mt-1 accent-[hsl(var(--primary))]" />
            <span>
              <b>Only this lesson</b> — other lessons keep the current video.
            </span>
          </label>
        </div>
      )}

      {preview ? (
        <div className="aspect-video max-w-xl rounded-lg overflow-hidden bg-black">
          <iframe src={preview} className="w-full h-full" title="Preview" allowFullScreen />
        </div>
      ) : isDirectVideo(enUrl || hiUrl) ? (
        <video src={(enUrl || hiUrl).trim()} controls className="aspect-video max-w-xl rounded-lg bg-black w-full" />
      ) : null}

      <div className="flex flex-wrap gap-2">
        <Button onClick={() => save.mutate()} isLoading={save.isPending} disabled={(!enUrl.trim() && !hiUrl.trim()) || bad || unplayable}>
          {current ? 'Replace video' : 'Add video'}
        </Button>
        {current && (
          <Button variant="outline" onClick={() => remove.mutate()} isLoading={remove.isPending}>
            Remove video from this lesson
          </Button>
        )}
      </div>
    </div>
  )
}

// ---------------- Notes ----------------
type Example = { title: string; language: string; code: string; output?: string; explanation?: string }

function NotesTab({ subtopicId, data }: { subtopicId: string; data: Content }) {
  const { toast } = useToast()
  const qc = useQueryClient()
  const note = data.notes[0]
  const [title, setTitle] = useState(note?.title ?? data.subtopic.title)
  const [content, setContent] = useState(note?.content ?? '')
  const [points, setPoints] = useState((note?.highlights ?? []).join('\n'))
  const [mistakes, setMistakes] = useState((note?.commonMistakes ?? []).join('\n'))
  const [examples, setExamples] = useState<Example[]>((note?.examples ?? []).map((e) => ({ title: e.title, language: e.language, code: e.code, output: e.output, explanation: e.explanation })))
  const [preview, setPreview] = useState(false)
  const refresh = () => invalidateContent(qc)

  const save = useMutation({
    mutationFn: () => syllabusService.saveNotes(subtopicId, { title: title.trim(), content, highlights: lines(points), commonMistakes: lines(mistakes), examples: examples.filter((e) => e.code.trim()) }),
    onSuccess: () => {
      toast({ title: 'Notes saved', description: 'Students see the new notes straight away.' })
      refresh()
    },
    onError: (e) => toast({ title: 'Could not save notes', description: errMsg(e), variant: 'destructive' }),
  })
  const del = useMutation({
    mutationFn: () => syllabusService.deleteNotes(subtopicId),
    onSuccess: () => {
      toast({ title: 'Notes deleted' })
      setContent('')
      setPoints('')
      setMistakes('')
      setExamples([])
      refresh()
    },
  })
  const setEx = (i: number, patch: Partial<Example>) => setExamples(examples.map((e, n) => (n === i ? { ...e, ...patch } : e)))

  return (
    <div className="space-y-4 pt-4">
      <div>
        <label className="text-sm font-medium">Title</label>
        <Input className="mt-1" value={title} onChange={(e) => setTitle(e.target.value)} />
      </div>
      <div>
        <div className="flex items-center justify-between">
          <label className="text-sm font-medium">Notes</label>
          <Button size="sm" variant="ghost" onClick={() => setPreview((v) => !v)}>{preview ? 'Edit' : 'Preview'}</Button>
        </div>
        {preview ? (
          <div className="mt-1 rounded-md border p-4 text-sm min-h-[200px]"><Markdown source={content || '*Nothing to preview yet.*'} /></div>
        ) : (
          <textarea className="mt-1 w-full min-h-[220px] rounded-md border border-input bg-background p-3 text-sm font-mono" value={content} onChange={(e) => setContent(e.target.value)} placeholder={'Explain the lesson here.\nYou can use **bold**, `code`, "- " bullet lists and ``` code blocks.'} />
        )}
      </div>
      <div className="grid md:grid-cols-2 gap-3">
        <div>
          <label className="text-sm font-medium">Key points (one per line)</label>
          <textarea className="mt-1 w-full min-h-[90px] rounded-md border border-input bg-background p-3 text-sm" value={points} onChange={(e) => setPoints(e.target.value)} />
        </div>
        <div>
          <label className="text-sm font-medium">Common mistakes (one per line)</label>
          <textarea className="mt-1 w-full min-h-[90px] rounded-md border border-input bg-background p-3 text-sm" value={mistakes} onChange={(e) => setMistakes(e.target.value)} />
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-sm font-medium">Code examples (students can run them in the editor)</label>
          <Button size="sm" variant="outline" onClick={() => setExamples([...examples, { title: 'Example', language: 'python', code: '' }])}>
            <Plus className="h-4 w-4 mr-1" /> Add example
          </Button>
        </div>
        {examples.map((e, i) => (
          <div key={i} className="rounded-md border p-3 space-y-2">
            <div className="flex gap-2">
              <Input value={e.title} onChange={(ev) => setEx(i, { title: ev.target.value })} placeholder="Example title" />
              <Select value={e.language} onValueChange={(v) => setEx(i, { language: v })}>
                <SelectTrigger className="w-[150px]"><SelectValue /></SelectTrigger>
                <SelectContent>{LANGUAGES.map((l) => <SelectItem key={l.id} value={l.id}>{l.label}</SelectItem>)}</SelectContent>
              </Select>
              <Button variant="ghost" size="icon" onClick={() => setExamples(examples.filter((_, n) => n !== i))}><Trash2 className="h-4 w-4" /></Button>
            </div>
            <textarea className="w-full min-h-[100px] rounded-md border border-input bg-background p-2 text-sm font-mono" value={e.code} onChange={(ev) => setEx(i, { code: ev.target.value })} placeholder="Code" />
            <Input value={e.output ?? ''} onChange={(ev) => setEx(i, { output: ev.target.value })} placeholder="Expected output (optional)" />
            <Input value={e.explanation ?? ''} onChange={(ev) => setEx(i, { explanation: ev.target.value })} placeholder="One-line explanation (optional)" />
          </div>
        ))}
      </div>

      <div className="flex gap-2">
        <Button onClick={() => save.mutate()} isLoading={save.isPending} disabled={!title.trim() || !content.trim()}>
          {note ? 'Save changes (replaces old notes)' : 'Add notes'}
        </Button>
        {note && <Button variant="outline" onClick={() => del.mutate()} isLoading={del.isPending}>Delete notes</Button>}
      </div>
    </div>
  )
}

// ---------------- Practice ----------------
function PracticeTab({ subtopicId, courseId, title }: { subtopicId: string; courseId: string; title: string }) {
  const { toast } = useToast()
  const qc = useQueryClient()
  const [adding, setAdding] = useState(false)
  const { data: questions, isLoading } = useQuery({ queryKey: ['admin', 'lesson-practice', subtopicId], queryFn: () => adminService.lessonPractice(subtopicId), staleTime: 0 })
  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['admin'] })
    qc.invalidateQueries({ queryKey: ['syllabus', 'subtopic-content'] })
  }
  const remove = useMutation({
    mutationFn: (id: string) => adminService.removeFromLesson(subtopicId, id),
    onSuccess: () => {
      toast({ title: 'Question removed from this lesson' })
      refresh()
    },
    onError: (e) => toast({ title: 'Could not remove', description: errMsg(e), variant: 'destructive' }),
  })

  return (
    <div className="space-y-4 pt-4">
      <p className="text-sm text-muted-foreground">These are the questions students get when they press “Start practice questions” on this lesson.</p>
      {isLoading && <Loader2 className="h-5 w-5 animate-spin text-primary" />}
      {questions?.map((q, i) => (
        <div key={q.id} className="rounded-md border p-3 flex gap-3 justify-between">
          <div className="min-w-0 space-y-1">
            <div className="flex gap-2 items-center">
              <span className="text-xs text-muted-foreground">Q{i + 1}</span>
              <Badge variant="outline">{q.type === 'MCQ' ? 'Multiple choice' : q.type === 'SHORT_ANSWER' ? 'Short answer' : q.type === 'OUTPUT_PREDICTION' ? 'Predict the output' : q.type}</Badge>
            </div>
            <p className="text-sm whitespace-pre-wrap">{q.content}</p>
            {q.options.length > 0 ? (
              <ul className="text-sm text-muted-foreground list-disc pl-5">
                {q.options.map((o) => <li key={o.id} className={o.isCorrect ? 'text-emerald-600 dark:text-emerald-400 font-medium' : ''}>{o.content}{o.isCorrect ? ' ✓' : ''}</li>)}
              </ul>
            ) : (
              <p className="text-sm text-emerald-600 dark:text-emerald-400">Answer: {String(q.correctAnswer)}</p>
            )}
          </div>
          <Button variant="ghost" size="icon" onClick={() => remove.mutate(q.id)} title="Remove from this lesson"><Trash2 className="h-4 w-4 text-destructive" /></Button>
        </div>
      ))}
      {!isLoading && questions?.length === 0 && <p className="text-sm text-muted-foreground">No practice questions yet.</p>}

      <Button variant={adding ? 'outline' : 'default'} onClick={() => setAdding((v) => !v)}>
        <Plus className="h-4 w-4 mr-1" /> {adding ? 'Close form' : 'Add a question'}
      </Button>
      {adding && (
        <Card>
          <CardHeader><CardTitle className="text-base">New question for “{title}”</CardTitle><CardDescription>It is added to this lesson&apos;s practice straight away.</CardDescription></CardHeader>
          <CardContent><QuestionForm fixedCourseId={courseId} fixedSubtopicId={subtopicId} fixedLabel={title} onCreated={refresh} /></CardContent>
        </Card>
      )}
    </div>
  )
}

// ---------------- Other materials (links only) ----------------
function MaterialsTab({ subtopicId, data }: { subtopicId: string; data: Content }) {
  const { toast } = useToast()
  const qc = useQueryClient()
  const [title, setTitle] = useState('')
  const [url, setUrl] = useState('')
  const [kind, setKind] = useState('link')
  const refresh = () => invalidateContent(qc)

  const add = useMutation({
    mutationFn: () => syllabusService.addResource(subtopicId, { title: title.trim(), url: url.trim(), kind }),
    onSuccess: () => {
      toast({ title: 'Material added' })
      setTitle('')
      setUrl('')
      refresh()
    },
    onError: (e) => toast({ title: 'Could not add', description: errMsg(e), variant: 'destructive' }),
  })
  const del = useMutation({ mutationFn: (id: string) => syllabusService.deleteResource(id), onSuccess: refresh })

  return (
    <div className="space-y-4 pt-4">
      <p className="text-sm text-muted-foreground">Add PDFs, slides, articles or repositories as <b>links</b>. They appear under the notes for students. (Files are not uploaded, to keep the database small — host them on Google Drive, GitHub, etc.)</p>
      {data.resources.map((r) => (
        <div key={r.id} className="flex items-center justify-between rounded-md border p-3">
          <div className="min-w-0">
            <p className="text-sm font-medium">{r.title}</p>
            <a href={r.url} target="_blank" rel="noreferrer" className="text-xs text-primary hover:underline inline-flex items-center gap-1 truncate">{r.url}<ExternalLink className="h-3 w-3" /></a>
          </div>
          <Button variant="ghost" size="icon" onClick={() => del.mutate(r.id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>
        </div>
      ))}
      <div className="grid md:grid-cols-[1fr_1.4fr_150px_auto] gap-2">
        <Input placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <Input placeholder="https://…" value={url} onChange={(e) => setUrl(e.target.value)} />
        <Select value={kind} onValueChange={setKind}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            {['link', 'pdf', 'slides', 'article', 'code', 'video'].map((k) => <SelectItem key={k} value={k}>{k}</SelectItem>)}
          </SelectContent>
        </Select>
        <Button onClick={() => add.mutate()} isLoading={add.isPending} disabled={!title.trim() || !/^https?:\/\//i.test(url.trim())}>Add</Button>
      </div>
    </div>
  )
}
