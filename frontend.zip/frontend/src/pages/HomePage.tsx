import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { 
  Code2, 
  Brain, 
  Target, 
  TrendingUp, 
  Award, 
  Zap,
  ChevronRight,
  Play,
  Users,
  BookOpen,
} from 'lucide-react'

const features = [
  {
    icon: Brain,
    title: 'AI-Powered Learning',
    description: 'Personalized learning paths powered by advanced AI that adapts to your pace and style.',
  },
  {
    icon: Code2,
    title: 'Hands-On Coding',
    description: 'Practice coding in multiple languages with real-time feedback and intelligent hints.',
  },
  {
    icon: Target,
    title: 'Learning Gap Analysis',
    description: 'Identify and address knowledge gaps with targeted recommendations and practice.',
  },
  {
    icon: TrendingUp,
    title: 'Progress Analytics',
    description: 'Track your improvement with detailed analytics and performance insights.',
  },
  {
    icon: Award,
    title: 'Certifications',
    description: 'Earn recognized certificates as you complete courses and demonstrate mastery.',
  },
  {
    icon: Zap,
    title: 'Instant Feedback',
    description: 'Get immediate feedback on your code, quizzes, and assignments.',
  },
]

const courses = [
  {
    title: 'Python Programming',
    description: 'Master Python from basics to advanced concepts',
    level: 'Beginner to Advanced',
    duration: '40 hours',
    xp: '5000 XP',
  },
  {
    title: 'Java Development',
    description: 'Learn Java for enterprise application development',
    level: 'Intermediate',
    duration: '50 hours',
    xp: '6000 XP',
  },
  {
    title: 'Data Structures & Algorithms',
    description: 'Essential DSA for interviews and competitive programming',
    level: 'Intermediate',
    duration: '60 hours',
    xp: '7500 XP',
  },
  {
    title: 'C Programming',
    description: 'Build strong foundations with system-level programming',
    level: 'Beginner',
    duration: '35 hours',
    xp: '4500 XP',
  },
]

const stats = [
  { label: 'Active Students', value: '10,000+', icon: Users },
  { label: 'Courses', value: '50+', icon: BookOpen },
  { label: 'Coding Problems', value: '5,000+', icon: Code2 },
  { label: 'Completion Rate', value: '85%', icon: TrendingUp },
]

export default function HomePage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-background to-background" />
        <div className="container relative py-24 md:py-32">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight">
                  Master Programming with{' '}
                  <span className="text-primary">AI-Powered</span> Learning
                </h1>
                <p className="text-lg md:text-xl text-muted-foreground max-w-xl">
                  Code Mentor AI combines interactive courses, hands-on coding practice, 
                  intelligent assessments, and personalized recommendations to help you 
                  become a better developer.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/register">
                  <Button size="lg" className="w-full sm:w-auto">
                    Start Learning Free
                    <ChevronRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
                <Link to="/courses">
                  <Button size="lg" variant="outline" className="w-full sm:w-auto">
                    <Play className="mr-2 h-4 w-4" />
                    Explore Courses
                  </Button>
                </Link>
              </div>
              <div className="flex items-center gap-8 pt-4">
                <div>
                  <p className="text-2xl font-bold">10,000+</p>
                  <p className="text-sm text-muted-foreground">Active Students</p>
                </div>
                <div>
                  <p className="text-2xl font-bold">50+</p>
                  <p className="text-sm text-muted-foreground">Courses</p>
                </div>
                <div>
                  <p className="text-2xl font-bold">4.9/5</p>
                  <p className="text-sm text-muted-foreground">Average Rating</p>
                </div>
              </div>
            </div>
            <div className="relative hidden md:block">
              <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-primary/5 rounded-3xl blur-3xl" />
              <div className="relative bg-card border rounded-3xl p-6 shadow-2xl">
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="h-3 w-3 rounded-full bg-red-500" />
                    <div className="h-3 w-3 rounded-full bg-yellow-500" />
                    <div className="h-3 w-3 rounded-full bg-green-500" />
                  </div>
                  <div className="font-mono text-sm space-y-2">
                    <p className="text-muted-foreground"># Welcome to Code Mentor AI</p>
                    <p>
                      <span className="text-purple-500">def</span>{' '}
                      <span className="text-blue-500">start_learning</span>():
                    </p>
                    <p className="pl-4">
                      <span className="text-purple-500">return</span>{' '}
                      <span className="text-green-500">"Your coding journey begins here!"</span>
                    </p>
                    <p />
                    <p>
                      <span className="text-blue-500">print</span>(
                      <span className="text-blue-500">start_learning</span>())
                    </p>
                    <p className="text-green-500"># Your coding journey begins here!</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="border-y bg-muted/50">
        <div className="container py-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat) => (
              <div key={stat.label} className="text-center space-y-2">
                <stat.icon className="h-8 w-8 mx-auto text-primary" />
                <p className="text-3xl font-bold">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24">
        <div className="container">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl md:text-4xl font-bold">
              Everything You Need to Succeed
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Our comprehensive platform provides all the tools and resources you need 
              to master programming and land your dream job.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature) => (
              <Card key={feature.title} className="border-2 hover:border-primary/50 transition-colors">
                <CardHeader>
                  <feature.icon className="h-12 w-12 text-primary mb-4" />
                  <CardTitle>{feature.title}</CardTitle>
                  <CardDescription>{feature.description}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Courses Section */}
      <section className="py-24 bg-muted/50">
        <div className="container">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-3xl md:text-4xl font-bold">
              Popular Courses
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Start with our most popular courses designed by industry experts.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {courses.map((course) => (
              <Card key={course.title} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg">{course.title}</CardTitle>
                  <CardDescription>{course.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Level</span>
                      <span className="font-medium">{course.level}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Duration</span>
                      <span className="font-medium">{course.duration}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">XP</span>
                      <span className="font-medium text-primary">{course.xp}</span>
                    </div>
                  </div>
                  <Link to="/courses" className="mt-4 block">
                    <Button variant="outline" size="sm" className="w-full">
                      View Course
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link to="/courses">
              <Button size="lg" variant="outline">
                View All Courses
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="container">
          <div className="bg-primary rounded-3xl p-12 md:p-16 text-center text-primary-foreground">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Ready to Start Your Coding Journey?
            </h2>
            <p className="text-lg mb-8 max-w-2xl mx-auto opacity-90">
              Join thousands of students who are already learning with Code Mentor AI. 
              Start your free trial today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/register">
                <Button size="lg" variant="secondary">
                  Get Started Free
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link to="/contact">
                <Button size="lg" variant="outline" className="bg-transparent border-primary-foreground/30">
                  Contact Sales
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
