import { useMemo, useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Play,
  BookOpen,
  ClipboardCheck,
  MessageSquare,
  ChevronRight,
  ChevronLeft,
  ChevronDown,
  CheckCircle,
  Loader2,
  Bookmark,
  BookmarkCheck,
  ExternalLink,
  Code2,
  Lightbulb,
  AlertTriangle,
  Link2,
  FileText,
  Layers,
} from 'lucide-react'
import { syllabusService } from '@/services/syllabus.service'
import { learningService } from '@/services/learning.service'
import { coursesService } from '@/services/courses.service'
import { bookmarksService } from '@/services/bookmarks.service'
import { useToast } from '@/components/ui/use-toast'
import { ApiRequestError } from '@/lib/apiClient'
import { toEmbedUrl, isDirectVideo } from '@/lib/youtube'
import { CodeRunner } from '@/components/CodeRunner'
import { Markdown } from '@/components/Markdown'
import { CodeBlock } from '@/components/CodeBlock'
import { defaultLanguageForCourse, normaliseExampleLanguage } from '@/lib/codeTemplates'

export default function LearningPage() {
  // `topicId` in the URL is a SUBTOPIC id (Module -> Topic -> Subtopic).
  const { courseId, topicId: subtopicId } = useParams<{ courseId: string; topicId: string }>()
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [activeLanguage, setActiveLanguage] = useState<string | null>(null)
  const [openTopics, setOpenTopics] = useState<Record<string, boolean>>({})
  const [tab, setTab] = useState<string | null>(null)
  const [loadCode, setLoadCode] = useState<{ code: string; language: string; nonce: number } | null>(null)

  const { data, isLoading, error } = useQuery({
    queryKey: ['syllabus', 'subtopic-content', subtopicId],
    queryFn: () => syllabusService.getSubtopicContent(subtopicId!),
    enabled: !!subtopicId,
    retry: false,
  })

  // The whole course outline powers the NPTEL-style left sidebar.
  const { data: course } = useQuery({
    queryKey: ['courses', 'detail', courseId],
    queryFn: () => coursesService.get(courseId!),
    enabled: !!courseId,
  })

  const { data: progress } = useQuery({
    queryKey: ['learning', 'progress', course?.id],
    queryFn: () => learningService.getCourseProgress(course!.id),
    enabled: !!course?.id,
    retry: false,
  })

  const { data: bookmark } = useQuery({
    queryKey: ['bookmarks', 'check', subtopicId],
    queryFn: () => bookmarksService.check(subtopicId!),
    enabled: !!subtopicId,
  })

  // Reset language choice when moving to another lesson.
  useEffect(() => {
    setActiveLanguage(null)
    setTab(null)
    setLoadCode(null)
  }, [subtopicId])

  const doneIds = useMemo(() => {
    const set = new Set<string>()
    progress?.modulesProgress.forEach((m) =>
      m.topicsProgress.forEach((t) => t.subtopicsProgress.forEach((s) => s.status === 'completed' && set.add(s.subtopicId)))
    )
    return set
  }, [progress])

  // Flat, ordered lesson list for previous / next across the WHOLE course.
  const flatLessons = useMemo(
    () => (course?.modules ?? []).flatMap((m: any) => (m.topics ?? []).flatMap((t: any) => (t.subtopics ?? []).map((s: any) => ({ ...s, topicId: t.id })))),
    [course]
  )
  const idx = flatLessons.findIndex((s: any) => s.id === subtopicId)
  const prev = idx > 0 ? flatLessons[idx - 1] : null
  const next = idx >= 0 && idx < flatLessons.length - 1 ? flatLessons[idx + 1] : null

  // Auto-open the topic that contains the current lesson.
  useEffect(() => {
    if (data?.breadcrumb.topicId) setOpenTopics((o) => (o[data.breadcrumb.topicId] === undefined ? { ...o, [data.breadcrumb.topicId]: true } : o))
  }, [data?.breadcrumb.topicId])

  const markComplete = useMutation({
    mutationFn: async () => {
      // Opening a lesson never forces enrollment, but saving progress needs it — enroll quietly first.
      if (!progress && course) {
        try {
          await coursesService.enroll(course.id)
        } catch (e) {
          if (!(e instanceof ApiRequestError && e.status === 409)) throw e
        }
      }
      return learningService.markSubtopicViewed(subtopicId!, 'completed')
    },
    onSuccess: (result) => {
      toast({ title: 'Progress saved', description: result.xpEarned > 0 ? `+${result.xpEarned} XP earned!` : 'Marked complete.' })
      queryClient.invalidateQueries({ queryKey: ['learning', 'progress'] })
      queryClient.invalidateQueries({ queryKey: ['courses', 'my-enrollments'] })
    },
    onError: (e) => toast({ title: 'Could not save progress', description: e instanceof ApiRequestError ? e.message : 'Try again.', variant: 'destructive' }),
  })

  const toggleBookmark = useMutation({
    mutationFn: () => bookmarksService.toggle(subtopicId!),
    onSuccess: (r) => {
      toast({ title: r.bookmarked ? 'Bookmarked' : 'Bookmark removed' })
      queryClient.invalidateQueries({ queryKey: ['bookmarks'] })
    },
  })

  if (isLoading) {
    return (
      <div className="flex justify-center py-24">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!data) {
    return (
      <div className="text-center py-24 space-y-3">
        <p className="text-muted-foreground">{error instanceof ApiRequestError ? error.message : 'This lesson could not be found.'}</p>
        <Link to={`/courses/${courseId}`} className="text-primary hover:underline">
          Back to the course
        </Link>
      </div>
    )
  }

  const { subtopic, breadcrumb, videos, notes } = data
  const video = videos[0]
  const note = notes[0]
  const resources = data.resources
  const hasReading = !!note || resources.length > 0
  const languages = video?.languages ?? []
  const currentLanguage = activeLanguage ?? languages[0]?.code
  const currentTrack = languages.find((l: any) => l.code === currentLanguage)
  const embedUrl = toEmbedUrl(currentTrack?.url)
  const isDone = doneIds.has(subtopic.id)

  return (
    <div className="flex gap-6">
      {/* Course outline (NPTEL-style) */}
      <aside className="w-80 flex-shrink-0 hidden lg:block">
        <Card className="sticky top-20 rounded-2xl overflow-hidden">
          <CardHeader className="pb-3 bg-gradient-to-br from-primary/10 to-transparent">
            <CardTitle className="text-base leading-snug">{breadcrumb.courseName}</CardTitle>
            {progress && (
              <div className="space-y-1 pt-1">
                <Progress value={progress.overallProgress} />
                <p className="text-xs text-muted-foreground">{progress.overallProgress}% complete</p>
              </div>
            )}
          </CardHeader>
          <CardContent className="p-0">
            <div className="max-h-[calc(100vh-14rem)] overflow-y-auto px-3 py-3 space-y-1">
              {(course?.modules ?? []).flatMap((m: any) =>
                (m.topics ?? []).map((t: any) => {
                  const open = openTopics[t.id] ?? false
                  const doneCount = (t.subtopics ?? []).filter((s: any) => doneIds.has(s.id)).length
                  return (
                    <div key={t.id}>
                      <button
                        className="w-full flex items-center gap-2 py-2 px-2 rounded-lg hover:bg-muted text-left"
                        onClick={() => setOpenTopics((o) => ({ ...o, [t.id]: !open }))}
                      >
                        {open ? <ChevronDown className="h-4 w-4 flex-shrink-0" /> : <ChevronRight className="h-4 w-4 flex-shrink-0" />}
                        <span className="flex-1 text-sm font-medium leading-tight">{t.title}</span>
                        <span className="text-xs text-muted-foreground tabular-nums">
                          {doneCount}/{t.subtopics?.length ?? 0}
                        </span>
                      </button>
                      {open && (
                        <div className="ml-4 border-l pl-2 space-y-0.5">
                          {(t.subtopics ?? []).map((s: any) => (
                            <Link
                              key={s.id}
                              to={`/courses/${courseId}/topics/${s.id}`}
                              className={`flex items-center gap-2 py-1.5 px-2 rounded-lg text-sm hover:bg-muted ${s.id === subtopicId ? 'bg-primary/10 text-primary font-medium' : ''}`}
                            >
                              {doneIds.has(s.id) ? <CheckCircle className="h-4 w-4 text-green-500 flex-shrink-0" /> : <div className="h-4 w-4 rounded-full border flex-shrink-0" />}
                              <span className="leading-tight">{s.title}</span>
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>
                  )
                })
              )}
            </div>
          </CardContent>
        </Card>
      </aside>

      {/* Main content */}
      <div className="flex-1 min-w-0 space-y-6">
        {/* Lesson header */}
        <div className="relative overflow-hidden rounded-2xl border bg-gradient-to-br from-primary/10 via-card to-card p-6 md:p-8 shadow-sm">
          <div className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-primary/10 blur-3xl" />
          <div className="relative flex items-start justify-between gap-4">
            <div className="min-w-0 space-y-2">
              <p className="text-sm text-muted-foreground">
                <Link to={`/courses/${courseId}`} className="hover:underline">
                  {breadcrumb.courseName}
                </Link>{' '}
                / {breadcrumb.topicTitle}
              </p>
              <h1 className="text-3xl md:text-4xl font-bold tracking-tight leading-tight">{subtopic.title}</h1>
              <div className="flex flex-wrap items-center gap-2 pt-1">
                {idx >= 0 && (
                  <Badge variant="secondary">
                    <Layers className="h-3 w-3 mr-1" />
                    Lesson {idx + 1} of {flatLessons.length}
                  </Badge>
                )}
                {video && <Badge variant="outline">Video</Badge>}
                {note && <Badge variant="outline">Notes</Badge>}
                {data.practiceIds.length > 0 && <Badge variant="outline">Practice</Badge>}
                {isDone && <Badge variant="success">Completed</Badge>}
              </div>
            </div>
            <Button variant="outline" size="icon" className="flex-shrink-0 bg-background/70" title={bookmark?.bookmarked ? 'Remove bookmark' : 'Bookmark this lesson'} onClick={() => toggleBookmark.mutate()}>
              {bookmark?.bookmarked ? <BookmarkCheck className="h-4 w-4 text-primary" /> : <Bookmark className="h-4 w-4" />}
            </Button>
          </div>
        </div>

        <Tabs value={tab ?? (video ? 'video' : hasReading ? 'notes' : 'practice')} onValueChange={setTab} className="w-full">
          <TabsList className="h-12 p-1 rounded-xl bg-muted/70 w-full sm:w-auto">
            <TabsTrigger value="video" disabled={!video} className="rounded-lg px-4">
              <Play className="h-4 w-4 mr-2" />
              Video
            </TabsTrigger>
            <TabsTrigger value="notes" disabled={!hasReading} className="rounded-lg px-4">
              <BookOpen className="h-4 w-4 mr-2" />
              Notes
              {resources.length > 0 && <span className="ml-2 rounded-full bg-primary/15 text-primary text-[11px] px-1.5 py-0.5 leading-none">{resources.length}</span>}
            </TabsTrigger>
            <TabsTrigger value="practice" className="rounded-lg px-4">
              <ClipboardCheck className="h-4 w-4 mr-2" />
              Practice
            </TabsTrigger>
          </TabsList>

          <TabsContent value="video" className="space-y-4">
            <Card className="rounded-2xl overflow-hidden">
              <CardContent className="pt-6">
                {video ? (
                  <>
                    <div className="aspect-video bg-black rounded-xl overflow-hidden ring-1 ring-border shadow-lg">
                      {embedUrl ? (
                        <iframe
                          key={`${subtopicId}-${currentLanguage}`}
                          src={embedUrl}
                          className="w-full h-full"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                          allowFullScreen
                          title={video.title}
                        />
                      ) : isDirectVideo(currentTrack?.url) ? (
                        <video key={`${subtopicId}-${currentLanguage}`} src={currentTrack?.url} controls className="w-full h-full" />
                      ) : (
                        <div className="h-full flex items-center justify-center text-white/80 text-sm px-6 text-center">This video link cannot be played inside the platform. Use “Open video in a new tab” below.</div>
                      )}
                    </div>
                    <div className="flex flex-wrap justify-between items-center gap-3 mt-4">
                      <div className="flex flex-wrap items-center gap-2">
                        {languages.map((l: any) => (
                          <Button key={l.code} variant={currentLanguage === l.code ? 'default' : 'outline'} size="sm" onClick={() => setActiveLanguage(l.code)}>
                            {l.label}
                          </Button>
                        ))}
                        {currentTrack?.url && (
                          <a href={currentTrack.url} target="_blank" rel="noreferrer" className="text-xs text-primary hover:underline inline-flex items-center gap-1 ml-2">
                            Open video in a new tab <ExternalLink className="h-3 w-3" />
                          </a>
                        )}
                      </div>
                      <Button onClick={() => markComplete.mutate()} isLoading={markComplete.isPending} disabled={isDone}>
                        {isDone ? 'Completed' : 'Mark as Complete'}
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground mt-3">
                      One video can cover a whole topic block, so the same video may appear on several lessons under “{breadcrumb.topicTitle}”.
                    </p>
                  </>
                ) : (
                  <div className="text-center py-12 space-y-3">
                    <p className="text-muted-foreground">No video attached to this lesson yet.</p>
                    <Button onClick={() => markComplete.mutate()} isLoading={markComplete.isPending} disabled={isDone} variant="outline">
                      {isDone ? 'Completed' : 'Mark as Complete'}
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notes" className="space-y-4">
            <Card className="rounded-2xl overflow-hidden">
              <CardHeader className="border-b bg-muted/30">
                <CardTitle className="text-xl flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary" />
                  {note?.title ?? 'Learning material'}
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6 md:px-8">
                {note ? (
                  <>
                    <article className="max-w-3xl text-[15.5px]">
                      <Markdown source={note.content} />
                    </article>

                    {note.highlights && note.highlights.length > 0 && (
                      <div className="mt-8 rounded-2xl border border-primary/25 bg-primary/5 p-5">
                        <h4 className="font-semibold text-sm mb-3 flex items-center gap-2 text-primary">
                          <Lightbulb className="h-4 w-4" />
                          Key points
                        </h4>
                        <ul className="list-disc pl-5 text-sm leading-6 space-y-2 marker:text-primary">
                          {note.highlights.map((m: string, i: number) => (
                            <li key={i}>{m}</li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {note.examples && note.examples.length > 0 && (
                      <div className="mt-8 space-y-6">
                        <h4 className="font-semibold text-lg flex items-center gap-2">
                          <Code2 className="h-5 w-5 text-primary" />
                          Examples
                        </h4>
                        {note.examples.map((ex: any) => (
                          <div key={ex.id} className="space-y-2">
                            <h5 className="font-medium text-sm">{ex.title}</h5>
                            <CodeBlock code={ex.code} language={ex.language} className="my-0" />
                            {ex.output && <CodeBlock code={ex.output} language="text" className="my-0" />}
                            {ex.explanation && <p className="text-sm leading-6 text-muted-foreground">{ex.explanation}</p>}
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setLoadCode({ code: ex.code, language: normaliseExampleLanguage(ex.language), nonce: Date.now() })
                                setTab('practice')
                              }}
                            >
                              <Code2 className="h-4 w-4 mr-2" />
                              Try it in the editor
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}

                    {note.commonMistakes && note.commonMistakes.length > 0 && (
                      <div className="mt-8 rounded-2xl border border-amber-500/30 bg-amber-500/10 p-5">
                        <h4 className="font-semibold text-sm mb-3 flex items-center gap-2 text-amber-700 dark:text-amber-300">
                          <AlertTriangle className="h-4 w-4" />
                          Common mistakes
                        </h4>
                        <ul className="list-disc pl-5 text-sm leading-6 space-y-2">
                          {note.commonMistakes.map((m: string, i: number) => (
                            <li key={i}>{m}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </>
                ) : (
                  <p className="text-sm text-muted-foreground">There are no written notes for this lesson yet — the extra material below may help.</p>
                )}

                {resources.length > 0 && (
                  <div className="mt-8 rounded-2xl border p-5">
                    <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                      <Link2 className="h-4 w-4 text-primary" />
                      More learning material
                    </h4>
                    <ul className="space-y-2">
                      {resources.map((r) => (
                        <li key={r.id} className="flex items-center justify-between gap-3 rounded-lg bg-muted/40 px-3 py-2">
                          <a href={r.url} target="_blank" rel="noreferrer" className="text-sm text-primary hover:underline inline-flex items-center gap-1.5 min-w-0">
                            <span className="truncate">{r.title}</span>
                            <ExternalLink className="h-3 w-3 flex-shrink-0" />
                          </a>
                          <Badge variant="outline" className="flex-shrink-0">{r.kind}</Badge>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="flex justify-end mt-8">
                  <Button onClick={() => markComplete.mutate()} isLoading={markComplete.isPending} disabled={isDone}>
                    {isDone ? 'Completed' : 'Mark as Complete'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="practice" className="space-y-4">
            <Card className="rounded-2xl">
              <CardHeader>
                <CardTitle className="text-base">Practice questions</CardTitle>
                <p className="text-sm text-muted-foreground">Questions your instructor added for this lesson. You will see the correct answers and explanations after you submit.</p>
              </CardHeader>
              <CardContent className="space-y-3">
                {data.practiceIds.length > 0 ? (
                  data.practiceIds.map((id) => (
                    <Link key={id} to={`/practice/${id}`}>
                      <Button variant="outline" className="w-full justify-between h-12">
                        Start practice questions for this lesson
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </Link>
                  ))
                ) : (
                  <p className="text-muted-foreground text-center py-2">No practice questions are attached to this lesson yet.</p>
                )}
              </CardContent>
            </Card>

            <Card className="rounded-2xl">
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Code2 className="h-4 w-4" />
                  Code editor — try it yourself
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CodeRunner defaultLanguage={defaultLanguageForCourse(course?.slug ?? courseId)} loadCode={loadCode} />
                <div className="flex justify-between items-center mt-3">
                  <p className="text-xs text-muted-foreground">Supports Python, JavaScript, Java, C, C++ and SQL. Nothing here is graded.</p>
                  <Link to="/coding" className="text-xs text-primary hover:underline">
                    Graded coding problems →
                  </Link>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-between">
          <Link to={prev ? `/courses/${courseId}/topics/${prev.id}` : '#'} onClick={(e) => !prev && e.preventDefault()}>
            <Button variant="outline" disabled={!prev}>
              <ChevronLeft className="h-4 w-4 mr-2" />
              Previous
            </Button>
          </Link>
          <Link to={next ? `/courses/${courseId}/topics/${next.id}` : `/courses/${courseId}`}>
            <Button>
              {next ? 'Next lesson' : 'Back to course'}
              <ChevronRight className="h-4 w-4 ml-2" />
            </Button>
          </Link>
        </div>

        <p className="text-center text-xs text-muted-foreground flex items-center justify-center gap-1.5">
          <MessageSquare className="h-3.5 w-3.5" />
          Stuck? Tap Mira, the round chat button at the bottom-right, or open the{' '}
          <Link to="/ai-tutor" className="text-primary hover:underline">
            full AI Tutor
          </Link>
          .
        </p>
      </div>
    </div>
  )
}
