import { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import * as z from 'zod'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Code2, Mail, Lock, Eye, EyeOff, ShieldCheck } from 'lucide-react'
import { useToast } from '@/components/ui/use-toast'
import { useAuth } from '@/context/AuthContext'
import { ApiRequestError } from '@/lib/apiClient'
import { GoogleSignInButton } from '@/components/GoogleSignInButton'

const loginSchema = z.object({
  email: z.string().email('Please enter a valid email'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
})

type LoginForm = z.infer<typeof loginSchema>

export default function LoginPage() {
  const navigate = useNavigate()
  const location = useLocation()
  const { toast } = useToast()
  const { login, completeMfaLogin, loginWithGoogle } = useAuth()
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  // MFA step: once the backend reports mfaRequired, we hold the challenge
  // token and ask for the 6-digit code before ever issuing real tokens.
  const [mfaChallengeToken, setMfaChallengeToken] = useState<string | null>(null)
  const [mfaCode, setMfaCode] = useState('')
  const [mfaSubmitting, setMfaSubmitting] = useState(false)

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
  })

  const redirectAfterLogin = () => {
    const from = (location.state as { from?: { pathname: string } } | null)?.from?.pathname
    navigate(from ?? '/dashboard')
  }

  const onGoogleCredential = async (idToken: string) => {
    try {
      const result = await loginWithGoogle(idToken)
      if (result.mfaRequired) {
        setMfaChallengeToken(result.challengeToken!)
        toast({ title: 'Verification required', description: 'Enter the 6-digit code from your authenticator app.' })
        return
      }
      toast({ title: 'Signed in with Google', description: 'Welcome to Code Mentor AI!' })
      redirectAfterLogin()
    } catch (error) {
      const message = error instanceof ApiRequestError ? error.message : 'Google sign-in failed. Please try again.'
      toast({ title: 'Google sign-in failed', description: message, variant: 'destructive' })
    }
  }

  const onSubmit = async (data: LoginForm) => {
    setIsLoading(true)
    try {
      const result = await login(data.email, data.password)
      if (result.mfaRequired) {
        setMfaChallengeToken(result.challengeToken!)
        toast({ title: 'Verification required', description: 'Enter the 6-digit code from your authenticator app.' })
        return
      }
      toast({ title: 'Login successful', description: 'Welcome back to Code Mentor AI!' })
      redirectAfterLogin()
    } catch (error) {
      const message = error instanceof ApiRequestError ? error.message : 'Please check your credentials and try again.'
      toast({ title: 'Login failed', description: message, variant: 'destructive' })
    } finally {
      setIsLoading(false)
    }
  }

  const onSubmitMfa = async () => {
    if (!mfaChallengeToken || mfaCode.length !== 6) return
    setMfaSubmitting(true)
    try {
      await completeMfaLogin(mfaChallengeToken, mfaCode)
      toast({ title: 'Login successful', description: 'Welcome back to Code Mentor AI!' })
      redirectAfterLogin()
    } catch (error) {
      const message = error instanceof ApiRequestError ? error.message : 'Invalid or expired code.'
      toast({ title: 'Verification failed', description: message, variant: 'destructive' })
    } finally {
      setMfaSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen flex">
      {/* Left Side - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-primary text-primary-foreground flex-col justify-between p-12">
        <div>
          <Link to="/" className="flex items-center space-x-2 mb-8">
            <Code2 className="h-8 w-8" />
            <span className="text-2xl font-bold">Code Mentor AI</span>
          </Link>
          <div className="space-y-6 mt-16">
            <h1 className="text-4xl font-bold leading-tight">
              Welcome back to your learning journey
            </h1>
            <p className="text-lg opacity-90">
              Continue where you left off and keep building your programming skills.
            </p>
          </div>
        </div>
        <div className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-primary-foreground/20 flex items-center justify-center">
              <span className="text-2xl">🎯</span>
            </div>
            <div>
              <p className="font-semibold">Personalized Learning</p>
              <p className="text-sm opacity-80">AI-powered recommendations</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-primary-foreground/20 flex items-center justify-center">
              <span className="text-2xl">💻</span>
            </div>
            <div>
              <p className="font-semibold">Hands-On Practice</p>
              <p className="text-sm opacity-80">Real coding exercises</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 rounded-full bg-primary-foreground/20 flex items-center justify-center">
              <span className="text-2xl">📊</span>
            </div>
            <div>
              <p className="font-semibold">Progress Tracking</p>
              <p className="text-sm opacity-80">Detailed analytics</p>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Login Form */}
      <div className="flex-1 flex items-center justify-center p-8">
        <Card className="w-full max-w-md">
          <CardHeader className="space-y-1">
            <div className="flex items-center gap-2 mb-2 lg:hidden">
              <Code2 className="h-6 w-6 text-primary" />
              <span className="font-bold">Code Mentor AI</span>
            </div>
            <CardTitle className="text-2xl">Welcome back</CardTitle>
            <CardDescription>
              Enter your credentials to access your account
            </CardDescription>
          </CardHeader>
          <CardContent>
            {mfaChallengeToken ? (
              <div className="space-y-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <ShieldCheck className="h-4 w-4" />
                  <span>Enter the 6-digit code from your authenticator app</span>
                </div>
                <Input
                  inputMode="numeric"
                  maxLength={6}
                  placeholder="123456"
                  value={mfaCode}
                  onChange={(e) => setMfaCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  className="text-center text-lg tracking-[0.5em]"
                />
                <Button className="w-full" isLoading={mfaSubmitting} disabled={mfaCode.length !== 6} onClick={onSubmitMfa}>
                  Verify
                </Button>
                <Button variant="ghost" className="w-full" type="button" onClick={() => setMfaChallengeToken(null)}>
                  Back to login
                </Button>
              </div>
            ) : (
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="email" className="text-sm font-medium">
                  Email
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="you@example.com"
                    className="pl-10"
                    {...register('email')}
                  />
                </div>
                {errors.email && (
                  <p className="text-sm text-destructive">{errors.email.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <label htmlFor="password" className="text-sm font-medium">
                  Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter your password"
                    className="pl-10 pr-10"
                    {...register('password')}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                {errors.password && (
                  <p className="text-sm text-destructive">{errors.password.message}</p>
                )}
              </div>

              <div className="flex items-center justify-between">
                <label className="flex items-center space-x-2 text-sm">
                  <input type="checkbox" className="rounded border-input" />
                  <span>Remember me</span>
                </label>
                <Link
                  to="/forgot-password"
                  className="text-sm text-primary hover:underline"
                >
                  Forgot password?
                </Link>
              </div>

              <Button type="submit" className="w-full" isLoading={isLoading}>
                {isLoading ? 'Signing in...' : 'Sign in'}
              </Button>
            </form>
            )}
          </CardContent>
          <CardFooter className="flex flex-col space-y-4">
            <div className="text-sm text-center text-muted-foreground">
              Don't have an account?{' '}
              <Link to="/register" className="text-primary hover:underline">
                Sign up
              </Link>
            </div>
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-card px-2 text-muted-foreground">
                  Or continue with
                </span>
              </div>
            </div>
            <GoogleSignInButton onCredential={onGoogleCredential} />
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
