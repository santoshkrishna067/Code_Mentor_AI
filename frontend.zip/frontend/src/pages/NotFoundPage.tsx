import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/button'
import { Code2 } from 'lucide-react'

export default function NotFoundPage() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="text-center space-y-6">
        <Code2 className="h-16 w-16 mx-auto text-primary" />
        <div>
          <h1 className="text-4xl font-bold">404</h1>
          <p className="text-lg text-muted-foreground">Page not found</p>
        </div>
        <p className="text-muted-foreground max-w-md">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <Link to="/">
          <Button>Go back home</Button>
        </Link>
      </div>
    </div>
  )
}
