import { useState } from 'react'
import { useParams } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Loader2 } from 'lucide-react'
import { assignmentsService } from '@/services/assignments.service'
import { useToast } from '@/components/ui/use-toast'
import { ApiRequestError } from '@/lib/apiClient'

export default function AssignmentDetailPage() {
  const { assignmentId } = useParams<{ assignmentId: string }>()
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [comments, setComments] = useState('')

  const { data: assignment, isLoading } = useQuery({
    queryKey: ['assignments', assignmentId],
    queryFn: () => assignmentsService.get(assignmentId!),
    enabled: !!assignmentId,
  })

  const { data: submission } = useQuery({
    queryKey: ['assignments', assignmentId, 'submission'],
    queryFn: () => assignmentsService.startOrGetSubmission(assignmentId!),
    enabled: !!assignmentId,
  })

  const submitMutation = useMutation({
    mutationFn: () => assignmentsService.submit(assignmentId!, { comments }),
    onSuccess: () => {
      toast({ title: 'Assignment submitted', description: 'Your instructor will review it soon.' })
      queryClient.invalidateQueries({ queryKey: ['assignments', assignmentId, 'submission'] })
    },
    onError: (error) => {
      const message = error instanceof ApiRequestError ? error.message : 'Could not submit. Please try again.'
      toast({ title: 'Submission failed', description: message, variant: 'destructive' })
    },
  })

  if (isLoading) {
    return (
      <div className="flex justify-center py-24">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!assignment) {
    return <p className="text-center text-muted-foreground py-24">Assignment not found.</p>
  }

  const isSubmitted = submission?.status === 'submitted' || submission?.status === 'evaluated'

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold">{assignment.title}</h1>
        <p className="text-muted-foreground">{assignment.description}</p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Instructions</CardTitle>
          <CardDescription>Complete all tasks and submit before the deadline</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Badge variant="warning">Due: {new Date(assignment.dueDate).toLocaleDateString()}</Badge>
            <Badge>{assignment.totalMarks} marks</Badge>
          </div>
          {assignment.instructions?.length > 0 && (
            <ol className="list-decimal list-inside space-y-1 text-sm">
              {assignment.instructions.map((ins: string, i: number) => (
                <li key={i}>{ins}</li>
              ))}
            </ol>
          )}

          {isSubmitted ? (
            <div className="p-4 rounded-lg bg-muted">
              <p className="font-medium text-sm">Submitted {submission?.submittedAt ? new Date(submission.submittedAt).toLocaleString() : ''}</p>
              {submission?.marks !== undefined && (
                <p className="text-sm text-muted-foreground mt-1">
                  Grade: {submission.marks}/{assignment.totalMarks}
                  {submission.feedback ? ` — ${submission.feedback}` : ''}
                </p>
              )}
            </div>
          ) : (
            <>
              <textarea
                className="w-full min-h-[120px] rounded-md border border-input bg-background p-3 text-sm"
                placeholder="Add comments about your submission (optional)"
                value={comments}
                onChange={(e) => setComments(e.target.value)}
              />
              <Button onClick={() => submitMutation.mutate()} isLoading={submitMutation.isPending}>
                Submit Assignment
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
