import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Lightbulb, Play, Code2, BookOpen, Trophy, Target, ClipboardCheck, RefreshCw, Loader2 } from 'lucide-react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { recommendationsService } from '@/services/recommendations.service'
import { useToast } from '@/components/ui/use-toast'

const iconMap: Record<string, typeof Play> = {
  continue_learning: Play,
  revise_topic: BookOpen,
  watch_video: Play,
  practice: Code2,
  take_quiz: ClipboardCheck,
  complete_assignment: ClipboardCheck,
  take_assessment: Trophy,
  coding_practice: Code2,
  review_notes: BookOpen,
  address_gap: Target,
}

function priorityVariant(priority: string): 'destructive' | 'warning' | 'secondary' {
  if (priority === 'high') return 'destructive'
  if (priority === 'medium') return 'warning'
  return 'secondary'
}

export default function RecommendationsPage() {
  const { toast } = useToast()
  const queryClient = useQueryClient()

  const { data: recommendations, isLoading } = useQuery({
    queryKey: ['recommendations', 'me'],
    queryFn: () => recommendationsService.myRecommendations(),
  })

  const refreshMutation = useMutation({
    mutationFn: () => recommendationsService.refresh(),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['recommendations', 'me'] })
      toast({ title: 'Recommendations refreshed' })
    },
  })

  const dismissMutation = useMutation({
    mutationFn: (id: string) => recommendationsService.dismiss(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['recommendations', 'me'] }),
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Recommendations</h1>
          <p className="text-muted-foreground">Personalized suggestions based on your progress</p>
        </div>
        <Button variant="outline" onClick={() => refreshMutation.mutate()} isLoading={refreshMutation.isPending}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      {isLoading && (
        <div className="flex justify-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      )}

      {!isLoading && (!recommendations || recommendations.length === 0) && (
        <p className="text-center text-muted-foreground py-16">
          No recommendations right now — hit "Refresh" after completing a few lessons.
        </p>
      )}

      <div className="grid md:grid-cols-2 gap-4">
        {recommendations?.map((r) => {
          const Icon = iconMap[r.type] || Lightbulb
          return (
            <Card key={r.id} className="hover:border-primary/50 transition-colors">
              <CardHeader>
                <div className="flex items-start gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-lg">{r.title}</CardTitle>
                      <Badge variant={priorityVariant(r.priority)}>{r.priority}</Badge>
                    </div>
                    <CardDescription>{r.description}</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground mb-3">{r.reason}</p>
                <div className="flex items-center justify-between">
                  {r.xpReward ? <span className="text-sm font-medium text-primary">+{r.xpReward} XP</span> : <span />}
                  <Button variant="ghost" size="sm" onClick={() => dismissMutation.mutate(r.id)}>
                    Dismiss
                  </Button>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
