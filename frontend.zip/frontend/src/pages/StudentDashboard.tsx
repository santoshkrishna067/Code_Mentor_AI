import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import {
  BookOpen,
  Play,
  Trophy,
  Target,
  TrendingUp,
  Award,
  Flame,
  ChevronRight,
  Lightbulb,
  Code2,
  ClipboardCheck,
  Loader2,
} from 'lucide-react'
import { useAuth } from '@/context/AuthContext'
import { coursesService } from '@/services/courses.service'
import { learningService } from '@/services/learning.service'
import { recommendationsService } from '@/services/recommendations.service'
import { learningGapsService } from '@/services/learningGaps.service'
import { xpService } from '@/services/xp.service'
import { analyticsService } from '@/services/analytics.service'
import { aiService } from '@/services/ai.service'

const REC_ICONS: Record<string, typeof Play> = {
  continue_learning: Play,
  practice: Code2,
  address_gap: Target,
  take_quiz: ClipboardCheck,
  revise_topic: Target,
}

function severityBadgeVariant(severity: string): 'destructive' | 'warning' | 'secondary' {
  if (severity === 'critical') return 'destructive'
  if (severity === 'moderate') return 'warning'
  return 'secondary'
}

// Owns its own progress fetch so each enrolled course card is independent —
// keeps the parent from having to call hooks inside a loop.
function CourseProgressRow({ courseId, name }: { courseId: string; name: string }) {
  const { data: progress } = useQuery({
    queryKey: ['learning', 'progress', courseId],
    queryFn: () => learningService.getCourseProgress(courseId),
  })
  const completedModules = progress?.modulesProgress.filter((m) => m.progress === 100).length ?? 0
  const totalModules = progress?.modulesProgress.length ?? 0

  return (
    <div className="flex gap-4 p-4 rounded-lg border hover:bg-muted/50 transition-colors">
      <div className="h-16 w-16 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
        <BookOpen className="h-7 w-7 text-primary" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-semibold">{name}</h3>
          <Badge variant="secondary">{progress?.overallProgress ?? 0}%</Badge>
        </div>
        <Progress value={progress?.overallProgress ?? 0} className="mt-2" />
        <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
          <span>{completedModules}/{totalModules} modules</span>
          <Link to={`/courses/${courseId}`}>
            <Button variant="ghost" size="sm" className="h-7">
              Continue
              <ChevronRight className="h-3 w-3 ml-1" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

function PredictedPerformanceCard({ courseId }: { courseId: string }) {
  const { data: perf } = useQuery({
    queryKey: ['ai', 'performance-prediction', courseId],
    queryFn: () => aiService.performancePrediction('me', courseId),
    enabled: !!courseId,
  })
  const { data: insights } = useQuery({
    queryKey: ['ai', 'insights', courseId],
    queryFn: () => aiService.courseInsights('me', courseId),
    enabled: !!courseId,
  })

  if (!perf || perf.insufficientData || perf.value === null) {
    return (
      <p className="text-sm text-muted-foreground text-center py-8">
        {perf?.reason ?? 'Complete a few more graded activities to unlock a performance prediction.'}
      </p>
    )
  }

  const pct = Math.round(perf.value)
  const circumference = 251.2

  return (
    <div className="text-center space-y-4">
      <div className="relative h-32 w-32 mx-auto">
        <svg className="h-full w-full" viewBox="0 0 100 100">
          <circle className="text-muted" strokeWidth="8" stroke="currentColor" fill="transparent" r="40" cx="50" cy="50" />
          <circle
            className="text-primary"
            strokeWidth="8"
            strokeDasharray={circumference}
            strokeDashoffset={circumference - (circumference * pct) / 100}
            strokeLinecap="round"
            stroke="currentColor"
            fill="transparent"
            r="40"
            cx="50"
            cy="50"
            transform="rotate(-90 50 50)"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-2xl font-bold">{pct}%</span>
        </div>
      </div>
      <div>
        <p className="text-sm font-medium">Predicted next-assessment score</p>
        <p className="text-xs text-muted-foreground">
          {Math.round((perf.confidence ?? 0) * 100)}% confidence · {perf.method}
        </p>
      </div>
      {insights && (insights as any).strengths?.length > 0 && (
        <div className="grid grid-cols-2 gap-2 text-center">
          <div className="p-2 rounded bg-muted">
            <p className="text-lg font-semibold text-green-500">Strong</p>
            <p className="text-xs text-muted-foreground truncate">{(insights as any).strengths[0]?.courseName ?? '—'}</p>
          </div>
          <div className="p-2 rounded bg-muted">
            <p className="text-lg font-semibold text-yellow-500">Needs Work</p>
            <p className="text-xs text-muted-foreground truncate">{(insights as any).weaknesses?.[0]?.courseName ?? 'None'}</p>
          </div>
        </div>
      )}
    </div>
  )
}

export default function StudentDashboard() {
  const { user } = useAuth()

  const { data: enrollments, isLoading: enrollmentsLoading } = useQuery({
    queryKey: ['courses', 'my-enrollments'],
    queryFn: () => coursesService.myEnrollments(),
  })
  const { data: recommendations } = useQuery({
    queryKey: ['recommendations', 'me'],
    queryFn: () => recommendationsService.myRecommendations(),
  })
  const { data: gaps } = useQuery({
    queryKey: ['learning-gaps', 'me'],
    queryFn: () => learningGapsService.myGaps(),
  })
  const { data: xpHistory } = useQuery({
    queryKey: ['xp', 'history'],
    queryFn: () => xpService.history(),
  })
  const { data: overview } = useQuery({
    queryKey: ['analytics', 'me'],
    queryFn: () => analyticsService.myOverview(),
  })

  const activeCourses = (enrollments ?? []).filter((e) => e.status !== 'COMPLETED')
  const primaryCourseId = enrollments?.[0]?.courseId

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Welcome back, {user?.name?.split(' ')[0] ?? 'there'}! 👋</h1>
          <p className="text-muted-foreground">
            {user && user.streak > 0
              ? `You're on a ${user.streak}-day learning streak. Keep it up!`
              : 'Complete something today to start a streak.'}
          </p>
        </div>
        <div className="flex items-center gap-4">
          <Card className="px-4 py-2">
            <div className="flex items-center gap-2">
              <Flame className="h-5 w-5 text-orange-500" />
              <div>
                <p className="text-sm font-semibold">{user?.streak ?? 0} days</p>
                <p className="text-xs text-muted-foreground">Streak</p>
              </div>
            </div>
          </Card>
          <Card className="px-4 py-2">
            <div className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-yellow-500" />
              <div>
                <p className="text-sm font-semibold">{(user?.xp ?? 0).toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Total XP</p>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                <BookOpen className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{activeCourses.length}</p>
                <p className="text-sm text-muted-foreground">Active Courses</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-green-500/10 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{overview?.averageScore ?? 0}%</p>
                <p className="text-sm text-muted-foreground">Avg Accuracy</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                <ClipboardCheck className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{overview?.contentItemsCompleted ?? 0}</p>
                <p className="text-sm text-muted-foreground">Items Completed</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-purple-500/10 flex items-center justify-center">
                <Award className="h-5 w-5 text-purple-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{overview?.completedCourseCount ?? 0}</p>
                <p className="text-sm text-muted-foreground">Courses Completed</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Continue Learning - 2 columns */}
        <div className="lg:col-span-2 space-y-8">
          {/* Continue Learning */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Continue Learning</CardTitle>
                  <CardDescription>Pick up where you left off</CardDescription>
                </div>
                <Link to="/courses">
                  <Button variant="ghost" size="sm">
                    View All
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              {enrollmentsLoading && <Loader2 className="h-6 w-6 animate-spin text-primary mx-auto my-8" />}
              {!enrollmentsLoading && activeCourses.length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-6">
                  You're not enrolled in any courses yet. <Link to="/courses" className="text-primary hover:underline">Browse courses</Link>.
                </p>
              )}
              <div className="space-y-4">
                {activeCourses.slice(0, 2).map((e) => (
                  <CourseProgressRow key={e.courseId} courseId={e.courseId} name={e.course.name} />
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recommended For You */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Lightbulb className="h-5 w-5 text-yellow-500" />
                <div>
                  <CardTitle>Recommended For You</CardTitle>
                  <CardDescription>Personalized suggestions based on your progress</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {(!recommendations || recommendations.length === 0) && (
                <p className="text-sm text-muted-foreground text-center py-6">
                  No recommendations yet — complete a few lessons and check back.
                </p>
              )}
              <div className="grid sm:grid-cols-2 gap-4">
                {recommendations?.slice(0, 4).map((rec) => {
                  const Icon = REC_ICONS[rec.type] ?? Lightbulb
                  return (
                    <div key={rec.id} className="p-4 rounded-lg border hover:border-primary/50 transition-colors">
                      <div className="flex items-start gap-3">
                        <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <Icon className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-sm">{rec.title}</h3>
                          <p className="text-xs text-muted-foreground mt-1">{rec.description}</p>
                          <div className="flex items-center justify-between mt-3">
                            <span className="text-xs font-medium text-primary">{rec.reason}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* Learning Gaps */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Learning Gaps</CardTitle>
                  <CardDescription>Areas that need your attention</CardDescription>
                </div>
                <Link to="/learning-gaps">
                  <Button variant="ghost" size="sm">
                    View All
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </Button>
                </Link>
              </div>
            </CardHeader>
            <CardContent>
              {(!gaps || gaps.length === 0) && (
                <p className="text-sm text-muted-foreground text-center py-6">No open learning gaps detected. Nice work!</p>
              )}
              <div className="space-y-3">
                {gaps?.slice(0, 3).map((gap) => (
                  <div key={gap.id} className="flex items-center justify-between p-3 rounded-lg border">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{gap.concept}</h3>
                        <Badge variant={severityBadgeVariant(gap.severity)}>{gap.severity}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{gap.courseName}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold">Gap: {Math.round(gap.gapScore)}%</p>
                      <Link to="/learning-gaps">
                        <Button variant="link" size="sm" className="h-auto p-0 text-xs">
                          Address Gap
                        </Button>
                      </Link>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Sidebar - 1 column */}
        <div className="space-y-8">
          {/* Course Progress */}
          <Card>
            <CardHeader>
              <CardTitle>Course Progress</CardTitle>
              <CardDescription>All your enrolled courses</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {(enrollments ?? []).map((e) => (
                <Link key={e.courseId} to={`/courses/${e.courseId}`}>
                  <div className="p-3 rounded-lg border hover:bg-muted/50 transition-colors">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-medium text-sm">{e.course.name}</h3>
                    </div>
                    <MiniProgressBar courseId={e.courseId} />
                  </div>
                </Link>
              ))}
              <Link to="/courses">
                <Button variant="outline" size="sm" className="w-full">
                  View All Courses
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Recent Activity (from XP ledger) */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Your latest learning activities</CardDescription>
            </CardHeader>
            <CardContent>
              {(!xpHistory || xpHistory.history.length === 0) && (
                <p className="text-sm text-muted-foreground text-center py-6">No activity yet.</p>
              )}
              <div className="space-y-4">
                {xpHistory?.history.slice(0, 6).map((activity) => (
                  <div key={activity.id} className="flex items-start gap-3">
                    <div className="h-2 w-2 rounded-full bg-primary mt-2" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-muted-foreground">{activity.description}</p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <span>{new Date(activity.createdAt).toLocaleDateString()}</span>
                        {activity.amount > 0 && <span className="text-primary">+{activity.amount} XP</span>}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <Link to="/analytics">
                <Button variant="ghost" size="sm" className="w-full mt-4">
                  View All Activity
                  <ChevronRight className="h-4 w-4 ml-1" />
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Predicted Performance (Part 4 AI) */}
          <Card>
            <CardHeader>
              <CardTitle>Predicted Performance</CardTitle>
              <CardDescription>AI estimate based on your current progress</CardDescription>
            </CardHeader>
            <CardContent>
              {primaryCourseId ? (
                <PredictedPerformanceCard courseId={primaryCourseId} />
              ) : (
                <p className="text-sm text-muted-foreground text-center py-8">Enroll in a course to see predictions.</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function MiniProgressBar({ courseId }: { courseId: string }) {
  const { data: progress } = useQuery({
    queryKey: ['learning', 'progress', courseId],
    queryFn: () => learningService.getCourseProgress(courseId),
  })
  return (
    <>
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs text-muted-foreground">{progress?.xpEarned ?? 0} XP earned</span>
        <span className="text-xs text-muted-foreground">{progress?.overallProgress ?? 0}%</span>
      </div>
      <Progress value={progress?.overallProgress ?? 0} />
    </>
  )
}
