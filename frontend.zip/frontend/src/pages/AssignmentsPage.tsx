import { Link } from 'react-router-dom'
import { useQuery, useQueries } from '@tanstack/react-query'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Loader2 } from 'lucide-react'
import { coursesService } from '@/services/courses.service'
import { assignmentsService } from '@/services/assignments.service'

function statusVariant(status?: string): 'success' | 'warning' | 'secondary' {
  if (status === 'submitted' || status === 'evaluated') return 'success'
  if (status === 'in-progress') return 'warning'
  return 'secondary'
}

export default function AssignmentsPage() {
  const { data: enrollments, isLoading: enrollmentsLoading } = useQuery({
    queryKey: ['courses', 'my-enrollments'],
    queryFn: () => coursesService.myEnrollments(),
  })

  // Assignments are scoped per-course on the backend, so we fan out one
  // request per enrolled course and merge — there is no single
  // cross-course "all my assignments" endpoint.
  const assignmentQueries = useQueries({
    queries: (enrollments ?? []).map((e) => ({
      queryKey: ['assignments', 'mine', e.courseId],
      queryFn: () => assignmentsService.myAssignments(e.courseId),
      enabled: !!enrollments,
    })),
  })

  const isLoading = enrollmentsLoading || assignmentQueries.some((q) => q.isLoading)
  const allAssignments = assignmentQueries.flatMap((q, i) =>
    (q.data ?? []).map((a: any) => ({ ...a, courseName: enrollments?.[i]?.course.name }))
  )

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Assignments</h1>
        <p className="text-muted-foreground">View and submit your assignments</p>
      </div>

      {isLoading && (
        <div className="flex justify-center py-16">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      )}

      {!isLoading && allAssignments.length === 0 && (
        <p className="text-center text-muted-foreground py-16">No assignments yet.</p>
      )}

      <div className="space-y-4">
        {allAssignments.map((a) => (
          <Link key={a.id} to={`/assignments/${a.id}`}>
            <Card className="hover:border-primary/50 transition-colors">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle>{a.title}</CardTitle>
                    <CardDescription>{a.courseName}</CardDescription>
                  </div>
                  <Badge variant={statusVariant(a.submission?.status)}>{a.submission?.status ?? 'not started'}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <p className="text-sm text-muted-foreground">
                    Due: {new Date(a.dueDate).toLocaleDateString()} • {a.totalMarks} marks
                  </p>
                  <Button variant="outline" size="sm">
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}
