import { useState, useRef, useEffect } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Send, MessageSquare, Lightbulb, Code2, BookOpen, Loader2, AlertTriangle } from 'lucide-react'
import { tutorService } from '@/services/tutor.service'
import { useToast } from '@/components/ui/use-toast'
import { ApiRequestError } from '@/lib/apiClient'

const quickActions = [
  { icon: Lightbulb, label: 'Explain', prompt: 'Can you explain this concept to me?' },
  { icon: Code2, label: 'Example', prompt: 'Can you show me an example?' },
  { icon: BookOpen, label: 'Revise', prompt: 'Help me revise what I just learned.' },
  { icon: MessageSquare, label: 'Quiz Me', prompt: 'Quiz me on this topic.' },
]

export default function AITutorPage() {
  const [input, setInput] = useState('')
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const scrollRef = useRef<HTMLDivElement>(null)

  const { data: history, isLoading } = useQuery({
    queryKey: ['tutor', 'history'],
    queryFn: () => tutorService.history(),
  })

  // Tell the student up-front when the AI engine is not running, instead of failing on first message.
  const { data: status } = useQuery({
    queryKey: ['tutor', 'status'],
    queryFn: () => tutorService.status(),
    refetchInterval: (q) => (q.state.data?.ready ? false : 15000),
    retry: false,
  })

  const sendMutation = useMutation({
    mutationFn: (message: string) => tutorService.sendMessage(message),
    onMutate: async (message) => {
      // Optimistically show the user's own message immediately.
      await queryClient.cancelQueries({ queryKey: ['tutor', 'history'] })
      const previous = queryClient.getQueryData(['tutor', 'history'])
      queryClient.setQueryData(['tutor', 'history'], (old: any) => [
        ...(old ?? []),
        { role: 'user', content: message, timestamp: new Date().toISOString() },
      ])
      return { previous }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['tutor', 'history'] })
    },
    onError: (error, _msg, context) => {
      queryClient.setQueryData(['tutor', 'history'], context?.previous)
      const message =
        error instanceof ApiRequestError
          ? error.message // e.g. "AI Tutor is disabled while a secured exam attempt is in progress."
          : 'The AI Tutor is temporarily unavailable.'
      toast({ title: 'Could not send message', description: message, variant: 'destructive' })
    },
  })

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [history])

  const handleSend = (text?: string) => {
    const message = (text ?? input).trim()
    if (!message) return
    sendMutation.mutate(message)
    setInput('')
  }

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-8rem)] flex flex-col">
      <div className="mb-4">
        <h1 className="text-3xl font-bold">AI Tutor</h1>
        <p className="text-muted-foreground">Get personalized help with your learning</p>
      </div>

      {status && !status.ready && (
        <div className="mb-4 flex items-start gap-3 rounded-md border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
          <AlertTriangle className="h-5 w-5 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-medium">The AI Tutor engine is not ready yet.</p>
            <p>{status.hint}</p>
          </div>
        </div>
      )}

      <div className="flex gap-2 mb-4">
        {quickActions.map((a) => (
          <Button key={a.label} variant="outline" size="sm" onClick={() => handleSend(a.prompt)}>
            <a.icon className="h-4 w-4 mr-2" />
            {a.label}
          </Button>
        ))}
      </div>

      <Card className="flex-1 mb-4 overflow-hidden">
        <CardContent ref={scrollRef} className="pt-6 h-full overflow-auto space-y-4">
          {isLoading && <Loader2 className="h-6 w-6 animate-spin text-primary mx-auto" />}
          {!isLoading && (!history || history.length === 0) && (
            <div className="flex justify-start">
              <div className="max-w-[80%] p-4 rounded-lg bg-muted">
                Hello! I'm your AI tutor. How can I help you today?
              </div>
            </div>
          )}
          {history?.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] p-4 rounded-lg whitespace-pre-wrap ${m.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                {m.content}
              </div>
            </div>
          ))}
          {sendMutation.isPending && (
            <div className="flex justify-start">
              <div className="max-w-[80%] p-4 rounded-lg bg-muted">
                <Loader2 className="h-4 w-4 animate-spin" />
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="flex gap-2">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask me anything..."
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
        />
        <Button onClick={() => handleSend()} isLoading={sendMutation.isPending}>
          <Send className="h-4 w-4 mr-2" />
          Send
        </Button>
      </div>
    </div>
  )
}
