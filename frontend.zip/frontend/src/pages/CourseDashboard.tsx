import { useMemo, useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { Play, BookOpen, ChevronRight, ChevronDown, CheckCircle, Loader2, Award, Video } from 'lucide-react'
import { coursesService } from '@/services/courses.service'
import { learningService } from '@/services/learning.service'
import { certificatesService } from '@/services/certificates.service'
import { useToast } from '@/components/ui/use-toast'
import { ApiRequestError } from '@/lib/apiClient'

export default function CourseDashboard() {
  const { courseId } = useParams<{ courseId: string }>()
  const { toast } = useToast()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const [open, setOpen] = useState<Record<string, boolean>>({})

  const { data: course, isLoading, error } = useQuery({
    queryKey: ['courses', 'detail', courseId],
    queryFn: () => coursesService.get(courseId!),
    enabled: !!courseId,
    retry: false,
  })

  const { data: progress } = useQuery({
    queryKey: ['learning', 'progress', course?.id],
    queryFn: () => learningService.getCourseProgress(course!.id),
    enabled: !!course?.id,
    retry: false,
  })

  const isEnrolled = !!progress

  const enroll = async () => {
    try {
      await coursesService.enroll(course!.id)
    } catch (e) {
      if (!(e instanceof ApiRequestError && e.status === 409)) throw e // already enrolled is fine
    }
    queryClient.invalidateQueries({ queryKey: ['learning', 'progress', course?.id] })
    queryClient.invalidateQueries({ queryKey: ['courses', 'my-enrollments'] })
  }

  const enrollMutation = useMutation({
    mutationFn: enroll,
    onSuccess: () => toast({ title: 'Enrolled!', description: `You're now enrolled in ${course?.name}.` }),
    onError: (e) => toast({ title: 'Enrollment failed', description: e instanceof ApiRequestError ? e.message : 'Please try again.', variant: 'destructive' }),
  })

  const claimCertificate = useMutation({
    mutationFn: () => certificatesService.claim(course!.id),
    onSuccess: () => {
      toast({ title: 'Certificate earned!', description: 'You can find it on the Certificates page.' })
      navigate('/certificates')
    },
    onError: (e) => toast({ title: 'Not yet', description: e instanceof ApiRequestError ? e.message : 'Try again.', variant: 'destructive' }),
  })

  const doneIds = useMemo(() => {
    const set = new Set<string>()
    progress?.modulesProgress.forEach((m) => m.topicsProgress.forEach((t) => t.subtopicsProgress.forEach((s) => s.status === 'completed' && set.add(s.subtopicId))))
    return set
  }, [progress])

  const topics = useMemo(() => (course?.modules ?? []).flatMap((m: any) => (m.topics ?? []).map((t: any) => ({ ...t, moduleTitle: m.title }))), [course])
  const allLessons = useMemo(() => topics.flatMap((t: any) => t.subtopics ?? []), [topics])
  const nextLesson = allLessons.find((s: any) => !doneIds.has(s.id)) ?? allLessons[0]

  // Opening a lesson enrolls the student first, so progress and XP are tracked from the first click.
  const openLesson = async (subtopicId: string) => {
    if (!isEnrolled) {
      try {
        await enroll()
      } catch (e) {
        toast({ title: 'Could not open lesson', description: e instanceof ApiRequestError ? e.message : 'Please try again.', variant: 'destructive' })
        return
      }
    }
    navigate(`/courses/${courseId}/topics/${subtopicId}`)
  }

  if (isLoading) {
    return (
      <div className="flex justify-center py-24">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!course) {
    return (
      <div className="text-center py-24 space-y-3">
        <p className="text-muted-foreground">{error instanceof ApiRequestError ? error.message : 'Course not found.'}</p>
        <Link to="/courses" className="text-primary hover:underline">
          Back to all courses
        </Link>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="h-48 w-full md:w-80 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
          <BookOpen className="h-16 w-16 text-primary" />
        </div>
        <div className="flex-1 space-y-4">
          <div>
            <h1 className="text-3xl font-bold">{course.name}</h1>
            <p className="text-muted-foreground mt-2">{course.description}</p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Badge variant="secondary">{course.difficulty?.toLowerCase()}</Badge>
            <Badge variant="outline">{topics.length} topics</Badge>
            <Badge variant="outline">{allLessons.length} lessons</Badge>
            <Badge variant="outline">~{course.estimatedDuration} hours</Badge>
            <Badge variant="outline">{course.enrolledCount} students</Badge>
          </div>

          {isEnrolled ? (
            <div className="space-y-3">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Your progress</span>
                  <span>{progress?.overallProgress ?? 0}%</span>
                </div>
                <Progress value={progress?.overallProgress ?? 0} />
              </div>
              <div className="flex flex-wrap gap-3">
                {nextLesson && (
                  <Button onClick={() => openLesson(nextLesson.id)}>
                    <Play className="h-4 w-4 mr-2" />
                    {(progress?.overallProgress ?? 0) > 0 ? 'Continue learning' : 'Start learning'}
                  </Button>
                )}
                <Button variant="outline" onClick={() => claimCertificate.mutate()} isLoading={claimCertificate.isPending} disabled={(progress?.overallProgress ?? 0) < 100}>
                  <Award className="h-4 w-4 mr-2" />
                  Get certificate
                </Button>
              </div>
              {(progress?.overallProgress ?? 0) < 100 && <p className="text-xs text-muted-foreground">The certificate unlocks when every lesson is complete.</p>}
            </div>
          ) : (
            <div className="flex flex-wrap gap-3">
              {nextLesson && (
                <Button onClick={() => openLesson(nextLesson.id)} isLoading={enrollMutation.isPending}>
                  <Play className="h-4 w-4 mr-2" />
                  Start course
                </Button>
              )}
              <Button variant="outline" onClick={() => enrollMutation.mutate()} isLoading={enrollMutation.isPending}>
                Enroll only
              </Button>
            </div>
          )}
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold">Course content</h2>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={() => setOpen(Object.fromEntries(topics.map((t: any) => [t.id, true])))}>
              Expand all
            </Button>
            <Button size="sm" variant="outline" onClick={() => setOpen({})}>
              Collapse all
            </Button>
          </div>
        </div>

        {topics.length === 0 && <p className="text-muted-foreground py-8 text-center">This course has no topics yet.</p>}

        {topics.map((topic: any, ti: number) => {
          const lessons = topic.subtopics ?? []
          const done = lessons.filter((s: any) => doneIds.has(s.id)).length
          const isOpen = open[topic.id] ?? false
          const hasVideo = lessons.some((s: any) => s.contentType === 'video')
          return (
            <Card key={topic.id}>
              <CardHeader className="py-3 cursor-pointer" onClick={() => setOpen((o) => ({ ...o, [topic.id]: !isOpen }))}>
                <div className="flex items-center gap-3">
                  {isOpen ? <ChevronDown className="h-5 w-5 flex-shrink-0" /> : <ChevronRight className="h-5 w-5 flex-shrink-0" />}
                  <CardTitle className="text-base flex-1">
                    {ti + 1}. {topic.title}
                  </CardTitle>
                  {hasVideo && <Video className="h-4 w-4 text-primary" />}
                  <span className="text-sm text-muted-foreground">
                    {done}/{lessons.length} lessons
                  </span>
                </div>
              </CardHeader>
              {isOpen && (
                <CardContent className="pt-0 space-y-1">
                  {lessons.map((lesson: any, li: number) => (
                    <button
                      key={lesson.id}
                      onClick={() => openLesson(lesson.id)}
                      className="w-full flex items-center gap-3 p-2 rounded-md hover:bg-muted text-left transition-colors"
                    >
                      {doneIds.has(lesson.id) ? <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" /> : <div className="h-5 w-5 rounded-full border flex-shrink-0" />}
                      <span className="flex-1 text-sm">
                        {li + 1}. {lesson.title}
                      </span>
                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    </button>
                  ))}
                </CardContent>
              )}
            </Card>
          )
        })}
      </div>
    </div>
  )
}
