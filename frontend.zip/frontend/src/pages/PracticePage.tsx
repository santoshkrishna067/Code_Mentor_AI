import { useParams, Link } from 'react-router-dom'
import { GradedAttemptRunner } from '@/components/GradedAttemptRunner'
import { practiceService } from '@/services/practice.service'

export default function PracticePage() {
  const { practiceId } = useParams<{ practiceId: string }>()

  if (!practiceId) {
    return (
      <div className="max-w-2xl mx-auto py-16 space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold">Practice</h1>
          <p className="text-muted-foreground">Two different ways to practise — pick the one you need.</p>
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          <div className="border rounded-lg p-5 space-y-3">
            <h2 className="font-semibold">Practice sets</h2>
            <p className="text-sm text-muted-foreground">Question sets (multiple choice and short answers) attached to a lesson. Open a lesson and use its <b>Practice</b> tab.</p>
            <Link to="/courses" className="text-primary hover:underline text-sm">
              Browse courses →
            </Link>
          </div>
          <div className="border rounded-lg p-5 space-y-3">
            <h2 className="font-semibold">Coding</h2>
            <p className="text-sm text-muted-foreground">Write real code in an editor, run it with your own input, and submit it to be graded by test cases.</p>
            <Link to="/coding" className="text-primary hover:underline text-sm">
              Open the code editor →
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return <GradedAttemptRunner id={practiceId} service={practiceService} backLink={-1} backLabel="Back to the lesson" queryKeyPrefix="practice" />
}
