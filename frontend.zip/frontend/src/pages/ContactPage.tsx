import { useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import { CheckCircle2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { useToast } from '@/components/ui/use-toast'
import { contactService } from '@/services/contact.service'
import { ApiRequestError } from '@/lib/apiClient'
import { useAuth } from '@/context/AuthContext'

export default function ContactPage() {
  const { toast } = useToast()
  const { user } = useAuth()
  const [form, setForm] = useState({ name: user?.name ?? '', email: user?.email ?? '', subject: '', message: '' })
  const [sent, setSent] = useState(false)

  const set = (k: keyof typeof form) => (e: { target: { value: string } }) => setForm((f) => ({ ...f, [k]: e.target.value }))

  const send = useMutation({
    mutationFn: () => contactService.send(form),
    onSuccess: () => {
      setSent(true)
      setForm((f) => ({ ...f, subject: '', message: '' }))
    },
    onError: (error) => {
      const details = error instanceof ApiRequestError ? (error.details as { fieldErrors?: Record<string, string[]> } | undefined) : undefined
      const firstField = details?.fieldErrors ? Object.values(details.fieldErrors).flat()[0] : undefined
      toast({
        title: 'Could not send message',
        description: firstField || (error instanceof ApiRequestError ? error.message : 'Please try again.'),
        variant: 'destructive',
      })
    },
  })

  const canSend = form.name.trim() && form.email.trim() && form.subject.trim() && form.message.trim().length >= 5

  return (
    <div className="container py-12">
      <h1 className="text-4xl font-bold mb-4">Contact Us</h1>
      <p className="text-lg text-muted-foreground mb-12">Have questions? We'd love to hear from you.</p>
      <div className="grid md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Send us a message</CardTitle>
            <CardDescription>Your message goes straight to the Code Mentor AI admin team.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {sent && (
              <div className="flex items-start gap-3 rounded-md border border-green-200 bg-green-50 p-3 text-sm text-green-800">
                <CheckCircle2 className="h-5 w-5 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="font-medium">Message sent!</p>
                  <p>An admin will read it and reply to {form.email}.</p>
                </div>
              </div>
            )}
            <Input placeholder="Your name" value={form.name} onChange={set('name')} />
            <Input placeholder="Your email" type="email" value={form.email} onChange={set('email')} />
            <Input placeholder="Subject" value={form.subject} onChange={set('subject')} />
            <textarea
              className="w-full min-h-[150px] p-3 border rounded-md bg-background"
              placeholder="Your message (at least 5 characters)"
              value={form.message}
              onChange={set('message')}
            />
            <Button onClick={() => send.mutate()} isLoading={send.isPending} disabled={!canSend}>
              Send Message
            </Button>
          </CardContent>
        </Card>
        <div className="space-y-6">
          <div>
            <h3 className="font-semibold mb-2">How it works</h3>
            <p className="text-muted-foreground">
              Messages are saved in our database and every admin is notified. Admins read and resolve them from the Messages page in the admin panel.
            </p>
          </div>
          <div>
            <h3 className="font-semibold mb-2">Email</h3>
            <p className="text-muted-foreground">support@codementor.ai</p>
          </div>
        </div>
      </div>
    </div>
  )
}
