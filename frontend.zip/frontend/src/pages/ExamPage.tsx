import { useState, useEffect, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Clock, AlertTriangle, Loader2, CheckCircle2, XCircle } from 'lucide-react'
import { examsService } from '@/services/exams.service'
import { proctoringService } from '@/services/proctoring.service'
import ProctoringPanel from '@/components/ProctoringPanel'
import { useToast } from '@/components/ui/use-toast'
import { ApiRequestError } from '@/lib/apiClient'

export default function ExamPage() {
  const { examId } = useParams<{ examId: string }>()
  const navigate = useNavigate()
  const { toast } = useToast()
  const queryClient = useQueryClient()

  const [attemptId, setAttemptId] = useState<string | null>(null)
  const [currentIndex, setCurrentIndex] = useState(0)
  const [remainingSeconds, setRemainingSeconds] = useState(0)
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null)
  const [result, setResult] = useState<{ score: number; passed: boolean; status: string } | null>(null)

  const { data: eligibility } = useQuery({
    queryKey: ['exams', examId, 'eligibility'],
    queryFn: () => examsService.checkEligibility(examId!),
    enabled: !!examId && !attemptId,
  })

  const { data: attempt, refetch: refetchAttempt } = useQuery({
    queryKey: ['exams', 'attempt', attemptId],
    queryFn: () => examsService.getAttemptState(attemptId!),
    enabled: !!attemptId,
    refetchInterval: 30_000,
  })

  useEffect(() => {
    if (attempt) setRemainingSeconds(attempt.remainingSeconds)
  }, [attempt])

  const submitMutation = useMutation({
    mutationFn: () => examsService.submit(attemptId!),
    onSuccess: (res) => {
      setResult(res)
      cameraStream?.getTracks().forEach((t) => t.stop())
      queryClient.invalidateQueries({ queryKey: ['exams'] })
    },
  })

  useEffect(() => {
    if (!attemptId || result || remainingSeconds <= 0) return
    const timer = setInterval(() => {
      setRemainingSeconds((s) => {
        if (s <= 1) {
          submitMutation.mutate()
          return 0
        }
        return s - 1
      })
    }, 1000)
    return () => clearInterval(timer)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [attemptId, result, remainingSeconds <= 0])

  const startMutation = useMutation({
    mutationFn: () => examsService.start(examId!),
    onSuccess: async (state) => {
      setAttemptId(state.attemptId)
      if (state.proctoringEnabled) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({
            video: { width: { ideal: 640 }, height: { ideal: 480 } },
            audio: false,
          })
          setCameraStream(stream)
        } catch {
          toast({ title: 'Camera access denied', description: 'Proctoring requires camera access for this exam.', variant: 'destructive' })
          // The exam cannot be proctored without a camera — leave a trail for the reviewer.
          proctoringService
            .reportWarning(state.attemptId, 'SUSPICIOUS_ACTIVITY', 'HIGH', 'Camera access was denied for a proctored exam')
            .catch(() => undefined)
        }
      }
    },
    onError: (error) => {
      const message = error instanceof ApiRequestError ? error.message : 'Could not start the exam.'
      toast({ title: 'Could not start exam', description: message, variant: 'destructive' })
    },
  })

  const saveAnswer = useMutation({
    mutationFn: (vars: { questionId: string; answer: string }) =>
      examsService.saveAnswers(attemptId!, [{ questionId: vars.questionId, answer: vars.answer }]),
  })

  // Called whenever the server's escalation policy ends the attempt (from a
  // tab-switch warning or from the camera analysis).
  const handleEscalation = useCallback(
    async (reason?: string) => {
      toast({ title: 'Exam ended', description: reason ?? 'Your session was flagged and ended.', variant: 'destructive' })
      cameraStream?.getTracks().forEach((t) => t.stop())
      await refetchAttempt()
      setResult({ score: 0, passed: false, status: 'flagged' })
    },
    [cameraStream, refetchAttempt, toast]
  )

  const reportWarning = useCallback(
    async (type: Parameters<typeof proctoringService.reportWarning>[1], severity: 'LOW' | 'MEDIUM' | 'HIGH', message: string) => {
      if (!attemptId) return
      const res = await proctoringService.reportWarning(attemptId, type, severity, message)
      if (res.escalated) await handleEscalation(res.reason)
    },
    [attemptId, handleEscalation]
  )

  // Tab / window switching is detected here in the browser. Face, multiple-face,
  // phone and looking-away detection happen on the server: <ProctoringPanel>
  // sends a camera frame once a second to /proctoring/sessions/:id/frame.
  useEffect(() => {
    if (!attemptId || result) return
    const handler = () => {
      if (document.hidden) {
        reportWarning('TAB_SWITCH', 'MEDIUM', 'Student switched away from the exam tab')
      }
    }
    document.addEventListener('visibilitychange', handler)
    return () => document.removeEventListener('visibilitychange', handler)
  }, [attemptId, result, reportWarning])

  useEffect(() => {
    return () => {
      cameraStream?.getTracks().forEach((t) => t.stop())
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const timeLabel = `${Math.floor(remainingSeconds / 60)}:${(remainingSeconds % 60).toString().padStart(2, '0')}`

  if (result) {
    return (
      <div className="max-w-2xl mx-auto text-center py-16 space-y-4">
        {result.status === 'flagged' ? (
          <>
            <AlertTriangle className="h-16 w-16 text-destructive mx-auto" />
            <h1 className="text-2xl font-bold">Exam session flagged</h1>
            <p className="text-muted-foreground">Your attempt was ended due to proctoring concerns and will be reviewed by an admin.</p>
          </>
        ) : (
          <>
            {result.passed ? <CheckCircle2 className="h-16 w-16 text-green-500 mx-auto" /> : <XCircle className="h-16 w-16 text-destructive mx-auto" />}
            <h1 className="text-2xl font-bold">Exam submitted</h1>
            <p className="text-4xl font-bold text-primary">{result.score}%</p>
          </>
        )}
        <Button onClick={() => navigate('/exams')}>Back to Exams</Button>
      </div>
    )
  }

  if (!attemptId) {
    return (
      <div className="max-w-2xl mx-auto py-16 space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Exam Instructions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {!eligibility ? (
              <Loader2 className="h-6 w-6 animate-spin text-primary mx-auto" />
            ) : eligibility.eligible ? (
              <>
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-yellow-600 mt-0.5" />
                  <div>
                    <p className="font-medium text-yellow-800">AI Tutor is unavailable during this examination</p>
                    <p className="text-sm text-yellow-600">This is enforced by the server, not just hidden in the UI.</p>
                  </div>
                </div>
                <Button className="w-full" onClick={() => startMutation.mutate()} isLoading={startMutation.isPending}>
                  {eligibility.resumableAttemptId ? 'Resume Exam' : 'Start Exam'}
                </Button>
              </>
            ) : (
              <div className="space-y-2">
                <p className="text-destructive font-medium">You can't take this exam right now:</p>
                <ul className="list-disc list-inside text-sm text-muted-foreground">
                  {eligibility.reasons.map((r, i) => (
                    <li key={i}>{r}</li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!attempt) {
    return (
      <div className="flex justify-center py-24">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  const question = attempt.questions[currentIndex]

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Exam in progress</h1>
          <p className="text-muted-foreground">Question {currentIndex + 1} of {attempt.questions.length}</p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant={remainingSeconds < 60 ? 'destructive' : 'outline'}>
            <Clock className="h-4 w-4 mr-2" />
            {timeLabel}
          </Badge>
        </div>
      </div>

      <Card>
        <CardContent className="pt-6 space-y-4">
          <p className="font-medium">{question.content}</p>
          <div className="space-y-2">
            {question.options?.map((opt) => (
              <Button
                key={opt.id}
                variant="outline"
                className="w-full justify-start text-left h-auto py-3"
                onClick={() => saveAnswer.mutate({ questionId: question.id, answer: opt.content })}
              >
                {opt.content}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-between">
        <Button variant="outline" disabled={currentIndex === 0} onClick={() => setCurrentIndex((i) => i - 1)}>
          Previous
        </Button>
        {currentIndex < attempt.questions.length - 1 ? (
          <Button onClick={() => setCurrentIndex((i) => i + 1)}>Next</Button>
        ) : (
          <Button onClick={() => submitMutation.mutate()} isLoading={submitMutation.isPending}>
            Submit Exam
          </Button>
        )}
      </div>

      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-10 gap-2">
            {attempt.questions.map((q, idx) => (
              <Button
                key={q.id}
                variant={idx === currentIndex ? 'default' : attempt.answeredQuestionIds.includes(q.id) ? 'secondary' : 'outline'}
                size="sm"
                className="h-10 w-10 p-0"
                onClick={() => setCurrentIndex(idx)}
              >
                {idx + 1}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {cameraStream && (
        <ProctoringPanel
          stream={cameraStream}
          attemptId={attemptId}
          onEscalated={handleEscalation}
          onCameraLost={() => reportWarning('SUSPICIOUS_ACTIVITY', 'HIGH', 'The camera was turned off or disconnected during the exam')}
        />
      )}
    </div>
  )
}
