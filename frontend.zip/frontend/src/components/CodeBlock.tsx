import { useState } from 'react'
import { Check, Copy } from 'lucide-react'
import { cn } from '@/utils/cn'

const LABELS: Record<string, string> = {
  py: 'Python',
  python: 'Python',
  js: 'JavaScript',
  javascript: 'JavaScript',
  ts: 'TypeScript',
  typescript: 'TypeScript',
  java: 'Java',
  c: 'C',
  cpp: 'C++',
  'c++': 'C++',
  sql: 'SQL',
  bash: 'Shell',
  sh: 'Shell',
  html: 'HTML',
  css: 'CSS',
  json: 'JSON',
  text: 'Output',
}

// A code snippet with a slim header (language + copy button). The surface is a soft
// slate in both light and dark mode so code stays readable and easy on the eyes.
export function CodeBlock({ code, language, className }: { code: string; language?: string; className?: string }) {
  const [copied, setCopied] = useState(false)
  const label = language ? LABELS[language.toLowerCase()] ?? language : 'Code'

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code)
      setCopied(true)
      setTimeout(() => setCopied(false), 1600)
    } catch {
      /* clipboard blocked by the browser - nothing to do */
    }
  }

  return (
    <div className={cn('rounded-xl overflow-hidden border border-slate-700/60 bg-slate-950 shadow-sm my-4', className)}>
      <div className="flex items-center justify-between px-4 py-2 bg-slate-900 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-rose-400/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-amber-400/70" />
          <span className="h-2.5 w-2.5 rounded-full bg-emerald-400/70" />
          <span className="ml-2 text-xs font-medium text-slate-400">{label}</span>
        </div>
        <button
          type="button"
          onClick={copy}
          className="inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-xs text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
          aria-label="Copy code"
        >
          {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      <pre className="p-4 text-[13.5px] font-mono leading-6 text-slate-100 overflow-auto max-h-[28rem]">
        <code>{code}</code>
      </pre>
    </div>
  )
}
