import { useEffect, useRef, useState } from 'react'

const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID as string | undefined

declare global {
  interface Window {
    google?: {
      accounts: {
        id: {
          initialize: (config: { client_id: string; callback: (r: { credential: string }) => void }) => void
          renderButton: (el: HTMLElement, options: Record<string, unknown>) => void
        }
      }
    }
  }
}

let scriptPromise: Promise<void> | null = null
function loadGoogleScript() {
  if (!scriptPromise) {
    scriptPromise = new Promise<void>((resolve, reject) => {
      const s = document.createElement('script')
      s.src = 'https://accounts.google.com/gsi/client'
      s.async = true
      s.defer = true
      s.onload = () => resolve()
      s.onerror = () => reject(new Error('Could not load Google sign-in'))
      document.head.appendChild(s)
    })
  }
  return scriptPromise
}

/**
 * Real "Sign in with Google" button (Google Identity Services). It needs a
 * Google OAuth Client ID in frontend/.env (VITE_GOOGLE_CLIENT_ID) and the same
 * id in backend/.env (GOOGLE_CLIENT_ID). Until those are set, it shows a
 * clear explanation instead of a button that silently does nothing.
 */
export function GoogleSignInButton({ onCredential }: { onCredential: (idToken: string) => void }) {
  const ref = useRef<HTMLDivElement>(null)
  const [error, setError] = useState<string | null>(null)
  const callbackRef = useRef(onCredential)
  callbackRef.current = onCredential

  useEffect(() => {
    if (!GOOGLE_CLIENT_ID) return
    let cancelled = false
    loadGoogleScript()
      .then(() => {
        if (cancelled || !ref.current || !window.google) return
        window.google.accounts.id.initialize({
          client_id: GOOGLE_CLIENT_ID,
          callback: (r) => callbackRef.current(r.credential),
        })
        window.google.accounts.id.renderButton(ref.current, { theme: 'outline', size: 'large', width: 320, text: 'continue_with' })
      })
      .catch(() => !cancelled && setError('Could not load Google sign-in. Check your internet connection.'))
    return () => {
      cancelled = true
    }
  }, [])

  if (!GOOGLE_CLIENT_ID) {
    return (
      <p className="text-xs text-center text-muted-foreground border rounded-md p-3">
        Google sign-in is not set up yet. Add <code>VITE_GOOGLE_CLIENT_ID</code> to <code>frontend/.env</code> and{' '}
        <code>GOOGLE_CLIENT_ID</code> to <code>backend/.env</code>, then restart both servers. Meanwhile, sign in with your email and password.
      </p>
    )
  }
  return (
    <div className="flex flex-col items-center gap-2">
      <div ref={ref} />
      {error && <p className="text-xs text-destructive">{error}</p>}
    </div>
  )
}
