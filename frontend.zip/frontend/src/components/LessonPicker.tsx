import { useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { coursesService } from '@/services/courses.service'

interface Props {
  courseId: string
  topicId: string
  subtopicId: string
  onTopic: (id: string) => void
  onSubtopic: (id: string) => void
}

// Two linked drop-downs: topic, then lesson. Used wherever an admin has to say
// "which lesson does this belong to?".
export function LessonPicker({ courseId, topicId, subtopicId, onTopic, onSubtopic }: Props) {
  const { data: course, isLoading } = useQuery({
    queryKey: ['courses', 'detail', courseId],
    queryFn: () => coursesService.get(courseId),
    enabled: !!courseId,
  })
  const topics = useMemo(() => (course?.modules ?? []).flatMap((m: any) => m.topics ?? []), [course])
  const lessons = useMemo(() => topics.find((t: any) => t.id === topicId)?.subtopics ?? [], [topics, topicId])

  if (!courseId) return <p className="text-sm text-muted-foreground">Choose a course first.</p>
  return (
    <div className="grid sm:grid-cols-2 gap-3">
      <Select
        value={topicId}
        onValueChange={(v) => {
          onTopic(v)
          onSubtopic('')
        }}
      >
        <SelectTrigger>
          <SelectValue placeholder={isLoading ? 'Loading topics…' : 'Topic'} />
        </SelectTrigger>
        <SelectContent className="max-h-72">
          {topics.map((t: any) => (
            <SelectItem key={t.id} value={t.id}>
              {t.title}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Select value={subtopicId} onValueChange={onSubtopic} disabled={!topicId}>
        <SelectTrigger>
          <SelectValue placeholder="Lesson" />
        </SelectTrigger>
        <SelectContent className="max-h-72">
          {lessons.map((s: any) => (
            <SelectItem key={s.id} value={s.id}>
              {s.title}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}
