import { useEffect, useRef, useState } from 'react'
import { Link, matchPath, useLocation } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { AlertTriangle, ExternalLink, Loader2, Send, Trash2, X } from 'lucide-react'
import { tutorService } from '@/services/tutor.service'
import { TutorAvatar } from '@/components/TutorAvatar'
import { Markdown } from '@/components/Markdown'
import { useToast } from '@/components/ui/use-toast'
import { ApiRequestError } from '@/lib/apiClient'
import { cn } from '@/utils/cn'

// The chatbot must never be available while a student is sitting an exam,
// assessment, test or quiz (and the server refuses tutor messages during a
// secured exam as well). It is also pointless on the full AI Tutor page.
const HIDDEN_ON = [/^\/exams/, /^\/exam\//, /^\/assessments?/, /^\/tests?(\/|$)/, /^\/quizzes/, /^\/quiz\//, /^\/ai-tutor/]

const QUICK = ['Explain this simply', 'Give me an example', 'Quiz me']

// A small floating version of the AI Tutor. It talks to exactly the same
// backend and shares the same conversation history as the full AI Tutor page.
export function TutorWidget() {
  const { pathname } = useLocation()
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [open, setOpen] = useState(false)
  const [input, setInput] = useState('')
  const scrollRef = useRef<HTMLDivElement>(null)

  const hidden = HIDDEN_ON.some((re) => re.test(pathname))

  // On a course or lesson page, tell the tutor which course the student is looking at.
  // The URL may hold a slug, so use the id of the course the page has already loaded.
  const routeCourse = matchPath({ path: '/courses/:courseId', end: false }, pathname)?.params.courseId
  const loadedCourse = routeCourse ? queryClient.getQueryData<{ id?: string }>(['courses', 'detail', routeCourse]) : undefined
  const courseId = loadedCourse?.id ?? (routeCourse && /^[a-f0-9]{24}$/i.test(routeCourse) ? routeCourse : undefined)

  const { data: history, isLoading } = useQuery({
    queryKey: ['tutor', 'history'],
    queryFn: () => tutorService.history(),
    enabled: open && !hidden,
  })
  const { data: status } = useQuery({
    queryKey: ['tutor', 'status'],
    queryFn: () => tutorService.status(),
    enabled: open && !hidden,
    refetchInterval: (q) => (q.state.data?.ready ? false : 15000),
    retry: false,
  })

  const send = useMutation({
    mutationFn: (message: string) => tutorService.sendMessage(message, courseId),
    onMutate: async (message) => {
      await queryClient.cancelQueries({ queryKey: ['tutor', 'history'] })
      const previous = queryClient.getQueryData(['tutor', 'history'])
      queryClient.setQueryData(['tutor', 'history'], (old: any) => [...(old ?? []), { role: 'user', content: message, timestamp: new Date().toISOString() }])
      return { previous }
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['tutor', 'history'] }),
    onError: (error, _m, ctx) => {
      queryClient.setQueryData(['tutor', 'history'], ctx?.previous)
      toast({ title: 'Could not send', description: error instanceof ApiRequestError ? error.message : 'The AI Tutor is temporarily unavailable.', variant: 'destructive' })
    },
  })

  const clear = useMutation({
    mutationFn: () => tutorService.clearHistory(),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['tutor', 'history'] }),
  })

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [history, open, send.isPending])

  // Close the window when the student moves to a page where the bot is not allowed.
  useEffect(() => {
    if (hidden) setOpen(false)
  }, [hidden])

  // Escape closes the chat window.
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [open])

  if (hidden) return null

  const submit = (text?: string) => {
    const message = (text ?? input).trim()
    if (!message || send.isPending) return
    send.mutate(message)
    setInput('')
  }

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end gap-3 print:hidden">
      {open && (
        <div className="w-[calc(100vw-2.5rem)] sm:w-[370px] h-[min(540px,calc(100vh-7.5rem))] flex flex-col rounded-2xl border bg-card text-card-foreground shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-2">
          {/* header */}
          <div className="flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-indigo-600 to-sky-500 text-white">
            <TutorAvatar size={40} className="rounded-full ring-2 ring-white/70" />
            <div className="min-w-0 flex-1">
              <p className="font-semibold leading-tight">Mira · AI Tutor</p>
              <p className="text-xs text-white/80 flex items-center gap-1">
                <span className={cn('h-1.5 w-1.5 rounded-full', status && !status.ready ? 'bg-amber-300' : 'bg-emerald-300')} />
                {status && !status.ready ? 'Engine not ready' : 'Online'}
              </p>
            </div>
            <button className="p-1.5 rounded-md hover:bg-white/15" title="Clear conversation" onClick={() => clear.mutate()}>
              <Trash2 className="h-4 w-4" />
            </button>
            <Link to="/ai-tutor" className="p-1.5 rounded-md hover:bg-white/15" title="Open the full AI Tutor">
              <ExternalLink className="h-4 w-4" />
            </Link>
            <button className="p-1.5 rounded-md hover:bg-white/15" title="Close" onClick={() => setOpen(false)}>
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3 bg-muted/30">
            {status && !status.ready && (
              <div className="flex gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 p-2.5 text-xs">
                <AlertTriangle className="h-4 w-4 flex-shrink-0 text-amber-600" />
                <p>{status.hint ?? 'The AI engine is not running yet.'}</p>
              </div>
            )}
            {isLoading && <Loader2 className="h-5 w-5 animate-spin text-primary mx-auto" />}
            {!isLoading && (!history || history.length === 0) && (
              <div className="flex gap-2">
                <TutorAvatar size={28} className="flex-shrink-0 rounded-full" />
                <div className="rounded-2xl rounded-tl-sm bg-card border px-3 py-2 text-sm">Hi! I&apos;m Mira, your AI tutor. Ask me anything about what you&apos;re learning.</div>
              </div>
            )}
            {history?.map((m, i) =>
              m.role === 'user' ? (
                <div key={i} className="flex justify-end">
                  <div className="max-w-[85%] rounded-2xl rounded-tr-sm bg-primary text-primary-foreground px-3 py-2 text-sm whitespace-pre-wrap">{m.content}</div>
                </div>
              ) : (
                <div key={i} className="flex gap-2">
                  <TutorAvatar size={28} className="flex-shrink-0 rounded-full" />
                  <div className="max-w-[85%] rounded-2xl rounded-tl-sm bg-card border px-3 py-1 text-sm">
                    <Markdown source={m.content} />
                  </div>
                </div>
              )
            )}
            {send.isPending && (
              <div className="flex gap-2">
                <TutorAvatar size={28} className="flex-shrink-0 rounded-full" />
                <div className="rounded-2xl rounded-tl-sm bg-card border px-3 py-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                </div>
              </div>
            )}
          </div>

          {/* input */}
          <div className="border-t p-3 space-y-2 bg-card">
            <div className="flex flex-wrap gap-1.5">
              {QUICK.map((q) => (
                <button key={q} onClick={() => submit(q)} className="text-xs rounded-full border px-2.5 py-1 hover:bg-muted transition-colors">
                  {q}
                </button>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && !e.nativeEvent.isComposing && submit()}
                placeholder="Ask Mira…"
                className="flex-1 h-10 rounded-full border border-input bg-background px-4 text-sm outline-none focus:ring-2 focus:ring-ring"
              />
              <button
                onClick={() => submit()}
                disabled={!input.trim() || send.isPending}
                className="h-10 w-10 rounded-full bg-primary text-primary-foreground grid place-items-center disabled:opacity-50"
                aria-label="Send"
              >
                <Send className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* launcher */}
      <button
        onClick={() => setOpen((v) => !v)}
        className="relative h-16 w-16 rounded-full shadow-xl ring-4 ring-background hover:scale-105 transition-transform"
        aria-label={open ? 'Close AI Tutor chat' : 'Open AI Tutor chat'}
        title="Ask Mira, your AI tutor"
      >
        {!open && <span className="absolute inset-0 rounded-full bg-primary/40 animate-ping" />}
        <TutorAvatar size={64} className="relative rounded-full" />
      </button>
    </div>
  )
}
