import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { CheckCircle2, ListChecks, Plus, TextCursorInput, Terminal, Trash2 } from 'lucide-react'
import { adminService } from '@/services/admin.service'
import { coursesService } from '@/services/courses.service'
import { LessonPicker } from '@/components/LessonPicker'
import { useToast } from '@/components/ui/use-toast'
import { ApiRequestError } from '@/lib/apiClient'
import { cn } from '@/utils/cn'

const KINDS = [
  {
    id: 'MCQ',
    title: 'Multiple choice',
    icon: ListChecks,
    what: 'The student picks ONE correct option from a list you write.',
    when: 'Best for definitions, concepts and quick checks.',
    example: 'Which keyword defines a function in Python?  →  def / func / function / lambda',
  },
  {
    id: 'SHORT_ANSWER',
    title: 'Short answer',
    icon: TextCursorInput,
    what: 'The student types a word or short phrase. It is marked correct when it matches your answer (capital letters and extra spaces are ignored).',
    when: 'Best when there is one clear answer, like a keyword or a term.',
    example: 'Which built-in function returns the length of a list?  →  len',
  },
  {
    id: 'OUTPUT_PREDICTION',
    title: 'Predict the output',
    icon: Terminal,
    what: 'You paste a small piece of code. The student types exactly what it prints.',
    when: 'Best for checking that students can read and trace code.',
    example: 'print(2 ** 3)   →   8',
  },
] as const

const DIFFICULTIES = ['BEGINNER', 'INTERMEDIATE', 'ADVANCED', 'EXPERT']

interface Props {
  // When set, the course/lesson are fixed (used inside the course content manager).
  fixedCourseId?: string
  fixedSubtopicId?: string
  fixedLabel?: string
  onCreated?: () => void
}

export function QuestionForm({ fixedCourseId, fixedSubtopicId, fixedLabel, onCreated }: Props) {
  const { toast } = useToast()
  const queryClient = useQueryClient()
  const [kind, setKind] = useState<(typeof KINDS)[number]['id']>('MCQ')
  const [content, setContent] = useState('')
  const [options, setOptions] = useState(['', '', '', ''])
  const [correctIdx, setCorrectIdx] = useState(0)
  const [answer, setAnswer] = useState('')
  const [explanation, setExplanation] = useState('')
  const [difficulty, setDifficulty] = useState('BEGINNER')
  const [courseId, setCourseId] = useState(fixedCourseId ?? '')
  const [topicId, setTopicId] = useState('')
  const [subtopicId, setSubtopicId] = useState(fixedSubtopicId ?? '')

  const { data: courses } = useQuery({
    queryKey: ['courses', 'list-for-select'],
    queryFn: () => coursesService.list({ limit: 100 }),
    enabled: !fixedCourseId,
  })

  const cleanOptions = options.map((o) => o.trim()).filter(Boolean)
  const mcqValid = cleanOptions.length >= 2 && !!options[correctIdx]?.trim() && new Set(cleanOptions).size === cleanOptions.length
  const targetCourse = fixedCourseId ?? courseId
  const targetLesson = fixedSubtopicId ?? subtopicId
  const valid = !!content.trim() && !!targetCourse && (kind === 'MCQ' ? mcqValid : !!answer.trim())

  const create = useMutation({
    mutationFn: () => {
      const correctAnswer = kind === 'MCQ' ? options[correctIdx].trim() : answer.trim()
      return adminService.createQuestion({
        type: kind,
        content: content.trim(),
        correctAnswer,
        explanation: explanation.trim() || undefined,
        difficulty,
        courseId: targetCourse,
        subtopicId: targetLesson || undefined,
        estimatedTime: kind === 'MCQ' ? 60 : 90,
        marks: 1,
        options: kind === 'MCQ' ? cleanOptions.map((o) => ({ content: o, isCorrect: o === correctAnswer })) : undefined,
      })
    },
    onSuccess: () => {
      toast({
        title: 'Question saved',
        description: targetLesson
          ? 'Students will now see it in that lesson → Practice tab.'
          : 'Saved to the question bank only. Students will not see it until you add it to a lesson.',
      })
      setContent('')
      setOptions(['', '', '', ''])
      setCorrectIdx(0)
      setAnswer('')
      setExplanation('')
      queryClient.invalidateQueries({ queryKey: ['admin'] })
      onCreated?.()
    },
    onError: (e) => toast({ title: 'Could not save', description: e instanceof ApiRequestError ? e.message : 'Please check the form.', variant: 'destructive' }),
  })

  const active = KINDS.find((k) => k.id === kind)!

  return (
    <div className="space-y-6">
      {/* STEP 1 */}
      <section className="space-y-3">
        <h3 className="font-semibold flex items-center gap-2">
          <span className="h-6 w-6 rounded-full bg-primary text-primary-foreground text-xs grid place-items-center">1</span>
          What kind of question is it?
        </h3>
        <div className="grid md:grid-cols-3 gap-3">
          {KINDS.map((k) => (
            <button
              key={k.id}
              type="button"
              onClick={() => setKind(k.id)}
              className={cn(
                'text-left rounded-xl border p-4 transition-all hover:border-primary/60',
                kind === k.id ? 'border-primary bg-primary/5 ring-1 ring-primary' : 'bg-card'
              )}
            >
              <div className="flex items-center gap-2 font-medium">
                <k.icon className="h-5 w-5 text-primary" />
                {k.title}
                {kind === k.id && <CheckCircle2 className="h-4 w-4 text-primary ml-auto" />}
              </div>
              <p className="text-sm text-muted-foreground mt-2">{k.what}</p>
              <p className="text-xs text-muted-foreground mt-2">
                <b>Use it:</b> {k.when}
              </p>
              <p className="text-xs mt-2 rounded bg-muted px-2 py-1 font-mono">{k.example}</p>
            </button>
          ))}
        </div>
      </section>

      {/* STEP 2 */}
      <section className="space-y-3">
        <h3 className="font-semibold flex items-center gap-2">
          <span className="h-6 w-6 rounded-full bg-primary text-primary-foreground text-xs grid place-items-center">2</span>
          Write the question
        </h3>
        <textarea
          className={cn('w-full min-h-[110px] rounded-md border border-input bg-background p-3 text-sm', kind === 'OUTPUT_PREDICTION' && 'font-mono')}
          placeholder={kind === 'OUTPUT_PREDICTION' ? 'Paste the code here, for example:\nx = 5\nprint(x * 2)' : 'Type the question the student will see'}
          value={content}
          onChange={(e) => setContent(e.target.value)}
        />

        {kind === 'MCQ' ? (
          <div className="space-y-2">
            <p className="text-sm text-muted-foreground">Write the options, then tick the one that is correct.</p>
            {options.map((o, i) => (
              <div key={i} className="flex items-center gap-2">
                <input type="radio" name="correct" checked={correctIdx === i} onChange={() => setCorrectIdx(i)} className="h-4 w-4 accent-[hsl(var(--primary))]" title="Mark as the correct answer" />
                <Input placeholder={`Option ${String.fromCharCode(65 + i)}`} value={o} onChange={(e) => setOptions(options.map((x, n) => (n === i ? e.target.value : x)))} />
                {options.length > 2 && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => {
                      setOptions(options.filter((_, n) => n !== i))
                      setCorrectIdx((c) => (c === i ? 0 : c > i ? c - 1 : c))
                    }}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
            {options.length < 6 && (
              <Button type="button" variant="outline" size="sm" onClick={() => setOptions([...options, ''])}>
                <Plus className="h-4 w-4 mr-1" /> Add option
              </Button>
            )}
            {cleanOptions.length >= 2 && new Set(cleanOptions).size !== cleanOptions.length && <p className="text-xs text-destructive">Two options are identical — make each one different.</p>}
          </div>
        ) : (
          <Input
            placeholder={kind === 'OUTPUT_PREDICTION' ? 'Exact output the code prints (e.g. 10)' : 'The correct answer (e.g. len)'}
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
          />
        )}

        <textarea
          className="w-full min-h-[60px] rounded-md border border-input bg-background p-3 text-sm"
          placeholder="Explanation (optional) — shown to the student after they answer"
          value={explanation}
          onChange={(e) => setExplanation(e.target.value)}
        />
      </section>

      {/* STEP 3 */}
      <section className="space-y-3">
        <h3 className="font-semibold flex items-center gap-2">
          <span className="h-6 w-6 rounded-full bg-primary text-primary-foreground text-xs grid place-items-center">3</span>
          Where should students see it?
        </h3>
        {fixedSubtopicId ? (
          <p className="text-sm rounded-md bg-primary/5 border border-primary/20 p-3">
            It will be added to the Practice tab of <b>{fixedLabel ?? 'this lesson'}</b>.
          </p>
        ) : (
          <>
            <Select
              value={courseId}
              onValueChange={(v) => {
                setCourseId(v)
                setTopicId('')
                setSubtopicId('')
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Course" />
              </SelectTrigger>
              <SelectContent>
                {courses?.data.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <LessonPicker courseId={courseId} topicId={topicId} subtopicId={subtopicId} onTopic={setTopicId} onSubtopic={setSubtopicId} />
            <p className={cn('text-sm rounded-md p-3 border', subtopicId ? 'bg-primary/5 border-primary/20' : 'bg-amber-50 border-amber-200 text-amber-900 dark:bg-amber-500/10 dark:text-amber-200 dark:border-amber-500/30')}>
              {subtopicId
                ? 'Students will find it in: Courses → this course → this lesson → Practice tab → “Start practice questions”.'
                : 'No lesson chosen: the question is saved in the question bank only, so students will NOT see it yet. Pick a lesson to publish it to students.'}
            </p>
          </>
        )}
        <div className="max-w-xs">
          <Select value={difficulty} onValueChange={setDifficulty}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {DIFFICULTIES.map((d) => (
                <SelectItem key={d} value={d}>
                  {d.charAt(0) + d.slice(1).toLowerCase()}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </section>

      <div className="flex items-center gap-3">
        <Button onClick={() => create.mutate()} isLoading={create.isPending} disabled={!valid}>
          Save {active.title.toLowerCase()} question
        </Button>
        {!valid && <span className="text-xs text-muted-foreground">Fill in the course, the question and {kind === 'MCQ' ? 'at least two different options with the correct one ticked' : 'the correct answer'}.</span>}
      </div>
    </div>
  )
}
