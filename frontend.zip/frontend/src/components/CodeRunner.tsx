import { useEffect, useRef, useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import Editor from '@monaco-editor/react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Loader2, Play } from 'lucide-react'
import { codingService } from '@/services/coding.service'
import { useToast } from '@/components/ui/use-toast'
import { ApiRequestError } from '@/lib/apiClient'
import { LANGUAGES, PLAYGROUND_STARTER } from '@/lib/codeTemplates'

interface Props {
  defaultLanguage?: string
  // When this changes (e.g. the student clicks "Try it" on a note example) the editor is replaced.
  loadCode?: { code: string; language: string; nonce: number } | null
  height?: number
}

// A self-contained multi-language editor: pick a language, write code, give it
// input and press Run. Used inside lessons so students can practise right there.
export function CodeRunner({ defaultLanguage = 'python', loadCode, height = 320 }: Props) {
  const { toast } = useToast()
  const [language, setLanguage] = useState(defaultLanguage)
  const [code, setCode] = useState(PLAYGROUND_STARTER[defaultLanguage] ?? '')
  const [stdin, setStdin] = useState('')
  const lastNonce = useRef<number | null>(null)

  useEffect(() => {
    if (loadCode && loadCode.nonce !== lastNonce.current) {
      lastNonce.current = loadCode.nonce
      setLanguage(loadCode.language)
      setCode(loadCode.code)
    }
  }, [loadCode])

  const run = useMutation({
    mutationFn: () => codingService.run(code, language, language === 'sql' ? '' : stdin),
    onError: (e) => toast({ title: 'Could not run code', description: e instanceof ApiRequestError ? e.message : 'Please try again.', variant: 'destructive' }),
  })

  const result = run.data
  const monacoLang = LANGUAGES.find((l) => l.id === language)?.monaco ?? 'plaintext'

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Select
          value={language}
          onValueChange={(lang) => {
            setLanguage(lang)
            setCode(PLAYGROUND_STARTER[lang] ?? '')
          }}
        >
          <SelectTrigger className="w-[160px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {LANGUAGES.map((l) => (
              <SelectItem key={l.id} value={l.id}>
                {l.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={() => setCode(PLAYGROUND_STARTER[language] ?? '')}>
            Reset
          </Button>
          <Button size="sm" onClick={() => run.mutate()} isLoading={run.isPending}>
            <Play className="h-4 w-4 mr-2" />
            Run
          </Button>
        </div>
      </div>

      <div className="border rounded-md overflow-hidden" style={{ height }}>
        <Editor
          height="100%"
          language={monacoLang}
          value={code}
          onChange={(v) => setCode(v ?? '')}
          theme="vs-dark"
          options={{ fontSize: 14, minimap: { enabled: false }, scrollBeyondLastLine: false, automaticLayout: true, tabSize: 4 }}
          loading={<Loader2 className="h-6 w-6 animate-spin text-primary" />}
        />
      </div>

      {language !== 'sql' && (
        <div>
          <label className="text-sm font-medium">Input (stdin) — optional</label>
          <textarea
            value={stdin}
            onChange={(e) => setStdin(e.target.value)}
            placeholder="If your program reads input, type it here (one value per line)"
            className="mt-1 w-full min-h-[60px] p-2 border rounded-md font-mono text-sm bg-background"
            spellCheck={false}
          />
        </div>
      )}

      <Card>
        <CardHeader className="py-3">
          <CardTitle className="text-sm flex items-center justify-between">
            <span>Output</span>
            {result && (
              <span className="text-xs font-normal text-muted-foreground">
                {result.timedOut ? 'Time limit exceeded' : `exit ${result.exitCode}`} · {result.executionTimeMs} ms
              </span>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          {run.isPending ? (
            <Loader2 className="h-5 w-5 animate-spin text-primary" />
          ) : !result ? (
            <p className="text-sm text-muted-foreground">Press Run to see the output here.</p>
          ) : (
            <div className="space-y-2">
              {result.stdout && <pre className="text-sm bg-muted rounded p-3 whitespace-pre-wrap overflow-auto max-h-56">{result.stdout}</pre>}
              {result.stderr && <pre className="text-sm bg-red-50 text-red-700 rounded p-3 whitespace-pre-wrap overflow-auto max-h-56">{result.stderr}</pre>}
              {!result.stdout && !result.stderr && <p className="text-sm text-muted-foreground">(no output)</p>}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
