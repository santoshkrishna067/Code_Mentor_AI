import { Fragment, type ReactNode } from 'react'
import { CodeBlock } from '@/components/CodeBlock'

// A small, dependency-free Markdown renderer for lesson notes: headings, paragraphs,
// bullet / numbered lists, block quotes, rules, fenced code blocks, links, **bold**,
// *italic* and `inline code`. Everything is rendered as React nodes (no HTML injection).
function inline(text: string): ReactNode[] {
  const out: ReactNode[] = []
  const re = /(`[^`]+`|\*\*[^*]+\*\*|\[[^\]]+\]\(https?:\/\/[^)\s]+\)|\*[^*\s][^*]*\*)/g
  let last = 0
  let m: RegExpExecArray | null
  let i = 0
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(text.slice(last, m.index))
    const tok = m[0]
    if (tok.startsWith('`')) {
      out.push(
        <code key={i++} className="px-1.5 py-0.5 rounded-md bg-primary/10 text-primary text-[0.88em] font-mono border border-primary/15">
          {tok.slice(1, -1)}
        </code>
      )
    } else if (tok.startsWith('**')) {
      out.push(<strong key={i++} className="font-semibold text-foreground">{tok.slice(2, -2)}</strong>)
    } else if (tok.startsWith('[')) {
      const mm = /^\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)$/.exec(tok)
      if (mm) {
        out.push(
          <a key={i++} href={mm[2]} target="_blank" rel="noreferrer" className="text-primary underline underline-offset-2 hover:opacity-80">
            {mm[1]}
          </a>
        )
      } else out.push(tok)
    } else out.push(<em key={i++}>{tok.slice(1, -1)}</em>)
    last = m.index + tok.length
  }
  if (last < text.length) out.push(text.slice(last))
  return out
}

const isBullet = (l: string) => /^\s*[-*]\s+/.test(l)
const isNumbered = (l: string) => /^\s*\d+\.\s+/.test(l)
const isQuote = (l: string) => /^\s*>\s?/.test(l)
const isRule = (l: string) => /^\s*(-{3,}|\*{3,})\s*$/.test(l)
const isHeading = (l: string) => /^(#{1,4})\s+/.test(l)
const isFence = (l: string) => l.trim().startsWith('```')

export function Markdown({ source }: { source: string }) {
  const lines = source.replace(/\r\n/g, '\n').split('\n')
  const blocks: ReactNode[] = []
  let i = 0
  let key = 0
  while (i < lines.length) {
    const line = lines[i]
    if (isFence(line)) {
      const language = line.trim().slice(3).trim()
      const code: string[] = []
      i++
      while (i < lines.length && !isFence(lines[i])) code.push(lines[i++])
      i++
      blocks.push(<CodeBlock key={key++} code={code.join('\n')} language={language || undefined} />)
      continue
    }
    const h = /^(#{1,4})\s+(.*)$/.exec(line)
    if (h) {
      const level = h[1].length
      if (level <= 2) {
        blocks.push(
          <h2 key={key++} className="text-2xl font-bold tracking-tight mt-9 mb-3 pb-2 border-b border-border/70 first:mt-0">
            {inline(h[2])}
          </h2>
        )
      } else if (level === 3) {
        blocks.push(<h3 key={key++} className="text-lg font-semibold tracking-tight mt-7 mb-2">{inline(h[2])}</h3>)
      } else {
        blocks.push(<h4 key={key++} className="text-base font-semibold mt-5 mb-1 text-foreground/90">{inline(h[2])}</h4>)
      }
      i++
      continue
    }
    if (isRule(line)) {
      blocks.push(<hr key={key++} className="my-8 border-border" />)
      i++
      continue
    }
    if (isQuote(line)) {
      const quote: string[] = []
      while (i < lines.length && isQuote(lines[i])) quote.push(lines[i++].replace(/^\s*>\s?/, ''))
      blocks.push(
        <blockquote key={key++} className="my-5 rounded-r-xl border-l-4 border-primary/70 bg-primary/5 px-4 py-3 text-foreground/90 leading-7">
          {inline(quote.join(' '))}
        </blockquote>
      )
      continue
    }
    if (isBullet(line)) {
      const items: string[] = []
      while (i < lines.length && isBullet(lines[i])) items.push(lines[i++].replace(/^\s*[-*]\s+/, ''))
      blocks.push(
        <ul key={key++} className="list-disc pl-6 space-y-2 my-4 leading-7 marker:text-primary">
          {items.map((t, n) => <li key={n}>{inline(t)}</li>)}
        </ul>
      )
      continue
    }
    if (isNumbered(line)) {
      const items: string[] = []
      while (i < lines.length && isNumbered(lines[i])) items.push(lines[i++].replace(/^\s*\d+\.\s+/, ''))
      blocks.push(
        <ol key={key++} className="list-decimal pl-6 space-y-2 my-4 leading-7 marker:text-primary marker:font-semibold">
          {items.map((t, n) => <li key={n}>{inline(t)}</li>)}
        </ol>
      )
      continue
    }
    if (!line.trim()) {
      i++
      continue
    }
    const para: string[] = []
    while (i < lines.length && lines[i].trim() && !isFence(lines[i]) && !isHeading(lines[i]) && !isBullet(lines[i]) && !isNumbered(lines[i]) && !isQuote(lines[i]) && !isRule(lines[i])) para.push(lines[i++])
    blocks.push(<p key={key++} className="my-4 leading-8 text-foreground/90">{inline(para.join(' '))}</p>)
  }
  return <Fragment>{blocks}</Fragment>
}
