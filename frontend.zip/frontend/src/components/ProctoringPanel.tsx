import { useEffect, useRef, useState } from 'react'
import { AlertTriangle, Camera, EyeOff, Loader2, ShieldCheck, Smartphone, UserX, Users, WifiOff } from 'lucide-react'
import type { LucideIcon } from 'lucide-react'
import { proctoringService, type FrameAnalysis, type VisionStatus } from '@/services/proctoring.service'
import { ApiRequestError } from '@/lib/apiClient'
import { useToast } from '@/components/ui/use-toast'
import { cn } from '@/utils/cn'

// Live camera preview for a proctored exam. Once a second it grabs a frame from
// the camera, sends it to the server for face analysis, and shows the result:
// a box around the detected face and a plain-language status line. The server
// (not this component) decides what counts as a warning.

const FRAME_INTERVAL_MS = 1000
const CAPTURE_WIDTH = 640
const JPEG_QUALITY = 0.7
const FAILURES_BEFORE_OFFLINE = 3

type PanelStatus = VisionStatus | 'connecting'
type Tone = 'ok' | 'warn' | 'bad' | 'muted'

const STATUS_UI: Record<PanelStatus, { label: string; tone: Tone; Icon: LucideIcon }> = {
  connecting: { label: 'Starting camera check…', tone: 'muted', Icon: Loader2 },
  calibrating: { label: 'Calibrating — look at the screen', tone: 'muted', Icon: Loader2 },
  ok: { label: 'Proctoring active', tone: 'ok', Icon: ShieldCheck },
  no_face: { label: 'Face not visible — stay in view', tone: 'bad', Icon: UserX },
  multiple_faces: { label: 'More than one person detected', tone: 'bad', Icon: Users },
  phone: { label: 'Phone detected — put it away', tone: 'bad', Icon: Smartphone },
  looking_away: { label: 'Please look at the screen', tone: 'warn', Icon: EyeOff },
  unavailable: { label: 'Camera check unavailable', tone: 'warn', Icon: WifiOff },
}

const TONE_CLASS: Record<Tone, string> = {
  ok: 'bg-emerald-50 text-emerald-800 dark:bg-emerald-500/15 dark:text-emerald-300',
  warn: 'bg-amber-50 text-amber-800 dark:bg-amber-500/15 dark:text-amber-300',
  bad: 'bg-red-50 text-red-800 dark:bg-red-500/15 dark:text-red-300',
  muted: 'bg-muted text-muted-foreground',
}

interface Props {
  stream: MediaStream
  attemptId: string
  /** Called when the server ended the attempt because of the warnings. */
  onEscalated: (reason?: string) => void
  /** Called when the camera track stops (unplugged, turned off). */
  onCameraLost: () => void
}

export default function ProctoringPanel({ stream, attemptId, onEscalated, onCameraLost }: Props) {
  const { toast } = useToast()
  const videoRef = useRef<HTMLVideoElement>(null)
  const [analysis, setAnalysis] = useState<FrameAnalysis | null>(null)
  const [offline, setOffline] = useState(false)
  const [warningCount, setWarningCount] = useState(0)

  // Latest callbacks, so the capture loop below does not restart on every parent render.
  const onEscalatedRef = useRef(onEscalated)
  const onCameraLostRef = useRef(onCameraLost)
  const toastRef = useRef(toast)
  useEffect(() => {
    onEscalatedRef.current = onEscalated
    onCameraLostRef.current = onCameraLost
    toastRef.current = toast
  })

  // Show the live camera. (Attached here, where the <video> element actually exists.)
  useEffect(() => {
    const video = videoRef.current
    if (!video) return
    video.srcObject = stream
    video.play().catch(() => undefined)
    return () => {
      video.srcObject = null
    }
  }, [stream])

  // Camera unplugged / turned off mid-exam.
  useEffect(() => {
    const track = stream.getVideoTracks()[0]
    if (!track) return
    const handleEnded = () => onCameraLostRef.current()
    track.addEventListener('ended', handleEnded)
    return () => track.removeEventListener('ended', handleEnded)
  }, [stream])

  // Capture loop: one frame per second, never more than one request in flight.
  useEffect(() => {
    let stopped = false
    let inFlight = false
    let failures = 0
    const canvas = document.createElement('canvas')

    const tick = async () => {
      const video = videoRef.current
      if (stopped || inFlight || !video || video.readyState < 2 || video.videoWidth === 0) return
      inFlight = true
      try {
        const width = CAPTURE_WIDTH
        const height = Math.round((video.videoHeight / video.videoWidth) * width)
        canvas.width = width
        canvas.height = height
        const ctx = canvas.getContext('2d')
        if (!ctx) return
        ctx.drawImage(video, 0, 0, width, height)
        const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/jpeg', JPEG_QUALITY))
        if (!blob || stopped) return

        const result = await proctoringService.analyzeFrame(attemptId, blob)
        if (stopped) return
        failures = 0
        setOffline(false)
        setAnalysis(result)
        if (result.totalCount !== undefined) setWarningCount(result.totalCount)
        for (const w of result.newWarnings) {
          toastRef.current({ title: 'Proctoring warning', description: w.message, variant: 'destructive' })
        }
        if (result.escalated) {
          stopped = true
          clearInterval(timer)
          onEscalatedRef.current(result.reason)
        }
      } catch (err) {
        // 409 = the session already ended (submitted / flagged): just stop sending.
        if (err instanceof ApiRequestError && err.status === 409) {
          stopped = true
          clearInterval(timer)
          return
        }
        failures += 1
        if (failures >= FAILURES_BEFORE_OFFLINE) setOffline(true)
      } finally {
        inFlight = false
      }
    }

    const timer = setInterval(() => void tick(), FRAME_INTERVAL_MS)
    void tick()
    return () => {
      stopped = true
      clearInterval(timer)
    }
  }, [attemptId])

  const status: PanelStatus = offline || analysis?.status === 'unavailable' ? 'unavailable' : analysis?.status ?? 'connecting'
  const ui = STATUS_UI[status]
  const frameW = analysis?.frame?.width ?? 640
  const frameH = analysis?.frame?.height ?? 480

  return (
    <div className="fixed bottom-4 right-4 z-40 w-60 overflow-hidden rounded-lg border bg-card text-card-foreground shadow-lg" aria-label="Exam camera">
      <div className="relative aspect-[4/3] w-full bg-black">
        <video ref={videoRef} autoPlay muted playsInline className="absolute inset-0 h-full w-full object-contain" />
        <svg
          className="pointer-events-none absolute inset-0 h-full w-full"
          viewBox={`0 0 ${frameW} ${frameH}`}
          preserveAspectRatio="xMidYMid meet"
          aria-hidden="true"
        >
          {analysis?.faces.map((f, i) => (
            <rect
              key={i}
              x={f.x}
              y={f.y}
              width={f.w}
              height={f.h}
              rx={8}
              fill="none"
              strokeWidth={3}
              stroke={!f.significant ? '#9ca3af' : ui.tone === 'ok' ? '#22c55e' : '#ef4444'}
            />
          ))}
        </svg>
        <Camera className="absolute left-1.5 top-1.5 h-3.5 w-3.5 text-white drop-shadow" aria-hidden="true" />
        <span className="absolute right-1.5 top-1.5 flex items-center gap-1 rounded bg-black/55 px-1.5 py-0.5 text-[10px] font-medium text-white">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-500" /> LIVE
        </span>
      </div>
      <div className={cn('flex items-center gap-2 px-3 py-2 text-xs font-medium', TONE_CLASS[ui.tone])} role="status" aria-live="polite">
        <ui.Icon className={cn('h-4 w-4 shrink-0', ui.Icon === Loader2 && 'animate-spin')} aria-hidden="true" />
        <span className="leading-tight">{ui.label}</span>
      </div>
      <div className="flex items-center justify-between border-t px-3 py-1.5 text-[11px] text-muted-foreground">
        <span>Frames are checked live, not stored.</span>
        {warningCount > 0 && (
          <span className="flex items-center gap-1 font-medium text-foreground">
            <AlertTriangle className="h-3 w-3" aria-hidden="true" />
            {warningCount}
          </span>
        )}
      </div>
    </div>
  )
}
