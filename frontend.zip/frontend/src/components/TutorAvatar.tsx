// Original illustration of the AI tutor: a friendly female AI-bot with a
// headset, hair buns and softly glowing eyes. Pure SVG, no external files.
import { useId } from 'react'

export function TutorAvatar({ size = 48, className = '' }: { size?: number; className?: string }) {
  // Unique gradient ids: several avatars are on screen at once (launcher + chat bubbles).
  const uid = useId().replace(/[^a-zA-Z0-9]/g, '')
  const bg = `tb-bg-${uid}`
  const hair = `tb-hair-${uid}`
  const face = `tb-face-${uid}`
  return (
    <svg width={size} height={size} viewBox="0 0 96 96" className={className} role="img" aria-label="AI tutor avatar">
      <defs>
        <linearGradient id={bg} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#6366f1" />
          <stop offset="1" stopColor="#0ea5e9" />
        </linearGradient>
        <linearGradient id={hair} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7c3aed" />
          <stop offset="1" stopColor="#4c1d95" />
        </linearGradient>
        <linearGradient id={face} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f8fafc" />
          <stop offset="1" stopColor="#dbeafe" />
        </linearGradient>
      </defs>
      <circle cx="48" cy="48" r="48" fill={`url(#${bg})`} />
      {/* hair buns */}
      <circle cx="24" cy="26" r="11" fill={`url(#${hair})`} />
      <circle cx="72" cy="26" r="11" fill={`url(#${hair})`} />
      {/* back hair */}
      <path d="M17 52c0-22 14-34 31-34s31 12 31 34c0 8-2 15-6 21H23c-4-6-6-13-6-21z" fill={`url(#${hair})`} />
      {/* face */}
      <ellipse cx="48" cy="52" rx="23" ry="25" fill={`url(#${face})`} />
      {/* fringe */}
      <path d="M25 46c4-14 14-20 26-20 11 0 19 6 22 18-8-5-15-8-23-8-9 0-17 3-25 10z" fill={`url(#${hair})`} />
      {/* eyes */}
      <ellipse cx="38" cy="54" rx="4.2" ry="5.2" fill="#0f172a" />
      <ellipse cx="58" cy="54" rx="4.2" ry="5.2" fill="#0f172a" />
      <circle cx="39.6" cy="52.2" r="1.7" fill="#67e8f9" />
      <circle cx="59.6" cy="52.2" r="1.7" fill="#67e8f9" />
      {/* blush + smile */}
      <circle cx="31" cy="63" r="3.2" fill="#fda4af" opacity=".6" />
      <circle cx="65" cy="63" r="3.2" fill="#fda4af" opacity=".6" />
      <path d="M41 66c3.5 4 10.5 4 14 0" stroke="#0f172a" strokeWidth="2.2" strokeLinecap="round" fill="none" />
      {/* headset */}
      <path d="M18 54c-1-20 11-33 30-33s31 13 30 33" stroke="#e2e8f0" strokeWidth="4" strokeLinecap="round" fill="none" />
      <rect x="11" y="50" width="9" height="16" rx="4.5" fill="#e2e8f0" />
      <rect x="76" y="50" width="9" height="16" rx="4.5" fill="#e2e8f0" />
      <path d="M80 64c0 8-6 12-16 12" stroke="#e2e8f0" strokeWidth="3" strokeLinecap="round" fill="none" />
      <circle cx="62" cy="76" r="3" fill="#22d3ee" />
      {/* bot antenna-earrings */}
      <circle cx="15" cy="70" r="2.6" fill="#22d3ee" />
      <circle cx="81" cy="70" r="2.6" fill="#22d3ee" />
    </svg>
  )
}
