import { Navigate, Outlet, useLocation } from 'react-router-dom'
import { useAuth } from '@/context/AuthContext'
import { Loader2 } from 'lucide-react'

// Wraps a route group (see src/app/App.tsx) so student/admin areas require a
// real, verified session instead of being reachable by anyone who types the
// URL. This is a client-side convenience only — every backend route also
// independently enforces its own auth/RBAC, which is the actual security
// boundary (see backend requireAuth/requireRole middleware).
export function ProtectedRoute({ role }: { role?: 'student' | 'admin' }) {
  const { isAuthenticated, isLoading, user } = useAuth()
  const location = useLocation()

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />
  }

  if (role && user?.role !== role) {
    return <Navigate to={user?.role === 'admin' ? '/admin' : '/dashboard'} replace />
  }

  return <Outlet />
}
