import { useState, useEffect, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { useQuery, useMutation } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Clock, ChevronLeft, ChevronRight, Flag, Loader2, CheckCircle2, XCircle, Lightbulb, RotateCcw } from 'lucide-react'
import { useToast } from '@/components/ui/use-toast'
import { ApiRequestError } from '@/lib/apiClient'
import { CodeBlock } from '@/components/CodeBlock'
import { cn } from '@/utils/cn'
import type { AttemptQuestion, GradingResult, SubmittedAnswer } from '@/services/gradedContent.factory'

export interface GradedAttemptService {
  getForAttempt(id: string): Promise<{ id: string; title: string; description?: string; questions: AttemptQuestion[]; duration?: number } & Record<string, unknown>>
  submit(id: string, answers: SubmittedAnswer[], ...extra: unknown[]): Promise<GradingResult>
}

// What each question type means, shown to the student above the answer box.
const KIND: Record<string, { label: string; help: string }> = {
  mcq: { label: 'Multiple choice', help: 'Pick the one correct option.' },
  multiple_choice: { label: 'Multiple choice', help: 'Pick the one correct option.' },
  short_answer: { label: 'Short answer', help: 'Type a word or short phrase. Capital letters and extra spaces do not matter.' },
  output_prediction: { label: 'Predict the output', help: 'Read the code, then type exactly what it prints.' },
}

const asText = (a: string | string[] | undefined) => (Array.isArray(a) ? a.join(', ') : a ?? '')

function QuestionBody({ q, className }: { q: AttemptQuestion; className?: string }) {
  // Code in "predict the output" questions is shown as a code block, not as prose.
  if (q.type === 'output_prediction') return <CodeBlock code={q.content} className={cn('my-0', className)} />
  return <p className={cn('whitespace-pre-wrap text-base leading-7 text-foreground/90', className)}>{q.content}</p>
}

export function GradedAttemptRunner({
  id,
  service,
  backLink,
  backLabel = 'Back',
  timed = false,
  queryKeyPrefix,
}: {
  id: string
  service: GradedAttemptService
  backLink: string | -1
  backLabel?: string
  timed?: boolean
  queryKeyPrefix: string
}) {
  const navigate = useNavigate()
  const { toast } = useToast()
  const [currentIndex, setCurrentIndex] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string | string[]>>({})
  const [marked, setMarked] = useState<Set<string>>(new Set())
  const [secondsElapsed, setSecondsElapsed] = useState(0)
  const [result, setResult] = useState<(GradingResult & { showResults?: boolean; timeSpentSeconds?: number }) | null>(null)

  const { data, isLoading } = useQuery({
    queryKey: [queryKeyPrefix, 'attempt', id],
    queryFn: () => service.getForAttempt(id),
    enabled: !!id,
    staleTime: 0, // always load the latest questions - the admin may have just changed them
  })

  useEffect(() => {
    if (!timed || result) return
    const interval = setInterval(() => setSecondsElapsed((s) => s + 1), 1000)
    return () => clearInterval(interval)
  }, [timed, result])

  const submitMutation = useMutation({
    mutationFn: () => {
      const submittedAnswers: SubmittedAnswer[] = Object.entries(answers)
        .filter(([, answer]) => (Array.isArray(answer) ? answer.length > 0 : String(answer).trim() !== ''))
        .map(([questionId, answer]) => ({ questionId, answer }))
      return timed ? service.submit(id, submittedAnswers, secondsElapsed) : service.submit(id, submittedAnswers)
    },
    onSuccess: (res) => {
      setResult(res)
      window.scrollTo({ top: 0, behavior: 'smooth' })
      toast({ title: res.passed ? 'Passed!' : 'Submitted', description: `Score: ${res.scorePercent}%${res.xpEarned ? ` · +${res.xpEarned} XP` : ''}` })
    },
    onError: (error) => {
      const message = error instanceof ApiRequestError ? error.message : 'Could not submit. Please try again.'
      toast({ title: 'Submission failed', description: message, variant: 'destructive' })
    },
  })

  const timeLabel = useMemo(() => {
    const m = Math.floor(secondsElapsed / 60)
    const s = secondsElapsed % 60
    return `${m}:${s.toString().padStart(2, '0')}`
  }, [secondsElapsed])

  const goBack = () => (typeof backLink === 'string' ? navigate(backLink) : navigate(-1))

  const retry = () => {
    setResult(null)
    setAnswers({})
    setMarked(new Set())
    setCurrentIndex(0)
    setSecondsElapsed(0)
  }

  if (isLoading) {
    return (
      <div className="flex justify-center py-24">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!data) {
    return <p className="text-center text-muted-foreground py-24">This could not be found.</p>
  }

  const questions = data.questions
  if (questions.length === 0) {
    return (
      <div className="max-w-md mx-auto text-center py-24 space-y-4">
        <p className="text-muted-foreground">There are no questions in this set yet. Please check back later.</p>
        <Button variant="outline" onClick={goBack}>{backLabel}</Button>
      </div>
    )
  }

  if (result) {
    const reviewById = new Map((result.review ?? []).map((r) => [r.questionId, r]))
    return (
      <div className="max-w-3xl mx-auto space-y-8 py-6">
        <div className="text-center space-y-3">
          {result.passed ? <CheckCircle2 className="h-16 w-16 text-green-500 mx-auto" /> : <XCircle className="h-16 w-16 text-destructive mx-auto" />}
          <h1 className="text-3xl font-bold">{result.passed ? 'Nice work!' : 'Keep practicing'}</h1>
          <div className="text-5xl font-bold text-primary">{result.scorePercent}%</div>
          <div className="flex justify-center gap-6 text-sm text-muted-foreground">
            <span>{result.correctCount} correct</span>
            <span>{result.incorrectCount} incorrect</span>
            <span>{result.unansweredCount} unanswered</span>
          </div>
          {result.xpEarned > 0 && <Badge variant="secondary">+{result.xpEarned} XP earned</Badge>}
          <div className="flex justify-center gap-3 pt-2">
            <Button onClick={goBack}>{backLabel}</Button>
            <Button variant="outline" onClick={retry}>
              <RotateCcw className="h-4 w-4 mr-2" />
              Try again
            </Button>
          </div>
        </div>

        {result.review && (
          <section className="space-y-4">
            <h2 className="text-xl font-semibold">Review your answers</h2>
            {questions.map((q, n) => {
              const r = reviewById.get(q.id)
              if (!r) return null
              const given = asText(answers[q.id]).trim()
              return (
                <Card key={q.id} className={cn('border-l-4', r.isCorrect ? 'border-l-emerald-500' : given ? 'border-l-rose-500' : 'border-l-amber-500')}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between gap-3">
                      <CardTitle className="text-base">Question {n + 1}</CardTitle>
                      <Badge variant={r.isCorrect ? 'success' : given ? 'destructive' : 'warning'}>{r.isCorrect ? 'Correct' : given ? 'Incorrect' : 'Not answered'}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <QuestionBody q={q} />
                    <p>
                      <span className="text-muted-foreground">Your answer: </span>
                      <span className={cn('font-medium', r.isCorrect ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400')}>{given || '—'}</span>
                    </p>
                    {!r.isCorrect && (
                      <p>
                        <span className="text-muted-foreground">Correct answer: </span>
                        <span className="font-medium text-emerald-600 dark:text-emerald-400">{asText(r.correctAnswer)}</span>
                      </p>
                    )}
                    {r.explanation && (
                      <div className="flex gap-2 rounded-lg border border-primary/25 bg-primary/5 p-3">
                        <Lightbulb className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                        <p className="leading-6 whitespace-pre-wrap">{r.explanation}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )
            })}
          </section>
        )}
      </div>
    )
  }

  const question = questions[currentIndex]
  const kind = KIND[question.type]
  const unanswered = questions.filter((q) => !String(answers[q.id] ?? '').trim()).length

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">{data.title}</h1>
          {data.description && <p className="text-muted-foreground">{data.description}</p>}
        </div>
        <div className="flex items-center gap-4">
          {timed && (
            <Badge variant="outline">
              <Clock className="h-4 w-4 mr-2" />
              {timeLabel}
            </Badge>
          )}
          <Badge>
            Question {currentIndex + 1}/{questions.length}
          </Badge>
        </div>
      </div>

      <Progress value={((currentIndex + 1) / questions.length) * 100} />

      <Card className="rounded-2xl">
        <CardHeader className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <CardTitle className="text-xl">Question {currentIndex + 1}</CardTitle>
            {kind && <Badge variant="secondary">{kind.label}</Badge>}
          </div>
          {kind && <p className="text-sm text-muted-foreground">{kind.help}</p>}
          <QuestionBody q={question} />
        </CardHeader>
        <CardContent className="space-y-3">
          {question.options && question.options.length > 0 ? (
            question.options.map((opt, n) => {
              const chosen = answers[question.id] === opt.content
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => setAnswers({ ...answers, [question.id]: opt.content })}
                  className={cn(
                    'w-full flex items-center gap-3 rounded-xl border p-3.5 text-left text-sm transition-colors',
                    chosen ? 'border-primary bg-primary/10 ring-1 ring-primary' : 'bg-background hover:bg-muted/60'
                  )}
                >
                  <span className={cn('h-7 w-7 rounded-full grid place-items-center text-xs font-semibold flex-shrink-0', chosen ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground')}>
                    {String.fromCharCode(65 + n)}
                  </span>
                  <span className="leading-6">{opt.content}</span>
                </button>
              )
            })
          ) : question.type === 'short_answer' ? (
            <Input placeholder="Type your answer…" value={(answers[question.id] as string) ?? ''} onChange={(e) => setAnswers({ ...answers, [question.id]: e.target.value })} />
          ) : (
            <textarea
              className={cn('w-full min-h-[110px] rounded-md border border-input bg-background p-3 text-sm', question.type === 'output_prediction' && 'font-mono')}
              placeholder={question.type === 'output_prediction' ? 'What does the code print?' : 'Type your answer…'}
              value={(answers[question.id] as string) ?? ''}
              onChange={(e) => setAnswers({ ...answers, [question.id]: e.target.value })}
            />
          )}
        </CardContent>
      </Card>

      <div className="flex items-center justify-between">
        <Button variant="outline" disabled={currentIndex === 0} onClick={() => setCurrentIndex(currentIndex - 1)}>
          <ChevronLeft className="h-4 w-4 mr-2" />
          Previous
        </Button>

        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            const next = new Set(marked)
            if (next.has(question.id)) next.delete(question.id)
            else next.add(question.id)
            setMarked(next)
          }}
        >
          <Flag className={`h-4 w-4 mr-2 ${marked.has(question.id) ? 'text-yellow-500' : ''}`} />
          Mark
        </Button>

        {currentIndex < questions.length - 1 ? (
          <Button onClick={() => setCurrentIndex(currentIndex + 1)}>
            Next
            <ChevronRight className="h-4 w-4 ml-2" />
          </Button>
        ) : (
          <Button onClick={() => submitMutation.mutate()} isLoading={submitMutation.isPending}>
            Submit
          </Button>
        )}
      </div>
      {currentIndex === questions.length - 1 && unanswered > 0 && <p className="text-xs text-right text-muted-foreground">{unanswered} question(s) still unanswered — you can jump back using the numbers below.</p>}

      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-10 gap-2">
            {questions.map((q, idx) => (
              <Button
                key={q.id}
                variant={idx === currentIndex ? 'default' : String(answers[q.id] ?? '').trim() ? 'secondary' : 'outline'}
                size="sm"
                className={cn('h-10 w-10 p-0', marked.has(q.id) && idx !== currentIndex && 'ring-2 ring-yellow-400')}
                onClick={() => setCurrentIndex(idx)}
              >
                {idx + 1}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
