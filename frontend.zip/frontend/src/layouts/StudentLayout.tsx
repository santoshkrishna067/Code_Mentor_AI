import { useState } from 'react'
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { 
  LayoutDashboard, 
  BookOpen, 
  Code2, 
  FileText, 
  ClipboardCheck, 
  FileCheck, 
  GraduationCap, 
  Target, 
  Lightbulb, 
  BarChart3, 
  Trophy, 
  Bookmark, 
  MessageSquare,
  Bell,
  Search,
  Menu,
  X,
  User,
  LogOut,
  Settings,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useToast } from '@/components/ui/use-toast'
import { cn } from '@/utils/cn'
import { useAuth } from '@/context/AuthContext'
import { notificationsService } from '@/services/notifications.service'
import { ThemeToggle } from '@/components/ThemeToggle'
import { TutorWidget } from '@/components/TutorWidget'

const sidebarItems = [
  { icon: LayoutDashboard, label: 'Dashboard', href: '/dashboard' },
  { icon: BookOpen, label: 'My Courses', href: '/courses' },
  { icon: Code2, label: 'Practice', href: '/practice' },
  { icon: FileText, label: 'Coding', href: '/coding' },
  { icon: ClipboardCheck, label: 'Assignments', href: '/assignments' },
  { icon: FileCheck, label: 'Quizzes', href: '/quizzes' },
  { icon: GraduationCap, label: 'Tests', href: '/tests' },
  { icon: Trophy, label: 'Assessments', href: '/assessments' },
  { icon: Target, label: 'Learning Gaps', href: '/learning-gaps' },
  { icon: Lightbulb, label: 'Recommendations', href: '/recommendations' },
  { icon: BarChart3, label: 'Analytics', href: '/analytics' },
  { icon: GraduationCap, label: 'Exams', href: '/exams' },
  { icon: Trophy, label: 'Certificates', href: '/certificates' },
  { icon: Bookmark, label: 'Bookmarks', href: '/bookmarks' },
  { icon: MessageSquare, label: 'AI Tutor', href: '/ai-tutor' },
]

export default function StudentLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const location = useLocation()
  const navigate = useNavigate()
  const { toast } = useToast()
  const { user, logout } = useAuth()

  const { data: notifData } = useQuery({
    queryKey: ['notifications', 'unread-preview'],
    queryFn: () => notificationsService.list({ limit: 1, unreadOnly: true }),
    refetchInterval: 60_000,
  })
  const unreadCount = notifData?.unreadCount ?? 0

  const initials = (user?.name ?? '')
    .split(' ')
    .map((p) => p[0])
    .slice(0, 2)
    .join('')
    .toUpperCase()

  const handleLogout = async () => {
    await logout()
    toast({ title: 'Signed out', description: 'You have been logged out.' })
    navigate('/login')
  }

  return (
    <div className="min-h-screen flex bg-background">
      {/* Mobile Sidebar Toggle */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 flex items-center justify-between p-4 border-b bg-background">
        <Link to="/" className="flex items-center space-x-2">
          <Code2 className="h-6 w-6 text-primary" />
          <span className="font-bold">Code Mentor AI</span>
        </Link>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setSidebarOpen(!sidebarOpen)}
        >
          {sidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>
      </div>

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-40 w-64 transform border-r bg-background transition-transform duration-200 ease-in-out lg:translate-x-0 lg:static lg:inset-0',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full',
          'pt-16 lg:pt-0'
        )}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="hidden lg:flex items-center space-x-2 p-6 border-b">
            <Code2 className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold">Code Mentor AI</span>
          </div>

          {/* Navigation */}
          <ScrollArea className="flex-1 px-3 py-4">
            <nav className="space-y-1">
              {sidebarItems.map((item) => {
                const isActive = location.pathname === item.href
                return (
                  <Link
                    key={item.href}
                    to={item.href}
                    onClick={() => setSidebarOpen(false)}
                    className={cn(
                      'flex items-center space-x-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                      isActive
                        ? 'bg-primary text-primary-foreground'
                        : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                    )}
                  >
                    <item.icon className="h-5 w-5" />
                    <span>{item.label}</span>
                  </Link>
                )
              })}
            </nav>
          </ScrollArea>

          {/* User Section */}
          <div className="p-4 border-t">
            <div className="flex items-center space-x-3 p-2 rounded-lg bg-muted">
              <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-semibold">
                {initials || <User className="h-5 w-5" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{user?.name ?? 'Loading…'}</p>
                <p className="text-xs text-muted-foreground truncate">{(user?.xp ?? 0).toLocaleString()} XP</p>
              </div>
              <Button variant="ghost" size="icon" className="h-8 w-8" asChild>
                <Link to="/profile">
                  <Settings className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </aside>

      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-h-screen lg:ml-0 pt-16 lg:pt-0">
        {/* Top Bar */}
        <header className="sticky top-0 z-20 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="flex items-center justify-between px-6 py-3">
            {/* Search */}
            <div className="flex items-center flex-1 max-w-md">
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search courses, topics, questions..."
                  className="pl-10"
                />
              </div>
            </div>

            {/* Right Actions */}
            <div className="flex items-center space-x-4">
              {/* XP Badge */}
              <Badge variant="secondary" className="hidden sm:flex">
                <Trophy className="h-3.5 w-3.5 mr-1" />
                {(user?.xp ?? 0).toLocaleString()} XP
              </Badge>

              {/* Streak */}
              <Badge variant="outline" className="hidden sm:flex">
                🔥 {user?.streak ?? 0} day streak
              </Badge>

              <ThemeToggle />

              {/* Notifications */}
              <Button variant="ghost" size="icon" className="relative" asChild>
                <Link to="/notifications">
                  <Bell className="h-5 w-5" />
                  {unreadCount > 0 && <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-red-500" />}
                </Link>
              </Button>

              {/* Profile */}
              <Button variant="ghost" size="icon" asChild>
                <Link to="/profile">
                  <User className="h-5 w-5" />
                </Link>
              </Button>

              {/* Logout */}
              <Button variant="ghost" size="icon" onClick={handleLogout} title="Sign out">
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-6">
          <Outlet />
        </main>
      </div>

      {/* Floating AI tutor (hidden automatically on exam / assessment pages) */}
      <TutorWidget />
    </div>
  )
}
