import { apiClient } from '@/lib/apiClient'

export interface NotificationDto {
  id: string
  type: string
  title: string
  message: string
  link?: string
  isRead: boolean
  createdAt: string
}

export const notificationsService = {
  async list(params: { page?: number; limit?: number; unreadOnly?: boolean } = {}) {
    const res = await apiClient.get('/notifications', { params })
    return { data: res.data.data as NotificationDto[], pagination: res.data.pagination, unreadCount: Number(res.headers['x-unread-count'] ?? 0) }
  },
  async markRead(id: string) {
    const res = await apiClient.patch(`/notifications/${id}/read`)
    return res.data.data as NotificationDto
  },
  async markAllRead() {
    await apiClient.patch('/notifications/read-all')
  },
  async remove(id: string) {
    await apiClient.delete(`/notifications/${id}`)
  },
}
