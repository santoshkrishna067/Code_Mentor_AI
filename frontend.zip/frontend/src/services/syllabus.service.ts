import { apiClient } from '@/lib/apiClient'

export const syllabusService = {
  async createModule(courseId: string, input: { title: string; description: string; order: number; estimatedDuration: number }) {
    const res = await apiClient.post(`/syllabus/courses/${courseId}/modules`, input)
    return res.data.data
  },
  async createTopic(moduleId: string, input: { title: string; description: string; order: number; estimatedDuration: number }) {
    const res = await apiClient.post(`/syllabus/modules/${moduleId}/topics`, input)
    return res.data.data
  },
  async getTopic(topicId: string) {
    const res = await apiClient.get(`/syllabus/topics/${topicId}`)
    return res.data.data
  },
  async createSubtopic(topicId: string, input: { title: string; order: number; estimatedDuration?: number }) {
    const res = await apiClient.post(`/syllabus/topics/${topicId}/subtopics`, input)
    return res.data.data
  },
  // The core "learning page" payload: video + notes + practice/quiz refs + breadcrumb.
  async getSubtopicContent(subtopicId: string) {
    const res = await apiClient.get(`/syllabus/subtopics/${subtopicId}/content`)
    return res.data.data as {
      subtopic: { id: string; topicId: string; title: string; contentType?: string; contentId?: string; estimatedDuration: number }
      breadcrumb: { courseId: string; courseName: string; moduleId: string; moduleTitle: string; topicId: string; topicTitle: string }
      videos: { id: string; title: string; url: string; duration: number; languages: { code: string; label: string; url: string }[] }[]
      notes: {
        id: string
        title: string
        content: string
        highlights?: string[]
        commonMistakes?: string[]
        interviewPoints?: string[]
        examPoints?: string[]
        examples?: { id: string; title: string; code: string; language: string; output?: string; explanation?: string }[]
      }[]
      practiceIds: string[]
      resources: { id: string; title: string; url: string; kind: string }[]
      quizIds: string[]
    }
  },
  async attachVideo(subtopicId: string, input: { title: string; description?: string; duration: number; languages: { code: string; label: string; url: string }[] }) {
    const res = await apiClient.post(`/syllabus/subtopics/${subtopicId}/video`, input)
    return res.data.data
  },
  async attachNotes(subtopicId: string, input: { title: string; content: string; highlights?: string[]; commonMistakes?: string[]; interviewPoints?: string[]; examPoints?: string[] }) {
    const res = await apiClient.post(`/syllabus/subtopics/${subtopicId}/notes`, input)
    return res.data.data
  },
  // ---- Admin content manager: everything is replace-in-place, videos are links only ----
  async replaceVideo(subtopicId: string, input: { title?: string; scope: 'topic' | 'lesson'; languages: { code: 'en' | 'hi'; label: string; url: string }[] }) {
    const res = await apiClient.put(`/syllabus/subtopics/${subtopicId}/video`, input)
    return res.data.data as { replaced: boolean; lessonsAffected: number }
  },
  async removeVideo(subtopicId: string) {
    await apiClient.delete(`/syllabus/subtopics/${subtopicId}/video`)
  },
  async saveNotes(
    subtopicId: string,
    input: {
      title: string
      content: string
      highlights?: string[]
      commonMistakes?: string[]
      examples?: { title: string; language: string; code: string; output?: string; explanation?: string }[]
    }
  ) {
    const res = await apiClient.put(`/syllabus/subtopics/${subtopicId}/notes`, input)
    return res.data.data
  },
  async deleteNotes(subtopicId: string) {
    await apiClient.delete(`/syllabus/subtopics/${subtopicId}/notes`)
  },
  async addResource(subtopicId: string, input: { title: string; url: string; kind?: string }) {
    const res = await apiClient.post(`/syllabus/subtopics/${subtopicId}/resources`, input)
    return res.data.data
  },
  async deleteResource(resourceId: string) {
    await apiClient.delete(`/syllabus/resources/${resourceId}`)
  },
}
