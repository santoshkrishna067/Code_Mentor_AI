import { apiClient } from '@/lib/apiClient'
import type { AttemptQuestion } from './gradedContent.factory'

export interface ExamSummary {
  id: string
  title: string
  description: string
  instructions: string[]
  courseId: string
  moduleId?: string
  duration: number
  totalMarks: number
  passingScore: number
  negativeMarking: boolean
  randomizeQuestions: boolean
  randomizeOptions: boolean
  showResults: boolean
  proctoringEnabled: boolean
  maxAttempts: number
  scheduledStart: string
  scheduledEnd: string
  status: string
  questionCount?: number
}

export interface ExamAttemptState {
  attemptId: string
  examId: string
  status: string
  startedAt: string
  remainingSeconds: number
  duration: number
  totalMarks: number
  negativeMarking: boolean
  proctoringEnabled: boolean
  questions: AttemptQuestion[]
  answeredQuestionIds: string[]
  markedForReviewQuestionIds: string[]
}

export const examsService = {
  // Student
  async listForCourse(courseId: string) {
    const res = await apiClient.get(`/exams/courses/${courseId}`)
    return res.data.data as ExamSummary[]
  },
  async checkEligibility(examId: string) {
    const res = await apiClient.get(`/exams/${examId}/eligibility`)
    return res.data.data as { eligible: boolean; reasons: string[]; attemptsUsed: number; maxAttempts: number; resumableAttemptId?: string }
  },
  async start(examId: string) {
    const res = await apiClient.post(`/exams/${examId}/start`)
    return res.data.data as ExamAttemptState
  },
  async getAttemptState(attemptId: string) {
    const res = await apiClient.get(`/exams/attempts/${attemptId}`)
    return res.data.data as ExamAttemptState
  },
  async saveAnswers(attemptId: string, answers: { questionId: string; answer: string | string[]; timeSpent?: number; markedForReview?: boolean }[]) {
    const res = await apiClient.patch(`/exams/attempts/${attemptId}/answers`, { answers })
    return res.data.data as ExamAttemptState
  },
  async submit(attemptId: string) {
    const res = await apiClient.post(`/exams/attempts/${attemptId}/submit`)
    return res.data.data as { attemptId: string; status: string; score: number; percentile: number | null; passed: boolean; showResults: boolean }
  },
  async review(attemptId: string) {
    const res = await apiClient.get(`/exams/attempts/${attemptId}/review`)
    return res.data.data
  },

  // Admin
  async create(courseId: string, input: Record<string, unknown>) {
    const res = await apiClient.post(`/exams/courses/${courseId}`, input)
    return res.data.data as ExamSummary
  },
  async update(examId: string, input: Record<string, unknown>) {
    const res = await apiClient.patch(`/exams/${examId}`, input)
    return res.data.data as ExamSummary
  },
  async publish(examId: string) {
    const res = await apiClient.post(`/exams/${examId}/publish`)
    return res.data.data as ExamSummary
  },
  async cancel(examId: string) {
    const res = await apiClient.post(`/exams/${examId}/cancel`)
    return res.data.data as ExamSummary
  },
  async remove(examId: string) {
    await apiClient.delete(`/exams/${examId}`)
  },
  async getAdminDetail(examId: string) {
    const res = await apiClient.get(`/exams/${examId}/admin`)
    return res.data.data as ExamSummary
  },
  async listForCourseAdmin(courseId: string) {
    const res = await apiClient.get(`/exams/courses/${courseId}/admin`)
    return res.data.data as ExamSummary[]
  },
  async report(examId: string) {
    const res = await apiClient.get(`/exams/${examId}/report`)
    return res.data.data as {
      examId: string
      title: string
      totalAttempts: number
      averageScore: number
      passRate: number
      autoSubmittedCount: number
      flaggedCount: number
      attempts: { attemptId: string; studentId: string; studentName: string; status: string; score?: number; percentile?: number; timeSpent: number; submittedAt?: string; warningCount: number; highSeverityWarningCount: number }[]
    }
  },
  async warnings(examId: string) {
    const res = await apiClient.get(`/exams/${examId}/warnings`)
    return res.data.data
  },
  async reconcileExpired() {
    const res = await apiClient.post('/exams/reconcile-expired')
    return res.data.data as { reconciledCount: number }
  },
}
