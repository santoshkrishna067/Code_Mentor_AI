import { apiClient } from '@/lib/apiClient'

export interface CertificateItem {
  id: string
  courseId: string
  courseName?: string
  courseSlug?: string
  issuedAt: string
  verificationCode: string
}

export const certificatesService = {
  async mine() {
    const res = await apiClient.get('/certificates/me')
    return res.data.data as CertificateItem[]
  },
  async claim(courseId: string) {
    const res = await apiClient.post(`/certificates/courses/${courseId}/claim`)
    return res.data.data as CertificateItem
  },
}
