import { apiClient } from '@/lib/apiClient'

export interface RecommendationDto {
  id: string
  type: string
  priority: string
  title: string
  description: string
  courseId?: string
  moduleId?: string
  topicId?: string
  contentId?: string
  contentType?: string
  estimatedDuration?: number
  xpReward?: number
  reason: string
  source: string
  confidence?: number
  createdAt: string
}

export const recommendationsService = {
  async myRecommendations() {
    const res = await apiClient.get('/recommendations/me')
    return res.data.data as RecommendationDto[]
  },
  async refresh() {
    const res = await apiClient.post('/recommendations/me/refresh')
    return res.data.data
  },
  async forStudent(studentId: string) {
    const res = await apiClient.get(`/recommendations/students/${studentId}`)
    return res.data.data as RecommendationDto[]
  },
  async dismiss(id: string) {
    await apiClient.patch(`/recommendations/${id}/dismiss`)
  },
}
