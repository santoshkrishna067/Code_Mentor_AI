import { apiClient } from '@/lib/apiClient'

export interface ProblemSummary {
  id: string
  title: string
  difficulty: string
  tags: string[]
  estimatedTime: number
  marks: number
  courseId: string
  courseName: string
  courseSlug: string
  solved: boolean
}

export interface RunResult {
  stdout: string
  stderr: string
  exitCode: number
  executionTimeMs: number
  timedOut: boolean
}

export const codingService = {
  async list() {
    const res = await apiClient.get('/coding')
    return res.data.data as ProblemSummary[]
  },
  async run(code: string, language: string, stdin: string) {
    const res = await apiClient.post('/coding/run', { code, language, stdin })
    return res.data.data as RunResult
  },
  async getForAttempt(problemId: string) {
    const res = await apiClient.get(`/coding/${problemId}/attempt`)
    return res.data.data as {
      id: string
      title: string
      description: string
      constraints: string[]
      hints?: string[]
      starterCode: Record<string, string>
      difficulty: string
      examples?: { id: string; title: string; code: string; language: string; output?: string; explanation?: string }[]
      visibleTestCases: { id: string; input: string; expectedOutput: string }[]
    }
  },
  async submit(problemId: string, code: string, language: string) {
    const res = await apiClient.post(`/coding/${problemId}/submit`, { code, language })
    return res.data.data as {
      submissionId: string
      status: string
      results: { testCaseId: string; passed: boolean; isHidden: boolean; stderr?: string }[]
      scorePercent: number
      xpEarned: number
    }
  },
  async mySubmissions(problemId: string) {
    const res = await apiClient.get(`/coding/${problemId}/submissions`)
    return res.data.data
  },
  async create(courseId: string, input: Record<string, unknown>) {
    const res = await apiClient.post(`/coding/courses/${courseId}`, input)
    return res.data.data
  },
}
