import { apiClient } from '@/lib/apiClient'

export const xpService = {
  async history() {
    const res = await apiClient.get('/xp/history')
    return res.data.data as {
      date: string
      totalXP: number
      earnedToday: number
      history: { id: string; amount: number; source: string; description: string; createdAt: string }[]
    }
  },
  async streak() {
    const res = await apiClient.get('/xp/streak')
    return res.data.data as {
      currentStreak: number
      longestStreak: number
      lastActiveDate: string
      streakHistory: { date: string; xpEarned: number; activitiesCompleted: number }[]
    }
  },
  async studentHistory(studentId: string) {
    const res = await apiClient.get(`/xp/students/${studentId}/history`)
    return res.data.data
  },
  async leaderboard() {
    const res = await apiClient.get('/xp/leaderboard')
    return res.data.data as { rank: number; id: string; name: string; avatar?: string; xp: number; currentStreak: number }[]
  },
}
