import { apiClient } from '@/lib/apiClient'

export interface ContactMessage {
  id: string
  name: string
  email: string
  subject: string
  message: string
  status: 'NEW' | 'READ' | 'RESOLVED'
  createdAt: string
}

export const contactService = {
  async send(input: { name: string; email: string; subject: string; message: string }) {
    const res = await apiClient.post('/contact', input)
    return res.data.data as { id: string }
  },
  async list(params: { page?: number; limit?: number; status?: string } = {}) {
    const res = await apiClient.get('/contact', { params })
    return { data: res.data.data as ContactMessage[], pagination: res.data.pagination as { page: number; totalPages: number; total: number } }
  },
  async setStatus(id: string, status: ContactMessage['status']) {
    const res = await apiClient.patch(`/contact/${id}`, { status })
    return res.data.data as ContactMessage
  },
  async remove(id: string) {
    await apiClient.delete(`/contact/${id}`)
  },
}
