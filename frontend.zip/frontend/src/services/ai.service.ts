import { apiClient } from '@/lib/apiClient'

// Every prediction is returned as an Estimate<T> by the backend — never a
// bare number. insufficientData=true means there wasn't enough history to
// produce a real estimate; the UI must handle that state explicitly rather
// than rendering a misleading 0.
export interface Estimate<T> {
  value: T | null
  confidence: number | null
  method: string
  sampleSize: number
  insufficientData: boolean
  reason?: string
}

export const aiService = {
  async performancePrediction(studentId: string, courseId: string) {
    const res = await apiClient.get(`/ai/students/${studentId}/courses/${courseId}/performance-prediction`)
    return res.data.data as Estimate<number>
  },
  async completionPrediction(studentId: string, courseId: string) {
    const res = await apiClient.get(`/ai/students/${studentId}/courses/${courseId}/completion-prediction`)
    return res.data.data as Estimate<{ estimatedDaysRemaining: number; estimatedCompletionDate: string }>
  },
  async riskPrediction(studentId: string, courseId: string) {
    const res = await apiClient.get(`/ai/students/${studentId}/courses/${courseId}/risk-prediction`)
    return res.data.data as Estimate<{ riskLevel: 'low' | 'medium' | 'high'; riskScore: number; factors: string[] }>
  },
  async engagement(studentId: string) {
    const res = await apiClient.get(`/ai/students/${studentId}/engagement`)
    return res.data.data as Estimate<{ engagementScore: number; trend: 'up' | 'down' | 'flat' }>
  },
  async courseInsights(studentId: string, courseId: string) {
    const res = await apiClient.get(`/ai/students/${studentId}/courses/${courseId}/insights`)
    return res.data.data
  },
  async courseRiskRanking(courseId: string) {
    const res = await apiClient.get(`/ai/courses/${courseId}/risk-ranking`)
    return res.data.data
  },
  async detectGapsML(studentId: string, courseId: string) {
    const res = await apiClient.post(`/ai/students/${studentId}/courses/${courseId}/detect-gaps`)
    return res.data.data
  },
  async rankRecommendationsML(studentId: string) {
    const res = await apiClient.post(`/ai/students/${studentId}/rank-recommendations`)
    return res.data.data
  },
}
