import { createGradedContentService } from './gradedContent.factory'
import { apiClient } from '@/lib/apiClient'

export const practiceService = {
  ...createGradedContentService('practice'),
  async create(subtopicId: string, input: { title: string; description: string; difficulty: string; estimatedDuration: number; passingScore: number; questionIds: string[] }) {
    const res = await apiClient.post(`/practice/subtopics/${subtopicId}`, input)
    return res.data.data
  },
}
