import { apiClient } from '@/lib/apiClient'
import type { Student } from '@/types'

export const usersService = {
  async getMyProfile() {
    const res = await apiClient.get('/users/me')
    return res.data.data
  },
  async updateMyProfile(input: { name?: string; avatar?: string }) {
    const res = await apiClient.patch('/users/me', input)
    return res.data.data
  },
  async listStudents(params: { page?: number; limit?: number; search?: string } = {}) {
    const res = await apiClient.get('/users/students', { params })
    return { data: res.data.data as Student[], pagination: res.data.pagination }
  },
  async getStudent(studentId: string) {
    const res = await apiClient.get(`/users/students/${studentId}`)
    return res.data.data as Student
  },
  async setStudentActive(studentId: string, isActive: boolean) {
    const res = await apiClient.patch(`/users/students/${studentId}/active`, { isActive })
    return res.data.data as Student
  },
  async listAdmins() {
    const res = await apiClient.get('/users/admins')
    return res.data.data
  },
  async createAdmin(input: { email: string; password: string; name: string; permissions?: string[] }) {
    const res = await apiClient.post('/users/admins', input)
    return res.data.data
  },
}
