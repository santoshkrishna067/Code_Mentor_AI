import { apiClient } from '@/lib/apiClient'

export interface BookmarkItem {
  id: string
  courseId: string
  subtopicId: string
  courseName: string
  courseSlug: string
  subtopicTitle: string
  createdAt: string
}

export const bookmarksService = {
  async list() {
    const res = await apiClient.get('/bookmarks')
    return res.data.data as BookmarkItem[]
  },
  async toggle(subtopicId: string) {
    const res = await apiClient.post('/bookmarks/toggle', { subtopicId })
    return res.data.data as { bookmarked: boolean }
  },
  async check(subtopicId: string) {
    const res = await apiClient.get(`/bookmarks/check/${subtopicId}`)
    return res.data.data as { bookmarked: boolean }
  },
}
