import { apiClient } from '@/lib/apiClient'

export interface AttemptQuestion {
  id: string
  type: string
  content: string
  options?: { id: string; content: string }[]
  difficulty: string
  estimatedTime: number
  marks: number
  negativeMarks?: number
}

// Only practice sets return this: the answer key + explanation, shown after submitting.
export interface ReviewItem {
  questionId: string
  isCorrect: boolean
  correctAnswer: string | string[]
  explanation?: string
}

export interface GradingResult {
  totalMarks: number
  marksAwarded: number
  correctCount: number
  incorrectCount: number
  unansweredCount: number
  scorePercent: number
  passed: boolean
  xpEarned: number
  review?: ReviewItem[]
}

export interface SubmittedAnswer {
  questionId: string
  answer: string | string[]
}

// `basePath` matches the backend router mount (e.g. 'practice', 'quizzes', 'tests', 'assessments').
export function createGradedContentService(basePath: string) {
  return {
    async getForAttempt(id: string) {
      const res = await apiClient.get(`/${basePath}/${id}/attempt`)
      return res.data.data as { id: string; title: string; description: string; questions: AttemptQuestion[] } & Record<string, unknown>
    },
    async submit(id: string, answers: SubmittedAnswer[]) {
      const res = await apiClient.post(`/${basePath}/${id}/submit`, { answers })
      return res.data.data as GradingResult
    },
    async review(id: string) {
      const res = await apiClient.get(`/${basePath}/${id}/review`)
      return res.data.data
    },
  }
}
