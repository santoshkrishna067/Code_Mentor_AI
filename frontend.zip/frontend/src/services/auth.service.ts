import { apiClient } from '@/lib/apiClient'

export interface AuthUser {
  id: string
  email: string
  name: string
  avatar?: string
  role: 'student' | 'admin'
  xp: number
  streak: number
  createdAt: string
  lastActiveAt: string
  mfaEnabled: boolean
}

interface LoginResult {
  mfaRequired: boolean
  challengeToken?: string
  accessToken?: string
  refreshToken?: string
  user?: AuthUser
}

export const authService = {
  async register(input: { email: string; password: string; name: string; agreeToTerms: true }) {
    const res = await apiClient.post('/auth/register', input)
    return res.data.data as { user: AuthUser; accessToken: string; refreshToken: string }
  },

  async login(input: { email: string; password: string; mfaCode?: string }): Promise<LoginResult> {
    const res = await apiClient.post('/auth/login', input)
    return res.data.data as LoginResult
  },

  async loginWithGoogle(idToken: string): Promise<LoginResult> {
    const res = await apiClient.post('/auth/google', { idToken })
    return res.data.data as LoginResult
  },

  async completeMfaLogin(challengeToken: string, code: string) {
    const res = await apiClient.post('/auth/login/mfa', { challengeToken, code })
    return res.data.data as { user: AuthUser; accessToken: string; refreshToken: string }
  },

  async logout() {
    await apiClient.post('/auth/logout')
  },

  async logoutAllDevices() {
    await apiClient.post('/auth/logout-all')
  },

  async me() {
    const res = await apiClient.get('/auth/me')
    return res.data.data as AuthUser
  },

  async changePassword(currentPassword: string, newPassword: string) {
    await apiClient.post('/auth/change-password', { currentPassword, newPassword })
  },

  async startMfaSetup() {
    const res = await apiClient.post('/auth/mfa/setup')
    return res.data.data as { secret: string; qrCodeDataUrl: string; issuer: string }
  },

  async confirmMfaEnable(token: string) {
    const res = await apiClient.post('/auth/mfa/enable', { token })
    return res.data.data as { backupCodes: string[] }
  },

  async disableMfa(currentPassword: string, token: string) {
    await apiClient.post('/auth/mfa/disable', { currentPassword, token })
  },
}
