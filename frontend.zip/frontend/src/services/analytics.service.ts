import { apiClient } from '@/lib/apiClient'

export interface StudentAnalyticsOverview {
  studentId: string
  totalXP: number
  currentStreak: number
  longestStreak: number
  enrolledCourseCount: number
  completedCourseCount: number
  contentItemsCompleted: number
  averageScore: number
  examAttemptCount: number
  averageExamScore: number
  codingProblemsAttempted: number
  codingProblemsSolved: number
  strengths: { courseId: string; courseName: string; averageScore: number; itemsScored: number }[]
  weaknesses: { courseId: string; courseName: string; averageScore: number; itemsScored: number }[]
}

export const analyticsService = {
  async myOverview() {
    const res = await apiClient.get('/analytics/me')
    return res.data.data as StudentAnalyticsOverview
  },
  async myActivity() {
    const res = await apiClient.get('/analytics/me/activity')
    return res.data.data as { date: string; xpEarned: number; activitiesCompleted: number }[]
  },
  async studentOverview(studentId: string) {
    const res = await apiClient.get(`/analytics/students/${studentId}`)
    return res.data.data as StudentAnalyticsOverview
  },
  async courseOverview(courseId: string) {
    const res = await apiClient.get(`/analytics/courses/${courseId}`)
    return res.data.data
  },
  async platformOverview() {
    const res = await apiClient.get('/analytics/platform')
    return res.data.data as {
      studentCount: number
      courseCount: number
      publishedCourseCount: number
      totalEnrollments: number
      examAttemptCount: number
      pendingEvaluations: number
    }
  },
}
