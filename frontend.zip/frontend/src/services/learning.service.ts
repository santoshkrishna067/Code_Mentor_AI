import { apiClient } from '@/lib/apiClient'

export interface CourseProgress {
  courseId: string
  studentId: string
  overallProgress: number
  modulesProgress: {
    moduleId: string
    progress: number
    topicsProgress: { topicId: string; progress: number; subtopicsProgress: { subtopicId: string; status: string; attempts?: number; score?: number }[] }[]
  }[]
  totalXP: number
  xpEarned: number
  startedAt: string
  completedAt?: string
}

export interface AvailableItem {
  id: string
  title: string
  description: string
  difficulty: string
  durationMinutes: number
  passingScore: number
  questionCount: number
  courseName?: string
  context?: string
  kind?: string
  attempted: boolean
  score?: number
  completed?: boolean
}

export const learningService = {
  async available() {
    const res = await apiClient.get('/learning/available')
    return res.data.data as { enrolledCourses: number; quizzes: AvailableItem[]; tests: AvailableItem[]; assessments: AvailableItem[] }
  },
  async getCourseProgress(courseId: string) {
    const res = await apiClient.get(`/learning/courses/${courseId}/progress`)
    return res.data.data as CourseProgress
  },
  async getStudentCourseProgress(studentId: string, courseId: string) {
    const res = await apiClient.get(`/learning/students/${studentId}/courses/${courseId}/progress`)
    return res.data.data as CourseProgress
  },
  async markSubtopicViewed(subtopicId: string, status: 'in-progress' | 'completed') {
    const res = await apiClient.post(`/learning/subtopics/${subtopicId}/view`, { status })
    return res.data.data as { progress: unknown; xpEarned: number; isFirstCompletion: boolean }
  },
}
