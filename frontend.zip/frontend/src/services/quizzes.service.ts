import { createGradedContentService } from './gradedContent.factory'
import { apiClient } from '@/lib/apiClient'

export const quizzesService = {
  ...createGradedContentService('quizzes'),
  async create(subtopicId: string, input: { title: string; description: string; difficulty: string; estimatedDuration: number; passingScore: number; isTimed?: boolean; questionIds: string[] }) {
    const res = await apiClient.post(`/quizzes/subtopics/${subtopicId}`, input)
    return res.data.data
  },
}
