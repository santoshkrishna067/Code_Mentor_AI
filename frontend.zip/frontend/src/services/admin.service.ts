import { apiClient } from '@/lib/apiClient'

export const adminService = {
  async dashboard() {
    const res = await apiClient.get('/admin/dashboard')
    return res.data.data as {
      studentCount: number
      adminCount: number
      courseCount: number
      publishedCount: number
      pendingEvaluations: number
      criticalLearningGaps: number
      recentActivity: { id: string; action: string; resource: string; resourceId?: string; actor: string; timestamp: string }[]
    }
  },
  async auditLogs(params: { page?: number; limit?: number; resource?: string; userId?: string } = {}) {
    const res = await apiClient.get('/admin/audit-logs', { params })
    return { data: res.data.data, pagination: res.data.pagination }
  },
  async createQuestion(input: Record<string, unknown>) {
    const res = await apiClient.post('/admin/questions', input)
    return res.data.data
  },
  async listQuestions(params: { page?: number; limit?: number; courseId?: string; topicId?: string; difficulty?: string } = {}) {
    const res = await apiClient.get('/admin/questions', { params })
    return { data: res.data.data, pagination: res.data.pagination }
  },
  async deleteQuestion(id: string) {
    await apiClient.delete(`/admin/questions/${id}`)
  },
  async attachQuestion(questionId: string, subtopicId: string) {
    const res = await apiClient.post(`/admin/questions/${questionId}/attach`, { subtopicId })
    return res.data.data as { practiceId: string }
  },
  async lessonPractice(subtopicId: string) {
    const res = await apiClient.get(`/admin/lessons/${subtopicId}/practice`)
    return res.data.data as {
      id: string
      type: string
      content: string
      correctAnswer: string | string[]
      explanation?: string
      difficulty: string
      options: { id: string; content: string; isCorrect: boolean }[]
    }[]
  },
  // Which lessons of a course already have a video / notes / practice questions / materials.
  async contentSummary(courseId: string) {
    const res = await apiClient.get(`/admin/courses/${courseId}/content-summary`)
    return res.data.data as { id: string; hasVideo: boolean; hasNotes: boolean; practiceQuestions: number; materials: number }[]
  },
  async removeFromLesson(subtopicId: string, questionId: string) {
    await apiClient.delete(`/admin/lessons/${subtopicId}/practice/${questionId}`)
  },
}
