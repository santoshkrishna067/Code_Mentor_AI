import { apiClient } from '@/lib/apiClient'

export interface TutorMessageDto {
  role: 'user' | 'assistant' | 'system'
  content: string
  timestamp: string
}

export const tutorService = {
  async sendMessage(message: string, courseId?: string) {
    const res = await apiClient.post('/tutor/message', { message, courseId })
    return res.data.data as { message: string; timestamp: string }
  },
  async status() {
    const res = await apiClient.get('/tutor/status')
    return res.data.data as { provider: string; ready: boolean; hint?: string }
  },
  async history() {
    const res = await apiClient.get('/tutor/history')
    return res.data.data as TutorMessageDto[]
  },
  async clearHistory() {
    await apiClient.delete('/tutor/history')
  },
}
