import { createGradedContentService } from './gradedContent.factory'
import { apiClient } from '@/lib/apiClient'

export const assessmentsService = {
  ...createGradedContentService('assessments'),
  async create(courseId: string, input: Record<string, unknown>) {
    const res = await apiClient.post(`/assessments/courses/${courseId}`, input)
    return res.data.data
  },
}
