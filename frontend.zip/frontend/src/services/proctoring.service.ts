import { apiClient } from '@/lib/apiClient'

export type ProctoringWarningType = 'MULTIPLE_FACES' | 'NO_FACE' | 'PHONE_DETECTED' | 'LOOKING_AWAY' | 'SUSPICIOUS_ACTIVITY' | 'TAB_SWITCH'
export type WarningSeverity = 'LOW' | 'MEDIUM' | 'HIGH'

// What the server's face analysis says about the latest camera frame.
export type VisionStatus = 'ok' | 'calibrating' | 'no_face' | 'multiple_faces' | 'phone' | 'looking_away' | 'unavailable'

export interface FrameAnalysis {
  available: boolean
  status: VisionStatus
  frame?: { width: number; height: number }
  // Face boxes in the coordinates of `frame`; `significant` is false for small background faces.
  faces: { x: number; y: number; w: number; h: number; significant: boolean }[]
  newWarnings: { type: string; severity: string; message: string }[]
  escalated: boolean
  reason?: string
  totalCount?: number
}

export const proctoringService = {
  async getSession(examAttemptId: string) {
    const res = await apiClient.get(`/proctoring/sessions/${examAttemptId}`)
    return res.data.data
  },
  async reportEvent(examAttemptId: string, type: string, description: string, metadata?: Record<string, unknown>) {
    await apiClient.post(`/proctoring/sessions/${examAttemptId}/events`, { type, description, metadata })
  },
  // Returns whether the escalation policy just ended the exam attempt —
  // the caller (ExamPage) must stop the exam UI immediately if so.
  async reportWarning(examAttemptId: string, type: ProctoringWarningType, severity: WarningSeverity, message: string, evidence?: string) {
    const res = await apiClient.post(`/proctoring/sessions/${examAttemptId}/warnings`, { type, severity, message, evidence })
    return res.data.data as { escalated: boolean; reason?: string; highCount: number; totalCount: number }
  },
  // Sends one JPEG camera frame for analysis (about once a second during an exam).
  async analyzeFrame(examAttemptId: string, jpeg: Blob) {
    const res = await apiClient.post(`/proctoring/sessions/${examAttemptId}/frame`, jpeg, {
      headers: { 'Content-Type': 'image/jpeg' },
      timeout: 8000,
    })
    return res.data.data as FrameAnalysis
  },
  async reviewWarning(warningId: string, notes: string) {
    await apiClient.patch(`/proctoring/warnings/${warningId}/review`, { notes })
  },
}
