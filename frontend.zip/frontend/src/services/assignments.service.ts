import { apiClient } from '@/lib/apiClient'

export const assignmentsService = {
  async myAssignments(courseId: string) {
    const res = await apiClient.get(`/assignments/courses/${courseId}/mine`)
    return res.data.data
  },
  async get(assignmentId: string) {
    const res = await apiClient.get(`/assignments/${assignmentId}`)
    return res.data.data
  },
  async startOrGetSubmission(assignmentId: string) {
    const res = await apiClient.post(`/assignments/${assignmentId}/start`)
    return res.data.data
  },
  async submit(assignmentId: string, input: { comments?: string; files?: { name: string; url: string; type: string; size: number }[] }) {
    const res = await apiClient.post(`/assignments/${assignmentId}/submit`, input)
    return res.data.data
  },
  async listSubmissions(assignmentId: string) {
    const res = await apiClient.get(`/assignments/${assignmentId}/submissions`)
    return res.data.data
  },
  async evaluate(submissionId: string, input: { marks: number; feedback: string }) {
    const res = await apiClient.post(`/assignments/submissions/${submissionId}/evaluate`, input)
    return res.data.data
  },
  async create(courseId: string, input: Record<string, unknown>) {
    const res = await apiClient.post(`/assignments/courses/${courseId}`, input)
    return res.data.data
  },
}
