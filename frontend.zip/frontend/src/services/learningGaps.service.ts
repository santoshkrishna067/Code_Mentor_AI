import { apiClient } from '@/lib/apiClient'

export interface LearningGapDto {
  id: string
  studentId: string
  courseId: string
  courseName: string
  moduleId?: string
  topicId?: string
  topicName?: string
  concept: string
  description: string
  gapScore: number
  severity: string
  detectedAt: string
  improvedAt?: string
  resolvedAt?: string
  detectionSource: string
  confidence?: number
}

export const learningGapsService = {
  async myGaps() {
    const res = await apiClient.get('/learning-gaps/me')
    return res.data.data as LearningGapDto[]
  },
  async forStudent(studentId: string) {
    const res = await apiClient.get(`/learning-gaps/students/${studentId}`)
    return res.data.data as LearningGapDto[]
  },
  async detect(studentId: string, courseId: string) {
    const res = await apiClient.post(`/learning-gaps/students/${studentId}/courses/${courseId}/detect`)
    return res.data.data
  },
  async forCourse(courseId: string) {
    const res = await apiClient.get(`/learning-gaps/courses/${courseId}`)
    return res.data.data
  },
  async markReviewed(gapId: string) {
    const res = await apiClient.patch(`/learning-gaps/${gapId}/reviewed`)
    return res.data.data
  },
}
