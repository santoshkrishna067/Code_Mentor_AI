import { apiClient } from '@/lib/apiClient'
import type { Course } from '@/types'

export const coursesService = {
  async list(params: { page?: number; limit?: number; difficulty?: string; status?: string; search?: string } = {}) {
    const res = await apiClient.get('/courses', { params })
    return { data: res.data.data as Course[], pagination: res.data.pagination }
  },
  async get(idOrSlug: string) {
    const res = await apiClient.get(`/courses/${idOrSlug}`)
    return res.data.data as Course
  },
  async create(input: Partial<Course>) {
    const res = await apiClient.post('/courses', input)
    return res.data.data as Course
  },
  async update(id: string, input: Partial<Course>) {
    const res = await apiClient.patch(`/courses/${id}`, input)
    return res.data.data as Course
  },
  async remove(id: string) {
    await apiClient.delete(`/courses/${id}`)
  },
  async enroll(id: string) {
    const res = await apiClient.post(`/courses/${id}/enroll`)
    return res.data.data
  },
  async myEnrollments() {
    const res = await apiClient.get('/courses/my-enrollments')
    return res.data.data as { courseId: string; status: string; enrolledAt: string; completedAt?: string; course: Course }[]
  },
}
