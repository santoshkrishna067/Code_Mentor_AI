import { apiClient } from '@/lib/apiClient'
import type { AttemptQuestion, GradingResult, SubmittedAnswer } from './gradedContent.factory'

export const testsService = {
  async getForAttempt(testId: string) {
    const res = await apiClient.get(`/tests/${testId}/attempt`)
    return res.data.data as { id: string; title: string; description: string; duration: number; questions: AttemptQuestion[] }
  },
  async submit(testId: string, answers: SubmittedAnswer[], timeSpentSeconds: number) {
    const res = await apiClient.post(`/tests/${testId}/submit`, { answers, timeSpentSeconds })
    return res.data.data as GradingResult & { showResults: boolean; timeSpentSeconds: number }
  },
  async review(testId: string) {
    const res = await apiClient.get(`/tests/${testId}/review`)
    return res.data.data
  },
  async create(courseId: string, input: Record<string, unknown>) {
    const res = await apiClient.post(`/tests/courses/${courseId}`, input)
    return res.data.data
  },
}
