import { Routes, Route } from 'react-router-dom'
import { Toaster } from '@/components/ui/toaster'
import { TooltipProvider } from '@/components/ui/tooltip'
import { ProtectedRoute } from '@/components/ProtectedRoute'

// Layouts
import PublicLayout from '@/layouts/PublicLayout'
import StudentLayout from '@/layouts/StudentLayout'
import AdminLayout from '@/layouts/AdminLayout'

// Public Pages
import HomePage from '@/pages/HomePage'
import AboutPage from '@/pages/AboutPage'
import FeaturesPage from '@/pages/FeaturesPage'
import CoursesPage from '@/pages/CoursesPage'
import ContactPage from '@/pages/ContactPage'
import LoginPage from '@/pages/LoginPage'
import RegisterPage from '@/pages/RegisterPage'
import ForgotPasswordPage from '@/pages/ForgotPasswordPage'

// Student Pages
import StudentDashboard from '@/pages/StudentDashboard'
import CourseDashboard from '@/pages/CourseDashboard'
import LearningPage from '@/pages/LearningPage'
import PracticePage from '@/pages/PracticePage'
import CodingPage from '@/pages/CodingPage'
import QuizPage from '@/pages/QuizPage'
import TestPage from '@/pages/TestPage'
import AssessmentPage from '@/pages/AssessmentPage'
import AssignmentsPage from '@/pages/AssignmentsPage'
import AssignmentDetailPage from '@/pages/AssignmentDetailPage'
import AnalyticsPage from '@/pages/AnalyticsPage'
import LearningGapsPage from '@/pages/LearningGapsPage'
import RecommendationsPage from '@/pages/RecommendationsPage'
import ExamsPage from '@/pages/ExamsPage'
import ExamPage from '@/pages/ExamPage'
import AITutorPage from '@/pages/AITutorPage'
import ContentListPage from '@/pages/ContentListPage'
import CertificatesPage from '@/pages/CertificatesPage'
import BookmarksPage from '@/pages/BookmarksPage'
import NotificationsPage from '@/pages/NotificationsPage'
import ProfilePage from '@/pages/ProfilePage'

// Admin Pages
import AdminDashboard from '@/pages/admin/AdminDashboard'
import AdminStudentsPage from '@/pages/admin/AdminStudentsPage'
import AdminCoursesPage from '@/pages/admin/AdminCoursesPage'
import AdminCourseContentPage from '@/pages/admin/AdminCourseContentPage'
import AdminQuestionsPage from '@/pages/admin/AdminQuestionsPage'
import AdminExamsPage from '@/pages/admin/AdminExamsPage'
import AdminAnalyticsPage from '@/pages/admin/AdminAnalyticsPage'
import AdminReportsPage from '@/pages/admin/AdminReportsPage'
import AdminSecurityPage from '@/pages/admin/AdminSecurityPage'
import AdminMessagesPage from '@/pages/admin/AdminMessagesPage'

// Error Pages
import NotFoundPage from '@/pages/NotFoundPage'

function App() {
  return (
    <TooltipProvider>
      <Routes>
        {/* Public Routes */}
        <Route element={<PublicLayout />}>
          <Route path="/" element={<HomePage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/features" element={<FeaturesPage />} />
          <Route path="/courses" element={<CoursesPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
        </Route>

        {/* Student Routes — requires an authenticated student session */}
        <Route element={<ProtectedRoute role="student" />}>
          <Route element={<StudentLayout />}>
            <Route path="/dashboard" element={<StudentDashboard />} />
            <Route path="/courses" element={<CoursesPage />} />
            <Route path="/courses/:courseId" element={<CourseDashboard />} />
            <Route path="/courses/:courseId/topics/:topicId" element={<LearningPage />} />
            <Route path="/practice" element={<PracticePage />} />
            <Route path="/practice/:practiceId" element={<PracticePage />} />
            <Route path="/coding" element={<CodingPage />} />
            <Route path="/coding/:problemId" element={<CodingPage />} />
            <Route path="/quizzes" element={<ContentListPage kind="quizzes" />} />
            <Route path="/tests" element={<ContentListPage kind="tests" />} />
            <Route path="/assessments" element={<ContentListPage kind="assessments" />} />
            <Route path="/certificates" element={<CertificatesPage />} />
            <Route path="/bookmarks" element={<BookmarksPage />} />
            <Route path="/notifications" element={<NotificationsPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/quiz/:quizId" element={<QuizPage />} />
            <Route path="/test/:testId" element={<TestPage />} />
            <Route path="/assessment/:assessmentId" element={<AssessmentPage />} />
            <Route path="/assignments" element={<AssignmentsPage />} />
            <Route path="/assignments/:assignmentId" element={<AssignmentDetailPage />} />
            <Route path="/analytics" element={<AnalyticsPage />} />
            <Route path="/learning-gaps" element={<LearningGapsPage />} />
            <Route path="/learning-gaps/:gapId" element={<LearningGapsPage />} />
            <Route path="/recommendations" element={<RecommendationsPage />} />
            <Route path="/exams" element={<ExamsPage />} />
            <Route path="/exams/:examId" element={<ExamPage />} />
            <Route path="/ai-tutor" element={<AITutorPage />} />
          </Route>
        </Route>

        {/* Admin Routes — requires an authenticated admin session */}
        <Route element={<ProtectedRoute role="admin" />}>
          <Route element={<AdminLayout />}>
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/students" element={<AdminStudentsPage />} />
            <Route path="/admin/courses" element={<AdminCoursesPage />} />
            <Route path="/admin/courses/:courseId/content" element={<AdminCourseContentPage />} />
            <Route path="/admin/questions" element={<AdminQuestionsPage />} />
            <Route path="/admin/exams" element={<AdminExamsPage />} />
            <Route path="/admin/analytics" element={<AdminAnalyticsPage />} />
            <Route path="/admin/reports" element={<AdminReportsPage />} />
            <Route path="/admin/security" element={<AdminSecurityPage />} />
            <Route path="/admin/messages" element={<AdminMessagesPage />} />
          </Route>
        </Route>

        {/* 404 */}
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
      <Toaster />
    </TooltipProvider>
  )
}

export default App
