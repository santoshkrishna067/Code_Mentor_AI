# Code Mentor AI - Frontend

A premium technical learning platform frontend built with React, TypeScript, and modern web technologies.

## 🚀 Tech Stack

- **React 18** - UI library
- **TypeScript** - Type safety
- **Vite** - Build tool
- **React Router** - Routing
- **Tailwind CSS** - Styling
- **Radix UI** - Accessible components
- **TanStack Query** - Data fetching
- **React Hook Form** - Form handling
- **Zod** - Validation
- **Recharts** - Charts
- **Monaco Editor** - Code editor

## 📁 Project Structure

```
src/
├── app/                    # App configuration
├── assets/                 # Static assets
├── components/
│   ├── ui/                # Reusable UI components
│   ├── layout/            # Layout components
│   └── common/            # Common components
├── features/              # Feature-based modules
│   ├── auth/
│   ├── dashboard/
│   ├── courses/
│   ├── learning/
│   ├── practice/
│   ├── coding/
│   ├── assessments/
│   ├── analytics/
│   ├── learning-gaps/
│   ├── recommendations/
│   ├── ai-tutor/
│   ├── exams/
│   └── admin/
├── layouts/               # Layout wrappers
│   ├── PublicLayout
│   ├── StudentLayout
│   └── AdminLayout
├── pages/                 # Page components
│   ├── admin/
│   └── *.tsx
├── services/
│   ├── api/               # API service layer
│   └── mock/              # Mock data for development
├── types/                 # TypeScript types
├── hooks/                 # Custom hooks
├── utils/                 # Utility functions
└── styles/                # Global styles
```

## 🛠️ Getting Started

### Prerequisites

- Node.js 18+ 
- npm or yarn

### Installation

1. **Navigate to project directory**
   ```bash
   cd code-mentor-ai
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start development server**
   ```bash
   npm run dev
   ```

4. **Open in browser**
   ```
   http://localhost:5173
   ```

## 📝 Available Scripts

```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run preview      # Preview production build
npm run lint         # Run ESLint
```

## 🎨 Design System

### UI Components

All reusable UI components are in `src/components/ui/`:

- Button
- Card
- Input
- Progress
- Badge
- Tabs
- Dialog/Modal
- Toast
- Tooltip
- Skeleton
- ScrollArea
- Table
- Select

### Usage Example

```tsx
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

function MyComponent() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Example</CardTitle>
      </CardHeader>
      <CardContent>
        <Button>Click me</Button>
        <Badge variant="success">Success</Badge>
      </CardContent>
    </Card>
  )
}
```

## 🗂️ Features

### Public Pages
- `/` - Landing page
- `/about` - About page
- `/features` - Features page
- `/courses` - Course listing
- `/contact` - Contact page
- `/login` - Student login
- `/register` - Student registration
- `/forgot-password` - Password reset

### Student Features
- `/dashboard` - Student dashboard
- `/courses` - Browse courses
- `/courses/:courseId` - Course detail
- `/courses/:courseId/topics/:topicId` - Learning page
- `/practice` - Practice questions
- `/coding` - Coding problems
- `/assignments` - Assignments
- `/quiz/:quizId` - Quiz interface
- `/test/:testId` - Test interface
- `/assessment/:assessmentId` - Assessment
- `/analytics` - Performance analytics
- `/learning-gaps` - Learning gap analysis
- `/recommendations` - Personalized recommendations
- `/exams` - Exam listing
- `/exams/:examId` - Exam interface
- `/ai-tutor` - AI tutor chat

### Admin Features
- `/admin` - Admin dashboard
- `/admin/students` - Student management
- `/admin/courses` - Course management
- `/admin/questions` - Question bank
- `/admin/exams` - Exam management
- `/admin/analytics` - Platform analytics
- `/admin/reports` - Reports generation
- `/admin/security` - Security monitoring

## 🎯 Key Principles

### 1. Reusable Components
All components are designed to be reusable across different courses and contexts. No course-specific UI logic.

### 2. API-Ready Architecture
- Services layer separates API logic from UI
- Mock data for development
- Easy to switch to real backend

### 3. Type Safety
Comprehensive TypeScript types in `src/types/index.ts`

### 4. Responsive Design
All pages work on desktop, tablet, and mobile

### 5. Accessibility
- Keyboard navigation
- Focus states
- Screen reader support
- Good color contrast

## 📊 Mock Data

Mock data is available in `src/services/mock/data.ts` for development:

- Students
- Courses
- Modules, Topics, Subtopics
- Videos
- Notes
- Questions
- Coding problems
- Assignments
- Quizzes
- Learning gaps
- Recommendations

## 🔌 API Integration

### Service Layer

API services are organized in `src/services/api/index.ts`:

```typescript
import { coursesAPI, studentAPI } from '@/services/api'

// Fetch courses
const courses = await coursesAPI.getAll()

// Get student profile
const student = await studentAPI.getProfile()
```

### Available API Services

- `authAPI` - Authentication
- `studentAPI` - Student data
- `coursesAPI` - Courses and content
- `contentAPI` - Learning content
- `codingAPI` - Coding problems
- `assignmentsAPI` - Assignments
- `questionsAPI` - Questions
- `progressAPI` - Progress tracking
- `examsAPI` - Exams
- `proctoringAPI` - Proctoring
- `aiTutorAPI` - AI tutor
- `analyticsAPI` - Analytics
- `adminAPI` - Admin operations

## 🎨 Styling

### Tailwind CSS

All styling uses Tailwind CSS with custom configuration in `tailwind.config.js`.

### Custom Utilities

```typescript
import { cn } from '@/utils/cn'

// Combine class names conditionally
className={cn('base-class', isActive && 'active-class')}
```

### Theme Colors

Defined in `globals.css`:

- Primary
- Secondary
- Muted
- Accent
- Destructive
- Background
- Foreground

## 📱 Responsive Breakpoints

- Mobile: < 640px
- Tablet: 640px - 1024px
- Desktop: > 1024px

## ♿ Accessibility

### Keyboard Navigation
All interactive elements are keyboard accessible

### Focus States
Visible focus indicators on all interactive elements

### ARIA Labels
Proper ARIA labels for screen readers

### Color Contrast
WCAG AA compliant color contrast

## 🧪 Testing

### Manual Testing Checklist

1. ✅ All routes load correctly
2. ✅ Navigation works on all pages
3. ✅ Forms validate properly
4. ✅ Responsive on mobile/tablet
5. ✅ Keyboard navigation works
6. ✅ Loading states display
7. ✅ Error states display
8. ✅ Empty states display

## 🚀 Next Steps

### Phase 1 (Current)
- ✅ Project setup
- ✅ Folder structure
- ✅ Design system
- ✅ Base components
- ✅ Layouts
- ✅ Core pages
- ✅ Routing

### Phase 2
- [ ] Complete all feature pages
- [ ] Add more mock data
- [ ] Implement all UI states
- [ ] Add animations
- [ ] Optimize performance

### Phase 3
- [ ] Connect to backend APIs
- [ ] Implement authentication
- [ ] Add real-time updates
- [ ] Performance optimization
- [ ] Production deployment

## 📝 Notes

- This is frontend-only implementation
- Backend integration will be done separately
- Mock data is used for development
- All API calls are structured for easy backend integration
- No real AI/ML/CV logic implemented yet

## 🤝 Contributing

1. Follow the existing folder structure
2. Use TypeScript for all new files
3. Create reusable components
4. Add proper types
5. Test responsive behavior
6. Ensure accessibility

## 📄 License

Proprietary - Code Mentor AI Platform

---

**Built with ❤️ using React, TypeScript, and Tailwind CSS**
