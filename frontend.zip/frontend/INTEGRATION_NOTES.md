# Integration Notes (Part 6)

## What this pass did

Wired the entire frontend to the real backend (Parts 2–5) instead of mock
data. Every page listed below fetches from and mutates real data through
`src/services/*.ts` (21 files, one per backend module, matching every
endpoint exactly) via a shared axios client (`src/lib/apiClient.ts`) with
real auth-token/refresh-cookie handling (`src/context/AuthContext.tsx`).

## The frontend zip was still a partial export

Before any of this work, the uploaded frontend was 31 flat files with no
`src/` folder — but `App.tsx` (also flat) imported from `@/pages/admin/*`
(8 files that didn't exist anywhere) and `@/components/ui/*` (10 files that
didn't exist anywhere), and `BUILD_SUMMARY.txt` claimed a full `src/`
structure, a services layer, and mock data files that also weren't present.
**None of it would have compiled as uploaded.**

This pass:
1. Moved every given file into the `src/pages`, `src/layouts`, `src/app`,
   `src/types` structure that `vite.config.ts` and the files' own imports
   already assumed.
2. Rebuilt the 10 missing UI primitives as standard shadcn/ui components —
   justified because the exact dependency signature (Radix primitives +
   `cva` + `tailwind-merge` + the canonical shadcn CSS-variable theme in
   `globals.css`) *is* shadcn/ui's signature stack, so this is the
   well-defined standard, not a guess at unseen design.
3. Built all 8 missing admin pages from scratch, since they didn't exist at
   all — kept deliberately plain/utilitarian rather than elaborately
   designed, since no design reference existed for them.
4. Wired all 25 student-facing pages + 8 admin pages to real data.

## Real bugs found and fixed along the way

These existed in the files as originally uploaded and would have broken the
build or misbehaved at runtime, independent of any integration work:

- `LearningPage.tsx` used `<Link>` without importing it — would not compile.
- `RegisterPage.tsx`'s submit button had no handler at all — not functional.
- `PracticePage.tsx` had unescaped `'` characters inside single-quoted JS
  string literals (e.g. `'<class 'int'>'`) — would not compile.
- `RecommendationsPage.tsx` and `AITutorPage.tsx` both had unescaped `'`
  inside string literals (`'You're on...'`, `'Hello! I'm...'`) — would not
  compile.
- Course→Learning routing mismatch: the route `/courses/:courseId/topics/:topicId`
  implies the backend's leaf content unit is a "Topic," but the actual
  schema's leaf content unit is a `Subtopic` (`Course → Module → Topic →
  Subtopic → content`). Rather than rename the route (a bigger, unrequested
  frontend change), `:topicId` is treated as a subtopic id when calling the
  API — documented in `CourseDashboard.tsx` and `LearningPage.tsx`.

## Known gaps — honest, not hidden

- **No password-reset-by-email flow exists on the backend.** `ForgotPasswordPage`
  says so directly to the user rather than faking a "check your email"
  success message. Building this needs a reset-token endpoint + an email
  provider, neither of which were part of any prior part's scope.
- **No sandboxed code execution is wired up.** `CodingPage` submissions will
  fail with a clear error until a real judge (Judge0/Piston/self-hosted
  Docker) is plugged into `backend/src/modules/coding/codeExecution.provider.ts`.
  This was flagged as a deliberate placeholder back in Part 5.
- **No LLM is wired up behind the GenAI Tutor.** `AITutorPage` will show a
  clear "temporarily unavailable" error until a provider is implemented in
  `backend/src/modules/tutor/tutor.provider.ts` (a working example
  implementation is commented in that file).
- **Face/multiple-face/phone detection is not implemented client-side.**
  `ExamPage` requests real camera access and shows a live preview, and
  implements one genuine ML-free proctoring signal (tab-switch detection via
  the browser's `visibilitychange` API, which is real and does report to
  the backend's escalation policy) — but actual visual analysis of the
  camera feed needs a browser-side model (e.g. face-api.js, MediaPipe) that
  wasn't built. This is real remaining work, not something faked to look
  finished.
- **No dedicated exam-builder admin UI.** Exam creation (assembling a
  question set, setting schedule/config) has to go through the backend API
  directly (`POST /api/exams/courses/:courseId`) for now — `AdminExamsPage`
  can list, publish, and report on exams, but not construct one from a form.
- **`AdminSecurityPage` doesn't have a global cross-exam proctoring feed** —
  the backend only exposes warnings scoped per-exam
  (`GET /api/exams/:examId/warnings`). The security page instead shows real
  account-security audit events (registration, password/MFA changes,
  activation toggles) and points admins to per-exam reports for proctoring
  review.
- **`AssignmentsPage` and `ExamsPage` fan out one request per enrolled
  course** to build a cross-course view, since the backend scopes both
  resources per-course and no aggregate "all my assignments/exams" endpoint
  exists. Fine at the scale this platform is likely to run at; would want a
  dedicated aggregate endpoint if enrollment counts grow large.

## Not touched

Marketing/static pages (`HomePage`, `AboutPage`, `FeaturesPage`, `ContactPage`,
`NotFoundPage`) needed no data wiring and were left as-is.
