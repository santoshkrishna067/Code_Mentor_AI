# Proctoring face-analysis service

Small Python (Flask + OpenCV + dlib) service that looks at ONE camera frame at a time and
reports: how many faces, head yaw/pitch, eye direction, mouth open, eyes closed, and objects
(phone, laptop, ...). It holds no state and decides nothing. The Express backend
(`backend/src/modules/proctoring/`) forwards frames from the logged-in student to it and
turns the findings into proctoring warnings using the existing escalation policy.

    Browser (camera, 1 frame/s) --> Express /api/proctoring/sessions/:id/frame --> this service :8001

## First-time setup (SETUP.ps1 does steps 2-3 for you)
1. `.\proctoring-service\copy-models.ps1`   (copies the 99 MB landmark model and the 35 MB YOLO weights)
2. `python -m venv venv` then `.\venv\Scripts\python.exe -m pip install -r requirements.txt`
3. `.\venv\Scripts\python.exe server.py`

## Test the camera + detection on its own
    .\venv\Scripts\python.exe live_preview.py
A window shows your camera with a green box on your face, your head angles (yaw/pitch),
and boxes on any phone/laptop. Press `q` to quit.

## Settings (environment variables, all optional)
| Name | Default | Meaning |
|---|---|---|
| PROCTORING_SERVICE_PORT | 8001 | port (also set PROCTORING_SERVICE_URL in backend/.env if you change it) |
| PROCTORING_SERVICE_TOKEN | (empty) | if set, requests must send it in `X-Proctoring-Token` (set the same value in backend/.env) |
| YOLO_CONFIDENCE | 0.45 | minimum confidence for object detections |
| YOLO_INPUT_SIZE | 416 | YOLO network size; smaller is faster but misses small objects |
| PROCTOR_MODELS_DIR | ./models | where the model files live |

## Known limits
* A photo or poster with a face on the wall can be counted as a second face.
* Eye-direction ("gaze") is a rough heuristic; it is logged but never raises a warning on its own.
* Single instance only (dlib/OpenCV objects are guarded by a lock). Fine for development and small groups.
