"""
Face-analysis service for Code Mentor AI exam proctoring.

    POST /analyze   body = one JPEG frame (Content-Type: image/jpeg)
                    -> JSON with face count, head angles, gaze, mouth, blink, objects
    GET  /health    -> {"status": "ok"}

It only listens on 127.0.0.1. The browser never talks to it: the Express backend
receives frames from the logged-in student, forwards them here, and decides what
counts as a warning.
"""
import hmac
import os
import sys
import time

import cv2
import numpy as np
from flask import Flask, jsonify, request

try:
    import detectors
except Exception as exc:  # models missing, dlib missing, ...
    print("\n[proctoring-service] Could not start:\n" + str(exc) + "\n", file=sys.stderr)
    sys.exit(1)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024  # a 640x480 JPEG is ~50 KB

TOKEN = os.environ.get("PROCTORING_SERVICE_TOKEN", "")


@app.get("/health")
def health():
    return jsonify(status="ok")


@app.post("/analyze")
def analyze():
    if TOKEN:
        supplied = request.headers.get("X-Proctoring-Token", "")
        if not hmac.compare_digest(supplied, TOKEN):
            return jsonify(error="Invalid service token"), 401

    raw = request.get_data(cache=False)
    if not raw:
        return jsonify(error="Empty request body"), 400

    frame = cv2.imdecode(np.frombuffer(raw, np.uint8), cv2.IMREAD_COLOR)
    if frame is None:
        return jsonify(error="Body is not a valid image"), 400

    started = time.perf_counter()
    result = detectors.analyze(frame)
    result["timingMs"] = round((time.perf_counter() - started) * 1000, 1)
    return jsonify(result)


if __name__ == "__main__":
    port = int(os.environ.get("PROCTORING_SERVICE_PORT", "8001"))
    print(f"[proctoring-service] ready on http://127.0.0.1:{port}  (Ctrl+C to stop)")
    app.run(host="127.0.0.1", port=port, threaded=False, debug=False)
