"""
Live camera window with the proctoring detectors drawn on top.
Use it to check that your webcam, the models and the detection all work, and to
see the head angles the service measures for you.

    python live_preview.py            # default camera
    python live_preview.py --camera 1 # a second camera

Press  q  in the video window to quit.
"""
import argparse
import os
import sys
import time

import cv2

GREEN, RED, AMBER, WHITE = (80, 200, 80), (60, 60, 230), (0, 180, 255), (255, 255, 255)


def draw_overlay(frame, result, fps=None):
    """Draw boxes and status text onto `frame` (in place) from an analyze() result."""
    h, w = frame.shape[:2]
    rw = float(result["frame"]["width"])
    scale = w / rw if rw else 1.0

    one_face = result["faceCount"] == 1
    for f in result["faces"]:
        x, y, fw, fh = (int(v * scale) for v in (f["x"], f["y"], f["w"], f["h"]))
        cv2.rectangle(frame, (x, y), (x + fw, y + fh), GREEN if one_face else RED, 2)

    for obj in result["objects"]:
        x, y, bw, bh = (int(v * scale) for v in obj["box"])
        color = RED if obj["label"] == "cell phone" else AMBER
        cv2.rectangle(frame, (x, y), (x + bw, y + bh), color, 2)
        cv2.putText(frame, "%s %.0f%%" % (obj["label"], obj["confidence"] * 100), (x, max(14, y - 6)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1, cv2.LINE_AA)

    head = result.get("head")
    lines = ["faces: %d" % result["faceCount"]]
    if result["faceCount"] == 0:
        lines.append("NO FACE")
    elif result["faceCount"] > 1:
        lines.append("MORE THAN ONE FACE")
    else:
        if head:
            lines.append("yaw %+.0f  pitch %+.0f" % (head["yaw"], head["pitch"]))
        lines.append("gaze: %s" % result.get("gaze"))
        lines.append("mouth: %s" % ("open" if result.get("mouthOpen") else "closed"))
        lines.append("eyes: %s" % ("closed" if result.get("blink") else "open"))
    if fps is not None:
        lines.append("%.1f fps" % fps)

    y = 22
    for text in lines:
        bad = text.startswith(("NO FACE", "MORE THAN"))
        cv2.putText(frame, text, (10, y), cv2.FONT_HERSHEY_SIMPLEX, 0.6, RED if bad else WHITE, 2, cv2.LINE_AA)
        y += 22
    return frame


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--camera", type=int, default=0)
    args = parser.parse_args()

    try:
        import detectors
    except Exception as exc:
        print("\nCould not load the detectors:\n%s\n" % exc, file=sys.stderr)
        sys.exit(1)

    backend = cv2.CAP_DSHOW if os.name == "nt" else cv2.CAP_ANY
    cam = cv2.VideoCapture(args.camera, backend)
    if not cam.isOpened():
        print("Could not open camera %d. Close Zoom/Teams/browser tabs using it, and check "
              "Windows Settings > Privacy & security > Camera." % args.camera, file=sys.stderr)
        sys.exit(1)

    print("Live preview running. Click the video window and press 'q' to quit.")
    last = time.perf_counter()
    fps = None
    while True:
        ok, frame = cam.read()
        if not ok:
            print("Camera stopped delivering frames.", file=sys.stderr)
            break
        result = detectors.analyze(frame)
        now = time.perf_counter()
        fps = 1.0 / max(now - last, 1e-6) if fps is None else 0.9 * fps + 0.1 * (1.0 / max(now - last, 1e-6))
        last = now
        cv2.imshow("Proctoring live preview  (q = quit)", draw_overlay(frame, result, fps))
        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cam.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
