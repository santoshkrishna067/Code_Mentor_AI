"""
Stateless detectors for the Code Mentor AI exam-proctoring service.

Adapted from the "AI based Online Exam Proctoring System" project. Differences
from the original, and why:

* Nothing is drawn on the frame and nothing beeps. The functions only RETURN
  data; the Node backend decides what counts as a warning.
* Models are loaded ONCE (the original loaded the 99 MB landmark model four
  times) and from absolute paths, so the service works from any folder.
* Head pose is computed as real yaw/pitch angles. The original compared the
  slope of a line in the image, which reports "Head Up/Down" for a face that is
  looking straight at the camera.
* YOLO runs at 416x416 (the model's native size) so a phone held up to the
  camera is actually large enough to be detected.
* Every step is guarded, so one odd frame cannot crash the service.
"""
import math
import os
import threading

import cv2
import numpy as np
import dlib

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.environ.get("PROCTOR_MODELS_DIR", os.path.join(BASE_DIR, "models"))

LANDMARK_MODEL = os.path.join(MODELS_DIR, "shape_predictor_68_face_landmarks.dat")
YOLO_WEIGHTS = os.path.join(MODELS_DIR, "yolov3-tiny.weights")
YOLO_CONFIG = os.path.join(MODELS_DIR, "yolov3-tiny.cfg")
COCO_NAMES = os.path.join(MODELS_DIR, "coco.names")

# Frames are scaled to this width before analysis so the pixel-based thresholds
# below behave the same whatever resolution the browser camera uses.
FRAME_WIDTH = 640

YOLO_INPUT_SIZE = int(os.environ.get("YOLO_INPUT_SIZE", "416"))
YOLO_CONFIDENCE = float(os.environ.get("YOLO_CONFIDENCE", "0.45"))
YOLO_NMS = 0.4

BLINK_RATIO = 3.6        # eye width / eye height at or above this = eyes closed
MOUTH_OPEN_PX = 23       # lip gap (px at 640 wide) above this = mouth open
GAZE_RATIO = 1.2         # same value the original project used

# Generic 3D face model (nose tip, chin, eye corners, mouth corners) and the
# matching dlib 68-landmark indices.
_MODEL_POINTS = np.array(
    [
        (0.0, 0.0, 0.0),
        (0.0, -330.0, -65.0),
        (-225.0, 170.0, -135.0),
        (225.0, 170.0, -135.0),
        (-150.0, -150.0, -125.0),
        (150.0, -150.0, -125.0),
    ],
    dtype=np.float64,
)
_POSE_LANDMARKS = (30, 8, 36, 45, 48, 54)
_LEFT_EYE = (36, 37, 38, 39, 40, 41)
_RIGHT_EYE = (42, 43, 44, 45, 46, 47)


class ModelsMissingError(RuntimeError):
    pass


def _check_models():
    needed = [LANDMARK_MODEL, YOLO_WEIGHTS, YOLO_CONFIG, COCO_NAMES]
    missing = [p for p in needed if not os.path.isfile(p)]
    if missing:
        names = "\n  - ".join(missing)
        raise ModelsMissingError(
            "Model file(s) not found:\n  - "
            + names
            + "\n\nRun  .\\proctoring-service\\copy-models.ps1  (it copies the two large files from the "
            "proctoring project you downloaded), then start the service again."
        )


_check_models()

_face_detector = dlib.get_frontal_face_detector()
_landmark_predictor = dlib.shape_predictor(LANDMARK_MODEL)

_net = cv2.dnn.readNet(YOLO_WEIGHTS, YOLO_CONFIG)
_output_layers = _net.getUnconnectedOutLayersNames()
with open(COCO_NAMES, "r") as _f:
    _labels = [line.strip() for line in _f.readlines() if line.strip()]

# dlib / OpenCV-dnn objects are not documented as thread-safe.
_lock = threading.Lock()


def _normalise_frame(frame):
    h, w = frame.shape[:2]
    if w == FRAME_WIDTH:
        return frame
    scale = FRAME_WIDTH / float(w)
    return cv2.resize(frame, (FRAME_WIDTH, max(1, int(round(h * scale)))), interpolation=cv2.INTER_AREA)


def _pt(shape, i):
    p = shape.part(i)
    return (float(p.x), float(p.y))


def _dist(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])


def _mid(a, b):
    return ((a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0)


def eye_closed(shape):
    """Blink check from the eye aspect ratio (same rule as the original)."""
    def ratio(idx):
        left, right = _pt(shape, idx[0]), _pt(shape, idx[3])
        top = _mid(_pt(shape, idx[1]), _pt(shape, idx[2]))
        bottom = _mid(_pt(shape, idx[5]), _pt(shape, idx[4]))
        vertical = _dist(top, bottom)
        horizontal = _dist(left, right)
        return horizontal / vertical if vertical > 1e-6 else float("inf")

    return ratio(_LEFT_EYE) >= BLINK_RATIO or ratio(_RIGHT_EYE) >= BLINK_RATIO


def mouth_open(shape):
    return _dist(_pt(shape, 51), _pt(shape, 57)) > MOUTH_OPEN_PX


def _white_pixels(binary, half):
    h, w = binary.shape[:2]
    part = binary[:, : w // 2] if half == "left" else binary[:, w // 2:]
    return int(cv2.countNonZero(part))


def gaze_direction(gray, shape):
    """Rough eye-direction heuristic from the original project: left / right /
    center / unknown. It is noisy, so the backend only logs it, it never
    triggers a warning by itself."""
    try:
        regions = []
        for idx in (_LEFT_EYE, _RIGHT_EYE):
            regions.append(np.array([(int(shape.part(i).x), int(shape.part(i).y)) for i in idx], np.int32))

        mask = np.zeros(gray.shape[:2], np.uint8)
        cv2.fillPoly(mask, regions, 255)
        eyes = cv2.bitwise_and(gray, gray, mask=mask)

        thresholds = []
        for region in regions:
            x0, x1 = int(region[:, 0].min()), int(region[:, 0].max())
            y0, y1 = int(region[:, 1].min()), int(region[:, 1].max())
            x0, y0 = max(x0, 0), max(y0, 0)
            crop = eyes[y0:y1, x0:x1]
            if crop.shape[0] < 3 or crop.shape[1] < 4:
                return "unknown"
            thresholds.append(cv2.adaptiveThreshold(crop, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 11, 2))

        left_th, right_th = thresholds
        # Same comparisons as the original project, with clearer names.
        l_right_half, l_left_half = _white_pixels(left_th, "right"), _white_pixels(left_th, "left")
        r_right_half, r_left_half = _white_pixels(right_th, "right"), _white_pixels(right_th, "left")

        if r_left_half >= GAZE_RATIO * r_right_half:
            return "left"
        if l_right_half >= GAZE_RATIO * l_left_half:
            return "right"
        return "center"
    except Exception:
        return "unknown"


def head_pose(shape, width, height):
    """Head yaw / pitch in degrees, or None if the pose could not be solved.

    yaw   > 0  : face points toward the RIGHT edge of the image
    pitch > 0  : face points UP, pitch < 0 : face points DOWN

    Frontal face = (0, 0). Computed from the face-normal vector, so there is no
    Euler-angle wrap-around problem near +/-180 degrees.
    """
    try:
        image_points = np.array([_pt(shape, i) for i in _POSE_LANDMARKS], dtype=np.float64)
        focal = float(width)
        camera = np.array([[focal, 0, width / 2.0], [0, focal, height / 2.0], [0, 0, 1]], dtype=np.float64)
        ok, rvec, _tvec = cv2.solvePnP(
            _MODEL_POINTS, image_points, camera, np.zeros((4, 1)), flags=cv2.SOLVEPNP_ITERATIVE
        )
        if not ok:
            return None
        rotation, _ = cv2.Rodrigues(rvec)
        normal = rotation @ np.array([0.0, 0.0, 1.0])  # frontal => (0, 0, -1) in camera space
        yaw = math.degrees(math.atan2(normal[0], -normal[2]))
        pitch = math.degrees(math.atan2(-normal[1], -normal[2]))
        return {"yaw": round(yaw, 1), "pitch": round(pitch, 1)}
    except Exception:
        return None


def detect_objects(frame):
    """YOLOv3-tiny detections: [{label, confidence, box:[x, y, w, h]}]."""
    h, w = frame.shape[:2]
    blob = cv2.dnn.blobFromImage(frame, 1 / 255.0, (YOLO_INPUT_SIZE, YOLO_INPUT_SIZE), (0, 0, 0), True, crop=False)
    _net.setInput(blob)
    outputs = _net.forward(_output_layers)

    boxes, confidences, class_ids = [], [], []
    for out in outputs:
        for det in out:
            scores = det[5:]
            class_id = int(np.argmax(scores))
            confidence = float(scores[class_id])
            if confidence < YOLO_CONFIDENCE:
                continue
            cx, cy, bw, bh = det[0] * w, det[1] * h, det[2] * w, det[3] * h
            boxes.append([int(cx - bw / 2), int(cy - bh / 2), int(bw), int(bh)])
            confidences.append(confidence)
            class_ids.append(class_id)

    if not boxes:
        return []
    keep = cv2.dnn.NMSBoxes(boxes, confidences, YOLO_CONFIDENCE, YOLO_NMS)
    keep = np.array(keep).flatten().tolist() if len(keep) else []
    return [
        {
            "label": _labels[class_ids[i]] if class_ids[i] < len(_labels) else str(class_ids[i]),
            "confidence": round(confidences[i], 3),
            "box": boxes[i],
        }
        for i in keep
    ]


def analyze(frame_bgr):
    """Analyse one BGR frame and return a JSON-serialisable dict."""
    with _lock:
        frame = _normalise_frame(frame_bgr)
        height, width = frame.shape[:2]
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        rects = _face_detector(gray, 0)
        faces = [
            {"x": int(r.left()), "y": int(r.top()), "w": int(r.width()), "h": int(r.height())}
            for r in rects
        ]

        result = {
            "frame": {"width": int(width), "height": int(height)},
            "faceCount": len(faces),
            "faces": faces,
            "blink": None,
            "gaze": None,
            "mouthOpen": None,
            "head": None,
            "objects": [],
        }

        # Per-face detail only when exactly one face is present (as in the original).
        if len(rects) == 1:
            shape = _landmark_predictor(gray, rects[0])
            result["blink"] = bool(eye_closed(shape))
            result["gaze"] = gaze_direction(gray, shape)
            result["mouthOpen"] = bool(mouth_open(shape))
            result["head"] = head_pose(shape, width, height)

        try:
            result["objects"] = detect_objects(frame)
        except Exception:
            result["objects"] = []

        return result
