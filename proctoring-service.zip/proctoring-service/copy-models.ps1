# Copies the two large model files from the proctoring project you downloaded into
# proctoring-service\models.   Run from the project folder:
#     .\proctoring-service\copy-models.ps1
# If your downloaded folder is somewhere else, pass it:
#     .\proctoring-service\copy-models.ps1 -Source "D:\path\to\Artificial-Intelligence-based-Online-Exam-Proctoring-System-main"
param(
  [string]$Source = "D:\Downloads\Artificial-Intelligence-based-Online-Exam-Proctoring-System-main\Artificial-Intelligence-based-Online-Exam-Proctoring-System-main"
)
$ErrorActionPreference = "Stop"
$dest = Join-Path $PSScriptRoot "models"
$files = @(
  @{ From = "shape_predictor_model\shape_predictor_68_face_landmarks.dat"; To = "shape_predictor_68_face_landmarks.dat" },
  @{ From = "object_detection_model\weights\yolov3-tiny.weights";          To = "yolov3-tiny.weights" }
)
foreach ($f in $files) {
  $from = Join-Path $Source $f.From
  if (-not (Test-Path $from)) {
    Write-Host "Not found: $from" -ForegroundColor Red
    Write-Host "Pass the folder that contains shape_predictor_model\ with  -Source ""<folder>""" -ForegroundColor Yellow
    exit 1
  }
  Copy-Item $from (Join-Path $dest $f.To) -Force
  Write-Host "Copied $($f.To)" -ForegroundColor Green
}
Write-Host "Models are in place. You can now start the service (START.ps1 does it for you)." -ForegroundColor Green
