import request from 'supertest'
import { app, registerAndLogin, createAdminAndLogin, disconnectPrisma } from './helpers'

afterAll(disconnectPrisma)

async function setupCourseAndExam(opts: { negativeMarking?: boolean; showResults?: boolean; maxAttempts?: number; proctoringEnabled?: boolean } = {}) {
  const admin = await createAdminAndLogin()
  const adminAuth = `Bearer ${admin.accessToken}`

  const courseRes = await request(app)
    .post('/api/courses')
    .set('Authorization', adminAuth)
    .send({
      name: 'Exam Test Course',
      slug: `exam-course-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      description: 'x',
      difficulty: 'BEGINNER',
      estimatedDuration: 1,
      status: 'PUBLISHED',
    })
  const courseId = courseRes.body.data.id

  const q1 = await request(app)
    .post('/api/admin/questions')
    .set('Authorization', adminAuth)
    .send({
      type: 'MCQ',
      content: 'What is 2 + 2?',
      correctAnswer: '4',
      difficulty: 'BEGINNER',
      courseId,
      estimatedTime: 30,
      marks: 10,
      negativeMarks: 2,
      options: [{ content: '3', isCorrect: false }, { content: '4', isCorrect: true }, { content: '5', isCorrect: false }],
    })
  const q2 = await request(app)
    .post('/api/admin/questions')
    .set('Authorization', adminAuth)
    .send({
      type: 'MCQ',
      content: 'What is 3 + 3?',
      correctAnswer: '6',
      difficulty: 'BEGINNER',
      courseId,
      estimatedTime: 30,
      marks: 10,
      negativeMarks: 2,
      options: [{ content: '6', isCorrect: true }, { content: '7', isCorrect: false }],
    })

  const examRes = await request(app)
    .post(`/api/exams/courses/${courseId}`)
    .set('Authorization', adminAuth)
    .send({
      title: 'Arithmetic Exam',
      description: 'Basic arithmetic',
      duration: 30,
      totalMarks: 20,
      passingScore: 50,
      negativeMarking: opts.negativeMarking ?? false,
      randomizeQuestions: false,
      showResults: opts.showResults ?? true,
      proctoringEnabled: opts.proctoringEnabled ?? true,
      maxAttempts: opts.maxAttempts ?? 1,
      scheduledStart: new Date(Date.now() - 60_000).toISOString(),
      scheduledEnd: new Date(Date.now() + 3600_000).toISOString(),
      questionIds: [q1.body.data.id, q2.body.data.id],
    })
  const examId = examRes.body.data.id

  const publishRes = await request(app).post(`/api/exams/${examId}/publish`).set('Authorization', adminAuth)
  expect(publishRes.status).toBe(200)

  return { admin, adminAuth, courseId, examId, q1Id: q1.body.data.id, q2Id: q2.body.data.id }
}

describe('Exams: full lifecycle', () => {
  it('walks create -> publish -> enroll -> start -> answer -> submit -> review', async () => {
    const { adminAuth, courseId, examId } = await setupCourseAndExam()
    const student = await registerAndLogin()
    const studentAuth = `Bearer ${student.accessToken}`

    // not enrolled yet -> ineligible
    const notEligible = await request(app).get(`/api/exams/${examId}/eligibility`).set('Authorization', studentAuth)
    expect(notEligible.body.data.eligible).toBe(false)

    await request(app).post(`/api/courses/${courseId}/enroll`).set('Authorization', studentAuth)

    const eligible = await request(app).get(`/api/exams/${examId}/eligibility`).set('Authorization', studentAuth)
    expect(eligible.body.data.eligible).toBe(true)

    const startRes = await request(app).post(`/api/exams/${examId}/start`).set('Authorization', studentAuth)
    expect(startRes.status).toBe(201)
    const attemptId = startRes.body.data.attemptId
    expect(startRes.body.data.questions.length).toBe(2)
    // never leak the answer key before submission
    expect(startRes.body.data.questions[0].correctAnswer).toBeUndefined()

    const q1Id = startRes.body.data.questions[0].id
    const q2Id = startRes.body.data.questions[1].id

    // reject an answer for a question that doesn't belong to this attempt
    const badAnswer = await request(app)
      .patch(`/api/exams/attempts/${attemptId}/answers`)
      .set('Authorization', studentAuth)
      .send({ answers: [{ questionId: 'not-a-real-question-id', answer: '4' }] })
    expect(badAnswer.status).toBe(400)

    const saveRes = await request(app)
      .patch(`/api/exams/attempts/${attemptId}/answers`)
      .set('Authorization', studentAuth)
      .send({ answers: [{ questionId: q1Id, answer: '4' }, { questionId: q2Id, answer: '6' }] })
    expect(saveRes.status).toBe(200)
    expect(saveRes.body.data.answeredQuestionIds.length).toBe(2)

    const submitRes = await request(app).post(`/api/exams/attempts/${attemptId}/submit`).set('Authorization', studentAuth)
    expect(submitRes.status).toBe(200)
    expect(submitRes.body.data.score).toBe(100)
    expect(submitRes.body.data.passed).toBe(true)

    // cannot submit twice
    const doubleSubmit = await request(app).post(`/api/exams/attempts/${attemptId}/submit`).set('Authorization', studentAuth)
    expect(doubleSubmit.status).toBe(409)

    const reviewRes = await request(app).get(`/api/exams/attempts/${attemptId}/review`).set('Authorization', studentAuth)
    expect(reviewRes.status).toBe(200)
    expect(reviewRes.body.data.score).toBe(100)
    expect(reviewRes.body.data.questions[0].correctAnswer).toBeDefined() // answer key visible post-submission

    const reportRes = await request(app).get(`/api/exams/${examId}/report`).set('Authorization', adminAuth)
    expect(reportRes.status).toBe(200)
    expect(reportRes.body.data.totalAttempts).toBe(1)
    expect(reportRes.body.data.averageScore).toBe(100)
  })

  it('applies negative marking correctly end-to-end', async () => {
    const { examId } = await setupCourseAndExam({ negativeMarking: true })
    const student = await registerAndLogin()
    const studentAuth = `Bearer ${student.accessToken}`

    // Re-fetch courseId via the admin exam detail endpoint.
    const admin = await createAdminAndLogin()
    const examDetail = await request(app).get(`/api/exams/${examId}/admin`).set('Authorization', `Bearer ${admin.accessToken}`)
    const courseId = examDetail.body.data.courseId
    await request(app).post(`/api/courses/${courseId}/enroll`).set('Authorization', studentAuth)

    const startRes = await request(app).post(`/api/exams/${examId}/start`).set('Authorization', studentAuth)
    const attemptId = startRes.body.data.attemptId
    const q1Id = startRes.body.data.questions[0].id
    const q2Id = startRes.body.data.questions[1].id

    // one correct (10 marks), one wrong (-2 penalty) => 8/20 = 40%
    await request(app)
      .patch(`/api/exams/attempts/${attemptId}/answers`)
      .set('Authorization', studentAuth)
      .send({ answers: [{ questionId: q1Id, answer: '4' }, { questionId: q2Id, answer: 'wrong' }] })

    const submitRes = await request(app).post(`/api/exams/attempts/${attemptId}/submit`).set('Authorization', studentAuth)
    expect(submitRes.body.data.score).toBe(40)
    expect(submitRes.body.data.passed).toBe(false) // passingScore is 50
  })

  it('enforces maxAttempts', async () => {
    const { examId, courseId } = await setupCourseAndExam({ maxAttempts: 1 })
    const student = await registerAndLogin()
    const studentAuth = `Bearer ${student.accessToken}`
    await request(app).post(`/api/courses/${courseId}/enroll`).set('Authorization', studentAuth)

    const startRes = await request(app).post(`/api/exams/${examId}/start`).set('Authorization', studentAuth)
    const attemptId = startRes.body.data.attemptId
    await request(app).post(`/api/exams/attempts/${attemptId}/submit`).set('Authorization', studentAuth)

    const secondStart = await request(app).post(`/api/exams/${examId}/start`).set('Authorization', studentAuth)
    expect(secondStart.status).toBe(403)
  })

  it('a student cannot review another student’s attempt when showResults is disabled for them', async () => {
    const { examId, courseId } = await setupCourseAndExam({ showResults: false })
    const a = await registerAndLogin()
    const b = await registerAndLogin()
    await request(app).post(`/api/courses/${courseId}/enroll`).set('Authorization', `Bearer ${a.accessToken}`)
    await request(app).post(`/api/courses/${courseId}/enroll`).set('Authorization', `Bearer ${b.accessToken}`)

    const startRes = await request(app).post(`/api/exams/${examId}/start`).set('Authorization', `Bearer ${a.accessToken}`)
    const attemptId = startRes.body.data.attemptId
    await request(app).post(`/api/exams/attempts/${attemptId}/submit`).set('Authorization', `Bearer ${a.accessToken}`)

    // owner blocked because showResults=false
    const ownerReview = await request(app).get(`/api/exams/attempts/${attemptId}/review`).set('Authorization', `Bearer ${a.accessToken}`)
    expect(ownerReview.status).toBe(403)

    // another student blocked entirely (not their attempt)
    const otherReview = await request(app).get(`/api/exams/attempts/${attemptId}/review`).set('Authorization', `Bearer ${b.accessToken}`)
    expect(otherReview.status).toBe(403)
  })
})

describe('Proctoring escalation policy', () => {
  it('terminates an attempt for cause after 3 HIGH-severity warnings, and blocks further answering', async () => {
    const { examId, courseId, adminAuth } = await setupCourseAndExam({ proctoringEnabled: true })
    const student = await registerAndLogin()
    const studentAuth = `Bearer ${student.accessToken}`
    await request(app).post(`/api/courses/${courseId}/enroll`).set('Authorization', studentAuth)

    const startRes = await request(app).post(`/api/exams/${examId}/start`).set('Authorization', studentAuth)
    const attemptId = startRes.body.data.attemptId

    // 2 HIGH warnings: not enough to escalate yet
    for (let i = 0; i < 2; i++) {
      const res = await request(app)
        .post(`/api/proctoring/sessions/${attemptId}/warnings`)
        .set('Authorization', studentAuth)
        .send({ type: 'MULTIPLE_FACES', severity: 'HIGH', message: 'second face detected' })
      expect(res.body.data.escalated).toBe(false)
    }

    // 3rd HIGH warning crosses the threshold
    const escalating = await request(app)
      .post(`/api/proctoring/sessions/${attemptId}/warnings`)
      .set('Authorization', studentAuth)
      .send({ type: 'MULTIPLE_FACES', severity: 'HIGH', message: 'second face detected again' })
    expect(escalating.body.data.escalated).toBe(true)

    // the attempt is now terminal — further answers are rejected
    const answerAfterFlag = await request(app)
      .patch(`/api/exams/attempts/${attemptId}/answers`)
      .set('Authorization', studentAuth)
      .send({ answers: [] })
    expect(answerAfterFlag.status).toBe(409)

    const state = await request(app).get(`/api/exams/attempts/${attemptId}`).set('Authorization', studentAuth)
    expect(state.body.data.status).toBe('flagged')

    // it earned no XP / does not count as course completion
    const xpRes = await request(app).get('/api/xp/history').set('Authorization', studentAuth)
    expect(xpRes.body.data.totalXP).toBe(0)

    const reportRes = await request(app).get(`/api/exams/${examId}/report`).set('Authorization', adminAuth)
    expect(reportRes.body.data.flaggedCount).toBe(1)

    const warningsRes = await request(app).get(`/api/exams/${examId}/warnings`).set('Authorization', adminAuth)
    expect(warningsRes.body.data.length).toBe(3)
  })

  it('a single LOW-severity warning does not escalate', async () => {
    const { examId, courseId } = await setupCourseAndExam()
    const student = await registerAndLogin()
    const studentAuth = `Bearer ${student.accessToken}`
    await request(app).post(`/api/courses/${courseId}/enroll`).set('Authorization', studentAuth)
    const startRes = await request(app).post(`/api/exams/${examId}/start`).set('Authorization', studentAuth)
    const attemptId = startRes.body.data.attemptId

    const res = await request(app)
      .post(`/api/proctoring/sessions/${attemptId}/warnings`)
      .set('Authorization', studentAuth)
      .send({ type: 'LOOKING_AWAY', severity: 'LOW', message: 'looked away briefly' })
    expect(res.body.data.escalated).toBe(false)

    const state = await request(app).get(`/api/exams/attempts/${attemptId}`).set('Authorization', studentAuth)
    expect(state.body.data.status).toBe('in_progress')
  })

  it('a student cannot report a warning on another student’s session', async () => {
    const { examId, courseId } = await setupCourseAndExam()
    const a = await registerAndLogin()
    const b = await registerAndLogin()
    await request(app).post(`/api/courses/${courseId}/enroll`).set('Authorization', `Bearer ${a.accessToken}`)
    const startRes = await request(app).post(`/api/exams/${examId}/start`).set('Authorization', `Bearer ${a.accessToken}`)
    const attemptId = startRes.body.data.attemptId

    const res = await request(app)
      .post(`/api/proctoring/sessions/${attemptId}/warnings`)
      .set('Authorization', `Bearer ${b.accessToken}`)
      .send({ type: 'NO_FACE', severity: 'LOW', message: 'x' })
    expect(res.status).toBe(404) // owned-session lookup returns not-found rather than leaking existence
  })
})
