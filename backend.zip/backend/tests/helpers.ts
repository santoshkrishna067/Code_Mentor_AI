import request from 'supertest'
import { createApp } from '@/app'
import { prisma } from '@/config/prisma'

export const app = createApp()

export async function registerAndLogin(overrides?: Partial<{ email: string; password: string; name: string }>) {
  const email = overrides?.email ?? `student+${Date.now()}-${Math.random().toString(36).slice(2)}@test.com`
  const password = overrides?.password ?? 'Password123'
  const name = overrides?.name ?? 'Test Student'

  const res = await request(app).post('/api/auth/register').send({ email, password, name, agreeToTerms: true })
  return { ...res.body.data, email, password }
}

export async function createAdminAndLogin() {
  const email = `admin+${Date.now()}-${Math.random().toString(36).slice(2)}@test.com`
  const password = 'AdminPass123'
  await prisma.user.create({
    data: {
      email,
      name: 'Test Admin',
      role: 'ADMIN',
      passwordHash: await (await import('@/utils/password')).hashPassword(password),
      adminProfile: { create: {} },
    },
  })
  const res = await request(app).post('/api/auth/login').send({ email, password })
  return { ...res.body.data, email, password }
}

export async function disconnectPrisma() {
  await prisma.$disconnect()
}
