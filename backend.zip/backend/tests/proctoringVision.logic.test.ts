import {
  createVisionState,
  evaluateFrame,
  VisionFrame,
  VisionState,
  BASELINE_SAMPLES,
  COOLDOWN_MS,
} from '@/modules/proctoring/proctoring.vision.logic'

// Pure-logic tests: no database, no network, no Python service needed.

const face = (w = 160) => ({ x: 240, y: 120, w, h: w })

function frame(opts: Partial<VisionFrame> & { faces?: ReturnType<typeof face>[] } = {}): VisionFrame {
  const faces = opts.faces ?? [face()]
  return {
    frame: { width: 640, height: 480 },
    faceCount: faces.length,
    faces,
    head: faces.length === 1 ? opts.head ?? { yaw: 0, pitch: 0 } : null,
    gaze: 'center',
    mouthOpen: false,
    blink: false,
    objects: opts.objects ?? [],
  }
}

/** Feed the same frame once per second for `seconds`, starting at `startMs`. Returns every warning raised. */
function run(state: VisionState, f: VisionFrame, startMs: number, seconds: number) {
  const warnings: string[] = []
  let status = ''
  for (let s = 0; s <= seconds; s++) {
    const d = evaluateFrame(state, f, startMs + s * 1000)
    warnings.push(...d.warnings.map((w) => w.type))
    status = d.status
  }
  return { warnings, status }
}

function calibrated(): { state: VisionState; t: number } {
  const state = createVisionState()
  run(state, frame(), 0, BASELINE_SAMPLES) // BASELINE_SAMPLES + 1 frames
  return { state, t: (BASELINE_SAMPLES + 1) * 1000 }
}

describe('proctoring vision logic', () => {
  it('reports "calibrating" until the baseline is collected, then "ok"', () => {
    const state = createVisionState()
    expect(evaluateFrame(state, frame(), 0).status).toBe('calibrating')
    const { status } = run(state, frame(), 1000, BASELINE_SAMPLES)
    expect(status).toBe('ok')
  })

  it('raises nothing for a student who stays in view and faces the screen', () => {
    const { state, t } = calibrated()
    expect(run(state, frame(), t, 120).warnings).toEqual([])
  })

  it('NO_FACE needs ~4 seconds, and a brief dropout raises nothing', () => {
    const { state, t } = calibrated()
    expect(run(state, frame({ faces: [] }), t, 2).warnings).toEqual([]) // 3 frames over 2 s
    expect(evaluateFrame(state, frame(), t + 3000).status).toBe('ok') // face is back, timer resets
    const r = run(state, frame({ faces: [] }), t + 10_000, 4)
    expect(r.warnings).toEqual(['NO_FACE'])
    expect(r.status).toBe('no_face')
  })

  it('does not repeat the same warning inside the cooldown, then repeats after it', () => {
    const { state, t } = calibrated()
    const r = run(state, frame({ faces: [] }), t, 130)
    // ~4s, then every COOLDOWN_MS while the condition persists
    expect(COOLDOWN_MS).toBe(60_000)
    expect(r.warnings).toEqual(['NO_FACE', 'NO_FACE', 'NO_FACE'])
  })

  it('MULTIPLE_FACES is HIGH after ~2 seconds', () => {
    const { state, t } = calibrated()
    const d: string[] = []
    for (let s = 0; s <= 3; s++) {
      const out = evaluateFrame(state, frame({ faces: [face(160), face(150)] }), t + s * 1000)
      d.push(...out.warnings.map((w) => `${w.type}:${w.severity}`))
    }
    expect(d).toEqual(['MULTIPLE_FACES:HIGH'])
  })

  it('ignores a small background face (poster / far away) next to the student', () => {
    const { state, t } = calibrated()
    const r = run(state, frame({ faces: [face(160), face(50)] }), t, 30)
    expect(r.warnings).toEqual([])
    expect(r.status).toBe('ok')
  })

  it('PHONE_DETECTED is HIGH when seen for ~2 seconds, but one stray frame is ignored', () => {
    const { state, t } = calibrated()
    const phone = frame({ objects: [{ label: 'cell phone', confidence: 0.7 }] })
    expect(evaluateFrame(state, phone, t).warnings).toHaveLength(0)
    expect(evaluateFrame(state, frame(), t + 1000).warnings).toHaveLength(0) // gone again -> timer reset
    const r = run(state, phone, t + 5000, 3)
    expect(r.warnings).toEqual(['PHONE_DETECTED'])
  })

  it('LOOKING_AWAY (LOW) needs ~5 seconds of a turned head; a short glance is fine', () => {
    const { state, t } = calibrated()
    const away = frame({ head: { yaw: 45, pitch: 0 } })
    expect(run(state, away, t, 3).warnings).toEqual([])
    expect(evaluateFrame(state, frame(), t + 4000).warnings).toHaveLength(0)
    const r = run(state, away, t + 10_000, 6)
    expect(r.warnings).toEqual(['LOOKING_AWAY'])
    expect(r.status).toBe('looking_away')
  })

  it('measures head angle relative to the student’s own starting position', () => {
    const state = createVisionState()
    // camera sits to one side: this student's "looking at the screen" is yaw 15, pitch -10
    run(state, frame({ head: { yaw: 15, pitch: -10 } }), 0, BASELINE_SAMPLES)
    const t = (BASELINE_SAMPLES + 1) * 1000
    // yaw 40 is only 25 degrees from their baseline -> fine
    expect(run(state, frame({ head: { yaw: 40, pitch: -10 } }), t, 20).warnings).toEqual([])
    // yaw 60 is 45 degrees from baseline -> flagged
    expect(run(state, frame({ head: { yaw: 60, pitch: -10 } }), t + 30_000, 6).warnings).toEqual(['LOOKING_AWAY'])
  })

  it('a stall in frames does not turn into a "sustained" condition', () => {
    const { state, t } = calibrated()
    evaluateFrame(state, frame({ faces: [] }), t)
    evaluateFrame(state, frame({ faces: [] }), t + 2000)
    // 20 s gap (tab throttled / network hiccup), then the next no-face frame
    expect(evaluateFrame(state, frame({ faces: [] }), t + 22_000).warnings).toHaveLength(0)
  })

  it('logs watched objects as events (never warnings), once per cooldown, ignoring low confidence', () => {
    const { state, t } = calibrated()
    const laptop = frame({ objects: [{ label: 'laptop', confidence: 0.8 }] })
    const first = evaluateFrame(state, laptop, t)
    expect(first.warnings).toHaveLength(0)
    expect(first.events.map((e) => e.type)).toEqual(['OBJECT_SEEN'])
    expect(evaluateFrame(state, laptop, t + 5000).events).toHaveLength(0)
    expect(evaluateFrame(state, laptop, t + 121_000).events).toHaveLength(1)
    const weak = frame({ objects: [{ label: 'book', confidence: 0.4 }] })
    expect(evaluateFrame(createVisionState(), weak, 0).events).toHaveLength(0)
  })
})
