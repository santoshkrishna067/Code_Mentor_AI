import request from 'supertest'
import { app, registerAndLogin, createAdminAndLogin, disconnectPrisma } from './helpers'

afterAll(disconnectPrisma)

describe('Course -> Syllabus -> Learning -> XP integration', () => {
  it('walks the full student journey for one subtopic', async () => {
    const admin = await createAdminAndLogin()
    const student = await registerAndLogin()
    const adminAuth = `Bearer ${admin.accessToken}`
    const studentAuth = `Bearer ${student.accessToken}`

    // 1. Admin creates a published course
    const courseRes = await request(app)
      .post('/api/courses')
      .set('Authorization', adminAuth)
      .send({
        name: 'Integration Test Course',
        slug: `integration-course-${Date.now()}`,
        description: 'Course for integration testing',
        difficulty: 'BEGINNER',
        estimatedDuration: 10,
        status: 'PUBLISHED',
      })
    expect(courseRes.status).toBe(201)
    const courseId = courseRes.body.data.id

    // 2. Admin builds Module -> Topic -> Subtopic
    const moduleRes = await request(app)
      .post(`/api/syllabus/courses/${courseId}/modules`)
      .set('Authorization', adminAuth)
      .send({ title: 'Module 1', description: 'First module', order: 0, estimatedDuration: 5 })
    expect(moduleRes.status).toBe(201)
    const moduleId = moduleRes.body.data.id

    const topicRes = await request(app)
      .post(`/api/syllabus/modules/${moduleId}/topics`)
      .set('Authorization', adminAuth)
      .send({ title: 'Topic 1', description: 'First topic', order: 0, estimatedDuration: 30 })
    expect(topicRes.status).toBe(201)
    const topicId = topicRes.body.data.id

    const subtopicRes = await request(app)
      .post(`/api/syllabus/topics/${topicId}/subtopics`)
      .set('Authorization', adminAuth)
      .send({ title: 'Subtopic 1', order: 0, estimatedDuration: 10 })
    expect(subtopicRes.status).toBe(201)
    const subtopicId = subtopicRes.body.data.id

    // 3. Admin attaches a video to the subtopic
    const videoRes = await request(app)
      .post(`/api/syllabus/subtopics/${subtopicId}/video`)
      .set('Authorization', adminAuth)
      .send({
        title: 'Intro video',
        duration: 300,
        languages: [{ code: 'en', label: 'English', url: 'https://www.youtube.com/watch?v=test123' }],
      })
    expect(videoRes.status).toBe(201)

    // 4. Student enrolls
    const enrollRes = await request(app).post(`/api/courses/${courseId}/enroll`).set('Authorization', studentAuth)
    expect(enrollRes.status).toBe(201)

    // 5. Student views the subtopic content
    const contentRes = await request(app)
      .get(`/api/syllabus/subtopics/${subtopicId}/content`)
      .set('Authorization', studentAuth)
    expect(contentRes.status).toBe(200)
    expect(contentRes.body.data.videos.length).toBe(1)

    // 6. Student marks it complete
    const viewRes = await request(app)
      .post(`/api/learning/subtopics/${subtopicId}/view`)
      .set('Authorization', studentAuth)
      .send({ status: 'completed' })
    expect(viewRes.status).toBe(200)
    expect(viewRes.body.data.xpEarned).toBeGreaterThan(0)

    // 7. Course progress reflects the completion
    const progressRes = await request(app).get(`/api/learning/courses/${courseId}/progress`).set('Authorization', studentAuth)
    expect(progressRes.status).toBe(200)
    expect(progressRes.body.data.overallProgress).toBe(100)

    // 8. XP history reflects the award, and was NOT double-counted on repeat view
    const repeatView = await request(app)
      .post(`/api/learning/subtopics/${subtopicId}/view`)
      .set('Authorization', studentAuth)
      .send({ status: 'completed' })
    expect(repeatView.body.data.xpEarned).toBe(0) // XP only awarded once per content item

    const xpRes = await request(app).get('/api/xp/history').set('Authorization', studentAuth)
    expect(xpRes.status).toBe(200)
    expect(xpRes.body.data.totalXP).toBeGreaterThan(0)
  })

  it('cannot delete a course with active enrollments (orphan prevention)', async () => {
    const admin = await createAdminAndLogin()
    const student = await registerAndLogin()

    const courseRes = await request(app)
      .post('/api/courses')
      .set('Authorization', `Bearer ${admin.accessToken}`)
      .send({
        name: 'Undeletable Course',
        slug: `undeletable-${Date.now()}`,
        description: 'x',
        difficulty: 'BEGINNER',
        estimatedDuration: 1,
        status: 'PUBLISHED',
      })
    const courseId = courseRes.body.data.id

    await request(app).post(`/api/courses/${courseId}/enroll`).set('Authorization', `Bearer ${student.accessToken}`)

    const deleteRes = await request(app).delete(`/api/courses/${courseId}`).set('Authorization', `Bearer ${admin.accessToken}`)
    expect(deleteRes.status).toBe(409)
  })
})
