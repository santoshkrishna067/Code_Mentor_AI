import request from 'supertest'
import { app, registerAndLogin, createAdminAndLogin, disconnectPrisma } from './helpers'
import { prisma } from '@/config/prisma'

afterAll(disconnectPrisma)

describe('AI/ML predictions', () => {
  it('returns insufficientData=true (not a fabricated number) for a brand-new student with no course', async () => {
    const student = await registerAndLogin()
    const admin = await createAdminAndLogin()

    const courseRes = await request(app)
      .post('/api/courses')
      .set('Authorization', `Bearer ${admin.accessToken}`)
      .send({
        name: 'AI Test Course',
        slug: `ai-test-course-${Date.now()}`,
        description: 'x',
        difficulty: 'BEGINNER',
        estimatedDuration: 1,
        status: 'PUBLISHED',
      })
    const courseId = courseRes.body.data.id
    await request(app).post(`/api/courses/${courseId}/enroll`).set('Authorization', `Bearer ${student.accessToken}`)

    const perf = await request(app)
      .get(`/api/ai/students/${student.user.id}/courses/${courseId}/performance-prediction`)
      .set('Authorization', `Bearer ${student.accessToken}`)
    expect(perf.status).toBe(200)
    expect(perf.body.data.insufficientData).toBe(true)
    expect(perf.body.data.value).toBeNull()
    expect(perf.body.data.confidence).toBeNull()
    expect(typeof perf.body.data.reason).toBe('string')

    const engagement = await request(app)
      .get(`/api/ai/students/${student.user.id}/engagement`)
      .set('Authorization', `Bearer ${student.accessToken}`)
    expect(engagement.status).toBe(200)
    expect(engagement.body.data.insufficientData).toBe(true) // account is brand new
  })

  it('a student cannot read another student’s predictions', async () => {
    const a = await registerAndLogin()
    const b = await registerAndLogin()
    const res = await request(app)
      .get(`/api/ai/students/${b.user.id}/engagement`)
      .set('Authorization', `Bearer ${a.accessToken}`)
    expect(res.status).toBe(403)
  })

  it('only an admin can view the course risk ranking', async () => {
    const student = await registerAndLogin()
    const res = await request(app).get('/api/ai/courses/some-course-id/risk-ranking').set('Authorization', `Bearer ${student.accessToken}`)
    expect(res.status).toBe(403)
  })
})

describe('GenAI Tutor exam lock', () => {
  it('blocks the tutor while the student has an IN_PROGRESS exam attempt, and allows it once there is none', async () => {
    const student = await registerAndLogin()

    // No execution provider is configured in this build, so a normal tutor
    // call will fail with 500 ("temporarily unavailable") rather than 403 —
    // that failure mode itself proves the exam lock isn't what blocked it.
    const beforeExam = await request(app)
      .post('/api/tutor/message')
      .set('Authorization', `Bearer ${student.accessToken}`)
      .send({ message: 'hi' })
    expect(beforeExam.status).not.toBe(403)

    // Simulate an in-progress exam attempt directly (Part 5 routes aren't
    // built yet, but the DB shape and the lock's DB check both are).
    const course = await prisma.course.create({
      data: {
        name: 'Lock Test Course',
        slug: `lock-test-${Date.now()}`,
        description: 'x',
        difficulty: 'BEGINNER',
        estimatedDuration: 1,
        status: 'PUBLISHED',
      },
    })
    const exam = await prisma.exam.create({
      data: {
        title: 'Lock Test Exam',
        description: 'x',
        courseId: course.id,
        duration: 30,
        totalMarks: 10,
        passingScore: 50,
        scheduledStart: new Date(),
        scheduledEnd: new Date(Date.now() + 3600_000),
      },
    })
    await prisma.examAttempt.create({
      data: { examId: exam.id, studentId: student.user.id, questionOrder: [] },
    })

    const duringExam = await request(app)
      .post('/api/tutor/message')
      .set('Authorization', `Bearer ${student.accessToken}`)
      .send({ message: 'give me the answer' })
    expect(duringExam.status).toBe(403)
    expect(duringExam.body.message).toMatch(/exam/i)

    const historyDuringExam = await request(app).get('/api/tutor/history').set('Authorization', `Bearer ${student.accessToken}`)
    expect(historyDuringExam.status).toBe(403) // the lock applies to the whole tutor router, not just /message
  })
})
