import request from 'supertest'
import { app, registerAndLogin, createAdminAndLogin, disconnectPrisma } from './helpers'

afterAll(disconnectPrisma)

describe('RBAC', () => {
  it('a student cannot access admin-only routes', async () => {
    const student = await registerAndLogin()
    const res = await request(app).get('/api/users/students').set('Authorization', `Bearer ${student.accessToken}`)
    expect(res.status).toBe(403)
  })

  it('an admin can list students', async () => {
    const admin = await createAdminAndLogin()
    const res = await request(app).get('/api/users/students').set('Authorization', `Bearer ${admin.accessToken}`)
    expect(res.status).toBe(200)
    expect(Array.isArray(res.body.data)).toBe(true)
  })

  it('a student cannot read another student’s profile', async () => {
    const a = await registerAndLogin()
    const b = await registerAndLogin()
    const res = await request(app).get(`/api/users/students/${b.user.id}`).set('Authorization', `Bearer ${a.accessToken}`)
    expect(res.status).toBe(403)
  })

  it('a student can read their own profile via the self-or-admin route', async () => {
    const a = await registerAndLogin()
    const res = await request(app).get(`/api/users/students/${a.user.id}`).set('Authorization', `Bearer ${a.accessToken}`)
    expect(res.status).toBe(200)
  })

  it('only an admin can create a course', async () => {
    const student = await registerAndLogin()
    const res = await request(app)
      .post('/api/courses')
      .set('Authorization', `Bearer ${student.accessToken}`)
      .send({ name: 'X', slug: `x-${Date.now()}`, description: 'x', difficulty: 'BEGINNER', estimatedDuration: 1 })
    expect(res.status).toBe(403)
  })
})
