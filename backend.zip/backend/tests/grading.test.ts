import { gradeSubmission, isAnswerCorrect, shuffle } from '@/utils/grading'

describe('grading engine', () => {
  const questions = [
    { id: 'q1', correctAnswer: 'a', marks: 10, negativeMarks: 2 },
    { id: 'q2', correctAnswer: ['a', 'b'], marks: 10, negativeMarks: 2 },
    { id: 'q3', correctAnswer: 'c', marks: 10, negativeMarks: 2 },
  ]

  it('grades all-correct submissions at 100%', () => {
    const result = gradeSubmission(
      questions,
      [
        { questionId: 'q1', answer: 'a' },
        { questionId: 'q2', answer: ['b', 'a'] }, // order-independent
        { questionId: 'q3', answer: 'c' },
      ],
      false
    )
    expect(result.scorePercent).toBe(100)
    expect(result.correctCount).toBe(3)
  })

  it('treats unanswered questions as incorrect but does not apply negative marking to them', () => {
    const result = gradeSubmission(questions, [{ questionId: 'q1', answer: 'a' }], true)
    expect(result.unansweredCount).toBe(2)
    expect(result.marksAwarded).toBe(10) // only q1's marks, no penalty for the two unanswered
  })

  it('applies negative marking only when enabled', () => {
    const answers = [
      { questionId: 'q1', answer: 'a' }, // correct: +10
      { questionId: 'q2', answer: 'x' }, // wrong: -2 if enabled
      { questionId: 'q3', answer: 'y' }, // wrong: -2 if enabled
    ]
    const withPenalty = gradeSubmission(questions, answers, true)
    const withoutPenalty = gradeSubmission(questions, answers, false)

    expect(withPenalty.marksAwarded).toBe(10 - 2 - 2)
    expect(withoutPenalty.marksAwarded).toBe(10)
  })

  it('never lets the total score go negative', () => {
    const heavyPenalty = [
      { id: 'q1', correctAnswer: 'a', marks: 1, negativeMarks: 10 },
      { id: 'q2', correctAnswer: 'a', marks: 1, negativeMarks: 10 },
    ]
    const result = gradeSubmission(
      heavyPenalty,
      [
        { questionId: 'q1', answer: 'wrong' },
        { questionId: 'q2', answer: 'wrong' },
      ],
      true
    )
    expect(result.marksAwarded).toBe(0)
  })

  it('isAnswerCorrect is order-independent for array answers', () => {
    expect(isAnswerCorrect(['a', 'b', 'c'], ['c', 'a', 'b'])).toBe(true)
    expect(isAnswerCorrect(['a', 'b'], ['a'])).toBe(false)
  })

  it('shuffle with a fixed seed is deterministic and preserves all elements', () => {
    const input = [1, 2, 3, 4, 5]
    const a = shuffle(input, 42)
    const b = shuffle(input, 42)
    expect(a).toEqual(b)
    expect([...a].sort()).toEqual(input)
  })
})
