import path from 'path'
import dotenv from 'dotenv'

// Loads .env.test (falls back to .env if not present). This MUST run before
// any application module is imported, since @/config/env validates
// process.env at import time.
dotenv.config({ path: path.join(__dirname, '..', '.env.test') })

process.env.NODE_ENV = 'test'
