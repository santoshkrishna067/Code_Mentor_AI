import { linearRegression, mean, stdDev, coefficientOfVariation, confidenceFromSampleAndFit, clamp } from '@/modules/ai/predictors/stats'

describe('ML stats toolkit', () => {
  it('linearRegression fits a perfect increasing line with rSquared 1', () => {
    const points = [
      { x: 0, y: 10 },
      { x: 1, y: 20 },
      { x: 2, y: 30 },
      { x: 3, y: 40 },
    ]
    const fit = linearRegression(points)
    expect(fit).not.toBeNull()
    expect(fit!.slope).toBeCloseTo(10)
    expect(fit!.intercept).toBeCloseTo(10)
    expect(fit!.rSquared).toBeCloseTo(1)
  })

  it('linearRegression returns null with fewer than 2 points', () => {
    expect(linearRegression([{ x: 0, y: 5 }])).toBeNull()
    expect(linearRegression([])).toBeNull()
  })

  it('linearRegression returns null when all x values are identical (no trend fittable)', () => {
    expect(
      linearRegression([
        { x: 5, y: 1 },
        { x: 5, y: 2 },
        { x: 5, y: 3 },
      ])
    ).toBeNull()
  })

  it('linearRegression has low rSquared for noisy/flat data', () => {
    const points = [
      { x: 0, y: 50 },
      { x: 1, y: 20 },
      { x: 2, y: 80 },
      { x: 3, y: 10 },
    ]
    const fit = linearRegression(points)
    expect(fit).not.toBeNull()
    expect(fit!.rSquared).toBeLessThan(0.5)
  })

  it('mean and stdDev compute correctly', () => {
    expect(mean([1, 2, 3, 4, 5])).toBe(3)
    expect(mean([])).toBe(0)
    expect(stdDev([2, 2, 2, 2])).toBe(0)
    expect(stdDev([1, 2, 3])).toBeCloseTo(0.8165, 3)
  })

  it('coefficientOfVariation is null for a zero mean', () => {
    expect(coefficientOfVariation([0, 0, 0])).toBeNull()
    expect(coefficientOfVariation([2, 4, 6])).toBeCloseTo(stdDev([2, 4, 6]) / 4)
  })

  it('confidenceFromSampleAndFit scales with sample size and never exceeds 0.95', () => {
    const lowN = confidenceFromSampleAndFit(2, 1, 20)
    const highN = confidenceFromSampleAndFit(20, 1, 20)
    expect(highN).toBeGreaterThan(lowN)
    expect(highN).toBeLessThanOrEqual(0.95)
    expect(confidenceFromSampleAndFit(1000, 1, 20)).toBeLessThanOrEqual(0.95)
  })

  it('confidenceFromSampleAndFit penalizes a poor fit even with a large sample', () => {
    const goodFit = confidenceFromSampleAndFit(20, 0.95, 20)
    const badFit = confidenceFromSampleAndFit(20, 0.1, 20)
    expect(goodFit).toBeGreaterThan(badFit)
  })

  it('clamp bounds values correctly', () => {
    expect(clamp(150, 0, 100)).toBe(100)
    expect(clamp(-10, 0, 100)).toBe(0)
    expect(clamp(50, 0, 100)).toBe(50)
  })
})
