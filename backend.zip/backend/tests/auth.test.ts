import request from 'supertest'
import { app, disconnectPrisma } from './helpers'
import { prisma } from '@/config/prisma'

afterAll(disconnectPrisma)

describe('Auth', () => {
  const email = `auth-test-${Date.now()}@test.com`
  const password = 'Password123'

  it('registers a new student and returns tokens', async () => {
    const res = await request(app).post('/api/auth/register').send({ email, password, name: 'Auth Tester', agreeToTerms: true })
    expect(res.status).toBe(201)
    expect(res.body.data.accessToken).toBeDefined()
    expect(res.body.data.refreshToken).toBeDefined()
    expect(res.body.data.user.role).toBe('student')
  })

  it('rejects duplicate registration', async () => {
    const res = await request(app).post('/api/auth/register').send({ email, password, name: 'Dup', agreeToTerms: true })
    expect(res.status).toBe(409)
  })

  it('rejects weak passwords', async () => {
    const res = await request(app)
      .post('/api/auth/register')
      .send({ email: `weak-${Date.now()}@test.com`, password: 'weak', name: 'Weak', agreeToTerms: true })
    expect(res.status).toBe(400)
    expect(res.body.code).toBe('BAD_REQUEST')
  })

  it('logs in with correct credentials', async () => {
    const res = await request(app).post('/api/auth/login').send({ email, password })
    expect(res.status).toBe(200)
    expect(res.body.data.mfaRequired).toBe(false)
    expect(res.body.data.accessToken).toBeDefined()
  })

  it('rejects login with wrong password', async () => {
    const res = await request(app).post('/api/auth/login').send({ email, password: 'WrongPassword1' })
    expect(res.status).toBe(401)
  })

  it('rejects requests with no token on protected routes', async () => {
    const res = await request(app).get('/api/auth/me')
    expect(res.status).toBe(401)
  })

  it('returns the current user on /me with a valid token', async () => {
    const login = await request(app).post('/api/auth/login').send({ email, password })
    const token = login.body.data.accessToken
    const res = await request(app).get('/api/auth/me').set('Authorization', `Bearer ${token}`)
    expect(res.status).toBe(200)
    expect(res.body.data.email).toBe(email)
  })

  it('full MFA setup -> enable -> login-with-MFA flow', async () => {
    const login = await request(app).post('/api/auth/login').send({ email, password })
    const token = login.body.data.accessToken

    const setup = await request(app).post('/api/auth/mfa/setup').set('Authorization', `Bearer ${token}`)
    expect(setup.status).toBe(200)
    expect(setup.body.data.secret).toBeDefined()

    const { authenticator } = await import('otplib')
    const validCode = authenticator.generate(setup.body.data.secret)

    const enable = await request(app).post('/api/auth/mfa/enable').set('Authorization', `Bearer ${token}`).send({ token: validCode })
    expect(enable.status).toBe(200)
    expect(enable.body.data.backupCodes.length).toBe(10)

    // Password-only login must now require MFA, not issue tokens directly.
    const loginAgain = await request(app).post('/api/auth/login').send({ email, password })
    expect(loginAgain.status).toBe(200)
    expect(loginAgain.body.data.mfaRequired).toBe(true)
    expect(loginAgain.body.data.accessToken).toBeUndefined()

    const challengeToken = loginAgain.body.data.challengeToken
    const codeForLogin = authenticator.generate(setup.body.data.secret)
    const mfaLogin = await request(app).post('/api/auth/login/mfa').send({ challengeToken, code: codeForLogin })
    expect(mfaLogin.status).toBe(200)
    expect(mfaLogin.body.data.accessToken).toBeDefined()

    // cleanup: disable MFA so subsequent test runs against this email are unaffected
    const freshToken = mfaLogin.body.data.accessToken
    const disableCode = authenticator.generate(setup.body.data.secret)
    await request(app)
      .post('/api/auth/mfa/disable')
      .set('Authorization', `Bearer ${freshToken}`)
      .send({ currentPassword: password, token: disableCode })
  })

  it('refresh token rotates and old refresh token is rejected', async () => {
    const login = await request(app).post('/api/auth/login').send({ email, password })
    const refreshToken = login.body.data.refreshToken

    const refreshed = await request(app).post('/api/auth/refresh').send({ refreshToken })
    expect(refreshed.status).toBe(200)
    expect(refreshed.body.data.refreshToken).not.toBe(refreshToken)

    const reuseOld = await request(app).post('/api/auth/refresh').send({ refreshToken })
    expect(reuseOld.status).toBe(401)
  })

  it('a deactivated account cannot use its existing access token', async () => {
    const login = await request(app).post('/api/auth/login').send({ email, password })
    const token = login.body.data.accessToken
    const user = await prisma.user.findUnique({ where: { email } })

    await prisma.user.update({ where: { id: user!.id }, data: { isActive: false } })
    const res = await request(app).get('/api/auth/me').set('Authorization', `Bearer ${token}`)
    expect(res.status).toBe(401)

    await prisma.user.update({ where: { id: user!.id }, data: { isActive: true } }) // restore for other tests
  })
})
