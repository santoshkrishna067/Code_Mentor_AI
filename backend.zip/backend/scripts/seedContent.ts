/**
 * Loads lesson notes + practice questions (written per lesson) into the database.
 *
 *   npm run seed:content
 *
 * Reads every JSON file in data/content/ (named <course-slug>-NN.json) and, for each
 * lesson (course -> topic order -> lesson order), creates:
 *   - Notes (explanation, key points, common mistake, optional code example)
 *   - a Practice set with 3 multiple-choice questions
 * It also fills in each topic's description.
 * Safe to run again: lessons that already have notes are skipped.
 */
import fs from 'fs'
import path from 'path'
import crypto from 'crypto'
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()
const CONTENT_DIR = path.join(process.cwd(), 'data', 'content')

// 24-hex-character ids are valid MongoDB ObjectIds, so we can link rows without extra round trips.
const oid = () => crypto.randomBytes(12).toString('hex')

interface Item {
  t: number
  s: number
  n: string
  k: string[]
  m?: string
  c?: { title?: string; language?: string; code: string; output?: string; explanation?: string }
  q: [string, string[], number, string][]
}
interface ChunkFile {
  td?: Record<string, string>
  items: Item[]
}

async function insertInBatches<T>(rows: T[], fn: (batch: T[]) => Promise<unknown>, size = 400) {
  for (let i = 0; i < rows.length; i += size) await fn(rows.slice(i, i + size))
}

async function main() {
  if (!fs.existsSync(CONTENT_DIR)) {
    console.error(`No content folder found at ${CONTENT_DIR}.\nThis script is optional. You can also add notes, practice questions, videos and materials lesson by lesson in Admin -> Courses -> Manage content.`)
    process.exit(1)
  }
  const files = fs.readdirSync(CONTENT_DIR).filter((f) => f.endsWith('.json')).sort()
  const bySlug = new Map<string, ChunkFile[]>()
  for (const f of files) {
    const slug = f.replace(/-\d+\.json$/, '')
    const raw = JSON.parse(fs.readFileSync(path.join(CONTENT_DIR, f), 'utf8'))
    const chunk: ChunkFile = Array.isArray(raw) ? { items: raw } : raw
    bySlug.set(slug, [...(bySlug.get(slug) ?? []), chunk])
  }

  console.log('Code Mentor AI — lesson content import starting...')
  for (const [slug, chunks] of bySlug) {
    const course = await prisma.course.findUnique({ where: { slug } })
    if (!course) {
      console.log(`  skip ${slug}: course not found (run npm run seed:courses first)`)
      continue
    }
    const subtopics = await prisma.subtopic.findMany({
      where: { topic: { module: { courseId: course.id } } },
      select: { id: true, order: true, title: true, topic: { select: { id: true, order: true, moduleId: true, title: true, description: true } } },
    })
    const lookup = new Map(subtopics.map((s) => [`${s.topic.order}:${s.order}`, s]))
    const alreadyHasNotes = new Set((await prisma.notes.findMany({ where: { subtopicId: { in: subtopics.map((s) => s.id) } }, select: { subtopicId: true } })).map((n) => n.subtopicId))

    const notes: any[] = []
    const examples: any[] = []
    const questions: any[] = []
    const options: any[] = []
    const practices: any[] = []
    const practiceQs: any[] = []
    let skipped = 0
    let unmatched = 0

    // Topic descriptions
    const topicDescriptions = new Map<string, string>()
    for (const chunk of chunks) {
      for (const [ti, desc] of Object.entries(chunk.td ?? {})) {
        const any = subtopics.find((s) => s.topic.order === Number(ti))
        if (any && desc) topicDescriptions.set(any.topic.id, desc)
      }
    }

    for (const chunk of chunks) {
      for (const it of chunk.items) {
        const sub = lookup.get(`${it.t}:${it.s}`)
        if (!sub) {
          unmatched += 1
          continue
        }
        if (alreadyHasNotes.has(sub.id)) {
          skipped += 1
          continue
        }
        const notesId = oid()
        notes.push({
          id: notesId,
          subtopicId: sub.id,
          title: sub.title,
          content: it.n,
          order: 0,
          highlights: it.k ?? [],
          commonMistakes: it.m ? [it.m] : [],
        })
        if (it.c?.code) {
          examples.push({
            id: oid(),
            notesId,
            title: it.c.title || 'Example',
            code: it.c.code,
            language: it.c.language || 'text',
            output: it.c.output || null,
            explanation: it.c.explanation || null,
          })
        }
        const practiceId = oid()
        practices.push({
          id: practiceId,
          subtopicId: sub.id,
          title: `Practice: ${sub.title}`,
          description: `Check your understanding of "${sub.title}".`,
          difficulty: course.difficulty,
          estimatedDuration: 5,
          passingScore: 60,
        })
        it.q.forEach(([content, opts, answerIdx, explanation], order) => {
          const qid = oid()
          questions.push({
            id: qid,
            type: 'MCQ',
            content,
            correctAnswer: opts[answerIdx],
            explanation,
            difficulty: course.difficulty,
            tags: [sub.topic.title, sub.title],
            courseId: course.id,
            moduleId: sub.topic.moduleId,
            topicId: sub.topic.id,
            estimatedTime: 60,
            marks: 1,
          })
          opts.forEach((o) => options.push({ id: oid(), questionId: qid, content: o, isCorrect: o === opts[answerIdx] }))
          practiceQs.push({ id: oid(), practiceId, questionId: qid, order })
        })
      }
    }

    await insertInBatches(notes, (data) => prisma.notes.createMany({ data }))
    await insertInBatches(examples, (data) => prisma.example.createMany({ data }))
    await insertInBatches(questions, (data) => prisma.question.createMany({ data }))
    await insertInBatches(options, (data) => prisma.option.createMany({ data }))
    await insertInBatches(practices, (data) => prisma.practice.createMany({ data }))
    await insertInBatches(practiceQs, (data) => prisma.practiceQuestion.createMany({ data }))

    for (const [topicId, description] of topicDescriptions) {
      await prisma.topic.update({ where: { id: topicId }, data: { description } })
    }

    console.log(
      `  ${course.name}: ${notes.length} lessons filled, ${questions.length} questions` +
        (skipped ? `, ${skipped} already had notes` : '') +
        (unmatched ? `, ${unmatched} did not match a lesson` : '')
    )
  }
  console.log('Done.')
}

main()
  .catch((e) => {
    console.error(e)
    process.exitCode = 1
  })
  .finally(() => prisma.$disconnect())
