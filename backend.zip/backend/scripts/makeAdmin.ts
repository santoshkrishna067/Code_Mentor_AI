/**
 * Promotes an existing account to ADMIN (and gives it an admin profile).
 *   npm run make-admin -- you@example.com
 */
import { PrismaClient, Role } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  const email = process.argv[2]?.toLowerCase()
  if (!email) {
    console.error('Usage: npm run make-admin -- <email>')
    process.exitCode = 1
    return
  }
  const user = await prisma.user.findUnique({ where: { email } })
  if (!user) {
    console.error(`No account found for ${email}. Register it in the app first.`)
    process.exitCode = 1
    return
  }
  await prisma.user.update({ where: { id: user.id }, data: { role: Role.ADMIN } })
  const profile = await prisma.adminProfile.findUnique({ where: { userId: user.id } }).catch(() => null)
  if (!profile) await prisma.adminProfile.create({ data: { userId: user.id } }).catch(() => undefined)
  console.log(`${email} is now an ADMIN. Log out and log in again in the app.`)
}

main()
  .catch((e) => {
    console.error(e)
    process.exitCode = 1
  })
  .finally(() => prisma.$disconnect())
