/**
 * Seeds a starter set of coding problems (with visible + hidden test cases)
 * so the student "Coding" section has real exercises from day one.
 *
 *   npm run seed:coding
 *
 * Safe to re-run: a problem is skipped if one with the same title already
 * exists in its course. Expected outputs are produced by the reference
 * solution (`solve`) below at seed time, so they cannot drift from the
 * stated problem.
 *
 * Input convention: every problem reads plain text from standard input and
 * prints its answer to standard output.
 */
import { PrismaClient, Difficulty } from '@prisma/client'

const prisma = new PrismaClient()

interface Problem {
  courseSlug: string
  title: string
  difficulty: Difficulty
  tags: string[]
  estimatedTime: number
  description: string
  constraints: string[]
  hints: string[]
  todo: string // one-line hint shown inside the starter code
  tests: { input: string; hidden?: boolean }[]
  solve: (input: string) => string
}

const tokens = (s: string) => s.split(/\s+/).filter(Boolean)

const PROBLEMS: Problem[] = [
  {
    courseSlug: 'python-programming',
    title: 'Sum of Two Numbers',
    difficulty: Difficulty.BEGINNER,
    tags: ['input-output', 'arithmetic'],
    estimatedTime: 5,
    description:
      'Read two integers from one line of input and print their sum.\n\nSample input:\n3 5\n\nSample output:\n8',
    constraints: ['-10^9 <= a, b <= 10^9'],
    hints: ['Split the line, convert both parts to integers, then add them.'],
    todo: 'read two integers a and b, print a + b',
    tests: [{ input: '3 5' }, { input: '-2 7' }, { input: '100 250' }, { input: '0 0', hidden: true }, { input: '123456789 987654321', hidden: true }],
    solve: (i) => {
      const [a, b] = tokens(i).map(Number)
      return String(a + b)
    },
  },
  {
    courseSlug: 'python-programming',
    title: 'Reverse a String',
    difficulty: Difficulty.BEGINNER,
    tags: ['strings'],
    estimatedTime: 5,
    description: 'Read one word (no spaces) and print it reversed.\n\nSample input:\nhello\n\nSample output:\nolleh',
    constraints: ['1 <= length <= 1000', 'The word has no spaces'],
    hints: ['In Python, slicing with [::-1] reverses a string.'],
    todo: 'read a word and print it reversed',
    tests: [{ input: 'hello' }, { input: 'Python' }, { input: 'a' }, { input: 'racecar', hidden: true }, { input: 'OpenSource', hidden: true }],
    solve: (i) => tokens(i)[0].split('').reverse().join(''),
  },
  {
    courseSlug: 'python-programming',
    title: 'Prime Check',
    difficulty: Difficulty.BEGINNER,
    tags: ['math', 'loops'],
    estimatedTime: 10,
    description:
      'Read an integer n. Print "Prime" if n is a prime number, otherwise print "Not prime".\n\nSample input:\n7\n\nSample output:\nPrime',
    constraints: ['1 <= n <= 10^6'],
    hints: ['A number is not prime if some i from 2 to sqrt(n) divides it. Remember 1 is not prime.'],
    todo: 'read n and print Prime or Not prime',
    tests: [{ input: '7' }, { input: '10' }, { input: '1' }, { input: '2', hidden: true }, { input: '999983', hidden: true }, { input: '1000000', hidden: true }],
    solve: (i) => {
      const n = Number(tokens(i)[0])
      if (n < 2) return 'Not prime'
      for (let d = 2; d * d <= n; d++) if (n % d === 0) return 'Not prime'
      return 'Prime'
    },
  },
  {
    courseSlug: 'c-programming',
    title: 'Even or Odd',
    difficulty: Difficulty.BEGINNER,
    tags: ['conditions', 'operators'],
    estimatedTime: 5,
    description: 'Read an integer n. Print "Even" if it is even, otherwise print "Odd".\n\nSample input:\n12\n\nSample output:\nEven',
    constraints: ['-10^9 <= n <= 10^9'],
    hints: ['Use the remainder operator %. Careful with negative numbers: -3 % 2 is -1 in C.'],
    todo: 'read n and print Even or Odd',
    tests: [{ input: '12' }, { input: '7' }, { input: '0' }, { input: '-3', hidden: true }, { input: '-8', hidden: true }],
    solve: (i) => (Number(tokens(i)[0]) % 2 === 0 ? 'Even' : 'Odd'),
  },
  {
    courseSlug: 'c-programming',
    title: 'Factorial',
    difficulty: Difficulty.BEGINNER,
    tags: ['loops', 'recursion'],
    estimatedTime: 10,
    description: 'Read an integer n and print n! (n factorial). 0! is 1.\n\nSample input:\n5\n\nSample output:\n120',
    constraints: ['0 <= n <= 12 (the answer fits in a 32-bit int)'],
    hints: ['Multiply the numbers 1..n together, starting from 1.'],
    todo: 'read n and print n!',
    tests: [{ input: '5' }, { input: '0' }, { input: '1' }, { input: '10', hidden: true }, { input: '12', hidden: true }],
    solve: (i) => {
      let r = 1
      for (let k = 2; k <= Number(tokens(i)[0]); k++) r *= k
      return String(r)
    },
  },
  {
    courseSlug: 'data-structures-in-c',
    title: 'Maximum in an Array',
    difficulty: Difficulty.BEGINNER,
    tags: ['arrays'],
    estimatedTime: 10,
    description:
      'The first line has n, the second line has n integers. Print the largest one.\n\nSample input:\n5\n3 9 2 7 4\n\nSample output:\n9',
    constraints: ['1 <= n <= 1000', '-10^6 <= each value <= 10^6'],
    hints: ['Keep a variable for the biggest value seen so far and update it while scanning.'],
    todo: 'read n, then n integers; print the maximum',
    tests: [{ input: '5\n3 9 2 7 4' }, { input: '1\n-5' }, { input: '4\n-3 -1 -7 -2' }, { input: '6\n10 10 10 9 8 10', hidden: true }, { input: '3\n1000000 -1000000 0', hidden: true }],
    solve: (i) => {
      const t = tokens(i).map(Number)
      return String(Math.max(...t.slice(1, 1 + t[0])))
    },
  },
  {
    courseSlug: 'java-programming',
    title: 'Palindrome Check',
    difficulty: Difficulty.BEGINNER,
    tags: ['strings'],
    estimatedTime: 10,
    description:
      'Read one word (no spaces). Print "Yes" if it reads the same forwards and backwards (case-sensitive), otherwise "No".\n\nSample input:\nmadam\n\nSample output:\nYes',
    constraints: ['1 <= length <= 1000', 'Case-sensitive: "Madam" is not a palindrome'],
    hints: ['Compare the first and last characters, then move inward.'],
    todo: 'read a word, print Yes or No',
    tests: [{ input: 'madam' }, { input: 'hello' }, { input: 'a' }, { input: 'Madam', hidden: true }, { input: 'abccba', hidden: true }],
    solve: (i) => {
      const w = tokens(i)[0]
      return w === w.split('').reverse().join('') ? 'Yes' : 'No'
    },
  },
  {
    courseSlug: 'java-programming',
    title: 'Count the Vowels',
    difficulty: Difficulty.BEGINNER,
    tags: ['strings', 'loops'],
    estimatedTime: 10,
    description:
      'Read one word (no spaces) and print how many vowels (a, e, i, o, u — upper or lower case) it contains.\n\nSample input:\nEducation\n\nSample output:\n5',
    constraints: ['1 <= length <= 1000'],
    hints: ['Convert to lower case first, then check each character.'],
    todo: 'read a word, print the number of vowels',
    tests: [{ input: 'Education' }, { input: 'rhythm' }, { input: 'AEIOU' }, { input: 'Programming', hidden: true }, { input: 'xyz', hidden: true }],
    solve: (i) => String((tokens(i)[0].match(/[aeiou]/gi) ?? []).length),
  },
  {
    courseSlug: 'dsa-python',
    title: 'Nth Fibonacci Number',
    difficulty: Difficulty.BEGINNER,
    tags: ['recursion', 'dynamic-programming'],
    estimatedTime: 10,
    description:
      'Read n and print the nth Fibonacci number, where F(0)=0 and F(1)=1.\n\nSample input:\n10\n\nSample output:\n55',
    constraints: ['0 <= n <= 30'],
    hints: ['An iterative loop with two variables is faster than plain recursion.'],
    todo: 'read n and print F(n)',
    tests: [{ input: '10' }, { input: '0' }, { input: '1' }, { input: '20', hidden: true }, { input: '30', hidden: true }],
    solve: (i) => {
      const n = Number(tokens(i)[0])
      let a = 0
      let b = 1
      for (let k = 0; k < n; k++) [a, b] = [b, a + b]
      return String(a)
    },
  },
  {
    courseSlug: 'algorithms',
    title: 'Binary Search',
    difficulty: Difficulty.INTERMEDIATE,
    tags: ['searching', 'binary-search'],
    estimatedTime: 15,
    description:
      'Line 1: n. Line 2: n integers sorted in ascending order (all different). Line 3: a target value.\nPrint the 0-based index of the target, or -1 if it is not present.\n\nSample input:\n5\n1 3 5 7 9\n7\n\nSample output:\n3',
    constraints: ['1 <= n <= 10^5', 'The array is sorted and has no duplicates'],
    hints: ['Keep low and high indexes; look at the middle and discard half each step.'],
    todo: 'read n, the sorted array, then target; print its index or -1',
    tests: [{ input: '5\n1 3 5 7 9\n7' }, { input: '5\n1 3 5 7 9\n4' }, { input: '1\n42\n42' }, { input: '6\n-10 -3 0 4 8 15\n-10', hidden: true }, { input: '6\n-10 -3 0 4 8 15\n15', hidden: true }, { input: '4\n2 4 6 8\n9', hidden: true }],
    solve: (i) => {
      const t = tokens(i).map(Number)
      const n = t[0]
      const arr = t.slice(1, 1 + n)
      return String(arr.indexOf(t[1 + n]))
    },
  },
  {
    courseSlug: 'dsa-cpp',
    title: 'Sort the Array',
    difficulty: Difficulty.INTERMEDIATE,
    tags: ['sorting', 'arrays'],
    estimatedTime: 15,
    description:
      'Line 1: n. Line 2: n integers. Print them in ascending order, separated by single spaces.\n\nSample input:\n5\n5 2 9 1 3\n\nSample output:\n1 2 3 5 9',
    constraints: ['1 <= n <= 1000', '-10^6 <= each value <= 10^6'],
    hints: ['Try implementing bubble sort or insertion sort yourself before using a library sort.'],
    todo: 'read n and the array; print it sorted ascending',
    tests: [{ input: '5\n5 2 9 1 3' }, { input: '1\n7' }, { input: '4\n4 3 2 1' }, { input: '6\n3 3 1 1 2 2', hidden: true }, { input: '5\n-1 -5 0 5 1', hidden: true }],
    solve: (i) => {
      const t = tokens(i).map(Number)
      return t.slice(1, 1 + t[0]).sort((a, b) => a - b).join(' ')
    },
  },
]

function starterCode(todo: string): Record<string, string> {
  return {
    python: `import sys\n\ndata = sys.stdin.read().split()\n# TODO: ${todo}\n`,
    javascript: `const data = require('fs').readFileSync(0, 'utf8').split(/\\s+/).filter(Boolean);\n// TODO: ${todo}\n`,
    java: `import java.util.*;\n\npublic class Main {\n    public static void main(String[] args) {\n        Scanner sc = new Scanner(System.in);\n        // TODO: ${todo}\n    }\n}\n`,
    c: `#include <stdio.h>\n\nint main() {\n    /* TODO: ${todo} */\n    return 0;\n}\n`,
    cpp: `#include <iostream>\n#include <vector>\n#include <string>\n#include <algorithm>\nusing namespace std;\n\nint main() {\n    // TODO: ${todo}\n    return 0;\n}\n`,
  }
}

async function main() {
  console.log('Seeding coding problems...')
  let created = 0
  for (const p of PROBLEMS) {
    const course = await prisma.course.findUnique({ where: { slug: p.courseSlug } })
    if (!course) {
      console.warn(`  skip "${p.title}": course "${p.courseSlug}" not found (run npm run seed:courses first)`)
      continue
    }
    const exists = await prisma.codingProblem.findFirst({ where: { courseId: course.id, title: p.title } })
    if (exists) continue

    await prisma.codingProblem.create({
      data: {
        courseId: course.id,
        title: p.title,
        description: p.description,
        constraints: p.constraints,
        hints: p.hints,
        starterCode: starterCode(p.todo),
        difficulty: p.difficulty,
        tags: p.tags,
        estimatedTime: p.estimatedTime,
        marks: p.tests.length,
        testCases: {
          create: p.tests.map((t) => ({
            input: t.input,
            expectedOutput: p.solve(t.input),
            isHidden: !!t.hidden,
            marks: 1,
          })),
        },
      },
    })
    created += 1
    console.log(`  + ${p.title}  (${course.name})`)
  }
  console.log(`Done. ${created} new problem(s) added.`)
}

main()
  .catch((e) => {
    console.error(e)
    process.exitCode = 1
  })
  .finally(() => prisma.$disconnect())
