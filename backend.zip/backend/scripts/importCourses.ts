/**
 * Course data importer (Part 3)
 *
 * Reads the supplied Excel course files and populates:
 *   Course -> CourseModule -> Topic -> Subtopic -> Video (+ VideoLanguageTrack, VideoSubtopicCoverage)
 *
 * SOURCE DATA COMES IN TWO DIFFERENT SHAPES — handled by two separate readers:
 *
 * FORMAT A: 'topic-blob' (RDBMS.xlsx, C.xlsx, Algorithms.xlsx, and everything
 * under DSA/) — columns: 'sl no' | 'topics name' | 'sub topics name' |
 * 'youtube hindi video link' | 'youtube english video link'.
 *   - one row = one Topic
 *   - 'sub topics name' is a single cell containing many subtopic titles,
 *     separated by newlines or semicolons
 *   - one video (Hindi + English tracks) covers the WHOLE topic row, i.e.
 *     potentially many subtopics
 *
 * FORMAT B: 'subtopic-rows' (Java.xlsx, Python.xlsx) — one row = one
 * SUBTOPIC, with its own topic/module grouping column and its own
 * (optional) video link pair. That grouping column uses MERGED cells —
 * blank on every row but the first in each topic block — forward-filled
 * below from the last non-empty value.
 *
 * FIX (this file): ExcelJS represents a cell that's a real, clickable Excel
 * hyperlink NOT as a plain string, but as an object shaped like
 * { text: string, hyperlink: string }. Blindly calling String(v) on that
 * object produces the literal text "[object Object]" instead of the URL —
 * silently breaking every video link stored as a true hyperlink rather than
 * plain pasted text. readNamedRows() below extracts the real value for both
 * shapes.
 *
 * FIX (this file): __dirname does not exist under ESM (tsx runs this file
 * as an ES module on modern Node) — DATA_DIR is resolved via process.cwd()
 * instead, which works correctly as long as `npm run seed:courses` is run
 * from the `backend` folder (exactly how package.json's script invokes it).
 *
 * Run with: npm run seed:courses
 * Safe to re-run: matched by Course.slug / (moduleId,order) / (topicId,order)
 * uniqueness, so re-running updates rather than duplicates. NOTE: video
 * creation is also idempotent (skipped if a video already exists for that
 * primary subtopic) — if you need to re-import after a partial/broken run,
 * drop the database and push+seed fresh rather than relying on re-running
 * seed alone to repair already-created (possibly wrong) video records.
 */
import ExcelJS from 'exceljs'
import path from 'path'
import { PrismaClient, Difficulty, ContentType, CourseStatus } from '@prisma/client'

const prisma = new PrismaClient()
const DATA_DIR = path.join(process.cwd(), 'data', 'courses')

// ---------------------------------------------------------------------------
// Shared low-level reader: any worksheet -> array of {headerName: cellValue}
// objects, keyed by the (trimmed) first-row header text. Column ORDER and
// exact header text differ across files, so every mapping below looks up by
// name, never by fixed position.
// ---------------------------------------------------------------------------

async function readNamedRows(filePath: string): Promise<Record<string, string>[]> {
  const workbook = new ExcelJS.Workbook()
  await workbook.xlsx.readFile(filePath)
  const sheet = workbook.worksheets[0]

  const headerByColumn = new Map<number, string>()
  const rows: Record<string, string>[] = []

  sheet.eachRow((row, rowNumber) => {
    const values = row.values as unknown[] // 1-indexed; values[0] is always undefined
    if (rowNumber === 1) {
      values.forEach((v, i) => {
        if (v !== undefined && v !== null) headerByColumn.set(i, String(v).trim())
      })
      return
    }
    const obj: Record<string, string> = {}
    let hasAnyValue = false
    values.forEach((v, i) => {
      const key = headerByColumn.get(i)
      if (!key) return

      let strValue: string
      if (v && typeof v === 'object') {
        const hyperlinkVal = v as { text?: unknown; hyperlink?: unknown; richText?: { text: string }[] }
        if (typeof hyperlinkVal.hyperlink === 'string') strValue = hyperlinkVal.hyperlink
        else if (typeof hyperlinkVal.text === 'string') strValue = hyperlinkVal.text
        else if (Array.isArray(hyperlinkVal.richText)) strValue = hyperlinkVal.richText.map((rt) => rt.text).join('')
        else strValue = ''
      } else {
        strValue = v === undefined || v === null ? '' : String(v).trim()
      }
      strValue = strValue.trim()

      obj[key] = strValue
      if (strValue) hasAnyValue = true
    })
    if (hasAnyValue) rows.push(obj)
  })

  return rows
}

function isValidUrl(value: string | undefined): value is string {
  return !!value && /^https?:\/\//i.test(value.trim())
}

function stripLeadingNumbering(title: string): string {
  return title.replace(/^\d+\.\s*/, '').trim()
}

interface ParsedSubtopic {
  title: string
  englishUrl: string | null
  hindiUrl: string | null
}
interface ParsedTopic {
  title: string
  subtopics: ParsedSubtopic[]
}

// ---------------------------------------------------------------------------
// FORMAT A reader: one row = one Topic, subtopics packed into a single cell.
// ---------------------------------------------------------------------------

function parseSubtopicBlob(raw: string): string[] {
  return raw
    .split(/[\n;]+/)
    .map((s) => s.trim())
    .filter(Boolean)
}

async function readTopicBlobFile(filePath: string): Promise<ParsedTopic[]> {
  const rows = await readNamedRows(filePath)
  const topics: ParsedTopic[] = []

  for (const row of rows) {
    const topicName = row['topics name']?.trim()
    if (!topicName) continue

    const subtopicNames = parseSubtopicBlob(row['sub topics name'] ?? '')
    const englishUrl = isValidUrl(row['youtube english video link']) ? row['youtube english video link'].trim() : null
    const hindiUrl = isValidUrl(row['youtube hindi video link']) ? row['youtube hindi video link'].trim() : null

    // In this format, every subtopic parsed from the row shares the SAME
    // single video link pair (that's the whole premise of Format A).
    topics.push({
      title: topicName,
      subtopics: subtopicNames.map((title) => ({ title, englishUrl, hindiUrl })),
    })
  }

  return topics
}

// ---------------------------------------------------------------------------
// FORMAT B reader: one row = one Subtopic, with its own topic-grouping
// column (merged cells, forward-filled) and its own (possibly shared)
// video link pair.
// ---------------------------------------------------------------------------

interface SubtopicRowsColumnMap {
  topicColumn: string
  subtopicColumn: string
  englishUrlColumn: string
  hindiUrlColumn: string
  stripTopicNumbering?: boolean
}

async function readSubtopicRowsFile(filePath: string, columns: SubtopicRowsColumnMap): Promise<ParsedTopic[]> {
  const rows = await readNamedRows(filePath)
  const topicsInOrder: ParsedTopic[] = []
  const topicIndexByTitle = new Map<string, number>()

  let lastNonEmptyTopicName: string | null = null

  for (const row of rows) {
    const rawTopicCell = row[columns.topicColumn]?.trim()
    const subtopicName = row[columns.subtopicColumn]?.trim()

    const rawTopicName = rawTopicCell || lastNonEmptyTopicName
    if (rawTopicCell) lastNonEmptyTopicName = rawTopicCell

    if (!rawTopicName || !subtopicName) continue

    const topicName = columns.stripTopicNumbering ? stripLeadingNumbering(rawTopicName) : rawTopicName
    const englishUrl = isValidUrl(row[columns.englishUrlColumn]) ? row[columns.englishUrlColumn].trim() : null
    const hindiUrl = isValidUrl(row[columns.hindiUrlColumn]) ? row[columns.hindiUrlColumn].trim() : null

    let idx = topicIndexByTitle.get(topicName)
    if (idx === undefined) {
      idx = topicsInOrder.length
      topicIndexByTitle.set(topicName, idx)
      topicsInOrder.push({ title: topicName, subtopics: [] })
    }
    topicsInOrder[idx].subtopics.push({ title: subtopicName, englishUrl, hindiUrl })
  }

  return topicsInOrder
}

// ---------------------------------------------------------------------------
// Course configuration
// ---------------------------------------------------------------------------

type CourseFileConfig = {
  file: string
  courseName: string
  slug: string
  description: string
  difficulty: Difficulty
} & ({ format: 'topic-blob' } | { format: 'subtopic-rows'; columns: SubtopicRowsColumnMap })

const COURSE_FILES: CourseFileConfig[] = [
  {
    file: 'RDBMS.xlsx',
    courseName: 'RDBMS Fundamentals',
    slug: 'rdbms-fundamentals',
    description: 'Relational database concepts, from database fundamentals through advanced RDBMS topics.',
    difficulty: Difficulty.BEGINNER,
    format: 'topic-blob',
  },
  {
    file: 'C.xlsx',
    courseName: 'C Programming',
    slug: 'c-programming',
    description: 'C programming language fundamentals through advanced topics.',
    difficulty: Difficulty.BEGINNER,
    format: 'topic-blob',
  },
  {
    file: 'Algorithms.xlsx',
    courseName: 'Algorithms',
    slug: 'algorithms',
    description: 'Algorithm design, analysis, and classic algorithmic techniques.',
    difficulty: Difficulty.INTERMEDIATE,
    format: 'topic-blob',
  },
  {
    file: path.join('DSA', 'DSA_in_C.xlsx'),
    courseName: 'Data Structures in C',
    slug: 'data-structures-in-c',
    description: 'Core data structures (arrays, linked lists, stacks, queues) implemented in C.',
    difficulty: Difficulty.INTERMEDIATE,
    format: 'topic-blob',
  },
  {
    file: path.join('DSA', 'DSA_in_C++.xlsx'),
    courseName: 'Data Structures & Algorithms in C++',
    slug: 'dsa-cpp',
    description: 'Data structures and algorithms taught in C++, with Hindi and English video tracks.',
    difficulty: Difficulty.INTERMEDIATE,
    format: 'topic-blob',
  },
  {
    file: path.join('DSA', 'DSA_in_Java.xlsx'),
    courseName: 'Data Structures & Algorithms in Java',
    slug: 'dsa-java',
    description: 'Data structures and algorithms taught in Java, with Hindi and English video tracks.',
    difficulty: Difficulty.INTERMEDIATE,
    format: 'topic-blob',
  },
  {
    file: path.join('DSA', 'DSA_Python_Complete_Syllabus_YouTube_Links_TIMESTAMPED_UPDATED_ENGLISH 3.xlsx'),
    courseName: 'Data Structures & Algorithms in Python',
    slug: 'dsa-python',
    description: 'Data structures and algorithms taught in Python, with Hindi and English video tracks.',
    difficulty: Difficulty.INTERMEDIATE,
    format: 'topic-blob',
  },
  {
    file: 'Java.xlsx',
    courseName: 'Java Programming',
    slug: 'java-programming',
    description: 'Java programming language fundamentals, from syntax through core language features.',
    difficulty: Difficulty.BEGINNER,
    format: 'subtopic-rows',
    columns: {
      topicColumn: 'Topic',
      subtopicColumn: 'Subtopic',
      englishUrlColumn: 'English Video Link',
      hindiUrlColumn: 'Hindi Video Link',
      stripTopicNumbering: true,
    },
  },
  {
    file: 'Python.xlsx',
    courseName: 'Python Programming',
    slug: 'python-programming',
    description: 'Python programming language fundamentals, from syntax through core language features.',
    difficulty: Difficulty.BEGINNER,
    format: 'subtopic-rows',
    columns: {
      topicColumn: 'Modules',
      subtopicColumn: 'Topics',
      englishUrlColumn: 'English Video Link',
      hindiUrlColumn: 'Hindi Video Link',
    },
  },
]

// ---------------------------------------------------------------------------
// Import driver — identical DB-writing logic regardless of source format.
// ---------------------------------------------------------------------------

async function importCourseFile(config: CourseFileConfig) {
  const filePath = path.join(DATA_DIR, config.file)
  console.log(`\nImporting: ${config.courseName}  <-  ${config.file}  [format: ${config.format}]`)

  const topics = config.format === 'topic-blob' ? await readTopicBlobFile(filePath) : await readSubtopicRowsFile(filePath, config.columns)

  if (topics.length === 0) {
    console.warn(`  WARNING: no topics parsed from ${config.file}, skipping.`)
    return
  }

  const totalSubtopics = topics.reduce((sum, t) => sum + t.subtopics.length, 0)
  const estimatedDurationHours = Math.max(1, Math.round(totalSubtopics * 0.15))

  const course = await prisma.course.upsert({
    where: { slug: config.slug },
    create: {
      name: config.courseName,
      slug: config.slug,
      description: config.description,
      difficulty: config.difficulty,
      estimatedDuration: estimatedDurationHours,
      status: CourseStatus.PUBLISHED,
    },
    update: {
      name: config.courseName,
      description: config.description,
      difficulty: config.difficulty,
    },
  })

  const module_ = await prisma.courseModule.upsert({
    where: { courseId_order: { courseId: course.id, order: 0 } },
    create: {
      courseId: course.id,
      title: 'Core Syllabus',
      description: `Complete topic sequence for ${config.courseName}.`,
      order: 0,
      estimatedDuration: estimatedDurationHours,
    },
    update: {},
  })

  let topicsImported = 0
  let subtopicsImported = 0
  let videosImported = 0

  for (const [topicIndex, parsedTopic] of topics.entries()) {
    const topic = await prisma.topic.upsert({
      where: { moduleId_order: { moduleId: module_.id, order: topicIndex } },
      create: {
        moduleId: module_.id,
        title: parsedTopic.title,
        description: parsedTopic.title,
        order: topicIndex,
        estimatedDuration: Math.max(10, parsedTopic.subtopics.length * 5),
      },
      update: { title: parsedTopic.title },
    })
    topicsImported += 1

    const groups = new Map<string, { englishUrl: string | null; hindiUrl: string | null; subtopicIds: string[] }>()

    for (const [subIndex, parsedSub] of parsedTopic.subtopics.entries()) {
      const subtopic = await prisma.subtopic.upsert({
        where: { topicId_order: { topicId: topic.id, order: subIndex } },
        create: { topicId: topic.id, title: parsedSub.title, order: subIndex, estimatedDuration: 5 },
        update: { title: parsedSub.title },
      })
      subtopicsImported += 1

      if (!parsedSub.englishUrl && !parsedSub.hindiUrl) continue

      const key = `${parsedSub.englishUrl ?? ''}|${parsedSub.hindiUrl ?? ''}`
      const group = groups.get(key) ?? { englishUrl: parsedSub.englishUrl, hindiUrl: parsedSub.hindiUrl, subtopicIds: [] }
      group.subtopicIds.push(subtopic.id)
      groups.set(key, group)
    }

    for (const group of groups.values()) {
      const primarySubtopicId = group.subtopicIds[0]

      const existingVideo = await prisma.video.findFirst({ where: { primarySubtopicId } })
      if (existingVideo) continue

      const languages: { code: string; label: string; url: string }[] = []
      if (group.hindiUrl) languages.push({ code: 'hi', label: 'Hindi', url: group.hindiUrl })
      if (group.englishUrl) languages.push({ code: 'en', label: 'English', url: group.englishUrl })
      if (languages.length === 0) continue

      const video = await prisma.video.create({
        data: {
          title: parsedTopic.title,
          duration: 0,
          order: 0,
          primarySubtopicId,
          sourceTopicId: topic.id,
          languages: { create: languages },
          coverage: { create: group.subtopicIds.map((subtopicId) => ({ subtopicId })) },
        },
      })
      await prisma.subtopic.update({
        where: { id: primarySubtopicId },
        data: { contentType: ContentType.VIDEO, contentId: video.id },
      })
      videosImported += 1
    }
  }

  console.log(`  OK: ${topicsImported} topics, ${subtopicsImported} subtopics, ${videosImported} videos imported for "${config.courseName}"`)
}

async function main() {
  console.log('Code Mentor AI — course data import starting...')
  for (const config of COURSE_FILES) {
    try {
      await importCourseFile(config)
    } catch (err) {
      console.error(`  FAILED importing ${config.file}:`, err)
      process.exitCode = 1
    }
  }
  console.log('\nImport run complete.')
}

main()
  .catch((err) => {
    console.error(err)
    process.exitCode = 1
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
