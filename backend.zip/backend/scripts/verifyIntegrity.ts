/**
 * Verifies there is no orphaned content anywhere in the syllabus/content
 * graph. Foreign keys with onDelete: Cascade already prevent MOST orphans
 * structurally, but this script catches the cases FKs can't: e.g. a
 * Subtopic whose contentId points at a Video/Notes row that was deleted
 * out-of-band, or a Video whose primarySubtopicId coverage list is empty.
 *
 * Run with: npx tsx scripts/verifyIntegrity.ts
 * Exits with code 1 and prints every issue found if any exist.
 */
import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()
const issues: string[] = []

async function checkDanglingSubtopicContentPointers() {
  const subtopics = await prisma.subtopic.findMany({ where: { contentId: { not: null } } })
  for (const s of subtopics) {
    if (!s.contentType || !s.contentId) continue
    let exists = false
    switch (s.contentType) {
      case 'VIDEO':
        exists = !!(await prisma.video.findUnique({ where: { id: s.contentId } }))
        break
      case 'NOTES':
        exists = !!(await prisma.notes.findUnique({ where: { id: s.contentId } }))
        break
      case 'PRACTICE':
        exists = !!(await prisma.practice.findUnique({ where: { id: s.contentId } }))
        break
      case 'QUIZ':
        exists = !!(await prisma.quiz.findUnique({ where: { id: s.contentId } }))
        break
      default:
        exists = true // ASSIGNMENT/TEST/ASSESSMENT/CODING are not subtopic-scoped in this schema
    }
    if (!exists) {
      issues.push(`Subtopic ${s.id} ("${s.title}") points at missing ${s.contentType} ${s.contentId}`)
    }
  }
}

async function checkVideosWithoutCoverage() {
  const videos = await prisma.video.findMany({ include: { coverage: true } })
  for (const v of videos) {
    if (v.coverage.length === 0) {
      issues.push(`Video ${v.id} ("${v.title}") has no VideoSubtopicCoverage rows`)
    }
  }
}

async function checkEmptyModulesAndTopics() {
  const modules = await prisma.courseModule.findMany({ include: { topics: true } })
  for (const m of modules) {
    if (m.topics.length === 0) issues.push(`CourseModule ${m.id} ("${m.title}") has zero topics`)
  }
  const topics = await prisma.topic.findMany({ include: { subtopics: true } })
  for (const t of topics) {
    if (t.subtopics.length === 0) issues.push(`Topic ${t.id} ("${t.title}") has zero subtopics`)
  }
}

async function checkQuestionSetsReferenceRealQuestions() {
  const links = await prisma.practiceQuestion.findMany({ include: { question: true } })
  for (const l of links) {
    if (!l.question) issues.push(`PracticeQuestion ${l.id} references missing question ${l.questionId}`)
  }
}

async function checkProgressReferencesValidCourse() {
  const progress = await prisma.progress.findMany({ select: { id: true, courseId: true } })
  const courseIds = new Set((await prisma.course.findMany({ select: { id: true } })).map((c) => c.id))
  for (const p of progress) {
    if (!courseIds.has(p.courseId)) issues.push(`Progress ${p.id} references missing course ${p.courseId}`)
  }
}

async function main() {
  console.log('Running database integrity checks...')
  await checkDanglingSubtopicContentPointers()
  await checkVideosWithoutCoverage()
  await checkEmptyModulesAndTopics()
  await checkQuestionSetsReferenceRealQuestions()
  await checkProgressReferencesValidCourse()

  if (issues.length === 0) {
    console.log('OK: no integrity issues found.')
    return
  }

  console.error(`FOUND ${issues.length} integrity issue(s):`)
  for (const issue of issues) console.error(' - ' + issue)
  process.exitCode = 1
}

main()
  .catch((err) => {
    console.error(err)
    process.exitCode = 1
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
