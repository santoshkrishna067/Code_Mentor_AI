# Code Mentor AI — Backend (Parts 2 & 3)

Node.js + TypeScript + Express + Prisma (MongoDB Atlas). This delivers:

- **Part 2 — Backend/API**: Auth, RBAC, MFA, Users/Students/Admin, Course APIs,
  Syllabus APIs, Learning APIs, Progress, XP, Assignments, Quizzes, Tests,
  Assessments, Analytics, Recommendations, Notifications.
- **Part 3 — Database**: Full normalized MongoDB schema (Prisma) covering the
  entire Course→Module→Topic→Subtopic→content tree plus Users, Progress, XP,
  Learning Gaps, Recommendations, Analytics, Exams/Questions/Attempts,
  Proctoring, Notifications, Certificates, and Audit Logs. Includes an
  importer for the supplied Excel course data (9 courses now — see "Course
  data" below) and an orphan-detection script.
- **Part 4 — AI + ML**: statistical predictors (performance trend, course
  completion pace, dropout/risk scoring, engagement analysis) built directly
  on real Progress/XP/StreakDay/LearningGap data — every result is returned
  as an `Estimate<T>` with `confidence`, `method`, and `insufficientData`,
  never a bare number. A trajectory-based ML learning-gap detector runs
  alongside the Part 2 rule-engine (both write to the same table, tagged by
  `detectionSource`). A GenAI Tutor module is wired up behind a replaceable
  provider interface (no LLM key is configured in this build — see
  `src/modules/tutor/tutor.provider.ts`) and is **hard-blocked server-side**
  whenever the student has an exam attempt `IN_PROGRESS`.
- **Part 5 — Examination + Proctoring**: question bank (reused from Part 2),
  exam creation/scheduling/configuration, server-authoritative randomized
  question order (never trusts the client), negative marking (via the same
  shared `src/utils/grading.ts` engine as Practice/Quizzes/Tests/
  Assessments), reactive + batch auto-submit on timeout, and a webcam-driven
  proctoring pipeline (face/multi-face/phone/tab-switch/suspicious-activity
  warnings) with a documented, pattern-based escalation policy that ends a
  compromised attempt for cause — see `src/modules/proctoring/proctoring.service.ts`.
  Every attempt-ending path (normal submit, timeout, integrity flag) funnels
  through one `finalizeAttempt` function so grading/XP/percentile logic can
  never drift between them. The GenAI Tutor's exam lock (built in Part 4) is
  tested end-to-end against real exam attempts here.

**Not yet implemented** (this is a staged build — see "What's next" below):
live code execution for the Coding module (interface is defined and
replaceable, see `src/modules/coding/codeExecution.provider.ts`), a live LLM
behind the GenAI Tutor (same pattern, see `src/modules/tutor/tutor.provider.ts`),
a real browser-side face-detection client (the proctoring *backend* — event/
warning ingestion, escalation, review — is complete and tested; a
MediaPipe/face-api.js integration in the frontend to actually produce those
events is separate frontend work), and full system integration +
production-readiness passes (Parts 6–7).

## Database: MongoDB Atlas (migrated from MySQL)

This backend was originally built against MySQL and has since been migrated
to MongoDB Atlas. The migration touched **only** `prisma/schema.prisma`,
`.env*`, and the `prisma:*` npm scripts — no service/controller code
changed, since everything reads/writes exclusively through Prisma Client's
generated API rather than raw SQL. Specifics:

- Every model's `id` (and the two shared-primary-key exceptions,
  `StudentProfile.userId` / `AdminProfile.userId`) now maps to Mongo's `_id`
  via `@map("_id")`, typed `@db.ObjectId`. All 85 foreign-key scalar fields
  across the schema were annotated `@db.ObjectId` to match.
- MySQL-only type modifiers (`@db.Text`, `@db.LongText`, `@db.Date`) were
  removed — Mongo is schemaless at the storage level and doesn't need or
  support them; the original MySQL version of the schema is kept at
  `prisma/schema.mysql.prisma.bak` for reference/diffing only (not used by
  anything).
- **`prisma migrate dev`/`deploy` are not supported on MongoDB.** Schema
  changes are applied with `npm run prisma:push` (`prisma db push`)
  instead — there are no migration history files to commit; the schema
  file itself is the source of truth pushed directly to the cluster.
- `onDelete: Cascade` and friends still work exactly as before, but are
  worth knowing about: MongoDB has no native foreign-key constraints, so
  Prisma *emulates* referential actions at the query-engine level (issuing
  the cascading deletes itself as extra operations) rather than the
  database enforcing them. Functionally equivalent for everything in this
  codebase, since all deletes already go through Prisma Client.
- Atlas clusters (including the free M0 tier) are always provisioned as
  replica sets, which Prisma's MongoDB connector requires — no extra Atlas
  configuration needed on that front.



The importer (`scripts/importCourses.ts`) now handles **two different
source-file shapes**, both real quirks of the supplied Excel files, not
assumptions:

- **Format A** (`RDBMS.xlsx`, `C.xlsx`, `Algorithms.xlsx`, everything under
  `DSA/`): one row = one Topic, with all its subtopics packed into a single
  cell.
- **Format B** (`Java.xlsx`, `Python.xlsx`): one row = one Subtopic, with its
  own Topic-grouping column. These two files also use **merged cells** for
  that grouping column (blank on every row but the first in each topic
  block) — the importer forward-fills from the last non-empty value, which
  was verified against both files (Java: 582 subtopics across 48 topics;
  Python: 680 subtopics across 52 topics — a naive non-forward-filling
  reader would have silently imported roughly 1 row in 10).

9 courses import in total: RDBMS Fundamentals, C Programming, Algorithms,
Data Structures in C, DSA in C++, DSA in Java, DSA in Python, Java
Programming, Python Programming.

## Why this environment couldn't run/test it for you

This build environment has no network access, so `npm install` cannot reach
the npm registry and there is no live MongoDB instance to run schema pushes or
tests against. Every file here is real, complete source code — but you need
to run the install/migrate/test steps yourself, in an environment with
network + MongoDB access. Instructions below.

## Setup

```bash
cd backend
npm install
cp .env.example .env        # then fill in real secrets
npm run prisma:generate
npm run prisma:push         # pushes the schema to MongoDB (no migration files — see note below)
npm run seed:courses        # imports the supplied Excel course data
npm run verify:integrity    # checks for orphaned content
npm run dev                 # starts the API on :4000
```

`DATABASE_URL` in `.env` must point at a MongoDB Atlas cluster (any tier,
including the free M0 — Atlas clusters are always replica sets, which
Prisma's MongoDB connector requires), e.g.:
```
DATABASE_URL="mongodb+srv://user:password@your-cluster.mongodb.net/code_mentor_ai?retryWrites=true&w=majority"
```

## Running tests

```bash
cp .env.test.example .env.test   # point at a DISPOSABLE test database
npx prisma db push                # apply schema to the test DB (DATABASE_URL from .env.test)
npm test
```

Tests are real Jest + Supertest integration tests that hit the actual Express
app and a real MongoDB database — there are no mocks standing in for the
database. `tests/grading.test.ts` is a pure unit test suite (no DB) for the
shared scoring engine. Run `npm test` after every module you change, per the
"test before moving on" requirement — the suite is structured so each
module's tests are independent and can be run in isolation with
`npx jest tests/auth.test.ts`, etc.

## Architecture notes

- **Response envelope**: every route returns `{ success, data, message }` or,
  for paginated lists, `{ data, pagination }` — matching the frontend's
  `ApiResponse<T>` / `PaginatedResponse<T>` types in `index.ts` exactly.
- **Service boundaries**: each module owns `*.service.ts` (business logic +
  Prisma calls) and `*.routes.ts` (validation via Zod + calling the service).
  No module reaches into another module's Prisma queries directly — cross-
  module needs (e.g. Practice awarding XP) go through the other module's
  service (`learningService.recordProgress`, `xpService.award`), so there is
  exactly one place XP/progress logic lives.
- **Grading**: `src/utils/grading.ts` is the single scoring engine used by
  Practice, Quizzes, Tests, and Assessments (and will be used by Exams in
  Part 5) — negative marking, unanswered handling, and shuffling all live
  there once, not duplicated per module.
- **MFA**: TOTP (RFC 6238) via `otplib`, secret encrypted at rest
  (AES-256-GCM) using `MFA_SECRET_ENCRYPTION_KEY`, single-use hashed backup
  codes. An access token issued for an MFA-enabled account is only valid if
  it was minted after MFA verification (`requireAuth` checks this).
- **GenAI Tutor exam lock**: `src/middleware/examLock.middleware.ts` blocks
  any AI Tutor endpoint whenever the caller has an `ExamAttempt` with status
  `IN_PROGRESS`. Wired onto every route in `src/modules/tutor/tutor.routes.ts`
  and tested end-to-end in `tests/exams.test.ts` against real exam attempts.
- **Exam security model**: question order is generated and stored server-
  side at attempt-start (`ExamAttempt.questionOrder`) — the client never
  supplies or influences it. Option display order is independently
  randomized per (attempt, question) using a deterministic seeded shuffle
  (`src/modules/exams/attempts.service.ts`), so it's stable across repeated
  fetches without persisting extra state. The correct-answer key is never
  sent to a student before submission (`sanitizeQuestionForAttempt`).
  Every path that can end an attempt — a normal submit, a reactive or
  batch-reconciled timeout, or a proctoring-driven integrity flag — goes
  through the single `finalizeAttempt` function, so grading, XP, and
  percentile calculation can never diverge between those cases. A flagged
  (integrity-invalidated) attempt earns no XP and is excluded from course
  progress.
- **Proctoring escalation policy**: documented and centralized in
  `src/modules/proctoring/proctoring.service.ts` — termination requires a
  *pattern* (3+ HIGH-severity warnings, or 8+ warnings of any severity in
  one session), not a single flagged frame, to avoid a false positive from a
  webcam model ending someone's exam.
- **Course data import**: `scripts/importCourses.ts` documents every mapping
  decision from the source Excel files to the DB schema (see the file's
  header comment) — no syllabus content is invented; administrative fields
  like `estimatedDuration` are clearly called out as derived, not sourced.

## API surface (Part 2)

All routes are mounted under `/api`:

| Module | Base path | Notes |
|---|---|---|
| Auth | `/api/auth` | register, login, MFA setup/enable/disable/login, refresh, logout |
| Users | `/api/users` | profile, admin student/admin management |
| Courses | `/api/courses` | CRUD, enroll, my-enrollments |
| Syllabus | `/api/syllabus` | Module/Topic/Subtopic CRUD, video/notes attachment |
| Learning | `/api/learning` | progress tracking |
| XP | `/api/xp` | history, streak, leaderboard |
| Practice | `/api/practice` | subtopic practice sets |
| Quizzes | `/api/quizzes` | timed subtopic quizzes |
| Tests | `/api/tests` | module/course tests, negative marking |
| Assessments | `/api/assessments` | diagnostic/topic/module/course/final |
| Assignments | `/api/assignments` | submission + manual evaluation |
| Coding | `/api/coding` | problems + submissions (execution provider not wired up) |
| Notifications | `/api/notifications` | list/read/delete |
| Analytics | `/api/analytics` | student + course + platform (factual aggregation only) |
| Recommendations | `/api/recommendations` | rule-based baseline |
| Learning Gaps | `/api/learning-gaps` | rule-based detection baseline |
| AI/ML | `/api/ai` | performance/completion/risk/engagement predictors, ML gap detection, insights |
| Tutor | `/api/tutor` | GenAI Tutor chat — hard-blocked during any in-progress exam attempt |
| Exams | `/api/exams` | question bank reuse, exam CRUD/scheduling, attempt lifecycle, reports |
| Proctoring | `/api/proctoring` | session view, event/warning ingestion, escalation, admin review |
| Admin | `/api/admin` | dashboard, audit logs, question bank |

## What's next (Parts 6–7)

1. **Part 6 (Integration)**: nothing needs to change structurally — Parts 4
   and 5 already read/write the same tables the rest of the platform uses
   (exams flow through the unified `Progress`/`XPTransaction` tables via
   `ContentType.EXAM`, same as every other module), not a shadow data
   source. The main integration work left is frontend: wiring the (currently
   fully static/mock) frontend export to these real endpoints, and building
   a browser-side face-detection client that posts to
   `/api/proctoring/sessions/:examAttemptId/warnings`.
2. **Part 7 (Production readiness)**: expand the Jest suite (this build
   ships auth/RBAC/grading/full-journey/AI-predictor/exam-lock/exam-lifecycle/
   proctoring-escalation coverage as a foundation), add a CI pipeline that
   runs `npm test` + `verify:integrity` against a disposable MongoDB instance,
   wire `POST /api/exams/reconcile-expired` to a scheduler (cron/setInterval)
   for production, and run the security/accessibility/performance passes
   once the frontend is wired to real endpoints.
