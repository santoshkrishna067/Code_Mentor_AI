# Part 7 — Production Readiness: Status

This is an honest status report, not a checklist rubber-stamped complete.
This build environment has no network access and no live database, so
**anything requiring execution (running the test suite, load testing, a
real browser for accessibility/responsive checks, a real MongoDB instance
for integrity checks) could not actually be run here.** What follows is
what a careful static/code-level review found and fixed, and what
genuinely still needs to happen with real infrastructure.

## What this pass actually found and fixed

Real issues, not hypothetical ones — found by re-reading the codebase
critically rather than assuming past work was correct:

1. **Fragile sensitive-field stripping** (`users.service.ts`,
   `getMyProfile`): admin profile responses stripped `passwordHash` /
   `mfaSecret` by setting them to `undefined` on a spread object. This
   happened to work only because `JSON.stringify` (which Express's
   `res.json()` uses) silently drops `undefined`-valued keys — a fragile,
   implicit safety net. Fixed to explicit destructuring exclusion, which
   doesn't depend on serializer behavior.
2. **Missing rate limiting on MFA code validation** (`auth.routes.ts`):
   `/login` and `/login/mfa` were rate-limited, but `/mfa/enable` and
   `/mfa/disable` — both of which validate a brute-forceable 6-digit TOTP
   code — were not. `/mfa/disable` was partially mitigated by also requiring
   the account password, but defense-in-depth means any OTP-validating
   endpoint should be rate-limited regardless of what else it checks. Fixed
   by adding `authRateLimiter` to both.
3. Re-verified (not just assumed) that every admin-mutating route across
   all 20 route files is actually covered by `requireAuth`/`requireRole` —
   including router-level `.use()` middleware, which a naive per-route grep
   would miss and did initially flag as false positives. Confirmed correct
   after manual inspection of `admin.routes.ts` and `tutor.routes.ts`.
4. Confirmed CORS is origin-restricted (not `*`) with credentials enabled
   only for the configured origin, and that production error responses
   return a generic message (real error detail only in non-production,
   controlled by `isProd`).

## What was already correct from earlier parts (re-verified here)

- Coding submissions never leak hidden test case `stderr` to students
  (`coding.service.ts`: `stderr: tc.isHidden ? undefined : ...`).
- Exam questions are never served with `correctAnswer` before submission
  (`sanitizeQuestionForAttempt`); the full answer key is only ever returned
  from `/review` and gated on `showResults` or admin.
- The MongoDB schema conversion (49 models, 85 foreign keys) was verified
  structurally — every model has exactly one `@id` field mapped to `_id`,
  no leftover MySQL-only type modifiers, brace-balanced.

## What genuinely still needs real infrastructure to verify

Being direct about the limits of a static review:

- **Unit/integration/E2E test execution**: the Jest suite (auth, RBAC,
  grading, full learning journey, AI predictors, exam lifecycle, proctoring
  escalation) is real and was written to actually exercise the code — but
  it has never been run, because this environment has no MongoDB instance
  and no network for `npm install`. Run `npm install && npm run prisma:push
  && npm test` in a real environment before trusting it's green.
- **`verify:integrity`**: written to catch orphaned content, but needs a
  populated database to run against.
- **Load/performance testing**: not attempted. No profiling data exists for
  query performance under real data volume, N+1 query risk in nested
  Prisma `include`s (several exist — e.g. `examsService.report` includes
  student+user+warnings per attempt), or connection pool sizing for Mongo.
- **Accessibility review**: not attempted. Would need a real browser and
  a screen reader or axe-core run against the actual rendered app — this
  environment can't render React at all (no `npm install`).
- **Responsive testing**: same limitation — no browser to actually resize
  and inspect.
- **Frontend security review**: the frontend has real auth/token handling
  now (Part 6), but hasn't had a dedicated XSS/CSRF review pass. The access
  token is kept in memory rather than localStorage specifically to reduce
  XSS blast radius (see `apiClient.ts`), and the refresh token is httpOnly
  (set by the backend, never readable by JS) — but this wasn't stress-tested
  against a real attack.
- **Dependency vulnerability scan**: `npm audit` couldn't be run (no
  network). Should be run before any deployment.

## Recommended next steps, in order

1. `npm install && npm run prisma:push` against a real MongoDB Atlas
   cluster, then `npm test` — fix whatever the (never-yet-executed) test
   suite actually surfaces.
2. `npm audit` and update any flagged dependencies.
3. Load-test the endpoints most likely to see concurrent traffic under
   real usage: exam start/submit (many students starting simultaneously),
   the AI predictor endpoints (per-student aggregation queries).
4. A real accessibility pass (axe-core or similar) once the frontend is
   actually running in a browser.
5. Wire `POST /api/exams/reconcile-expired` to an actual scheduler — it
   exists as an admin-triggerable endpoint but needs a cron job in
   production, per its doc comment in `attempts.service.ts`.
