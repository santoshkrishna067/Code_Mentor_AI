import { authenticator } from 'otplib'
import crypto from 'crypto'
import QRCode from 'qrcode'
import { env } from '@/config/env'

// AES-256-GCM encryption for the TOTP secret at rest. The 32-byte key comes
// from MFA_SECRET_ENCRYPTION_KEY (env), never from the DB itself.
const ALGO = 'aes-256-gcm'

function getKey(): Buffer {
  // Accept either a 32-char passphrase or a 64-char hex string.
  const raw = env.MFA_SECRET_ENCRYPTION_KEY
  return raw.length === 64 ? Buffer.from(raw, 'hex') : crypto.createHash('sha256').update(raw).digest()
}

export function encryptSecret(plain: string): string {
  const iv = crypto.randomBytes(12)
  const cipher = crypto.createCipheriv(ALGO, getKey(), iv)
  const encrypted = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()])
  const authTag = cipher.getAuthTag()
  return [iv.toString('hex'), authTag.toString('hex'), encrypted.toString('hex')].join(':')
}

export function decryptSecret(payload: string): string {
  const [ivHex, tagHex, dataHex] = payload.split(':')
  const decipher = crypto.createDecipheriv(ALGO, getKey(), Buffer.from(ivHex, 'hex'))
  decipher.setAuthTag(Buffer.from(tagHex, 'hex'))
  const decrypted = Buffer.concat([decipher.update(Buffer.from(dataHex, 'hex')), decipher.final()])
  return decrypted.toString('utf8')
}

export function generateTotpSecret(): string {
  return authenticator.generateSecret()
}

export function verifyTotpToken(secret: string, token: string): boolean {
  authenticator.options = { window: 1 } // allow ±1 time-step clock drift
  return authenticator.check(token, secret)
}

export async function buildOtpAuthQrCode(email: string, secret: string): Promise<string> {
  const otpauth = authenticator.keyuri(email, env.MFA_ISSUER, secret)
  return QRCode.toDataURL(otpauth)
}
