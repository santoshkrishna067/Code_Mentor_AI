// Never send correctAnswer / Option.isCorrect to a student before they submit.
// Every module that serves questions to a student-facing "take this" endpoint
// must run results through this function.
export function sanitizeQuestionForAttempt(q: any) {
  return {
    id: q.id,
    type: q.type.toLowerCase(),
    content: q.content,
    options: q.options?.map((o: any) => ({ id: o.id, content: o.content })),
    difficulty: q.difficulty,
    tags: q.tags,
    courseId: q.courseId,
    moduleId: q.moduleId ?? undefined,
    topicId: q.topicId ?? undefined,
    estimatedTime: q.estimatedTime,
    marks: q.marks,
    negativeMarks: q.negativeMarks ?? undefined,
  }
}

// Full question including the answer key — for review-after-submit, admin
// editing, or once an attempt has been graded.
export function fullQuestionDto(q: any) {
  return {
    ...sanitizeQuestionForAttempt(q),
    correctAnswer: q.correctAnswer,
    explanation: q.explanation ?? undefined,
    options: q.options?.map((o: any) => ({ id: o.id, content: o.content, isCorrect: o.isCorrect })),
  }
}
