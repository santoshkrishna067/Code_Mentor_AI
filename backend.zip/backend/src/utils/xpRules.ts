import { ContentType } from '@prisma/client'

// Base XP awarded per content type on first completion. Kept in one place so
// every module (learning, practice, quizzes, assignments, exams...) computes
// XP the same way instead of re-implementing the formula.
const BASE_XP: Record<ContentType, number> = {
  VIDEO: 10,
  NOTES: 10,
  PRACTICE: 15,
  CODING: 25,
  QUIZ: 20,
  TEST: 40,
  ASSIGNMENT: 50,
  ASSESSMENT: 60,
  EXAM: 80,
}

// Score-scaled XP for graded content (quiz/test/assignment/assessment/coding):
// full base XP at 100% score, floor of 20% base XP for any passing attempt.
export function computeXp(contentType: ContentType, opts: { score?: number; isFirstCompletion: boolean }): number {
  const base = BASE_XP[contentType]
  if (!opts.isFirstCompletion) return 0 // XP is only awarded once per content item

  if (opts.score === undefined) return base // ungraded content (video/notes watched)

  const ratio = Math.max(0, Math.min(1, opts.score / 100))
  const scaled = Math.round(base * Math.max(ratio, 0.2))
  return scaled
}

export function streakBonusXp(currentStreak: number): number {
  if (currentStreak <= 0) return 0
  if (currentStreak % 30 === 0) return 100
  if (currentStreak % 7 === 0) return 40
  return 5
}
