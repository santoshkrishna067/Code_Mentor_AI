export interface GradableQuestion {
  id: string
  correctAnswer: unknown // string | string[]
  marks: number
  negativeMarks?: number | null
}

export interface SubmittedAnswer {
  questionId: string
  answer: unknown // string | string[]
}

function normalize(answer: unknown): string {
  if (Array.isArray(answer)) return [...answer].map((a) => String(a).trim().replace(/\s+/g, ' ').toLowerCase()).sort().join('|')
  return String(answer ?? '').trim().replace(/\s+/g, ' ').toLowerCase()
}

export function isAnswerCorrect(correctAnswer: unknown, submitted: unknown): boolean {
  return normalize(correctAnswer) === normalize(submitted)
}

export interface GradingResult {
  totalMarks: number
  marksAwarded: number
  correctCount: number
  incorrectCount: number
  unansweredCount: number
  scorePercent: number
  perQuestion: { questionId: string; isCorrect: boolean; marksAwarded: number }[]
}

// Applies negative marking (if any question defines negativeMarks) and
// computes a 0-100 percentage score, consistently, everywhere questions are graded.
export function gradeSubmission(
  questions: GradableQuestion[],
  answers: SubmittedAnswer[],
  negativeMarkingEnabled: boolean
): GradingResult {
  const answerMap = new Map(answers.map((a) => [a.questionId, a.answer]))
  const totalMarks = questions.reduce((sum, q) => sum + q.marks, 0)

  let marksAwarded = 0
  let correctCount = 0
  let incorrectCount = 0
  let unansweredCount = 0
  const perQuestion: GradingResult['perQuestion'] = []

  for (const q of questions) {
    const submitted = answerMap.get(q.id)
    if (submitted === undefined || submitted === null || submitted === '') {
      unansweredCount += 1
      perQuestion.push({ questionId: q.id, isCorrect: false, marksAwarded: 0 })
      continue
    }
    const correct = isAnswerCorrect(q.correctAnswer, submitted)
    if (correct) {
      correctCount += 1
      marksAwarded += q.marks
      perQuestion.push({ questionId: q.id, isCorrect: true, marksAwarded: q.marks })
    } else {
      incorrectCount += 1
      const penalty = negativeMarkingEnabled && q.negativeMarks ? q.negativeMarks : 0
      marksAwarded -= penalty
      perQuestion.push({ questionId: q.id, isCorrect: false, marksAwarded: -penalty })
    }
  }

  marksAwarded = Math.max(0, marksAwarded) // never let a raw score go negative
  const scorePercent = totalMarks > 0 ? Math.round((marksAwarded / totalMarks) * 100) : 0

  return { totalMarks, marksAwarded, correctCount, incorrectCount, unansweredCount, scorePercent, perQuestion }
}

// Fisher-Yates shuffle for question/option randomization.
export function shuffle<T>(arr: T[], seed?: number): T[] {
  const result = [...arr]
  let m = result.length
  let random = seed !== undefined ? mulberry32(seed) : Math.random
  while (m) {
    const i = Math.floor(random() * m--)
    ;[result[m], result[i]] = [result[i], result[m]]
  }
  return result
}

// Deterministic PRNG so a given attempt can be reproduced/audited if seeded.
function mulberry32(a: number) {
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}
