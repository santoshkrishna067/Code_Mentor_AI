import argon2 from 'argon2'
import crypto from 'crypto'

// argon2id is the OWASP-recommended variant for password hashing.
export async function hashPassword(plain: string): Promise<string> {
  return argon2.hash(plain, { type: argon2.argon2id })
}

export async function verifyPassword(hash: string, plain: string): Promise<boolean> {
  try {
    return await argon2.verify(hash, plain)
  } catch {
    return false
  }
}

// Refresh tokens and MFA backup codes are stored only as SHA-256 hashes —
// never in plaintext — so a DB leak alone can't be used to impersonate users.
export function sha256(value: string): string {
  return crypto.createHash('sha256').update(value).digest('hex')
}

export function generateBackupCodes(count = 10): string[] {
  return Array.from({ length: count }, () => crypto.randomBytes(5).toString('hex'))
}
