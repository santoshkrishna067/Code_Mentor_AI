import { Response } from 'express'

// Mirrors frontend `ApiResponse<T>` / `PaginatedResponse<T>` / `ApiError` types exactly.

export function ok<T>(res: Response, data: T, message?: string, status = 200) {
  return res.status(status).json({ success: true, data, message })
}

export function paginated<T>(
  res: Response,
  data: T[],
  pagination: { page: number; limit: number; total: number }
) {
  return res.status(200).json({
    data,
    pagination: {
      ...pagination,
      totalPages: Math.max(1, Math.ceil(pagination.total / pagination.limit)),
    },
  })
}

export class ApiError extends Error {
  status: number
  code: string
  details?: Record<string, unknown>

  constructor(status: number, code: string, message: string, details?: Record<string, unknown>) {
    super(message)
    this.status = status
    this.code = code
    this.details = details
  }

  static badRequest(message: string, details?: Record<string, unknown>) {
    return new ApiError(400, 'BAD_REQUEST', message, details)
  }
  static unauthorized(message = 'Unauthorized') {
    return new ApiError(401, 'UNAUTHORIZED', message)
  }
  static forbidden(message = 'Forbidden') {
    return new ApiError(403, 'FORBIDDEN', message)
  }
  static notFound(message = 'Not found') {
    return new ApiError(404, 'NOT_FOUND', message)
  }
  static conflict(message: string, details?: Record<string, unknown>) {
    return new ApiError(409, 'CONFLICT', message, details)
  }
  static unprocessable(message: string, details?: Record<string, unknown>) {
    return new ApiError(422, 'UNPROCESSABLE_ENTITY', message, details)
  }
  static tooManyRequests(message = 'Too many requests') {
    return new ApiError(429, 'TOO_MANY_REQUESTS', message)
  }
  static internal(message = 'Internal server error') {
    return new ApiError(500, 'INTERNAL_ERROR', message)
  }
}
