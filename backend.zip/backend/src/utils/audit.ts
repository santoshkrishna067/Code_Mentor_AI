import { Request } from 'express'
import { prisma } from '@/config/prisma'
import { logger } from './logger'

export async function writeAuditLog(
  req: Request,
  action: string,
  resource: string,
  resourceId?: string,
  details?: Record<string, unknown>
) {
  try {
    await prisma.auditLog.create({
      data: {
        userId: req.user?.id,
        action,
        resource,
        resourceId,
        details: details ? JSON.parse(JSON.stringify(details)) : undefined,
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'],
      },
    })
  } catch (err) {
    // Auditing must never break the primary request flow.
    logger.error({ err, action, resource }, 'Failed to write audit log')
  }
}
