import jwt from 'jsonwebtoken'
import { env } from '@/config/env'
import { Role } from '@prisma/client'

export interface AccessTokenPayload {
  sub: string // userId
  role: Role
  mfaVerified: boolean
}

export interface RefreshTokenPayload {
  sub: string // userId
  jti: string // unique token id, matches RefreshToken.id in DB for revocation checks
}

export function signAccessToken(payload: AccessTokenPayload): string {
  return jwt.sign(payload, env.JWT_ACCESS_SECRET, { expiresIn: env.JWT_ACCESS_TTL })
}

export function verifyAccessToken(token: string): AccessTokenPayload {
  return jwt.verify(token, env.JWT_ACCESS_SECRET) as AccessTokenPayload
}

export function signRefreshToken(payload: RefreshTokenPayload): string {
  return jwt.sign(payload, env.JWT_REFRESH_SECRET, { expiresIn: env.JWT_REFRESH_TTL })
}

export function verifyRefreshToken(token: string): RefreshTokenPayload {
  return jwt.verify(token, env.JWT_REFRESH_SECRET) as RefreshTokenPayload
}

// Short-lived token issued after password check but before MFA verification.
// Proves "this caller already knows the password for this account" without
// granting any API access — it is NOT an access token and is rejected by
// requireAuth.
export interface MfaChallengePayload {
  sub: string
  purpose: 'mfa_challenge'
}

export function signMfaChallengeToken(userId: string): string {
  return jwt.sign({ sub: userId, purpose: 'mfa_challenge' } as MfaChallengePayload, env.JWT_ACCESS_SECRET, {
    expiresIn: '5m',
  })
}

export function verifyMfaChallengeToken(token: string): MfaChallengePayload {
  const payload = jwt.verify(token, env.JWT_ACCESS_SECRET) as MfaChallengePayload
  if (payload.purpose !== 'mfa_challenge') throw new Error('Invalid challenge token')
  return payload
}
