import { PrismaClient } from '@prisma/client'
import { isProd } from './env'

// Prevent multiple PrismaClient instances during dev hot-reload.
declare global {
  // eslint-disable-next-line no-var
  var __prisma__: PrismaClient | undefined
}

export const prisma =
  global.__prisma__ ??
  new PrismaClient({
    log: isProd ? ['error', 'warn'] : ['error', 'warn'],
  })

if (!isProd) {
  global.__prisma__ = prisma
}
