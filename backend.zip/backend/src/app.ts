import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import cookieParser from 'cookie-parser'
import pinoHttp from 'pino-http'
import rateLimit from 'express-rate-limit'

import { env } from '@/config/env'
import { logger } from '@/utils/logger'
import { errorHandler, notFoundHandler } from '@/middleware/error.middleware'

import authRoutes from '@/modules/auth/auth.routes'
import userRoutes from '@/modules/users/users.routes'
import courseRoutes from '@/modules/courses/courses.routes'
import syllabusRoutes from '@/modules/syllabus/syllabus.routes'
import learningRoutes from '@/modules/learning/learning.routes'
import xpRoutes from '@/modules/xp/xp.routes'
import practiceRoutes from '@/modules/practice/practice.routes'
import quizRoutes from '@/modules/quizzes/quizzes.routes'
import testRoutes from '@/modules/tests/tests.routes'
import assessmentRoutes from '@/modules/assessments/assessments.routes'
import assignmentRoutes from '@/modules/assignments/assignments.routes'
import codingRoutes from '@/modules/coding/coding.routes'
import notificationRoutes from '@/modules/notifications/notifications.routes'
import analyticsRoutes from '@/modules/analytics/analytics.routes'
import recommendationRoutes from '@/modules/recommendations/recommendations.routes'
import learningGapRoutes from '@/modules/learningGaps/learningGaps.routes'
import adminRoutes from '@/modules/admin/admin.routes'
import aiRoutes from '@/modules/ai/ai.routes'
import tutorRoutes from '@/modules/tutor/tutor.routes'
import examRoutes from '@/modules/exams/exams.routes'
import proctoringRoutes from '@/modules/proctoring/proctoring.routes'
import contactRoutes from '@/modules/contact/contact.routes'
import bookmarkRoutes from '@/modules/bookmarks/bookmarks.routes'
import certificateRoutes from '@/modules/certificates/certificates.routes'

export function createApp() {
  const app = express()

  app.set('trust proxy', 1)
  app.use(helmet())
  app.use(
    cors({
      origin: env.CORS_ORIGIN.split(',').map((s) => s.trim()),
      credentials: true,
    })
  )
  app.use(express.json({ limit: '2mb' }))
  app.use(express.urlencoded({ extended: true }))
  app.use(cookieParser())
  app.use(pinoHttp({ logger, autoLogging: { ignore: (req) => req.url === '/health' } }))

  // Global soft rate limit; auth routes apply a stricter one of their own.
  app.use(
    rateLimit({
      windowMs: 60_000,
      max: 300,
      standardHeaders: true,
      legacyHeaders: false,
      // Webcam frames arrive about once a second per student; they have their own
      // per-student limiter (proctoring.routes.ts), so they must not eat the
      // per-IP budget shared by everyone on the same network.
      skip: (req) => req.method === 'POST' && /^\/api\/proctoring\/sessions\/[^/]+\/frame$/.test(req.path),
    })
  )

  app.get('/health', (_req, res) => res.json({ status: 'ok', time: new Date().toISOString() }))

  app.use('/api/auth', authRoutes)
  app.use('/api/users', userRoutes)
  app.use('/api/courses', courseRoutes)
  app.use('/api/syllabus', syllabusRoutes)
  app.use('/api/learning', learningRoutes)
  app.use('/api/xp', xpRoutes)
  app.use('/api/practice', practiceRoutes)
  app.use('/api/quizzes', quizRoutes)
  app.use('/api/tests', testRoutes)
  app.use('/api/assessments', assessmentRoutes)
  app.use('/api/assignments', assignmentRoutes)
  app.use('/api/coding', codingRoutes)
  app.use('/api/notifications', notificationRoutes)
  app.use('/api/analytics', analyticsRoutes)
  app.use('/api/recommendations', recommendationRoutes)
  app.use('/api/learning-gaps', learningGapRoutes)
  app.use('/api/admin', adminRoutes)
  app.use('/api/ai', aiRoutes)
  app.use('/api/tutor', tutorRoutes)
  app.use('/api/exams', examRoutes)
  app.use('/api/proctoring', proctoringRoutes)
  app.use('/api/contact', contactRoutes)
  app.use('/api/bookmarks', bookmarkRoutes)
  app.use('/api/certificates', certificateRoutes)

  app.use(notFoundHandler)
  app.use(errorHandler)

  return app
}
