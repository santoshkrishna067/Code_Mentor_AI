import { Request, Response, NextFunction } from 'express'
import { Role } from '@prisma/client'
import { ApiError } from '@/utils/apiResponse'

// Usage: router.get('/admin/x', requireAuth, requireRole('ADMIN'), handler)
export function requireRole(...roles: Role[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) return next(ApiError.unauthorized())
    if (!roles.includes(req.user.role)) {
      return next(ApiError.forbidden(`This action requires one of these roles: ${roles.join(', ')}`))
    }
    next()
  }
}

// Ownership check helper: student can only access their own resource unless admin.
export function requireSelfOrAdmin(paramKey: string) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) return next(ApiError.unauthorized())
    const targetId = req.params[paramKey]
    if (req.user.role === Role.ADMIN || req.user.id === targetId) return next()
    return next(ApiError.forbidden('You may only access your own resources'))
  }
}
