import { Request, Response, NextFunction } from 'express'
import { Prisma } from '@prisma/client'
import { ApiError } from '@/utils/apiResponse'
import { logger } from '@/utils/logger'
import { isProd } from '@/config/env'

export function notFoundHandler(req: Request, res: Response) {
  res.status(404).json({
    message: `Route not found: ${req.method} ${req.originalUrl}`,
    code: 'ROUTE_NOT_FOUND',
  })
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function errorHandler(err: unknown, req: Request, res: Response, _next: NextFunction) {
  // Known, intentional API errors
  if (err instanceof ApiError) {
    if (err.status >= 500) logger.error({ err, path: req.path }, 'API error')
    return res.status(err.status).json({
      message: err.message,
      code: err.code,
      details: err.details,
    })
  }

  // Prisma-specific errors get translated into safe, useful responses
  if (err instanceof Prisma.PrismaClientKnownRequestError) {
    if (err.code === 'P2002') {
      return res.status(409).json({
        message: `A record with this ${(err.meta?.target as string[])?.join(', ') || 'value'} already exists`,
        code: 'DUPLICATE_ENTRY',
      })
    }
    if (err.code === 'P2003') {
      return res.status(422).json({
        message: 'Operation violates a required relationship (foreign key constraint)',
        code: 'FOREIGN_KEY_VIOLATION',
      })
    }
    if (err.code === 'P2025') {
      return res.status(404).json({ message: 'Record not found', code: 'NOT_FOUND' })
    }
  }

  logger.error({ err, path: req.path }, 'Unhandled error')
  return res.status(500).json({
    message: isProd ? 'Internal server error' : (err as Error)?.message || 'Internal server error',
    code: 'INTERNAL_ERROR',
  })
}
