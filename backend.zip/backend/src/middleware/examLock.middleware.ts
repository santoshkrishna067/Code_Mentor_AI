import { Request, Response, NextFunction } from 'express'
import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { ExamAttemptStatus } from '@prisma/client'

// CRITICAL SECURITY RULE (Part 5): the GenAI Tutor must never respond while
// the student has any exam attempt IN_PROGRESS. This is enforced here, on
// the server, independent of anything the frontend does or fails to do —
// a student cannot bypass it by hiding the proctoring UI or calling the API
// directly.
export async function blockDuringActiveExam(req: Request, _res: Response, next: NextFunction) {
  if (!req.user) return next(ApiError.unauthorized())

  const activeAttempt = await prisma.examAttempt.findFirst({
    where: { studentId: req.user.id, status: ExamAttemptStatus.IN_PROGRESS },
    select: { id: true },
  })

  if (activeAttempt) {
    return next(
      ApiError.forbidden('The AI Tutor is disabled while a secured exam attempt is in progress.')
    )
  }

  next()
}
