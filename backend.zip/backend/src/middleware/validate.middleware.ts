import { Request, Response, NextFunction } from 'express'
import { AnyZodObject, ZodError } from 'zod'
import { ApiError } from '@/utils/apiResponse'

interface Schemas {
  body?: AnyZodObject
  query?: AnyZodObject
  params?: AnyZodObject
}

// Validates and REPLACES req.body/query/params with the parsed (typed,
// coerced, defaulted) result, so downstream handlers never re-validate.
export function validate(schemas: Schemas) {
  return (req: Request, _res: Response, next: NextFunction) => {
    try {
      if (schemas.body) req.body = schemas.body.parse(req.body)
      if (schemas.query) req.query = schemas.query.parse(req.query) as any
      if (schemas.params) req.params = schemas.params.parse(req.params) as any
      next()
    } catch (err) {
      if (err instanceof ZodError) {
        return next(
          ApiError.badRequest('Validation failed', {
            issues: err.issues.map((i) => ({ path: i.path.join('.'), message: i.message })),
          })
        )
      }
      next(err)
    }
  }
}
