import { Request, Response, NextFunction } from 'express'
import { verifyAccessToken } from '@/utils/jwt'
import { ApiError } from '@/utils/apiResponse'
import { prisma } from '@/config/prisma'
import { Role } from '@prisma/client'

export interface AuthUser {
  id: string
  role: Role
  mfaVerified: boolean
  isActive: boolean
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: AuthUser
      /** Set by exam-session middleware when the caller is inside an active proctored attempt. */
      activeExamAttemptId?: string
    }
  }
}

function extractToken(req: Request): string | null {
  const header = req.headers.authorization
  if (header?.startsWith('Bearer ')) return header.slice(7)
  if (req.cookies?.accessToken) return req.cookies.accessToken
  return null
}

// Requires a valid, non-expired access token. Rejects if the user account was
// deactivated after the token was issued (checked against the DB, not just
// the token claims) so a disabled account can't keep using live tokens.
export async function requireAuth(req: Request, _res: Response, next: NextFunction) {
  try {
    const token = extractToken(req)
    if (!token) throw ApiError.unauthorized('Authentication token missing')

    const payload = verifyAccessToken(token)
    const user = await prisma.user.findUnique({ where: { id: payload.sub } })

    if (!user || !user.isActive) throw ApiError.unauthorized('Account is inactive or does not exist')

    // If MFA is enabled for the account, the access token MUST have been
    // issued post-MFA-verification. This blocks a stolen password-only
    // token from ever reaching protected routes.
    if (user.mfaEnabled && !payload.mfaVerified) {
      throw ApiError.unauthorized('MFA verification required')
    }

    req.user = { id: user.id, role: user.role, mfaVerified: payload.mfaVerified, isActive: user.isActive }
    next()
  } catch (err) {
    if (err instanceof ApiError) return next(err)
    next(ApiError.unauthorized('Invalid or expired token'))
  }
}

// Optional auth: attaches req.user if a valid token is present, but never rejects.
export async function optionalAuth(req: Request, _res: Response, next: NextFunction) {
  const token = extractToken(req)
  if (!token) return next()
  try {
    const payload = verifyAccessToken(token)
    const user = await prisma.user.findUnique({ where: { id: payload.sub } })
    if (user?.isActive) {
      req.user = { id: user.id, role: user.role, mfaVerified: payload.mfaVerified, isActive: user.isActive }
    }
  } catch {
    // ignore invalid token on optional routes
  }
  next()
}
