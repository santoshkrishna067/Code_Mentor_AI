import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { ContentType, ProgressStatus } from '@prisma/client'
import { gradeSubmission, shuffle, SubmittedAnswer } from '@/utils/grading'
import { sanitizeQuestionForAttempt, fullQuestionDto } from '@/utils/questionSanitizer'
import { learningService } from '@/modules/learning/learning.service'

function toSummary(t: any) {
  return {
    id: t.id,
    title: t.title,
    description: t.description,
    difficulty: t.difficulty,
    duration: t.duration,
    passingScore: t.passingScore,
    totalMarks: t.totalMarks,
    negativeMarking: t.negativeMarking,
    randomizeQuestions: t.randomizeQuestions,
    showResults: t.showResults,
    moduleId: t.moduleId ?? undefined,
    courseId: t.courseId,
  }
}

export const testsService = {
  async create(courseId: string, input: any) {
    const course = await prisma.course.findUnique({ where: { id: courseId } })
    if (!course) throw ApiError.notFound('Course not found')
    if (input.moduleId) {
      const mod = await prisma.courseModule.findUnique({ where: { id: input.moduleId } })
      if (!mod || mod.courseId !== courseId) throw ApiError.badRequest('moduleId does not belong to this course')
    }
    const foundCount = await prisma.question.count({ where: { id: { in: input.questionIds } } })
    if (foundCount !== input.questionIds.length) throw ApiError.badRequest('One or more questionIds do not exist')

    const test = await prisma.test.create({
      data: {
        courseId,
        moduleId: input.moduleId,
        title: input.title,
        description: input.description,
        difficulty: input.difficulty,
        duration: input.duration,
        passingScore: input.passingScore,
        totalMarks: input.totalMarks,
        negativeMarking: input.negativeMarking ?? false,
        randomizeQuestions: input.randomizeQuestions ?? true,
        showResults: input.showResults ?? true,
        questions: { create: input.questionIds.map((questionId: string, order: number) => ({ questionId, order })) },
      },
    })
    return toSummary(test)
  },

  async getForAttempt(testId: string) {
    const test = await prisma.test.findUnique({
      where: { id: testId },
      include: { questions: { orderBy: { order: 'asc' }, include: { question: { include: { options: true } } } } },
    })
    if (!test) throw ApiError.notFound('Test not found')

    let questions = test.questions.map((tq) => sanitizeQuestionForAttempt(tq.question))
    if (test.randomizeQuestions) questions = shuffle(questions)

    return { ...toSummary(test), questions }
  },

  async submit(studentId: string, testId: string, answers: SubmittedAnswer[], timeSpentSeconds: number) {
    const test = await prisma.test.findUnique({
      where: { id: testId },
      include: { questions: { include: { question: true } }, course: true, module: true },
    })
    if (!test) throw ApiError.notFound('Test not found')

    const questions = test.questions.map((tq) => ({
      id: tq.question.id,
      correctAnswer: tq.question.correctAnswer,
      marks: tq.question.marks,
      negativeMarks: tq.question.negativeMarks,
    }))
    const result = gradeSubmission(questions, answers, test.negativeMarking)
    const passed = result.scorePercent >= test.passingScore

    const { xpEarned } = await learningService.recordProgress({
      studentId,
      courseId: test.courseId,
      moduleId: test.moduleId ?? undefined,
      contentType: ContentType.TEST,
      contentId: test.id,
      status: passed ? ProgressStatus.COMPLETED : ProgressStatus.IN_PROGRESS,
      score: result.scorePercent,
    })

    return { ...result, passed, xpEarned, showResults: test.showResults, timeSpentSeconds }
  },

  async review(testId: string) {
    const test = await prisma.test.findUnique({
      where: { id: testId },
      include: { questions: { orderBy: { order: 'asc' }, include: { question: { include: { options: true } } } } },
    })
    if (!test) throw ApiError.notFound('Test not found')
    if (!test.showResults) throw ApiError.forbidden('Result review is disabled for this test')
    return { ...toSummary(test), questions: test.questions.map((tq) => fullQuestionDto(tq.question)) }
  },
}
