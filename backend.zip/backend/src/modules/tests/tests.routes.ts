import { Router } from 'express'
import { z } from 'zod'
import { testsService } from './tests.service'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole } from '@/middleware/rbac.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok } from '@/utils/apiResponse'
import { Role } from '@prisma/client'

const router = Router()

const answerSchema = z.object({ questionId: z.string(), answer: z.union([z.string(), z.array(z.string())]) })

const createSchema = z.object({
  title: z.string().min(1),
  description: z.string().min(1),
  difficulty: z.enum(['BEGINNER', 'INTERMEDIATE', 'ADVANCED', 'EXPERT']),
  duration: z.number().int().positive(),
  passingScore: z.number().int().min(0).max(100),
  totalMarks: z.number().int().positive(),
  negativeMarking: z.boolean().optional(),
  randomizeQuestions: z.boolean().optional(),
  showResults: z.boolean().optional(),
  moduleId: z.string().optional(),
  questionIds: z.array(z.string()).min(1),
})

router.post(
  '/courses/:courseId',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({ body: createSchema }),
  asyncHandler(async (req, res) => ok(res, await testsService.create(req.params.courseId, req.body), 'Test created', 201))
)

router.get(
  '/:testId/attempt',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await testsService.getForAttempt(req.params.testId)))
)

router.post(
  '/:testId/submit',
  requireAuth,
  requireRole(Role.STUDENT),
  validate({ body: z.object({ answers: z.array(answerSchema), timeSpentSeconds: z.number().int().min(0).default(0) }) }),
  asyncHandler(async (req, res) =>
    ok(res, await testsService.submit(req.user!.id, req.params.testId, req.body.answers, req.body.timeSpentSeconds), 'Submitted')
  )
)

router.get(
  '/:testId/review',
  requireAuth,
  asyncHandler(async (req, res) => ok(res, await testsService.review(req.params.testId)))
)

export default router
