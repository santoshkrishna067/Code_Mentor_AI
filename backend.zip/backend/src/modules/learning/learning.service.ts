import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { ContentType, ProgressStatus, XPSource } from '@prisma/client'
import { computeXp } from '@/utils/xpRules'
import { xpService } from '@/modules/xp/xp.service'
import { notificationsService } from '@/modules/notifications/notifications.service'
import { learningGapsService } from '@/modules/learningGaps/learningGaps.service'
import { logger } from '@/utils/logger'

const CONTENT_TO_XP_SOURCE: Record<ContentType, XPSource> = {
  VIDEO: XPSource.VIDEO,
  NOTES: XPSource.NOTES,
  PRACTICE: XPSource.PRACTICE,
  CODING: XPSource.CODING,
  QUIZ: XPSource.QUIZ,
  TEST: XPSource.TEST,
  ASSIGNMENT: XPSource.ASSIGNMENT,
  ASSESSMENT: XPSource.ASSESSMENT,
  EXAM: XPSource.EXAM,
}

export const learningService = {
  // Everything a student can currently take, across the courses they are
  // enrolled in: quizzes (attached to lessons), tests, assessments and
  // assignments. Powers the Quizzes / Tests / Assessments sidebar pages.
  async available(studentId: string) {
    const enrollments = await prisma.enrollment.findMany({
      where: { studentId },
      include: { course: { select: { id: true, name: true, slug: true } } },
    })
    const courseIds = enrollments.map((e) => e.courseId)
    const courseById = new Map(enrollments.map((e) => [e.courseId, e.course]))
    if (courseIds.length === 0) return { quizzes: [], tests: [], assessments: [], enrolledCourses: 0 }

    const [quizzes, tests, assessments, attempts] = await Promise.all([
      prisma.quiz.findMany({
        where: { subtopic: { topic: { module: { courseId: { in: courseIds } } } } },
        include: { subtopic: { include: { topic: { include: { module: true } } } }, _count: { select: { questions: true } } },
      }),
      prisma.test.findMany({ where: { courseId: { in: courseIds } }, include: { _count: { select: { questions: true } } } }),
      prisma.assessment.findMany({ where: { courseId: { in: courseIds } }, include: { _count: { select: { questions: true } } } }),
      prisma.progress.findMany({
        where: { studentId, courseId: { in: courseIds }, contentType: { in: ['QUIZ', 'TEST', 'ASSESSMENT'] } },
        select: { contentId: true, score: true, status: true },
      }),
    ])
    const attemptById = new Map(attempts.map((a) => [a.contentId, a]))
    const attemptInfo = (id: string) => {
      const a = attemptById.get(id)
      return a ? { attempted: true, score: a.score ?? undefined, completed: a.status === 'COMPLETED' } : { attempted: false }
    }

    return {
      enrolledCourses: courseIds.length,
      quizzes: quizzes.map((q) => ({
        id: q.id,
        title: q.title,
        description: q.description,
        difficulty: q.difficulty,
        durationMinutes: q.estimatedDuration,
        passingScore: q.passingScore,
        questionCount: q._count.questions,
        courseName: courseById.get(q.subtopic.topic.module.courseId)?.name,
        context: q.subtopic.title,
        ...attemptInfo(q.id),
      })),
      tests: tests.map((t) => ({
        id: t.id,
        title: t.title,
        description: t.description,
        difficulty: t.difficulty,
        durationMinutes: t.duration,
        passingScore: t.passingScore,
        questionCount: t._count.questions,
        courseName: courseById.get(t.courseId)?.name,
        ...attemptInfo(t.id),
      })),
      assessments: assessments.map((a) => ({
        id: a.id,
        title: a.title,
        description: a.description,
        difficulty: a.difficulty,
        durationMinutes: a.duration,
        passingScore: a.passingScore,
        questionCount: a._count.questions,
        courseName: courseById.get(a.courseId)?.name,
        kind: a.type,
        ...attemptInfo(a.id),
      })),
    }
  },
  // Called by every content module (video watch, notes read, practice/quiz/
  // test/assignment/assessment submit) to record progress and award XP
  // exactly once per content item. This is the ONE place progress+XP logic
  // lives — no module duplicates it.
  async recordProgress(input: {
    studentId: string
    courseId: string
    moduleId?: string
    topicId?: string
    subtopicId?: string
    contentType: ContentType
    contentId: string
    status: ProgressStatus
    score?: number
  }) {
    const existing = await prisma.progress.findUnique({
      where: {
        studentId_contentType_contentId: {
          studentId: input.studentId,
          contentType: input.contentType,
          contentId: input.contentId,
        },
      },
    })

    const isFirstCompletion = input.status === ProgressStatus.COMPLETED && existing?.status !== ProgressStatus.COMPLETED
    const xpEarned = computeXp(input.contentType, { score: input.score, isFirstCompletion })

    const progress = await prisma.progress.upsert({
      where: {
        studentId_contentType_contentId: {
          studentId: input.studentId,
          contentType: input.contentType,
          contentId: input.contentId,
        },
      },
      create: {
        studentId: input.studentId,
        courseId: input.courseId,
        moduleId: input.moduleId,
        topicId: input.topicId,
        subtopicId: input.subtopicId,
        contentType: input.contentType,
        contentId: input.contentId,
        status: input.status,
        score: input.score,
        xpEarned,
        attempts: 1,
        completedAt: input.status === ProgressStatus.COMPLETED ? new Date() : undefined,
      },
      update: {
        status: input.status,
        score: input.score ?? undefined,
        xpEarned: { increment: xpEarned },
        attempts: { increment: 1 },
        completedAt: input.status === ProgressStatus.COMPLETED ? new Date() : undefined,
      },
    })

    if (xpEarned > 0) {
      await xpService.award(
        input.studentId,
        xpEarned,
        CONTENT_TO_XP_SOURCE[input.contentType],
        `Completed ${input.contentType.toLowerCase()}`,
        input.contentId
      )
    }

    if (isFirstCompletion) {
      await notificationsService.create({
        userId: input.studentId,
        type: 'SUCCESS',
        title: 'Progress saved',
        message: `You earned ${xpEarned} XP${input.score !== undefined ? ` (score: ${input.score}%)` : ''}.`,
      })
    }

    // Re-run the deterministic gap detector whenever we have a fresh graded
    // score on a topic-scoped item. This is the single trigger point so gap
    // detection never falls out of sync with progress data; it never blocks
    // the response, and a failure here must never fail the submission itself.
    if (input.score !== undefined && input.topicId) {
      learningGapsService.detectForStudentCourse(input.studentId, input.courseId).catch((err) => {
        logger.error({ err, studentId: input.studentId, courseId: input.courseId }, 'Learning gap detection failed')
      })
    }

    return { progress, xpEarned, isFirstCompletion }
  },

  async getCourseProgress(studentId: string, courseId: string) {
    const enrollment = await prisma.enrollment.findUnique({ where: { studentId_courseId: { studentId, courseId } } })
    if (!enrollment) throw ApiError.notFound('Not enrolled in this course')

    const course = await prisma.course.findUnique({
      where: { id: courseId },
      include: {
        modules: {
          orderBy: { order: 'asc' },
          include: { topics: { orderBy: { order: 'asc' }, include: { subtopics: { orderBy: { order: 'asc' } } } } },
        },
      },
    })
    if (!course) throw ApiError.notFound('Course not found')

    const progressRows = await prisma.progress.findMany({ where: { studentId, courseId } })
    const progressBySubtopic = new Map(progressRows.filter((p) => p.subtopicId).map((p) => [p.subtopicId as string, p]))

    let totalSubtopics = 0
    let completedSubtopics = 0

    const modulesProgress = course.modules.map((mod) => {
      const topicsProgress = mod.topics.map((topic) => {
        const subtopicsProgress = topic.subtopics.map((sub) => {
          totalSubtopics += 1
          const p = progressBySubtopic.get(sub.id)
          if (p?.status === ProgressStatus.COMPLETED) completedSubtopics += 1
          return {
            subtopicId: sub.id,
            status: (p?.status ?? ProgressStatus.NOT_STARTED).toLowerCase(),
            attempts: p?.attempts,
            score: p?.score ?? undefined,
          }
        })
        const done = subtopicsProgress.filter((s) => s.status === 'completed').length
        return {
          topicId: topic.id,
          progress: subtopicsProgress.length ? Math.round((done / subtopicsProgress.length) * 100) : 0,
          subtopicsProgress,
        }
      })
      const done = topicsProgress.reduce((sum, t) => sum + (t.progress === 100 ? 1 : 0), 0)
      return {
        moduleId: mod.id,
        progress: topicsProgress.length ? Math.round((done / topicsProgress.length) * 100) : 0,
        topicsProgress,
      }
    })

    const xpEarned = progressRows.reduce((sum, p) => sum + p.xpEarned, 0)

    return {
      courseId,
      studentId,
      overallProgress: totalSubtopics ? Math.round((completedSubtopics / totalSubtopics) * 100) : 0,
      modulesProgress,
      totalXP: course.totalXP,
      xpEarned,
      startedAt: enrollment.enrolledAt.toISOString(),
      completedAt: enrollment.completedAt?.toISOString(),
    }
  },

  async markSubtopicViewed(studentId: string, subtopicId: string, status: 'in-progress' | 'completed') {
    const subtopic = await prisma.subtopic.findUnique({
      where: { id: subtopicId },
      include: { topic: { include: { module: true } } },
    })
    if (!subtopic) throw ApiError.notFound('Subtopic not found')
    // The Excel import attaches ONE video to the first subtopic of each topic
    // block; the rest are covered by that video but have no contentType /
    // contentId of their own. They are still real lessons a student can finish,
    // so fall back to a per-subtopic VIDEO progress record (keyed by the
    // subtopic id, so each lesson keeps its own completion state).
    const contentType = subtopic.contentType ?? ContentType.VIDEO
    const contentId = subtopic.contentId ?? subtopic.id

    return learningService.recordProgress({
      studentId,
      courseId: subtopic.topic.module.courseId,
      moduleId: subtopic.topic.moduleId,
      topicId: subtopic.topicId,
      subtopicId: subtopic.id,
      contentType,
      contentId,
      status: status === 'completed' ? ProgressStatus.COMPLETED : ProgressStatus.IN_PROGRESS,
    })
  },
}
