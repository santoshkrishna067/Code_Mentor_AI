import { Router } from 'express'
import { z } from 'zod'
import { learningService } from './learning.service'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole, requireSelfOrAdmin } from '@/middleware/rbac.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok } from '@/utils/apiResponse'
import { Role } from '@prisma/client'

const router = Router()

router.get(
  '/available',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await learningService.available(req.user!.id)))
)

router.get(
  '/courses/:courseId/progress',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await learningService.getCourseProgress(req.user!.id, req.params.courseId)))
)

router.get(
  '/students/:studentId/courses/:courseId/progress',
  requireAuth,
  requireSelfOrAdmin('studentId'),
  asyncHandler(async (req, res) => ok(res, await learningService.getCourseProgress(req.params.studentId, req.params.courseId)))
)

router.post(
  '/subtopics/:subtopicId/view',
  requireAuth,
  requireRole(Role.STUDENT),
  validate({ body: z.object({ status: z.enum(['in-progress', 'completed']) }) }),
  asyncHandler(async (req, res) => {
    const result = await learningService.markSubtopicViewed(req.user!.id, req.params.subtopicId, req.body.status)
    return ok(res, result, 'Progress updated')
  })
)

export default router
