import { z } from 'zod'

export const difficultyEnum = z.enum(['BEGINNER', 'INTERMEDIATE', 'ADVANCED', 'EXPERT'])
export const courseStatusEnum = z.enum(['DRAFT', 'PUBLISHED', 'ARCHIVED'])

export const createCourseSchema = z.object({
  name: z.string().min(2).max(200),
  slug: z
    .string()
    .min(2)
    .max(200)
    .regex(/^[a-z0-9-]+$/, 'slug must be lowercase, alphanumeric, hyphen-separated'),
  description: z.string().min(1),
  thumbnail: z.string().url().optional(),
  difficulty: difficultyEnum,
  estimatedDuration: z.number().int().positive(),
  totalXP: z.number().int().min(0).default(0),
  status: courseStatusEnum.default('DRAFT'),
})

export const updateCourseSchema = createCourseSchema.partial()

export const listCoursesQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  difficulty: difficultyEnum.optional(),
  status: courseStatusEnum.optional(),
  search: z.string().optional(),
})
