import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { CourseStatus, ProgressStatus } from '@prisma/client'

function toCourseDto(course: any) {
  return {
    id: course.id,
    name: course.name,
    slug: course.slug,
    description: course.description,
    thumbnail: course.thumbnail ?? undefined,
    difficulty: course.difficulty,
    estimatedDuration: course.estimatedDuration,
    totalXP: course.totalXP,
    status: course.status,
    enrolledCount: course.enrolledCount,
    averageRating: course.averageRating,
    createdAt: course.createdAt.toISOString(),
    updatedAt: course.updatedAt.toISOString(),
    modules: course.modules?.map((m: any) => toModuleDto(m)) ?? undefined,
  }
}

function toModuleDto(mod: any) {
  return {
    id: mod.id,
    courseId: mod.courseId,
    title: mod.title,
    description: mod.description,
    order: mod.order,
    estimatedDuration: mod.estimatedDuration,
    topics: mod.topics?.map((t: any) => toTopicDto(t)) ?? undefined,
  }
}

function toTopicDto(topic: any, progressBySubtopic?: Map<string, any>) {
  return {
    id: topic.id,
    moduleId: topic.moduleId,
    title: topic.title,
    description: topic.description,
    order: topic.order,
    estimatedDuration: topic.estimatedDuration,
    subtopics: topic.subtopics?.map((s: any) => toSubtopicDto(s, progressBySubtopic)) ?? undefined,
  }
}

function toSubtopicDto(sub: any, progressBySubtopic?: Map<string, any>) {
  const progress = progressBySubtopic?.get(sub.id)
  return {
    id: sub.id,
    topicId: sub.topicId,
    title: sub.title,
    order: sub.order,
    contentType: sub.contentType?.toLowerCase(),
    contentId: sub.contentId ?? undefined,
    estimatedDuration: sub.estimatedDuration,
    isCompleted: progress?.status === ProgressStatus.COMPLETED,
    isLocked: sub.isLocked,
  }
}

const courseTreeInclude = {
  modules: {
    orderBy: { order: 'asc' as const },
    include: {
      topics: {
        orderBy: { order: 'asc' as const },
        include: { subtopics: { orderBy: { order: 'asc' as const } } },
      },
    },
  },
}

export const coursesService = {
  async list(query: { page: number; limit: number; difficulty?: string; status?: string; search?: string }) {
    const where: any = {
      ...(query.difficulty ? { difficulty: query.difficulty } : {}),
      ...(query.status ? { status: query.status } : { status: CourseStatus.PUBLISHED }),
      ...(query.search ? { name: { contains: query.search } } : {}),
    }
    const [total, courses] = await Promise.all([
      prisma.course.count({ where }),
      prisma.course.findMany({
        where,
        skip: (query.page - 1) * query.limit,
        take: query.limit,
        orderBy: { createdAt: 'desc' },
      }),
    ])
    return { data: courses.map((c) => toCourseDto(c)), total }
  },

  async getBySlugOrId(idOrSlug: string, studentId?: string) {
    // MongoDB ObjectId fields reject non-ObjectId strings (e.g. "python-programming")
    // with a "Malformed ObjectID" error, so only search by id when it looks like one.
    const isObjectId = /^[a-f\d]{24}$/i.test(idOrSlug)
    const course = await prisma.course.findFirst({
      where: isObjectId ? { OR: [{ id: idOrSlug }, { slug: idOrSlug }] } : { slug: idOrSlug },
      include: courseTreeInclude,
    })
    if (!course) throw ApiError.notFound('Course not found')

    let progressMap: Map<string, any> | undefined
    if (studentId) {
      const progress = await prisma.progress.findMany({
        where: { studentId, courseId: course.id, subtopicId: { not: null } },
      })
      progressMap = new Map(progress.map((p) => [p.subtopicId as string, p]))
    }

    return {
      ...toCourseDto(course),
      modules: course.modules.map((m) => ({
        ...toModuleDto(m),
        topics: m.topics.map((t) => toTopicDto(t, progressMap)),
      })),
    }
  },

  async create(input: any) {
    const course = await prisma.course.create({ data: input })
    return toCourseDto(course)
  },

  async update(id: string, input: any) {
    const course = await prisma.course.findUnique({ where: { id } })
    if (!course) throw ApiError.notFound('Course not found')
    const updated = await prisma.course.update({ where: { id }, data: input })
    return toCourseDto(updated)
  },

  async remove(id: string) {
    const course = await prisma.course.findUnique({ where: { id } })
    if (!course) throw ApiError.notFound('Course not found')
    // Prevent silent orphaning: block delete if students are enrolled; archive instead.
    const enrollmentCount = await prisma.enrollment.count({ where: { courseId: id } })
    if (enrollmentCount > 0) {
      throw ApiError.conflict(
        `Cannot delete a course with ${enrollmentCount} active enrollment(s). Archive it instead.`
      )
    }
    await prisma.course.delete({ where: { id } })
  },

  async enroll(studentId: string, courseId: string) {
    const course = await prisma.course.findUnique({ where: { id: courseId } })
    if (!course) throw ApiError.notFound('Course not found')
    if (course.status !== CourseStatus.PUBLISHED) throw ApiError.badRequest('Course is not open for enrollment')

    const existing = await prisma.enrollment.findUnique({ where: { studentId_courseId: { studentId, courseId } } })
    if (existing) throw ApiError.conflict('Already enrolled in this course')

    const [enrollment] = await prisma.$transaction([
      prisma.enrollment.create({ data: { studentId, courseId } }),
      prisma.course.update({ where: { id: courseId }, data: { enrolledCount: { increment: 1 } } }),
      prisma.studentProfile.update({ where: { userId: studentId }, data: { currentCourseId: courseId } }),
    ])
    return enrollment
  },

  async myEnrollments(studentId: string) {
    const enrollments = await prisma.enrollment.findMany({
      where: { studentId },
      include: { course: true },
      orderBy: { enrolledAt: 'desc' },
    })
    return enrollments.map((e) => ({
      courseId: e.courseId,
      status: e.status,
      enrolledAt: e.enrolledAt.toISOString(),
      completedAt: e.completedAt?.toISOString(),
      course: toCourseDto(e.course),
    }))
  },
}
