import { Router } from 'express'
import { z } from 'zod'
import { coursesService } from './courses.service'
import { createCourseSchema, updateCourseSchema, listCoursesQuerySchema } from './courses.validation'
import { requireAuth, optionalAuth } from '@/middleware/auth.middleware'
import { requireRole } from '@/middleware/rbac.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok, paginated } from '@/utils/apiResponse'
import { writeAuditLog } from '@/utils/audit'
import { Role } from '@prisma/client'

const router = Router()

router.get(
  '/',
  optionalAuth,
  validate({ query: listCoursesQuerySchema }),
  asyncHandler(async (req, res) => {
    const q = req.query as unknown as z.infer<typeof listCoursesQuerySchema>
    // Admins may pass status=DRAFT/ARCHIVED to manage unpublished content; students always see PUBLISHED only.
    if (q.status && req.user?.role !== Role.ADMIN) delete (q as any).status
    const { data, total } = await coursesService.list(q)
    return paginated(res, data, { page: q.page, limit: q.limit, total })
  })
)

router.get(
  '/my-enrollments',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await coursesService.myEnrollments(req.user!.id)))
)

router.get(
  '/:idOrSlug',
  optionalAuth,
  asyncHandler(async (req, res) => {
    const studentId = req.user?.role === Role.STUDENT ? req.user.id : undefined
    return ok(res, await coursesService.getBySlugOrId(req.params.idOrSlug, studentId))
  })
)

router.post(
  '/',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({ body: createCourseSchema }),
  asyncHandler(async (req, res) => {
    const course = await coursesService.create(req.body)
    await writeAuditLog(req, 'COURSE_CREATED', 'Course', course.id)
    return ok(res, course, 'Course created', 201)
  })
)

router.patch(
  '/:id',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({ body: updateCourseSchema }),
  asyncHandler(async (req, res) => {
    const course = await coursesService.update(req.params.id, req.body)
    await writeAuditLog(req, 'COURSE_UPDATED', 'Course', req.params.id, { fields: Object.keys(req.body) })
    return ok(res, course, 'Course updated')
  })
)

router.delete(
  '/:id',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => {
    await coursesService.remove(req.params.id)
    await writeAuditLog(req, 'COURSE_DELETED', 'Course', req.params.id)
    return ok(res, null, 'Course deleted')
  })
)

router.post(
  '/:id/enroll',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => {
    const enrollment = await coursesService.enroll(req.user!.id, req.params.id)
    await writeAuditLog(req, 'COURSE_ENROLLED', 'Course', req.params.id)
    return ok(res, enrollment, 'Enrolled successfully', 201)
  })
)

export default router
