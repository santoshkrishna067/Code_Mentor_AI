import { Router } from 'express'
import { analyticsService } from './analytics.service'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole, requireSelfOrAdmin } from '@/middleware/rbac.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok } from '@/utils/apiResponse'
import { Role } from '@prisma/client'

const router = Router()

router.get(
  '/me',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await analyticsService.studentOverview(req.user!.id)))
)

router.get(
  '/me/activity',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await analyticsService.activityTimeline(req.user!.id)))
)

router.get(
  '/students/:studentId',
  requireAuth,
  requireSelfOrAdmin('studentId'),
  asyncHandler(async (req, res) => ok(res, await analyticsService.studentOverview(req.params.studentId)))
)

router.get(
  '/courses/:courseId',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => ok(res, await analyticsService.courseOverview(req.params.courseId)))
)

router.get(
  '/platform',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => ok(res, await analyticsService.platformOverview()))
)

export default router
