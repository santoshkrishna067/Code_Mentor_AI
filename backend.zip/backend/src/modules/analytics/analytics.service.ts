import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { ProgressStatus } from '@prisma/client'

// Every number here is computed directly from stored Progress/XPTransaction/
// ExamAttempt rows — nothing is estimated or invented. Part 4 (AI/ML) adds
// predictive fields (risk, completion forecast) on top of this factual base
// and must clearly mark those as estimates with a confidence score, per the
// project's AI requirements — this module intentionally does not do that.
export const analyticsService = {
  async studentOverview(studentId: string) {
    const [progressRows, xpAgg, enrollments, examAttempts, codeSubmissions] = await Promise.all([
      prisma.progress.findMany({ where: { studentId } }),
      prisma.user.findUnique({ where: { id: studentId }, select: { xp: true, currentStreak: true, longestStreak: true } }),
      prisma.enrollment.findMany({ where: { studentId }, include: { course: true } }),
      prisma.examAttempt.findMany({ where: { studentId, status: { in: ['SUBMITTED', 'AUTO_SUBMITTED'] } } }),
      prisma.codeSubmission.findMany({ where: { studentId } }),
    ])

    if (!xpAgg) throw ApiError.notFound('Student not found')

    const completed = progressRows.filter((p) => p.status === ProgressStatus.COMPLETED)
    const scored = progressRows.filter((p) => p.score !== null)
    const averageScore = scored.length ? Math.round(scored.reduce((s, p) => s + (p.score ?? 0), 0) / scored.length) : 0

    // Group scores by course to surface strengths/weaknesses per course.
    const byCourse = new Map<string, { total: number; count: number; courseName: string }>()
    for (const p of scored) {
      const course = enrollments.find((e) => e.courseId === p.courseId)?.course
      const key = p.courseId
      const entry = byCourse.get(key) ?? { total: 0, count: 0, courseName: course?.name ?? key }
      entry.total += p.score ?? 0
      entry.count += 1
      byCourse.set(key, entry)
    }
    const courseBreakdown = [...byCourse.entries()].map(([courseId, v]) => ({
      courseId,
      courseName: v.courseName,
      averageScore: Math.round(v.total / v.count),
      itemsScored: v.count,
    }))
    const strengths = courseBreakdown.filter((c) => c.averageScore >= 75).sort((a, b) => b.averageScore - a.averageScore)
    const weaknesses = courseBreakdown.filter((c) => c.averageScore < 60).sort((a, b) => a.averageScore - b.averageScore)

    const codingAccepted = codeSubmissions.filter((c) => c.status === 'ACCEPTED').length

    return {
      studentId,
      totalXP: xpAgg.xp,
      currentStreak: xpAgg.currentStreak,
      longestStreak: xpAgg.longestStreak,
      enrolledCourseCount: enrollments.length,
      completedCourseCount: enrollments.filter((e) => e.status === ProgressStatus.COMPLETED).length,
      contentItemsCompleted: completed.length,
      averageScore,
      examAttemptCount: examAttempts.length,
      averageExamScore: examAttempts.length
        ? Math.round(examAttempts.reduce((s, a) => s + (a.score ?? 0), 0) / examAttempts.length)
        : 0,
      codingProblemsAttempted: codeSubmissions.length ? new Set(codeSubmissions.map((c) => c.problemId)).size : 0,
      codingProblemsSolved: codingAccepted,
      strengths,
      weaknesses,
    }
  },

  async activityTimeline(studentId: string, days = 30) {
    const since = new Date(Date.now() - days * 86400000)
    since.setHours(0, 0, 0, 0)
    const streakDays = await prisma.streakDay.findMany({
      where: { studentId, date: { gte: since } },
      orderBy: { date: 'asc' },
    })
    return streakDays.map((d) => ({
      date: d.date.toISOString().slice(0, 10),
      xpEarned: d.xpEarned,
      activitiesCompleted: d.activitiesCompleted,
    }))
  },

  // ---------------- Admin/course-wide analytics ----------------

  async courseOverview(courseId: string) {
    const course = await prisma.course.findUnique({ where: { id: courseId } })
    if (!course) throw ApiError.notFound('Course not found')

    const [enrollments, progressRows] = await Promise.all([
      prisma.enrollment.findMany({ where: { courseId } }),
      prisma.progress.findMany({ where: { courseId } }),
    ])

    const completedEnrollments = enrollments.filter((e) => e.status === ProgressStatus.COMPLETED).length
    const scored = progressRows.filter((p) => p.score !== null)
    const averageScore = scored.length ? Math.round(scored.reduce((s, p) => s + (p.score ?? 0), 0) / scored.length) : 0

    return {
      courseId,
      courseName: course.name,
      totalEnrollments: enrollments.length,
      completedEnrollments,
      completionRate: enrollments.length ? Math.round((completedEnrollments / enrollments.length) * 100) : 0,
      averageScore,
    }
  },

  async platformOverview() {
    const [studentCount, courseCount, publishedCourseCount, totalEnrollments, examAttemptCount, pendingEvaluations] =
      await Promise.all([
        prisma.user.count({ where: { role: 'STUDENT' } }),
        prisma.course.count(),
        prisma.course.count({ where: { status: 'PUBLISHED' } }),
        prisma.enrollment.count(),
        prisma.examAttempt.count(),
        prisma.assignmentSubmission.count({ where: { status: 'SUBMITTED' } }),
      ])

    return { studentCount, courseCount, publishedCourseCount, totalEnrollments, examAttemptCount, pendingEvaluations }
  },
}
