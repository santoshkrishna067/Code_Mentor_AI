import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { ContentType, ProgressStatus, SubmissionStatus } from '@prisma/client'
import { learningService } from '@/modules/learning/learning.service'
import { notificationsService } from '@/modules/notifications/notifications.service'

function toSummary(a: any) {
  return {
    id: a.id,
    title: a.title,
    description: a.description,
    instructions: a.instructions,
    dueDate: a.dueDate.toISOString(),
    estimatedDuration: a.estimatedDuration,
    totalMarks: a.totalMarks,
    courseId: a.courseId,
    moduleId: a.moduleId ?? undefined,
    topicId: a.topicId ?? undefined,
    attachments: a.attachments?.map((x: any) => ({ id: x.id, name: x.name, url: x.url, type: x.type, size: x.size })),
    rubric: a.rubric?.map((r: any) => ({ id: r.id, description: r.description, maxMarks: r.maxMarks })),
  }
}

function toSubmissionDto(s: any) {
  return {
    id: s.id,
    assignmentId: s.assignmentId,
    studentId: s.studentId,
    status: s.status.toLowerCase().replace('_', '-'),
    submittedAt: s.submittedAt?.toISOString(),
    files: s.files?.map((f: any) => ({ id: f.id, name: f.name, url: f.url, type: f.type, size: f.size })),
    comments: s.comments ?? undefined,
    marks: s.marks ?? undefined,
    feedback: s.feedback ?? undefined,
    evaluatedAt: s.evaluatedAt?.toISOString(),
    evaluatedBy: s.evaluatedById ?? undefined,
  }
}

export const assignmentsService = {
  async create(courseId: string, input: any) {
    const course = await prisma.course.findUnique({ where: { id: courseId } })
    if (!course) throw ApiError.notFound('Course not found')

    const assignment = await prisma.assignment.create({
      data: {
        courseId,
        moduleId: input.moduleId,
        topicId: input.topicId,
        title: input.title,
        description: input.description,
        instructions: input.instructions ?? [],
        dueDate: new Date(input.dueDate),
        estimatedDuration: input.estimatedDuration,
        totalMarks: input.totalMarks,
        rubric: input.rubric ? { create: input.rubric } : undefined,
      },
      include: { rubric: true, attachments: true },
    })
    return toSummary(assignment)
  },

  async get(assignmentId: string) {
    const assignment = await prisma.assignment.findUnique({
      where: { id: assignmentId },
      include: { rubric: true, attachments: true },
    })
    if (!assignment) throw ApiError.notFound('Assignment not found')
    return toSummary(assignment)
  },

  async startOrGetSubmission(studentId: string, assignmentId: string) {
    const assignment = await prisma.assignment.findUnique({ where: { id: assignmentId } })
    if (!assignment) throw ApiError.notFound('Assignment not found')

    const submission = await prisma.assignmentSubmission.upsert({
      where: { assignmentId_studentId: { assignmentId, studentId } },
      create: { assignmentId, studentId, status: SubmissionStatus.IN_PROGRESS },
      update: {},
      include: { files: true },
    })
    return toSubmissionDto(submission)
  },

  async submit(studentId: string, assignmentId: string, input: { comments?: string; files?: { name: string; url: string; type: string; size: number }[] }) {
    const assignment = await prisma.assignment.findUnique({
      where: { id: assignmentId },
      include: { course: true },
    })
    if (!assignment) throw ApiError.notFound('Assignment not found')

    const submission = await prisma.assignmentSubmission.upsert({
      where: { assignmentId_studentId: { assignmentId, studentId } },
      create: {
        assignmentId,
        studentId,
        status: SubmissionStatus.SUBMITTED,
        submittedAt: new Date(),
        comments: input.comments,
        files: input.files ? { create: input.files } : undefined,
      },
      update: {
        status: SubmissionStatus.SUBMITTED,
        submittedAt: new Date(),
        comments: input.comments,
        files: input.files ? { create: input.files } : undefined,
      },
      include: { files: true },
    })

    await learningService.recordProgress({
      studentId,
      courseId: assignment.courseId,
      moduleId: assignment.moduleId ?? undefined,
      topicId: assignment.topicId ?? undefined,
      contentType: ContentType.ASSIGNMENT,
      contentId: assignment.id,
      status: ProgressStatus.IN_PROGRESS, // completion (XP) happens only once graded — see evaluate()
    })

    return toSubmissionDto(submission)
  },

  async evaluate(evaluatorId: string, submissionId: string, input: { marks: number; feedback: string }) {
    const submission = await prisma.assignmentSubmission.findUnique({
      where: { id: submissionId },
      include: { assignment: true },
    })
    if (!submission) throw ApiError.notFound('Submission not found')
    if (submission.status !== SubmissionStatus.SUBMITTED) {
      throw ApiError.conflict('Only submitted assignments can be evaluated')
    }
    if (input.marks < 0 || input.marks > submission.assignment.totalMarks) {
      throw ApiError.badRequest(`marks must be between 0 and ${submission.assignment.totalMarks}`)
    }

    const updated = await prisma.assignmentSubmission.update({
      where: { id: submissionId },
      data: {
        status: SubmissionStatus.EVALUATED,
        marks: input.marks,
        feedback: input.feedback,
        evaluatedAt: new Date(),
        evaluatedById: evaluatorId,
      },
      include: { files: true, assignment: true },
    })

    const scorePercent = Math.round((input.marks / submission.assignment.totalMarks) * 100)
    const { xpEarned } = await learningService.recordProgress({
      studentId: submission.studentId,
      courseId: submission.assignment.courseId,
      moduleId: submission.assignment.moduleId ?? undefined,
      topicId: submission.assignment.topicId ?? undefined,
      contentType: ContentType.ASSIGNMENT,
      contentId: submission.assignment.id,
      status: ProgressStatus.COMPLETED,
      score: scorePercent,
    })

    await notificationsService.create({
      userId: submission.studentId,
      type: 'INFO',
      title: 'Assignment graded',
      message: `"${submission.assignment.title}" was graded: ${input.marks}/${submission.assignment.totalMarks} (+${xpEarned} XP)`,
    })

    return { ...toSubmissionDto(updated), xpEarned }
  },

  async listSubmissionsForAssignment(assignmentId: string) {
    const submissions = await prisma.assignmentSubmission.findMany({
      where: { assignmentId },
      include: { files: true },
      orderBy: { submittedAt: 'desc' },
    })
    return submissions.map(toSubmissionDto)
  },

  async myAssignments(studentId: string, courseId: string) {
    const assignments = await prisma.assignment.findMany({
      where: { courseId },
      include: {
        submissions: { where: { studentId } },
      },
      orderBy: { dueDate: 'asc' },
    })
    return assignments.map((a) => ({
      ...toSummary(a),
      submission: a.submissions[0] ? toSubmissionDto(a.submissions[0]) : undefined,
    }))
  },
}
