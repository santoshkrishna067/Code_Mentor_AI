import { Router } from 'express'
import { z } from 'zod'
import { assignmentsService } from './assignments.service'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole } from '@/middleware/rbac.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok } from '@/utils/apiResponse'
import { Role } from '@prisma/client'

const router = Router()

const fileSchema = z.object({ name: z.string(), url: z.string().url(), type: z.string(), size: z.number().int().positive() })

router.post(
  '/courses/:courseId',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({
    body: z.object({
      title: z.string().min(1),
      description: z.string().min(1),
      instructions: z.array(z.string()).optional(),
      dueDate: z.string().datetime(),
      estimatedDuration: z.number().int().positive(),
      totalMarks: z.number().int().positive(),
      moduleId: z.string().optional(),
      topicId: z.string().optional(),
      rubric: z.array(z.object({ description: z.string(), maxMarks: z.number().int().positive() })).optional(),
    }),
  }),
  asyncHandler(async (req, res) => ok(res, await assignmentsService.create(req.params.courseId, req.body), 'Assignment created', 201))
)

router.get(
  '/courses/:courseId/mine',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await assignmentsService.myAssignments(req.user!.id, req.params.courseId)))
)

router.get(
  '/:assignmentId',
  requireAuth,
  asyncHandler(async (req, res) => ok(res, await assignmentsService.get(req.params.assignmentId)))
)

router.post(
  '/:assignmentId/start',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await assignmentsService.startOrGetSubmission(req.user!.id, req.params.assignmentId)))
)

router.post(
  '/:assignmentId/submit',
  requireAuth,
  requireRole(Role.STUDENT),
  validate({ body: z.object({ comments: z.string().optional(), files: z.array(fileSchema).optional() }) }),
  asyncHandler(async (req, res) =>
    ok(res, await assignmentsService.submit(req.user!.id, req.params.assignmentId, req.body), 'Assignment submitted')
  )
)

router.get(
  '/:assignmentId/submissions',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => ok(res, await assignmentsService.listSubmissionsForAssignment(req.params.assignmentId)))
)

router.post(
  '/submissions/:submissionId/evaluate',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({ body: z.object({ marks: z.number().int().min(0), feedback: z.string().min(1) }) }),
  asyncHandler(async (req, res) =>
    ok(res, await assignmentsService.evaluate(req.user!.id, req.params.submissionId, req.body), 'Assignment evaluated')
  )
)

export default router
