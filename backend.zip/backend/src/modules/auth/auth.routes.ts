import { Router } from 'express'
import rateLimit from 'express-rate-limit'
import { z } from 'zod'
import { authService } from './auth.service'
import {
  registerSchema,
  loginSchema,
  refreshSchema,
  mfaVerifySchema,
  mfaLoginChallengeSchema,
  changePasswordSchema,
} from './auth.validation'
import { validate } from '@/middleware/validate.middleware'
import { requireAuth } from '@/middleware/auth.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok, ApiError } from '@/utils/apiResponse'
import { env } from '@/config/env'
import { writeAuditLog } from '@/utils/audit'

const router = Router()

const authRateLimiter = rateLimit({
  windowMs: env.AUTH_RATE_LIMIT_WINDOW_MS,
  max: env.AUTH_RATE_LIMIT_MAX,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Too many attempts, please try again later', code: 'TOO_MANY_REQUESTS' },
})

const REFRESH_COOKIE = 'refreshToken'
const isProdLike = env.NODE_ENV === 'production'

function setRefreshCookie(res: any, token: string) {
  res.cookie(REFRESH_COOKIE, token, {
    httpOnly: true,
    secure: isProdLike,
    sameSite: 'lax',
    path: '/api/auth',
    maxAge: 30 * 24 * 60 * 60 * 1000,
  })
}

router.post(
  '/register',
  authRateLimiter,
  validate({ body: registerSchema }),
  asyncHandler(async (req, res) => {
    const result = await authService.register(req.body, { ip: req.ip, ua: req.headers['user-agent'] as string })
    setRefreshCookie(res, result.refreshToken)
    await writeAuditLog(req, 'REGISTER', 'User', result.user.id)
    return ok(res, result, 'Account created', 201)
  })
)

router.post(
  '/login',
  authRateLimiter,
  validate({ body: loginSchema }),
  asyncHandler(async (req, res) => {
    const result = await authService.login(req.body, { ip: req.ip, ua: req.headers['user-agent'] as string })
    if (result.mfaRequired) {
      return ok(res, { mfaRequired: true, challengeToken: result.challengeToken }, 'MFA verification required')
    }
    setRefreshCookie(res, result.refreshToken)
    return ok(res, result, 'Login successful')
  })
)

router.post(
  '/google',
  authRateLimiter,
  validate({ body: z.object({ idToken: z.string().min(10) }) }),
  asyncHandler(async (req, res) => {
    const result = await authService.loginWithGoogle(req.body.idToken, { ip: req.ip, ua: req.headers['user-agent'] as string })
    if (result.mfaRequired) {
      return ok(res, { mfaRequired: true, challengeToken: result.challengeToken }, 'MFA verification required')
    }
    setRefreshCookie(res, result.refreshToken)
    await writeAuditLog(req, 'LOGIN_GOOGLE', 'User', result.user.id)
    return ok(res, result, 'Login successful')
  })
)

router.post(
  '/login/mfa',
  authRateLimiter,
  validate({ body: mfaLoginChallengeSchema }),
  asyncHandler(async (req, res) => {
    const result = await authService.completeMfaLogin(req.body.challengeToken, req.body.code, {
      ip: req.ip,
      ua: req.headers['user-agent'] as string,
    })
    setRefreshCookie(res, result.refreshToken)
    return ok(res, result, 'Login successful')
  })
)

router.post(
  '/refresh',
  validate({ body: refreshSchema }),
  asyncHandler(async (req, res) => {
    const token = req.body.refreshToken || req.cookies?.[REFRESH_COOKIE]
    if (!token) throw ApiError.unauthorized('No refresh token provided')
    const result = await authService.refresh(token, { ip: req.ip, ua: req.headers['user-agent'] as string })
    setRefreshCookie(res, result.refreshToken)
    return ok(res, result, 'Token refreshed')
  })
)

router.post(
  '/logout',
  asyncHandler(async (req, res) => {
    const token = req.body?.refreshToken || req.cookies?.[REFRESH_COOKIE]
    await authService.logout(token)
    res.clearCookie(REFRESH_COOKIE, { path: '/api/auth' })
    return ok(res, null, 'Logged out')
  })
)

router.post(
  '/logout-all',
  requireAuth,
  asyncHandler(async (req, res) => {
    await authService.logoutAllDevices(req.user!.id)
    res.clearCookie(REFRESH_COOKIE, { path: '/api/auth' })
    return ok(res, null, 'Logged out of all devices')
  })
)

router.get(
  '/me',
  requireAuth,
  asyncHandler(async (req, res) => {
    const user = await authService.me(req.user!.id)
    return ok(res, user)
  })
)

router.post(
  '/change-password',
  requireAuth,
  validate({ body: changePasswordSchema }),
  asyncHandler(async (req, res) => {
    await authService.changePassword(req.user!.id, req.body.currentPassword, req.body.newPassword)
    await writeAuditLog(req, 'CHANGE_PASSWORD', 'User', req.user!.id)
    return ok(res, null, 'Password changed. Please log in again on other devices.')
  })
)

// ---------------- MFA ----------------

router.post(
  '/mfa/setup',
  requireAuth,
  asyncHandler(async (req, res) => {
    const result = await authService.startMfaSetup(req.user!.id)
    return ok(res, result, 'Scan the QR code with your authenticator app, then confirm with /mfa/enable')
  })
)

router.post(
  '/mfa/enable',
  requireAuth,
  authRateLimiter,
  validate({ body: mfaVerifySchema }),
  asyncHandler(async (req, res) => {
    const result = await authService.confirmMfaEnable(req.user!.id, req.body.token)
    await writeAuditLog(req, 'MFA_ENABLED', 'User', req.user!.id)
    return ok(res, result, 'MFA enabled. Store these backup codes securely — they will not be shown again.')
  })
)

router.post(
  '/mfa/disable',
  requireAuth,
  authRateLimiter,
  validate({ body: z.object({ currentPassword: z.string().min(1), token: z.string().length(6) }) }),
  asyncHandler(async (req, res) => {
    await authService.disableMfa(req.user!.id, req.body.currentPassword, req.body.token)
    await writeAuditLog(req, 'MFA_DISABLED', 'User', req.user!.id)
    return ok(res, null, 'MFA disabled')
  })
)

export default router
