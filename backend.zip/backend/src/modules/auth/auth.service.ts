import { v4 as uuid } from 'uuid'
import { prisma } from '@/config/prisma'
import { Role } from '@prisma/client'
import { ApiError } from '@/utils/apiResponse'
import { hashPassword, verifyPassword, sha256, generateBackupCodes } from '@/utils/password'
import {
  signAccessToken,
  signRefreshToken,
  verifyRefreshToken,
  signMfaChallengeToken,
  verifyMfaChallengeToken,
} from '@/utils/jwt'
import { encryptSecret, decryptSecret, generateTotpSecret, verifyTotpToken, buildOtpAuthQrCode } from '@/utils/mfa'
import { env } from '@/config/env'

const REFRESH_TTL_MS = 30 * 24 * 60 * 60 * 1000 // fallback; JWT lib parses env.JWT_REFRESH_TTL for the token itself

function publicUser(user: {
  id: string
  email: string
  name: string
  avatar: string | null
  role: Role
  xp: number
  currentStreak: number
  createdAt: Date
  lastActiveAt: Date | null
  mfaEnabled: boolean
}) {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    avatar: user.avatar ?? undefined,
    role: user.role.toLowerCase() as 'student' | 'admin',
    xp: user.xp,
    streak: user.currentStreak,
    createdAt: user.createdAt.toISOString(),
    lastActiveAt: (user.lastActiveAt ?? user.createdAt).toISOString(),
    mfaEnabled: user.mfaEnabled,
  }
}

async function issueTokenPair(userId: string, role: Role, mfaVerified: boolean, meta: { ip?: string; ua?: string }) {
  const accessToken = signAccessToken({ sub: userId, role, mfaVerified })

  const jti = uuid()
  const refreshToken = signRefreshToken({ sub: userId, jti })
  await prisma.refreshToken.create({
    data: {
      id: jti,
      userId,
      tokenHash: sha256(refreshToken),
      expiresAt: new Date(Date.now() + REFRESH_TTL_MS),
      ip: meta.ip,
      userAgent: meta.ua,
    },
  })

  return { accessToken, refreshToken }
}

// Verifies a Google Identity Services ID token with Google's tokeninfo
// endpoint and checks it was issued for OUR client id.
async function verifyGoogleIdToken(idToken: string): Promise<{ email: string; name: string; picture?: string }> {
  const clientId = process.env.GOOGLE_CLIENT_ID
  if (!clientId) throw ApiError.badRequest('Google sign-in is not configured on this server (GOOGLE_CLIENT_ID is missing).')

  let res: Response
  try {
    res = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(idToken)}`)
  } catch {
    throw ApiError.internal('Could not reach Google to verify the sign-in. Check your internet connection.')
  }
  if (!res.ok) throw ApiError.unauthorized('Google sign-in could not be verified')

  const info = (await res.json()) as { aud?: string; email?: string; email_verified?: string | boolean; name?: string; picture?: string }
  if (info.aud !== clientId) throw ApiError.unauthorized('Google sign-in was issued for a different application')
  if (!info.email || String(info.email_verified) !== 'true') throw ApiError.unauthorized('Your Google email is not verified')
  return { email: info.email.toLowerCase(), name: info.name || info.email.split('@')[0], picture: info.picture }
}

export const authService = {
  async loginWithGoogle(idToken: string, meta: { ip?: string; ua?: string }) {
    const profile = await verifyGoogleIdToken(idToken)

    let user = await prisma.user.findUnique({ where: { email: profile.email } })
    if (!user) {
      // First Google sign-in creates a STUDENT account. The random password
      // is never shown or used; the person can set a real one via "Forgot password".
      user = await prisma.user.create({
        data: {
          email: profile.email,
          passwordHash: await hashPassword(uuid() + uuid()),
          name: profile.name,
          avatar: profile.picture,
          role: Role.STUDENT,
          emailVerifiedAt: new Date(),
          studentProfile: { create: {} },
        },
      })
    }
    if (!user.isActive) throw ApiError.forbidden('This account has been deactivated')

    // Accounts with MFA enabled must still complete the second factor.
    if (user.mfaEnabled) return { mfaRequired: true as const, challengeToken: signMfaChallengeToken(user.id) }

    const tokens = await issueTokenPair(user.id, user.role, true, meta)
    await prisma.user.update({ where: { id: user.id }, data: { lastActiveAt: new Date() } })
    await prisma.securityEvent.create({ data: { type: 'LOGIN', userId: user.id, ipAddress: meta.ip, details: { via: 'google' } } })
    return { mfaRequired: false as const, user: publicUser(user), ...tokens }
  },

  async register(input: { email: string; password: string; name: string }, meta: { ip?: string; ua?: string }) {
    const existing = await prisma.user.findUnique({ where: { email: input.email.toLowerCase() } })
    if (existing) throw ApiError.conflict('An account with this email already exists')

    const passwordHash = await hashPassword(input.password)

    const user = await prisma.user.create({
      data: {
        email: input.email.toLowerCase(),
        passwordHash,
        name: input.name,
        role: Role.STUDENT,
        studentProfile: { create: {} },
      },
    })

    const tokens = await issueTokenPair(user.id, user.role, true, meta)
    return { user: publicUser(user), ...tokens }
  },

  async login(input: { email: string; password: string; mfaCode?: string }, meta: { ip?: string; ua?: string }) {
    const user = await prisma.user.findUnique({ where: { email: input.email.toLowerCase() } })

    // Constant-shape response whether the email exists or not, to avoid
    // leaking account existence via timing/response differences.
    const passwordOk = user ? await verifyPassword(user.passwordHash, input.password) : false
    if (!user || !passwordOk) {
      await prisma.securityEvent.create({
        data: { type: 'FAILED_LOGIN', userId: user?.id, ipAddress: meta.ip, details: { email: input.email } },
      })
      throw ApiError.unauthorized('Invalid email or password')
    }
    if (!user.isActive) throw ApiError.forbidden('This account has been deactivated')

    if (user.mfaEnabled) {
      // Do not issue access/refresh tokens yet. Caller must complete /auth/login/mfa.
      const challengeToken = signMfaChallengeToken(user.id)
      return { mfaRequired: true as const, challengeToken }
    }

    const tokens = await issueTokenPair(user.id, user.role, true, meta)
    await prisma.user.update({ where: { id: user.id }, data: { lastActiveAt: new Date() } })
    await prisma.securityEvent.create({ data: { type: 'LOGIN', userId: user.id, ipAddress: meta.ip } })

    return { mfaRequired: false as const, user: publicUser(user), ...tokens }
  },

  async completeMfaLogin(challengeToken: string, code: string, meta: { ip?: string; ua?: string }) {
    let payload
    try {
      payload = verifyMfaChallengeToken(challengeToken)
    } catch {
      throw ApiError.unauthorized('MFA challenge expired or invalid, please log in again')
    }

    const user = await prisma.user.findUnique({ where: { id: payload.sub } })
    if (!user || !user.mfaEnabled || !user.mfaSecret) throw ApiError.unauthorized('MFA is not configured')

    const secret = decryptSecret(user.mfaSecret)
    const isValidTotp = verifyTotpToken(secret, code)

    let usedBackupCode = false
    if (!isValidTotp) {
      const backupCodes = ((user.mfaBackupCodes as string[] | null) ?? []).slice()
      const hashedInput = sha256(code)
      const idx = backupCodes.indexOf(hashedInput)
      if (idx === -1) {
        await prisma.securityEvent.create({
          data: { type: 'MFA', userId: user.id, ipAddress: meta.ip, details: { result: 'failed_code' } },
        })
        throw ApiError.unauthorized('Invalid MFA code')
      }
      // Backup codes are single-use — remove after use.
      backupCodes.splice(idx, 1)
      await prisma.user.update({ where: { id: user.id }, data: { mfaBackupCodes: backupCodes } })
      usedBackupCode = true
    }

    const tokens = await issueTokenPair(user.id, user.role, true, meta)
    await prisma.user.update({ where: { id: user.id }, data: { lastActiveAt: new Date() } })
    await prisma.securityEvent.create({
      data: { type: 'MFA', userId: user.id, ipAddress: meta.ip, details: { result: 'success', usedBackupCode } },
    })

    return { user: publicUser(user), ...tokens }
  },

  async refresh(refreshTokenRaw: string, meta: { ip?: string; ua?: string }) {
    let payload
    try {
      payload = verifyRefreshToken(refreshTokenRaw)
    } catch {
      throw ApiError.unauthorized('Invalid or expired refresh token')
    }

    const stored = await prisma.refreshToken.findUnique({ where: { id: payload.jti } })
    if (!stored || stored.revokedAt || stored.tokenHash !== sha256(refreshTokenRaw) || stored.expiresAt < new Date()) {
      throw ApiError.unauthorized('Refresh token is no longer valid')
    }

    const user = await prisma.user.findUnique({ where: { id: payload.sub } })
    if (!user || !user.isActive) throw ApiError.unauthorized('Account is inactive')

    // Rotate: revoke the used refresh token, issue a brand new pair.
    await prisma.refreshToken.update({ where: { id: stored.id }, data: { revokedAt: new Date() } })
    const tokens = await issueTokenPair(user.id, user.role, true, meta)

    return { user: publicUser(user), ...tokens }
  },

  async logout(refreshTokenRaw: string | undefined) {
    if (!refreshTokenRaw) return
    try {
      const payload = verifyRefreshToken(refreshTokenRaw)
      await prisma.refreshToken.updateMany({
        where: { id: payload.jti, revokedAt: null },
        data: { revokedAt: new Date() },
      })
    } catch {
      // Already invalid/expired — nothing to revoke, treat logout as successful anyway.
    }
  },

  async logoutAllDevices(userId: string) {
    await prisma.refreshToken.updateMany({ where: { userId, revokedAt: null }, data: { revokedAt: new Date() } })
  },

  async me(userId: string) {
    const user = await prisma.user.findUnique({ where: { id: userId } })
    if (!user) throw ApiError.notFound('User not found')
    return publicUser(user)
  },

  // ---------------- MFA setup/enable/disable ----------------

  async startMfaSetup(userId: string) {
    const user = await prisma.user.findUnique({ where: { id: userId } })
    if (!user) throw ApiError.notFound('User not found')
    if (user.mfaEnabled) throw ApiError.conflict('MFA is already enabled')

    const secret = generateTotpSecret()
    await prisma.user.update({ where: { id: userId }, data: { mfaSecret: encryptSecret(secret) } })
    const qrCodeDataUrl = await buildOtpAuthQrCode(user.email, secret)

    return { secret, qrCodeDataUrl, issuer: env.MFA_ISSUER }
  },

  async confirmMfaEnable(userId: string, token: string) {
    const user = await prisma.user.findUnique({ where: { id: userId } })
    if (!user?.mfaSecret) throw ApiError.badRequest('MFA setup has not been started')
    if (user.mfaEnabled) throw ApiError.conflict('MFA is already enabled')

    const secret = decryptSecret(user.mfaSecret)
    if (!verifyTotpToken(secret, token)) throw ApiError.badRequest('Invalid verification code')

    const backupCodesPlain = generateBackupCodes(10)
    const backupCodesHashed = backupCodesPlain.map(sha256)

    await prisma.user.update({
      where: { id: userId },
      data: { mfaEnabled: true, mfaBackupCodes: backupCodesHashed },
    })

    // Backup codes are returned exactly once, in plaintext, at enable time.
    return { backupCodes: backupCodesPlain }
  },

  async disableMfa(userId: string, currentPassword: string, totpToken: string) {
    const user = await prisma.user.findUnique({ where: { id: userId } })
    if (!user) throw ApiError.notFound('User not found')
    if (!user.mfaEnabled || !user.mfaSecret) throw ApiError.conflict('MFA is not enabled')

    const passwordOk = await verifyPassword(user.passwordHash, currentPassword)
    if (!passwordOk) throw ApiError.unauthorized('Incorrect password')

    const secret = decryptSecret(user.mfaSecret)
    if (!verifyTotpToken(secret, totpToken)) throw ApiError.badRequest('Invalid verification code')

    await prisma.user.update({
      where: { id: userId },
      data: { mfaEnabled: false, mfaSecret: null, mfaBackupCodes: undefined },
    })
    await authService.logoutAllDevices(userId) // disabling MFA invalidates existing sessions
  },

  async changePassword(userId: string, currentPassword: string, newPassword: string) {
    const user = await prisma.user.findUnique({ where: { id: userId } })
    if (!user) throw ApiError.notFound('User not found')

    const ok = await verifyPassword(user.passwordHash, currentPassword)
    if (!ok) throw ApiError.unauthorized('Current password is incorrect')

    const passwordHash = await hashPassword(newPassword)
    await prisma.user.update({ where: { id: userId }, data: { passwordHash } })
    await authService.logoutAllDevices(userId)
  },
}
