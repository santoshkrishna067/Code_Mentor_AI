import { prisma } from '@/config/prisma'
import { Role } from '@prisma/client'
import { ApiError } from '@/utils/apiResponse'
import { hashPassword } from '@/utils/password'

function toStudentDto(user: any) {
  return {
    id: user.id,
    email: user.email,
    name: user.name,
    avatar: user.avatar ?? undefined,
    role: 'student',
    xp: user.xp,
    streak: user.currentStreak,
    createdAt: user.createdAt.toISOString(),
    lastActiveAt: (user.lastActiveAt ?? user.createdAt).toISOString(),
    isActive: user.isActive,
    mfaEnabled: user.mfaEnabled,
    enrolledCourses: user.studentProfile?.enrollments?.map((e: any) => e.courseId) ?? [],
    completedCourses:
      user.studentProfile?.enrollments?.filter((e: any) => e.status === 'COMPLETED').map((e: any) => e.courseId) ??
      [],
    currentCourseId: user.studentProfile?.currentCourseId ?? undefined,
    badges: user.studentProfile?.badges?.map((b: any) => ({
      id: b.badge.id,
      name: b.badge.name,
      description: b.badge.description,
      icon: b.badge.icon,
      requirement: b.badge.requirement,
      xpBonus: b.badge.xpBonus,
      earnedAt: b.earnedAt.toISOString(),
    })) ?? [],
  }
}

export const usersService = {
  async getMyProfile(userId: string) {
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        studentProfile: {
          include: { enrollments: true, badges: { include: { badge: true } } },
        },
      },
    })
    if (!user) throw ApiError.notFound('User not found')
    if (user.role === Role.STUDENT) return toStudentDto(user)
    const { passwordHash, mfaSecret, mfaBackupCodes, ...safeUser } = user
    return safeUser
  },

  async updateMyProfile(userId: string, input: { name?: string; avatar?: string }) {
    const user = await prisma.user.update({ where: { id: userId }, data: input })
    return { id: user.id, name: user.name, avatar: user.avatar ?? undefined }
  },

  async listStudents(query: { page: number; limit: number; search?: string }) {
    const where = {
      role: Role.STUDENT,
      ...(query.search
        ? { OR: [{ name: { contains: query.search } }, { email: { contains: query.search } }] }
        : {}),
    }
    const [total, users] = await Promise.all([
      prisma.user.count({ where }),
      prisma.user.findMany({
        where,
        skip: (query.page - 1) * query.limit,
        take: query.limit,
        orderBy: { createdAt: 'desc' },
        include: { studentProfile: { include: { enrollments: true, badges: { include: { badge: true } } } } },
      }),
    ])
    return { data: users.map(toStudentDto), total }
  },

  async getStudentById(studentId: string) {
    const user = await prisma.user.findUnique({
      where: { id: studentId, role: Role.STUDENT },
      include: { studentProfile: { include: { enrollments: true, badges: { include: { badge: true } } } } },
    })
    if (!user) throw ApiError.notFound('Student not found')
    return toStudentDto(user)
  },

  async setStudentActive(studentId: string, isActive: boolean) {
    const user = await prisma.user.update({ where: { id: studentId, role: Role.STUDENT }, data: { isActive } })
    return toStudentDto(user)
  },

  async createAdmin(input: { email: string; password: string; name: string; permissions?: string[] }) {
    const existing = await prisma.user.findUnique({ where: { email: input.email.toLowerCase() } })
    if (existing) throw ApiError.conflict('An account with this email already exists')

    const passwordHash = await hashPassword(input.password)
    const user = await prisma.user.create({
      data: {
        email: input.email.toLowerCase(),
        passwordHash,
        name: input.name,
        role: Role.ADMIN,
        adminProfile: { create: { permissions: input.permissions ?? [] } },
      },
      include: { adminProfile: true },
    })
    return { id: user.id, email: user.email, name: user.name, permissions: user.adminProfile?.permissions }
  },

  async listAdmins() {
    const admins = await prisma.user.findMany({ where: { role: Role.ADMIN }, include: { adminProfile: true } })
    return admins.map((a) => ({
      id: a.id,
      email: a.email,
      name: a.name,
      isActive: a.isActive,
      permissions: a.adminProfile?.permissions,
      createdAt: a.createdAt.toISOString(),
    }))
  },
}
