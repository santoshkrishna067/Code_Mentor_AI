import { Router } from 'express'
import { z } from 'zod'
import { usersService } from './users.service'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole, requireSelfOrAdmin } from '@/middleware/rbac.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok, paginated } from '@/utils/apiResponse'
import { writeAuditLog } from '@/utils/audit'
import { Role } from '@prisma/client'

const router = Router()

router.get(
  '/me',
  requireAuth,
  asyncHandler(async (req, res) => ok(res, await usersService.getMyProfile(req.user!.id)))
)

router.patch(
  '/me',
  requireAuth,
  validate({ body: z.object({ name: z.string().min(2).max(100).optional(), avatar: z.string().url().optional() }) }),
  asyncHandler(async (req, res) => ok(res, await usersService.updateMyProfile(req.user!.id, req.body), 'Profile updated'))
)

// ---------------- Admin: student management ----------------

const listQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  search: z.string().optional(),
})

router.get(
  '/students',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({ query: listQuerySchema }),
  asyncHandler(async (req, res) => {
    const { page, limit, search } = req.query as unknown as z.infer<typeof listQuerySchema>
    const { data, total } = await usersService.listStudents({ page, limit, search })
    return paginated(res, data, { page, limit, total })
  })
)

router.get(
  '/students/:studentId',
  requireAuth,
  requireSelfOrAdmin('studentId'),
  asyncHandler(async (req, res) => ok(res, await usersService.getStudentById(req.params.studentId)))
)

router.patch(
  '/students/:studentId/active',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({ body: z.object({ isActive: z.boolean() }) }),
  asyncHandler(async (req, res) => {
    const result = await usersService.setStudentActive(req.params.studentId, req.body.isActive)
    await writeAuditLog(req, req.body.isActive ? 'STUDENT_REACTIVATED' : 'STUDENT_DEACTIVATED', 'User', req.params.studentId)
    return ok(res, result, 'Student status updated')
  })
)

// ---------------- Admin: admin management ----------------

router.get(
  '/admins',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => ok(res, await usersService.listAdmins()))
)

router.post(
  '/admins',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({
    body: z.object({
      email: z.string().email(),
      password: z.string().min(8),
      name: z.string().min(2),
      permissions: z.array(z.string()).optional(),
    }),
  }),
  asyncHandler(async (req, res) => {
    const result = await usersService.createAdmin(req.body)
    await writeAuditLog(req, 'ADMIN_CREATED', 'User', result.id)
    return ok(res, result, 'Admin created', 201)
  })
)

export default router
