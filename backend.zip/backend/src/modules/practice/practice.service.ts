import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { ContentType, ProgressStatus } from '@prisma/client'
import { gradeSubmission, SubmittedAnswer } from '@/utils/grading'
import { sanitizeQuestionForAttempt, fullQuestionDto } from '@/utils/questionSanitizer'
import { learningService } from '@/modules/learning/learning.service'

function toPracticeSummary(p: any) {
  return {
    id: p.id,
    title: p.title,
    description: p.description,
    difficulty: p.difficulty,
    estimatedDuration: p.estimatedDuration,
    passingScore: p.passingScore,
    subtopicId: p.subtopicId,
  }
}

export const practiceService = {
  async create(subtopicId: string, input: { title: string; description: string; difficulty: string; estimatedDuration: number; passingScore: number; questionIds: string[] }) {
    const subtopic = await prisma.subtopic.findUnique({ where: { id: subtopicId } })
    if (!subtopic) throw ApiError.notFound('Subtopic not found')
    if (input.questionIds.length === 0) throw ApiError.badRequest('At least one question is required')

    const foundCount = await prisma.question.count({ where: { id: { in: input.questionIds } } })
    if (foundCount !== input.questionIds.length) throw ApiError.badRequest('One or more questionIds do not exist')

    const practice = await prisma.practice.create({
      data: {
        subtopicId,
        title: input.title,
        description: input.description,
        difficulty: input.difficulty as any,
        estimatedDuration: input.estimatedDuration,
        passingScore: input.passingScore,
        questions: { create: input.questionIds.map((questionId, order) => ({ questionId, order })) },
      },
    })
    return toPracticeSummary(practice)
  },

  // Questions served WITHOUT correct answers.
  async getForAttempt(practiceId: string) {
    const practice = await prisma.practice.findUnique({
      where: { id: practiceId },
      include: { questions: { orderBy: { order: 'asc' }, include: { question: { include: { options: true } } } } },
    })
    if (!practice) throw ApiError.notFound('Practice not found')
    return {
      ...toPracticeSummary(practice),
      questions: practice.questions.map((pq) => sanitizeQuestionForAttempt(pq.question)),
    }
  },

  async submit(studentId: string, practiceId: string, answers: SubmittedAnswer[]) {
    const practice = await prisma.practice.findUnique({
      where: { id: practiceId },
      include: {
        questions: { include: { question: true } },
        subtopic: { include: { topic: { include: { module: true } } } },
      },
    })
    if (!practice) throw ApiError.notFound('Practice not found')

    const questions = practice.questions.map((pq) => ({
      id: pq.question.id,
      correctAnswer: pq.question.correctAnswer,
      marks: pq.question.marks,
      negativeMarks: pq.question.negativeMarks,
    }))

    const result = gradeSubmission(questions, answers, false) // practice sets never apply negative marking

    const passed = result.scorePercent >= practice.passingScore

    const { xpEarned } = await learningService.recordProgress({
      studentId,
      courseId: practice.subtopic.topic.module.courseId,
      moduleId: practice.subtopic.topic.moduleId,
      topicId: practice.subtopic.topicId,
      subtopicId: practice.subtopicId,
      contentType: ContentType.PRACTICE,
      contentId: practice.id,
      status: passed ? ProgressStatus.COMPLETED : ProgressStatus.IN_PROGRESS,
      score: result.scorePercent,
    })

    // Practice is for learning, so after submitting the student gets the answer key
    // and the admin's explanation for every question (never sent before submitting).
    const perQuestion = new Map(result.perQuestion.map((p) => [p.questionId, p.isCorrect]))
    const review = practice.questions.map((pq) => ({
      questionId: pq.question.id,
      isCorrect: perQuestion.get(pq.question.id) ?? false,
      correctAnswer: pq.question.correctAnswer,
      explanation: pq.question.explanation ?? undefined,
    }))

    return { ...result, passed, xpEarned, review }
  },

  async review(practiceId: string) {
    const practice = await prisma.practice.findUnique({
      where: { id: practiceId },
      include: { questions: { orderBy: { order: 'asc' }, include: { question: { include: { options: true } } } } },
    })
    if (!practice) throw ApiError.notFound('Practice not found')
    return { ...toPracticeSummary(practice), questions: practice.questions.map((pq) => fullQuestionDto(pq.question)) }
  },
}
