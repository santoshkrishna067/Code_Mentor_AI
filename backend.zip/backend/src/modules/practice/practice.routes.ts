import { Router } from 'express'
import { z } from 'zod'
import { practiceService } from './practice.service'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole } from '@/middleware/rbac.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok } from '@/utils/apiResponse'
import { Role } from '@prisma/client'

const router = Router()

const answerSchema = z.object({
  questionId: z.string(),
  answer: z.union([z.string(), z.array(z.string())]),
})

router.post(
  '/subtopics/:subtopicId',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({
    body: z.object({
      title: z.string().min(1),
      description: z.string().min(1),
      difficulty: z.enum(['BEGINNER', 'INTERMEDIATE', 'ADVANCED', 'EXPERT']),
      estimatedDuration: z.number().int().positive(),
      passingScore: z.number().int().min(0).max(100),
      questionIds: z.array(z.string()).min(1),
    }),
  }),
  asyncHandler(async (req, res) => ok(res, await practiceService.create(req.params.subtopicId, req.body), 'Practice created', 201))
)

router.get(
  '/:practiceId/attempt',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await practiceService.getForAttempt(req.params.practiceId)))
)

router.post(
  '/:practiceId/submit',
  requireAuth,
  requireRole(Role.STUDENT),
  validate({ body: z.object({ answers: z.array(answerSchema) }) }),
  asyncHandler(async (req, res) => ok(res, await practiceService.submit(req.user!.id, req.params.practiceId, req.body.answers), 'Submitted'))
)

router.get(
  '/:practiceId/review',
  requireAuth,
  asyncHandler(async (req, res) => ok(res, await practiceService.review(req.params.practiceId)))
)

export default router
