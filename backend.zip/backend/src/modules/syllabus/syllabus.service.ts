import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { ContentType } from '@prisma/client'

function toVideoDto(video: any) {
  return {
    id: video.id,
    title: video.title,
    description: video.description ?? undefined,
    url: video.languages?.[0]?.url ?? '',
    duration: video.duration,
    languages: video.languages?.map((l: any) => ({ code: l.code, label: l.label, url: l.url })) ?? [],
    order: video.order,
    subtopicId: video.primarySubtopicId,
  }
}

function toNotesDto(notes: any) {
  return {
    id: notes.id,
    title: notes.title,
    content: notes.content,
    subtopicId: notes.subtopicId,
    order: notes.order,
    highlights: notes.highlights ?? undefined,
    commonMistakes: notes.commonMistakes ?? undefined,
    interviewPoints: notes.interviewPoints ?? undefined,
    examPoints: notes.examPoints ?? undefined,
    examples: (notes.examples ?? []).map((e: any) => ({
      id: e.id,
      title: e.title,
      code: e.code,
      language: e.language,
      output: e.output ?? undefined,
      explanation: e.explanation ?? undefined,
    })),
  }
}

export const syllabusService = {
  async createModule(courseId: string, input: { title: string; description: string; order: number; estimatedDuration: number }) {
    const course = await prisma.course.findUnique({ where: { id: courseId } })
    if (!course) throw ApiError.notFound('Course not found')
    return prisma.courseModule.create({ data: { ...input, courseId } })
  },

  async updateModule(moduleId: string, input: Partial<{ title: string; description: string; order: number; estimatedDuration: number }>) {
    const mod = await prisma.courseModule.findUnique({ where: { id: moduleId } })
    if (!mod) throw ApiError.notFound('Module not found')
    return prisma.courseModule.update({ where: { id: moduleId }, data: input })
  },

  async deleteModule(moduleId: string) {
    const mod = await prisma.courseModule.findUnique({ where: { id: moduleId }, include: { topics: true } })
    if (!mod) throw ApiError.notFound('Module not found')
    if (mod.topics.length > 0) {
      throw ApiError.conflict(`Cannot delete a module with ${mod.topics.length} topic(s). Remove topics first.`)
    }
    await prisma.courseModule.delete({ where: { id: moduleId } })
  },

  async createTopic(moduleId: string, input: { title: string; description: string; order: number; estimatedDuration: number }) {
    const mod = await prisma.courseModule.findUnique({ where: { id: moduleId } })
    if (!mod) throw ApiError.notFound('Module not found')
    return prisma.topic.create({ data: { ...input, moduleId } })
  },

  async getTopicDetail(topicId: string) {
    const topic = await prisma.topic.findUnique({
      where: { id: topicId },
      include: { subtopics: { orderBy: { order: 'asc' } } },
    })
    if (!topic) throw ApiError.notFound('Topic not found')
    return topic
  },

  async updateTopic(topicId: string, input: Partial<{ title: string; description: string; order: number; estimatedDuration: number }>) {
    const topic = await prisma.topic.findUnique({ where: { id: topicId } })
    if (!topic) throw ApiError.notFound('Topic not found')
    return prisma.topic.update({ where: { id: topicId }, data: input })
  },

  async deleteTopic(topicId: string) {
    const topic = await prisma.topic.findUnique({ where: { id: topicId }, include: { subtopics: true } })
    if (!topic) throw ApiError.notFound('Topic not found')
    if (topic.subtopics.length > 0) {
      throw ApiError.conflict(`Cannot delete a topic with ${topic.subtopics.length} subtopic(s). Remove subtopics first.`)
    }
    await prisma.topic.delete({ where: { id: topicId } })
  },

  async createSubtopic(topicId: string, input: { title: string; order: number; estimatedDuration?: number }) {
    const topic = await prisma.topic.findUnique({ where: { id: topicId } })
    if (!topic) throw ApiError.notFound('Topic not found')
    return prisma.subtopic.create({ data: { ...input, topicId } })
  },

  // Full learning-page payload for one subtopic: video + notes + practice refs.
  //
  // FIX: the source Excel data attaches ONE video to a whole TOPIC's worth of
  // subtopics (often 5-15 of them), not one video per subtopic. The importer
  // correctly records this via VideoSubtopicCoverage for every subtopic in
  // that group, but only sets `videosPrimary` (a Video's designated single
  // "flat" subtopicId, kept for the frontend's simple contract) on the FIRST
  // subtopic in the group. Every other subtopic under that topic previously
  // showed "no video attached" even though the topic's real video covers it.
  // This now checks BOTH: a subtopic's own primary video, and — if it has
  // none — any video whose coverage set includes it.
  async getSubtopicContent(subtopicId: string) {
    const subtopic = await prisma.subtopic.findUnique({
      where: { id: subtopicId },
      include: {
        videosPrimary: { include: { languages: true } },
        videoCoverage: { include: { video: { include: { languages: true } } } },
        notes: { include: { examples: true }, orderBy: { order: 'asc' } },
        // A practice set with no questions left must not be offered to students.
        practices: { where: { questions: { some: {} } } },
        quizzes: true,
        resources: { orderBy: { createdAt: 'asc' } },
        topic: { include: { module: { include: { course: true } } } },
      },
    })
    if (!subtopic) throw ApiError.notFound('Subtopic not found')

    // Merge primary videos with covered videos, de-duplicated by video id —
    // a subtopic that IS the primary for its video would otherwise show up twice.
    const videoMap = new Map<string, any>()
    for (const v of subtopic.videosPrimary) videoMap.set(v.id, v)
    for (const coverage of subtopic.videoCoverage) videoMap.set(coverage.video.id, coverage.video)
    const videos = [...videoMap.values()]

    return {
      subtopic: {
        id: subtopic.id,
        topicId: subtopic.topicId,
        title: subtopic.title,
        order: subtopic.order,
        contentType: subtopic.contentType?.toLowerCase(),
        contentId: subtopic.contentId ?? undefined,
        estimatedDuration: subtopic.estimatedDuration,
        isLocked: subtopic.isLocked,
      },
      breadcrumb: {
        courseId: subtopic.topic.module.course.id,
        courseName: subtopic.topic.module.course.name,
        moduleId: subtopic.topic.module.id,
        moduleTitle: subtopic.topic.module.title,
        topicId: subtopic.topic.id,
        topicTitle: subtopic.topic.title,
      },
      videos: videos.map(toVideoDto),
      notes: subtopic.notes.map(toNotesDto),
      practiceIds: subtopic.practices.map((p) => p.id),
      resources: subtopic.resources.map((r) => ({ id: r.id, title: r.title, url: r.url, kind: r.kind })),
      quizIds: subtopic.quizzes.map((q) => q.id),
    }
  },

  async attachVideo(
    subtopicId: string,
    input: { title: string; description?: string; duration: number; order?: number; languages: { code: string; label: string; url: string }[] }
  ) {
    const subtopic = await prisma.subtopic.findUnique({ where: { id: subtopicId } })
    if (!subtopic) throw ApiError.notFound('Subtopic not found')
    if (!input.languages?.length) throw ApiError.badRequest('At least one language track is required')

    const video = await prisma.video.create({
      data: {
        title: input.title,
        description: input.description,
        duration: input.duration,
        order: input.order ?? 0,
        primarySubtopicId: subtopicId,
        languages: { create: input.languages },
        coverage: { create: { subtopicId } },
      },
      include: { languages: true },
    })

    await prisma.subtopic.update({
      where: { id: subtopicId },
      data: { contentType: ContentType.VIDEO, contentId: video.id },
    })

    return toVideoDto(video)
  },

  async attachNotes(
    subtopicId: string,
    input: {
      title: string
      content: string
      order?: number
      highlights?: string[]
      commonMistakes?: string[]
      interviewPoints?: string[]
      examPoints?: string[]
    }
  ) {
    const subtopic = await prisma.subtopic.findUnique({ where: { id: subtopicId } })
    if (!subtopic) throw ApiError.notFound('Subtopic not found')

    const notes = await prisma.notes.create({ data: { ...input, subtopicId } })

    if (!subtopic.contentType) {
      await prisma.subtopic.update({
        where: { id: subtopicId },
        data: { contentType: ContentType.NOTES, contentId: notes.id },
      })
    }

    return toNotesDto(notes)
  },

  // ---------------------------------------------------------------------
  // ADMIN CONTENT MANAGER
  // Videos are NEVER uploaded: we only store links (YouTube etc.), so the
  // database stays tiny. "Replace" swaps the links on the existing record.
  // ---------------------------------------------------------------------

  // Videos that cover a lesson (its own primary video and/or a shared topic video).
  async videosForSubtopic(subtopicId: string) {
    const [primary, covered] = await Promise.all([
      prisma.video.findMany({ where: { primarySubtopicId: subtopicId }, include: { languages: true, coverage: true } }),
      prisma.videoSubtopicCoverage.findMany({
        where: { subtopicId },
        include: { video: { include: { languages: true, coverage: true } } },
      }),
    ])
    const map = new Map<string, any>()
    for (const v of primary) map.set(v.id, v)
    for (const c of covered) map.set(c.video.id, c.video)
    return [...map.values()]
  },

  // scope "topic": change the shared video for every lesson it covers.
  // scope "lesson": give just this lesson its own video (the shared one is untouched for the others).
  async replaceVideo(
    subtopicId: string,
    input: { title?: string; scope: 'topic' | 'lesson'; languages: { code: string; label: string; url: string }[] }
  ) {
    const subtopic = await prisma.subtopic.findUnique({ where: { id: subtopicId }, include: { topic: true } })
    if (!subtopic) throw ApiError.notFound('Lesson not found')
    if (!input.languages.length) throw ApiError.badRequest('Add at least one video link')

    const existing = await syllabusService.videosForSubtopic(subtopicId)
    const title = input.title || existing[0]?.title || subtopic.topic.title

    if (input.scope === 'topic' && existing.length > 0) {
      const target = existing[0]
      await prisma.videoLanguageTrack.deleteMany({ where: { videoId: target.id } })
      await prisma.videoLanguageTrack.createMany({ data: input.languages.map((l) => ({ ...l, videoId: target.id })) })
      await prisma.video.update({ where: { id: target.id }, data: { title } })
      // a lesson may be covered by several videos (rare) - keep only the replaced one
      for (const extra of existing.slice(1)) {
        await prisma.videoSubtopicCoverage.deleteMany({ where: { videoId: extra.id, subtopicId } })
      }
      return { replaced: true, lessonsAffected: Math.max(1, target.coverage?.length ?? 1) }
    }

    // lesson scope (or no video yet): detach from old videos, create a fresh one for this lesson only
    for (const v of existing) {
      await prisma.videoSubtopicCoverage.deleteMany({ where: { videoId: v.id, subtopicId } })
      const remaining = await prisma.videoSubtopicCoverage.count({ where: { videoId: v.id } })
      if (remaining === 0) await prisma.video.delete({ where: { id: v.id } }) // nothing uses it any more
      else if (v.primarySubtopicId === subtopicId) {
        const next = await prisma.videoSubtopicCoverage.findFirst({ where: { videoId: v.id } })
        if (next) await prisma.video.update({ where: { id: v.id }, data: { primarySubtopicId: next.subtopicId } })
      }
    }
    const video = await prisma.video.create({
      data: {
        title,
        duration: 0,
        order: 0,
        primarySubtopicId: subtopicId,
        sourceTopicId: subtopic.topicId,
        languages: { create: input.languages },
        coverage: { create: { subtopicId } },
      },
    })
    await prisma.subtopic.update({ where: { id: subtopicId }, data: { contentType: ContentType.VIDEO, contentId: video.id } })
    return { replaced: true, lessonsAffected: 1 }
  },

  async removeVideo(subtopicId: string) {
    const existing = await syllabusService.videosForSubtopic(subtopicId)
    for (const v of existing) {
      await prisma.videoSubtopicCoverage.deleteMany({ where: { videoId: v.id, subtopicId } })
      const remaining = await prisma.videoSubtopicCoverage.count({ where: { videoId: v.id } })
      if (remaining === 0) await prisma.video.delete({ where: { id: v.id } })
    }
  },

  // Create the lesson's notes or replace them in place (examples are replaced too).
  async upsertNotes(
    subtopicId: string,
    input: {
      title: string
      content: string
      highlights?: string[]
      commonMistakes?: string[]
      interviewPoints?: string[]
      examPoints?: string[]
      examples?: { title: string; language: string; code: string; output?: string; explanation?: string }[]
    }
  ) {
    const subtopic = await prisma.subtopic.findUnique({ where: { id: subtopicId } })
    if (!subtopic) throw ApiError.notFound('Lesson not found')
    const { examples, ...fields } = input
    const existing = await prisma.notes.findFirst({ where: { subtopicId }, orderBy: { order: 'asc' } })
    const notes = existing
      ? await prisma.notes.update({ where: { id: existing.id }, data: fields })
      : await prisma.notes.create({ data: { ...fields, subtopicId, order: 0 } })
    if (examples) {
      await prisma.example.deleteMany({ where: { notesId: notes.id } })
      if (examples.length) {
        await prisma.example.createMany({
          data: examples.filter((e) => e.code.trim()).map((e) => ({ ...e, notesId: notes.id })),
        })
      }
    }
    return toNotesDto(await prisma.notes.findUnique({ where: { id: notes.id }, include: { examples: true } }))
  },

  async deleteNotes(subtopicId: string) {
    await prisma.notes.deleteMany({ where: { subtopicId } })
  },

  async addResource(subtopicId: string, input: { title: string; url: string; kind?: string }) {
    const subtopic = await prisma.subtopic.findUnique({ where: { id: subtopicId } })
    if (!subtopic) throw ApiError.notFound('Lesson not found')
    return prisma.lessonResource.create({ data: { subtopicId, title: input.title, url: input.url, kind: input.kind ?? 'link' } })
  },

  async deleteResource(resourceId: string) {
    await prisma.lessonResource.deleteMany({ where: { id: resourceId } })
  },
}
