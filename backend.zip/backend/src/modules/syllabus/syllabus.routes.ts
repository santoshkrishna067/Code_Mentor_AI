import { Router } from 'express'
import { z } from 'zod'
import { syllabusService } from './syllabus.service'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole } from '@/middleware/rbac.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok } from '@/utils/apiResponse'
import { writeAuditLog } from '@/utils/audit'
import { Role } from '@prisma/client'

const router = Router()

const orderedNodeSchema = z.object({
  title: z.string().min(1),
  description: z.string().min(1),
  order: z.number().int().min(0),
  estimatedDuration: z.number().int().min(0),
})

// ---------------- Modules ----------------

router.post(
  '/courses/:courseId/modules',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({ body: orderedNodeSchema }),
  asyncHandler(async (req, res) => {
    const mod = await syllabusService.createModule(req.params.courseId, req.body)
    await writeAuditLog(req, 'MODULE_CREATED', 'CourseModule', mod.id)
    return ok(res, mod, 'Module created', 201)
  })
)

router.patch(
  '/modules/:moduleId',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({ body: orderedNodeSchema.partial() }),
  asyncHandler(async (req, res) => ok(res, await syllabusService.updateModule(req.params.moduleId, req.body), 'Module updated'))
)

router.delete(
  '/modules/:moduleId',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => {
    await syllabusService.deleteModule(req.params.moduleId)
    await writeAuditLog(req, 'MODULE_DELETED', 'CourseModule', req.params.moduleId)
    return ok(res, null, 'Module deleted')
  })
)

// ---------------- Topics ----------------

router.post(
  '/modules/:moduleId/topics',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({ body: orderedNodeSchema }),
  asyncHandler(async (req, res) => {
    const topic = await syllabusService.createTopic(req.params.moduleId, req.body)
    await writeAuditLog(req, 'TOPIC_CREATED', 'Topic', topic.id)
    return ok(res, topic, 'Topic created', 201)
  })
)

router.get(
  '/topics/:topicId',
  requireAuth,
  asyncHandler(async (req, res) => ok(res, await syllabusService.getTopicDetail(req.params.topicId)))
)

router.patch(
  '/topics/:topicId',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({ body: orderedNodeSchema.partial() }),
  asyncHandler(async (req, res) => ok(res, await syllabusService.updateTopic(req.params.topicId, req.body), 'Topic updated'))
)

router.delete(
  '/topics/:topicId',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => {
    await syllabusService.deleteTopic(req.params.topicId)
    await writeAuditLog(req, 'TOPIC_DELETED', 'Topic', req.params.topicId)
    return ok(res, null, 'Topic deleted')
  })
)

// ---------------- Subtopics ----------------

router.post(
  '/topics/:topicId/subtopics',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({ body: z.object({ title: z.string().min(1), order: z.number().int().min(0), estimatedDuration: z.number().int().min(0).default(0) }) }),
  asyncHandler(async (req, res) => {
    const sub = await syllabusService.createSubtopic(req.params.topicId, req.body)
    await writeAuditLog(req, 'SUBTOPIC_CREATED', 'Subtopic', sub.id)
    return ok(res, sub, 'Subtopic created', 201)
  })
)

router.get(
  '/subtopics/:subtopicId/content',
  requireAuth,
  asyncHandler(async (req, res) => ok(res, await syllabusService.getSubtopicContent(req.params.subtopicId)))
)

router.post(
  '/subtopics/:subtopicId/video',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({
    body: z.object({
      title: z.string().min(1),
      description: z.string().optional(),
      duration: z.number().int().min(0),
      order: z.number().int().min(0).optional(),
      languages: z
        .array(z.object({ code: z.enum(['en', 'hi']), label: z.string().min(1), url: z.string().url() }))
        .min(1),
    }),
  }),
  asyncHandler(async (req, res) => {
    const video = await syllabusService.attachVideo(req.params.subtopicId, req.body)
    await writeAuditLog(req, 'VIDEO_ATTACHED', 'Subtopic', req.params.subtopicId)
    return ok(res, video, 'Video attached', 201)
  })
)

router.post(
  '/subtopics/:subtopicId/notes',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({
    body: z.object({
      title: z.string().min(1),
      content: z.string().min(1),
      order: z.number().int().min(0).optional(),
      highlights: z.array(z.string()).optional(),
      commonMistakes: z.array(z.string()).optional(),
      interviewPoints: z.array(z.string()).optional(),
      examPoints: z.array(z.string()).optional(),
    }),
  }),
  asyncHandler(async (req, res) => {
    const notes = await syllabusService.attachNotes(req.params.subtopicId, req.body)
    await writeAuditLog(req, 'NOTES_ATTACHED', 'Subtopic', req.params.subtopicId)
    return ok(res, notes, 'Notes attached', 201)
  })
)

// ---------------- Admin content manager (replace in place) ----------------

// Only links are stored - never video files - so the free MongoDB stays tiny.
const videoLinkSchema = z.object({
  code: z.enum(['en', 'hi']),
  label: z.string().min(1),
  url: z.string().url().refine((u) => /^https?:\/\//i.test(u), 'Link must start with http:// or https://'),
})

router.put(
  '/subtopics/:subtopicId/video',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({
    body: z.object({
      title: z.string().optional(),
      scope: z.enum(['topic', 'lesson']).default('topic'),
      languages: z.array(videoLinkSchema).min(1),
    }),
  }),
  asyncHandler(async (req, res) => {
    const result = await syllabusService.replaceVideo(req.params.subtopicId, req.body)
    await writeAuditLog(req, 'VIDEO_REPLACED', 'Subtopic', req.params.subtopicId)
    return ok(res, result, 'Video replaced')
  })
)

router.delete(
  '/subtopics/:subtopicId/video',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => {
    await syllabusService.removeVideo(req.params.subtopicId)
    await writeAuditLog(req, 'VIDEO_REMOVED', 'Subtopic', req.params.subtopicId)
    return ok(res, null, 'Video removed from this lesson')
  })
)

router.put(
  '/subtopics/:subtopicId/notes',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({
    body: z.object({
      title: z.string().min(1),
      content: z.string().min(1),
      highlights: z.array(z.string()).optional(),
      commonMistakes: z.array(z.string()).optional(),
      interviewPoints: z.array(z.string()).optional(),
      examPoints: z.array(z.string()).optional(),
      examples: z
        .array(z.object({ title: z.string().min(1), language: z.string().min(1), code: z.string(), output: z.string().optional(), explanation: z.string().optional() }))
        .optional(),
    }),
  }),
  asyncHandler(async (req, res) => {
    const notes = await syllabusService.upsertNotes(req.params.subtopicId, req.body)
    await writeAuditLog(req, 'NOTES_SAVED', 'Subtopic', req.params.subtopicId)
    return ok(res, notes, 'Notes saved')
  })
)

router.delete(
  '/subtopics/:subtopicId/notes',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => {
    await syllabusService.deleteNotes(req.params.subtopicId)
    await writeAuditLog(req, 'NOTES_DELETED', 'Subtopic', req.params.subtopicId)
    return ok(res, null, 'Notes deleted')
  })
)

router.post(
  '/subtopics/:subtopicId/resources',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({
    body: z.object({
      title: z.string().min(1),
      url: z.string().url(),
      kind: z.enum(['link', 'pdf', 'slides', 'article', 'code', 'video']).optional(),
    }),
  }),
  asyncHandler(async (req, res) => ok(res, await syllabusService.addResource(req.params.subtopicId, req.body), 'Resource added', 201))
)

router.delete(
  '/resources/:resourceId',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => {
    await syllabusService.deleteResource(req.params.resourceId)
    return ok(res, null, 'Resource removed')
  })
)

export default router
