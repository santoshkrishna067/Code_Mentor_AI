import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { ContentType, ProgressStatus } from '@prisma/client'
import { gradeSubmission, shuffle, SubmittedAnswer } from '@/utils/grading'
import { sanitizeQuestionForAttempt, fullQuestionDto } from '@/utils/questionSanitizer'
import { learningService } from '@/modules/learning/learning.service'

function toSummary(a: any) {
  return {
    id: a.id,
    title: a.title,
    type: a.type.toLowerCase(),
    description: a.description,
    difficulty: a.difficulty,
    duration: a.duration,
    passingScore: a.passingScore,
    totalMarks: a.totalMarks,
    courseId: a.courseId,
    moduleId: a.moduleId ?? undefined,
    topicId: a.topicId ?? undefined,
  }
}

export const assessmentsService = {
  async create(courseId: string, input: any) {
    const course = await prisma.course.findUnique({ where: { id: courseId } })
    if (!course) throw ApiError.notFound('Course not found')
    const foundCount = await prisma.question.count({ where: { id: { in: input.questionIds } } })
    if (foundCount !== input.questionIds.length) throw ApiError.badRequest('One or more questionIds do not exist')

    const assessment = await prisma.assessment.create({
      data: {
        courseId,
        moduleId: input.moduleId,
        topicId: input.topicId,
        title: input.title,
        type: input.type,
        description: input.description,
        difficulty: input.difficulty,
        duration: input.duration,
        passingScore: input.passingScore,
        totalMarks: input.totalMarks,
        questions: { create: input.questionIds.map((questionId: string, order: number) => ({ questionId, order })) },
      },
    })
    return toSummary(assessment)
  },

  async getForAttempt(assessmentId: string) {
    const assessment = await prisma.assessment.findUnique({
      where: { id: assessmentId },
      include: { questions: { orderBy: { order: 'asc' }, include: { question: { include: { options: true } } } } },
    })
    if (!assessment) throw ApiError.notFound('Assessment not found')
    const questions = shuffle(assessment.questions.map((aq) => sanitizeQuestionForAttempt(aq.question)))
    return { ...toSummary(assessment), questions }
  },

  async submit(studentId: string, assessmentId: string, answers: SubmittedAnswer[]) {
    const assessment = await prisma.assessment.findUnique({
      where: { id: assessmentId },
      include: { questions: { include: { question: true } } },
    })
    if (!assessment) throw ApiError.notFound('Assessment not found')

    const questions = assessment.questions.map((aq) => ({
      id: aq.question.id,
      correctAnswer: aq.question.correctAnswer,
      marks: aq.question.marks,
      negativeMarks: aq.question.negativeMarks,
    }))
    const result = gradeSubmission(questions, answers, false)
    const passed = result.scorePercent >= assessment.passingScore

    const { xpEarned } = await learningService.recordProgress({
      studentId,
      courseId: assessment.courseId,
      moduleId: assessment.moduleId ?? undefined,
      topicId: assessment.topicId ?? undefined,
      contentType: ContentType.ASSESSMENT,
      contentId: assessment.id,
      status: passed ? ProgressStatus.COMPLETED : ProgressStatus.IN_PROGRESS,
      score: result.scorePercent,
    })

    return { ...result, passed, xpEarned }
  },

  async review(assessmentId: string) {
    const assessment = await prisma.assessment.findUnique({
      where: { id: assessmentId },
      include: { questions: { orderBy: { order: 'asc' }, include: { question: { include: { options: true } } } } },
    })
    if (!assessment) throw ApiError.notFound('Assessment not found')
    return { ...toSummary(assessment), questions: assessment.questions.map((aq) => fullQuestionDto(aq.question)) }
  },
}
