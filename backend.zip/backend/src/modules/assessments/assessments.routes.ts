import { Router } from 'express'
import { z } from 'zod'
import { assessmentsService } from './assessments.service'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole } from '@/middleware/rbac.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok } from '@/utils/apiResponse'
import { Role } from '@prisma/client'

const router = Router()

const answerSchema = z.object({ questionId: z.string(), answer: z.union([z.string(), z.array(z.string())]) })

const createSchema = z.object({
  title: z.string().min(1),
  type: z.enum(['DIAGNOSTIC', 'TOPIC', 'MODULE', 'COURSE', 'FINAL']),
  description: z.string().min(1),
  difficulty: z.enum(['BEGINNER', 'INTERMEDIATE', 'ADVANCED', 'EXPERT']),
  duration: z.number().int().positive(),
  passingScore: z.number().int().min(0).max(100),
  totalMarks: z.number().int().positive(),
  moduleId: z.string().optional(),
  topicId: z.string().optional(),
  questionIds: z.array(z.string()).min(1),
})

router.post(
  '/courses/:courseId',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({ body: createSchema }),
  asyncHandler(async (req, res) => ok(res, await assessmentsService.create(req.params.courseId, req.body), 'Assessment created', 201))
)

router.get(
  '/:assessmentId/attempt',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await assessmentsService.getForAttempt(req.params.assessmentId)))
)

router.post(
  '/:assessmentId/submit',
  requireAuth,
  requireRole(Role.STUDENT),
  validate({ body: z.object({ answers: z.array(answerSchema) }) }),
  asyncHandler(async (req, res) =>
    ok(res, await assessmentsService.submit(req.user!.id, req.params.assessmentId, req.body.answers), 'Submitted')
  )
)

router.get(
  '/:assessmentId/review',
  requireAuth,
  asyncHandler(async (req, res) => ok(res, await assessmentsService.review(req.params.assessmentId)))
)

export default router
