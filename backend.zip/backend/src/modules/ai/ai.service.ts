import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { predictPerformance } from './predictors/performance.predictor'
import { predictCompletion } from './predictors/completion.predictor'
import { predictRisk } from './predictors/risk.predictor'
import { analyzeEngagement } from './predictors/engagement.analyzer'

function todayDateOnly(): Date {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  return d
}

export const aiInsightsService = {
  // Understands the full Student -> Course -> Module -> Topic -> Progress ->
  // Performance -> LearningGap chain: every predictor call below is scoped
  // to this specific student+course, and the gap/topic breakdown is pulled
  // from the same real Progress/LearningGap rows the rest of the platform
  // uses — this is not a separate shadow data source.
  async getStudentCourseInsights(studentId: string, courseId: string) {
    const enrollment = await prisma.enrollment.findUnique({ where: { studentId_courseId: { studentId, courseId } } })
    if (!enrollment) throw ApiError.notFound('Student is not enrolled in this course')

    const [performance, completion, risk, engagement, openGaps, topicBreakdown] = await Promise.all([
      predictPerformance(studentId, courseId),
      predictCompletion(studentId, courseId),
      predictRisk(studentId, courseId),
      analyzeEngagement(studentId),
      prisma.learningGap.findMany({ where: { studentId, courseId, resolvedAt: null }, include: { topic: true } }),
      prisma.progress.groupBy({
        by: ['topicId'],
        where: { studentId, courseId, score: { not: null }, topicId: { not: null } },
        _avg: { score: true },
        _count: { _all: true },
      }),
    ])

    const topicIds = topicBreakdown.map((t) => t.topicId).filter((id): id is string => !!id)
    const topics = await prisma.topic.findMany({ where: { id: { in: topicIds } } })
    const topicNameById = new Map(topics.map((t) => [t.id, t.title]))

    const snapshot = {
      studentId,
      courseId,
      generatedAt: new Date().toISOString(),
      hierarchy: {
        performanceByTopic: topicBreakdown.map((t) => ({
          topicId: t.topicId,
          topicName: t.topicId ? topicNameById.get(t.topicId) : undefined,
          averageScore: t._avg.score !== null ? Math.round(t._avg.score) : null,
          attemptCount: t._count._all,
        })),
        openLearningGaps: openGaps.map((g) => ({
          id: g.id,
          topicId: g.topicId ?? undefined,
          topicName: g.topic?.title,
          concept: g.concept,
          severity: g.severity.toLowerCase(),
          gapScore: g.gapScore,
          detectionSource: g.detectionSource,
          confidence: g.confidence ?? undefined,
        })),
      },
      predictions: { performance, completion, risk, engagement },
    }

    // Cache once per day — real predictions computed from live data, just
    // avoiding recomputation on every dashboard load within the same day.
    await prisma.analyticsSnapshot.upsert({
      where: { studentId_date: { studentId, date: todayDateOnly() } },
      create: { studentId, date: todayDateOnly(), payload: snapshot as any },
      update: { payload: snapshot as any },
    })

    return snapshot
  },

  async getCachedSnapshot(studentId: string) {
    const snapshot = await prisma.analyticsSnapshot.findUnique({
      where: { studentId_date: { studentId, date: todayDateOnly() } },
    })
    return snapshot?.payload ?? null
  },

  // Admin view: risk-ranked list across all students in a course, for
  // instructor triage. Reuses the same predictor — no separate scoring logic.
  async courseRiskRanking(courseId: string) {
    const enrollments = await prisma.enrollment.findMany({ where: { courseId }, include: { student: { include: { user: true } } } })

    const results = []
    for (const e of enrollments) {
      const risk = await predictRisk(e.studentId, courseId)
      results.push({
        studentId: e.studentId,
        studentName: e.student.user.name,
        risk: risk.insufficientData
          ? { riskLevel: 'unknown' as const, riskScore: null, confidence: null, reason: risk.reason }
          : { riskLevel: risk.value!.riskLevel, riskScore: risk.value!.riskScore, confidence: risk.confidence },
      })
    }

    return results.sort((a, b) => (b.risk.riskScore ?? -1) - (a.risk.riskScore ?? -1))
  },
}
