// Small, dependency-free statistics toolkit used by every predictor in this
// module. Nothing here fabricates a number: every function operates on real
// arrays of observed data points and returns null/insufficient when there
// isn't enough data to say anything meaningful.

export interface Point {
  x: number
  y: number
}

export interface LinearRegressionResult {
  slope: number
  intercept: number
  rSquared: number // 0-1, goodness of fit — used to scale confidence
  n: number
}

// Ordinary least squares. Requires at least 2 distinct x values.
export function linearRegression(points: Point[]): LinearRegressionResult | null {
  const n = points.length
  if (n < 2) return null

  const xs = points.map((p) => p.x)
  const ys = points.map((p) => p.y)
  const xMean = mean(xs)
  const yMean = mean(ys)

  let numerator = 0
  let denominator = 0
  for (let i = 0; i < n; i++) {
    numerator += (xs[i] - xMean) * (ys[i] - yMean)
    denominator += (xs[i] - xMean) ** 2
  }
  if (denominator === 0) return null // all x values identical — no trend can be fit

  const slope = numerator / denominator
  const intercept = yMean - slope * xMean

  // R²
  let ssRes = 0
  let ssTot = 0
  for (let i = 0; i < n; i++) {
    const predicted = slope * xs[i] + intercept
    ssRes += (ys[i] - predicted) ** 2
    ssTot += (ys[i] - yMean) ** 2
  }
  const rSquared = ssTot === 0 ? 1 : Math.max(0, 1 - ssRes / ssTot)

  return { slope, intercept, rSquared, n }
}

export function mean(values: number[]): number {
  if (values.length === 0) return 0
  return values.reduce((a, b) => a + b, 0) / values.length
}

export function stdDev(values: number[]): number {
  if (values.length < 2) return 0
  const m = mean(values)
  const variance = mean(values.map((v) => (v - m) ** 2))
  return Math.sqrt(variance)
}

// Coefficient of variation — used as a consistency measure (lower = more
// consistent pace/behavior). Returns null when mean is 0 (undefined ratio).
export function coefficientOfVariation(values: number[]): number | null {
  const m = mean(values)
  if (m === 0) return null
  return stdDev(values) / m
}

// Confidence heuristic shared across predictors: scales with both sample
// size (more observations = more trustworthy) and fit quality (rSquared,
// when available). Always documented, always capped at 0.95 — a statistical
// model should never claim certainty.
export function confidenceFromSampleAndFit(n: number, rSquared?: number, maxN = 20): number {
  const sizeComponent = Math.min(1, n / maxN)
  const fitComponent = rSquared === undefined ? 1 : Math.max(0.2, rSquared) // a bad fit still gets some credit for the sample size itself
  return Math.round(Math.min(0.95, sizeComponent * fitComponent) * 100) / 100
}

export function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value))
}
