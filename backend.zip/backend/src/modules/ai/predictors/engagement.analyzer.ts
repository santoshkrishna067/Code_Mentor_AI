import { prisma } from '@/config/prisma'
import { mean, clamp } from './stats'
import { Estimate, insufficientDataEstimate } from './estimate'

const RECENT_WINDOW_DAYS = 7
const PRIOR_WINDOW_DAYS = 14 // the 7 days before the recent window

export interface EngagementAnalysis {
  activeDaysLast30: number
  activityRateLast30: number // 0-1, activeDaysLast30 / 30
  recentAvgActivitiesPerDay: number
  priorAvgActivitiesPerDay: number
  trend: 'increasing' | 'decreasing' | 'stable' | 'inactive'
  currentStreak: number
  engagementScore: number // 0-100 composite, documented weighting below
}

// Composite score = 50% recent activity rate + 30% streak health + 20% trend
// direction. Weights are fixed constants, stated here rather than hidden in
// a black box, so the score can be audited or retuned.
const WEIGHT_ACTIVITY_RATE = 0.5
const WEIGHT_STREAK = 0.3
const WEIGHT_TREND = 0.2

export async function analyzeEngagement(studentId: string): Promise<Estimate<EngagementAnalysis>> {
  const method = 'activity-frequency + XP-velocity composite (fixed weights: 50% recent rate, 30% streak, 20% trend)'

  const [user, streakDays] = await Promise.all([
    prisma.user.findUnique({ where: { id: studentId }, select: { currentStreak: true, createdAt: true } }),
    prisma.streakDay.findMany({
      where: { studentId, date: { gte: new Date(Date.now() - 30 * 86400000) } },
      orderBy: { date: 'asc' },
    }),
  ])

  if (!user) return insufficientDataEstimate(method, 0, 'Student not found.')

  const accountAgeDays = Math.max(1, Math.round((Date.now() - user.createdAt.getTime()) / 86400000))
  if (accountAgeDays < 3) {
    return insufficientDataEstimate(method, streakDays.length, 'Account is less than 3 days old; not enough history to analyze engagement.')
  }

  const now = Date.now()
  const recentDays = streakDays.filter((d) => now - d.date.getTime() <= RECENT_WINDOW_DAYS * 86400000)
  const priorDays = streakDays.filter((d) => {
    const age = now - d.date.getTime()
    return age > RECENT_WINDOW_DAYS * 86400000 && age <= (RECENT_WINDOW_DAYS + PRIOR_WINDOW_DAYS) * 86400000
  })

  const recentAvg = mean(recentDays.map((d) => d.activitiesCompleted))
  const priorAvg = mean(priorDays.map((d) => d.activitiesCompleted))

  let trend: EngagementAnalysis['trend'] = 'stable'
  if (recentDays.length === 0) trend = 'inactive'
  else if (priorDays.length === 0) trend = recentAvg > 0 ? 'increasing' : 'inactive' // no baseline to compare against, but there's recent activity
  else if (recentAvg > priorAvg * 1.15) trend = 'increasing'
  else if (recentAvg < priorAvg * 0.85) trend = 'decreasing'

  const activityRateLast30 = streakDays.length / 30
  const streakHealth = clamp(user.currentStreak / 14, 0, 1) // a 14-day streak maxes out this component
  const trendComponent = trend === 'increasing' ? 1 : trend === 'stable' ? 0.6 : trend === 'decreasing' ? 0.3 : 0

  const engagementScore = Math.round(
    clamp(activityRateLast30 * WEIGHT_ACTIVITY_RATE + streakHealth * WEIGHT_STREAK + trendComponent * WEIGHT_TREND, 0, 1) * 100
  )

  return {
    isEstimate: true,
    value: {
      activeDaysLast30: streakDays.length,
      activityRateLast30: Math.round(activityRateLast30 * 100) / 100,
      recentAvgActivitiesPerDay: Math.round(recentAvg * 100) / 100,
      priorAvgActivitiesPerDay: Math.round(priorAvg * 100) / 100,
      trend,
      currentStreak: user.currentStreak,
      engagementScore,
    },
    confidence: Math.round(clamp(0.4 + streakDays.length / 30, 0.4, 0.9) * 100) / 100,
    method,
    sampleSize: streakDays.length,
    insufficientData: false,
  }
}
