import { prisma } from '@/config/prisma'
import { linearRegression, confidenceFromSampleAndFit, clamp } from './stats'
import { Estimate, insufficientDataEstimate } from './estimate'

const MIN_POINTS = 4 // fewer than this and a regression line is more noise than signal

export interface PerformancePrediction {
  currentAverage: number
  predictedNextScore: number
  trend: 'improving' | 'declining' | 'stable'
  trendSlope: number // score-points change per attempt
}

// Fits a straight line through the student's scored attempts (in the order
// they occurred) for one course and extrapolates one step forward. This is
// intentionally simple and auditable — a real production system would
// likely swap in a proper time-series model, which is exactly why this
// lives behind the same Estimate<T> contract as every other predictor here.
export async function predictPerformance(studentId: string, courseId: string): Promise<Estimate<PerformancePrediction>> {
  const method = 'linear-regression-least-squares (score vs. attempt sequence)'

  const scoredProgress = await prisma.progress.findMany({
    where: { studentId, courseId, score: { not: null } },
    orderBy: { completedAt: 'asc' },
    select: { score: true, completedAt: true, startedAt: true },
  })

  if (scoredProgress.length < MIN_POINTS) {
    return insufficientDataEstimate(
      method,
      scoredProgress.length,
      `Need at least ${MIN_POINTS} scored attempts to fit a trend; only ${scoredProgress.length} available.`
    )
  }

  const points = scoredProgress.map((p, i) => ({ x: i, y: p.score as number }))
  const fit = linearRegression(points)
  if (!fit) {
    return insufficientDataEstimate(method, scoredProgress.length, 'All attempts had identical timing; no trend could be fit.')
  }

  const currentAverage = points.reduce((s, p) => s + p.y, 0) / points.length
  const predictedNextScore = clamp(fit.slope * points.length + fit.intercept, 0, 100)
  const trend: PerformancePrediction['trend'] = fit.slope > 1 ? 'improving' : fit.slope < -1 ? 'declining' : 'stable'

  return {
    isEstimate: true,
    value: { currentAverage: Math.round(currentAverage), predictedNextScore: Math.round(predictedNextScore), trend, trendSlope: Math.round(fit.slope * 100) / 100 },
    confidence: confidenceFromSampleAndFit(fit.n, fit.rSquared),
    method,
    sampleSize: fit.n,
    insufficientData: false,
  }
}
