// Every prediction returned by this module must be shaped like this. There
// is no variant that omits `isEstimate`/`confidence`/`method` — a caller
// (API route, frontend, admin dashboard) can never accidentally render a raw
// number without also seeing how it was derived and how much to trust it.
export interface Estimate<T> {
  isEstimate: true
  value: T | null // null when there isn't enough data to estimate at all
  confidence: number | null // 0-1; null exactly when value is null
  method: string // human-readable description of the algorithm used
  sampleSize: number
  insufficientData: boolean
  reason?: string // populated when insufficientData is true, or to explain a low-confidence result
}

export function insufficientDataEstimate<T>(method: string, sampleSize: number, reason: string): Estimate<T> {
  return { isEstimate: true, value: null, confidence: null, method, sampleSize, insufficientData: true, reason }
}
