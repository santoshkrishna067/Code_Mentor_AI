import { prisma } from '@/config/prisma'
import { ProgressStatus } from '@prisma/client'
import { coefficientOfVariation, clamp } from './stats'
import { Estimate, insufficientDataEstimate } from './estimate'

const MIN_ACTIVE_DAYS = 3

export interface CompletionPrediction {
  completedItems: number
  totalItems: number
  percentComplete: number
  itemsPerActiveDay: number
  estimatedDaysToCompletion: number | null // null when pace is 0 (no forward progress to extrapolate)
  estimatedCompletionDate: string | null
}

// Pace is computed from real StreakDay activity records (actual days the
// student did something) rather than calendar days since enrollment, so a
// student who studies 3x/week isn't penalized for the days they didn't.
export async function predictCompletion(studentId: string, courseId: string): Promise<Estimate<CompletionPrediction>> {
  const method = 'pace-extrapolation (completed subtopics per active day)'

  const [course, enrollment, allSubtopics, completedProgress, activeDays] = await Promise.all([
    prisma.course.findUnique({ where: { id: courseId } }),
    prisma.enrollment.findUnique({ where: { studentId_courseId: { studentId, courseId } } }),
    prisma.subtopic.count({ where: { topic: { module: { courseId } } } }),
    prisma.progress.count({ where: { studentId, courseId, status: ProgressStatus.COMPLETED, subtopicId: { not: null } } }),
    prisma.streakDay.findMany({ where: { studentId }, orderBy: { date: 'asc' } }),
  ])

  if (!course || !enrollment) {
    return insufficientDataEstimate(method, 0, 'Student is not enrolled in this course.')
  }
  if (allSubtopics === 0) {
    return insufficientDataEstimate(method, 0, 'This course has no syllabus content yet.')
  }

  const enrollmentDate = enrollment.enrolledAt
  const relevantActiveDays = activeDays.filter((d) => d.date >= enrollmentDate)

  if (relevantActiveDays.length < MIN_ACTIVE_DAYS) {
    return insufficientDataEstimate(
      method,
      relevantActiveDays.length,
      `Need at least ${MIN_ACTIVE_DAYS} active study days since enrollment to estimate pace; only ${relevantActiveDays.length} recorded.`
    )
  }

  const itemsPerActiveDay = completedProgress / relevantActiveDays.length
  const remaining = Math.max(0, allSubtopics - completedProgress)
  const percentComplete = Math.round((completedProgress / allSubtopics) * 100)

  // Consistency check: a wildly irregular pace still gets a number, but with
  // reduced confidence rather than a false sense of precision.
  const cv = coefficientOfVariation(relevantActiveDays.map((d) => d.activitiesCompleted))
  const consistencyPenalty = cv === null ? 0.3 : clamp(cv / 3, 0, 0.5) // higher variability -> lower confidence

  let estimatedDaysToCompletion: number | null = null
  let estimatedCompletionDate: string | null = null
  if (itemsPerActiveDay > 0 && remaining > 0) {
    // Convert "active days needed" back into calendar days using the
    // observed ratio of active days to calendar days since enrollment.
    const calendarDaysSinceEnrollment = Math.max(1, Math.round((Date.now() - enrollmentDate.getTime()) / 86400000))
    const activeDayRatio = relevantActiveDays.length / calendarDaysSinceEnrollment
    const activeDaysNeeded = remaining / itemsPerActiveDay
    const calendarDaysNeeded = activeDayRatio > 0 ? Math.round(activeDaysNeeded / activeDayRatio) : null
    if (calendarDaysNeeded !== null) {
      estimatedDaysToCompletion = calendarDaysNeeded
      estimatedCompletionDate = new Date(Date.now() + calendarDaysNeeded * 86400000).toISOString().slice(0, 10)
    }
  }

  const confidence = Math.round(clamp(0.85 - consistencyPenalty, 0.1, 0.85) * 100) / 100

  return {
    isEstimate: true,
    value: {
      completedItems: completedProgress,
      totalItems: allSubtopics,
      percentComplete,
      itemsPerActiveDay: Math.round(itemsPerActiveDay * 100) / 100,
      estimatedDaysToCompletion,
      estimatedCompletionDate,
    },
    confidence,
    method,
    sampleSize: relevantActiveDays.length,
    insufficientData: false,
    reason: remaining === 0 ? 'Course already complete.' : itemsPerActiveDay === 0 ? 'No completions recorded yet on active days; cannot project forward.' : undefined,
  }
}
