import { prisma } from '@/config/prisma'
import { clamp } from './stats'
import { Estimate, insufficientDataEstimate } from './estimate'
import { analyzeEngagement } from './engagement.analyzer'
import { predictPerformance } from './performance.predictor'

export interface RiskPrediction {
  riskScore: number // 0-100, higher = more at risk
  riskLevel: 'low' | 'medium' | 'high'
  contributingFactors: { factor: string; weight: number; contribution: number }[]
}

// Fixed, documented weights — this is a transparent scoring rule, not a
// trained model. It composes the SAME underlying data the engagement and
// performance predictors already computed (via their real service calls,
// not re-derived), so there is exactly one place each of those metrics is
// calculated.
const WEIGHTS = {
  engagement: 0.35, // low engagement -> higher risk
  performanceTrend: 0.3, // declining scores -> higher risk
  criticalGaps: 0.25, // unresolved critical learning gaps -> higher risk
  inactivity: 0.1, // days since last activity -> higher risk
}

export async function predictRisk(studentId: string, courseId: string): Promise<Estimate<RiskPrediction>> {
  const method = `weighted-heuristic-v1 (engagement ${WEIGHTS.engagement}, score trend ${WEIGHTS.performanceTrend}, critical gaps ${WEIGHTS.criticalGaps}, inactivity ${WEIGHTS.inactivity})`

  const [engagement, performance, criticalGapCount, user] = await Promise.all([
    analyzeEngagement(studentId),
    predictPerformance(studentId, courseId),
    prisma.learningGap.count({ where: { studentId, courseId, resolvedAt: null, severity: 'CRITICAL' } }),
    prisma.user.findUnique({ where: { id: studentId }, select: { lastActiveAt: true } }),
  ])

  // Risk scoring requires engagement data at minimum — without it there is
  // nothing to weight, so refuse rather than substitute a guess.
  if (engagement.insufficientData) {
    return insufficientDataEstimate(method, 0, `Cannot assess risk without engagement data: ${engagement.reason}`)
  }

  const factors: RiskPrediction['contributingFactors'] = []

  // Engagement component: lower engagementScore -> higher risk contribution.
  const engagementRisk = 100 - engagement.value!.engagementScore
  factors.push({ factor: 'low_engagement', weight: WEIGHTS.engagement, contribution: Math.round(engagementRisk * WEIGHTS.engagement) })

  // Performance trend component: only included if we actually have a fitted trend.
  let performanceRisk = 30 // neutral default when no trend data exists — documented, not hidden
  if (!performance.insufficientData) {
    const slope = performance.value!.trendSlope
    // Map slope (-10..+10 clamp) onto a 0-100 risk contribution, declining = riskier.
    performanceRisk = Math.round(clamp(50 - slope * 5, 0, 100))
  }
  factors.push({
    factor: performance.insufficientData ? 'performance_trend_unknown' : 'performance_trend',
    weight: WEIGHTS.performanceTrend,
    contribution: Math.round(performanceRisk * WEIGHTS.performanceTrend),
  })

  // Critical learning gaps component.
  const gapRisk = clamp(criticalGapCount * 25, 0, 100)
  factors.push({ factor: 'unresolved_critical_gaps', weight: WEIGHTS.criticalGaps, contribution: Math.round(gapRisk * WEIGHTS.criticalGaps) })

  // Inactivity component.
  const daysSinceActive = user?.lastActiveAt ? Math.round((Date.now() - user.lastActiveAt.getTime()) / 86400000) : 30
  const inactivityRisk = clamp(daysSinceActive * 10, 0, 100)
  factors.push({ factor: 'days_since_last_activity', weight: WEIGHTS.inactivity, contribution: Math.round(inactivityRisk * WEIGHTS.inactivity) })

  const riskScore = Math.round(factors.reduce((sum, f) => sum + f.contribution, 0))
  const riskLevel: RiskPrediction['riskLevel'] = riskScore >= 65 ? 'high' : riskScore >= 35 ? 'medium' : 'low'

  // Confidence is capped by the weakest input — if performance trend was
  // unavailable, we should not claim high confidence just because
  // engagement data was solid.
  const confidence = performance.insufficientData
    ? Math.min(0.55, engagement.confidence ?? 0.5)
    : Math.min(engagement.confidence ?? 0.5, performance.confidence ?? 0.5)

  return {
    isEstimate: true,
    value: { riskScore, riskLevel, contributingFactors: factors },
    confidence: Math.round(confidence * 100) / 100,
    method,
    sampleSize: engagement.sampleSize,
    insufficientData: false,
    reason: performance.insufficientData ? 'Performance trend unavailable; risk score uses a neutral default for that factor.' : undefined,
  }
}
