import { prisma } from '@/config/prisma'
import { RecommendationType, Priority } from '@prisma/client'
import { recommendationsService } from '@/modules/recommendations/recommendations.service'

const DETECTION_SOURCE = 'ml-model:v1'
const TOP_N = 3

// A gap with no ML confidence (i.e. detected by the Part 2 rule-engine, which
// is deterministic rather than probabilistic) is given a fixed moderate
// trust weight here — documented explicitly rather than silently treated as
// either 0 or 1.
const RULE_ENGINE_TRUST_WEIGHT = 0.6

export interface RankedGap {
  gapId: string
  topicName?: string
  courseId: string
  impactScore: number
  confidence: number
}

// Ranks every open LearningGap the student has (across all their enrolled
// courses, across BOTH detection sources) by a single, documented impact
// formula: gapScore * trust-weighted-confidence. This is the "which gap
// matters most right now" decision — it does not reimplement gap detection
// or candidate generation, both of which already exist elsewhere.
export async function rankLearningGapsByImpact(studentId: string): Promise<RankedGap[]> {
  const gaps = await prisma.learningGap.findMany({
    where: { studentId, resolvedAt: null },
    include: { topic: true },
  })

  const ranked = gaps.map((g) => {
    const trust = g.confidence ?? RULE_ENGINE_TRUST_WEIGHT
    return {
      gapId: g.id,
      topicName: g.topic?.title,
      courseId: g.courseId,
      impactScore: Math.round(g.gapScore * trust),
      confidence: Math.round(trust * 100) / 100,
    }
  })

  return ranked.sort((a, b) => b.impactScore - a.impactScore)
}

// Ensures the top-N highest-impact gaps have a corresponding Recommendation
// row, generated with ML-ranked priority. Runs the Part 2 rule-based
// generator FIRST so baseline continue-learning/revise-topic candidates
// already exist — this only adds/upgrades priority ordering on top of them.
export async function generateMLRecommendations(studentId: string) {
  await recommendationsService.generateForStudent(studentId) // reuse, don't duplicate

  const ranked = await rankLearningGapsByImpact(studentId)
  const top = ranked.slice(0, TOP_N)

  const updated = []
  for (const item of top) {
    const gap = await prisma.learningGap.findUnique({ where: { id: item.gapId } })
    if (!gap) continue

    const priority = item.impactScore >= 60 ? Priority.HIGH : item.impactScore >= 30 ? Priority.MEDIUM : Priority.LOW

    const existing = await prisma.recommendation.findFirst({
      where: { studentId, learningGapId: gap.id, isCompleted: false },
    })

    const rec = existing
      ? await prisma.recommendation.update({
          where: { id: existing.id },
          data: {
            priority,
            source: DETECTION_SOURCE,
            confidence: item.confidence,
            reason: `Ranked by impact score ${item.impactScore} (gap severity ${item.confidence < 1 ? '× rule-engine trust weight' : '× ML confidence'} ${item.confidence}).`,
          },
        })
      : await prisma.recommendation.create({
          data: {
            studentId,
            type: RecommendationType.ADDRESS_GAP,
            priority,
            title: `Priority: address "${gap.concept}"`,
            description: gap.description,
            courseId: gap.courseId,
            moduleId: gap.moduleId,
            topicId: gap.topicId,
            learningGapId: gap.id,
            reason: `Ranked by impact score ${item.impactScore} across all open gaps.`,
            source: DETECTION_SOURCE,
            confidence: item.confidence,
          },
        })
    updated.push(rec)
  }

  return { rankedGaps: ranked, recommendationsUpdated: updated.length }
}
