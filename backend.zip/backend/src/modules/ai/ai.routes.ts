import { Router } from 'express'
import { aiInsightsService } from './ai.service'
import { detectLearningGapsML } from './learningGapML.service'
import { generateMLRecommendations } from './recommendationML.service'
import { predictPerformance } from './predictors/performance.predictor'
import { predictCompletion } from './predictors/completion.predictor'
import { predictRisk } from './predictors/risk.predictor'
import { analyzeEngagement } from './predictors/engagement.analyzer'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole, requireSelfOrAdmin } from '@/middleware/rbac.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok } from '@/utils/apiResponse'
import { Role } from '@prisma/client'

const router = Router()

// ---------------- Individual predictors ----------------

router.get(
  '/students/:studentId/courses/:courseId/performance-prediction',
  requireAuth,
  requireSelfOrAdmin('studentId'),
  asyncHandler(async (req, res) => ok(res, await predictPerformance(req.params.studentId, req.params.courseId)))
)

router.get(
  '/students/:studentId/courses/:courseId/completion-prediction',
  requireAuth,
  requireSelfOrAdmin('studentId'),
  asyncHandler(async (req, res) => ok(res, await predictCompletion(req.params.studentId, req.params.courseId)))
)

router.get(
  '/students/:studentId/courses/:courseId/risk-prediction',
  requireAuth,
  requireSelfOrAdmin('studentId'),
  asyncHandler(async (req, res) => ok(res, await predictRisk(req.params.studentId, req.params.courseId)))
)

router.get(
  '/students/:studentId/engagement',
  requireAuth,
  requireSelfOrAdmin('studentId'),
  asyncHandler(async (req, res) => ok(res, await analyzeEngagement(req.params.studentId)))
)

// ---------------- Aggregate hierarchy-aware insights ----------------

router.get(
  '/students/:studentId/courses/:courseId/insights',
  requireAuth,
  requireSelfOrAdmin('studentId'),
  asyncHandler(async (req, res) => ok(res, await aiInsightsService.getStudentCourseInsights(req.params.studentId, req.params.courseId)))
)

router.get(
  '/courses/:courseId/risk-ranking',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => ok(res, await aiInsightsService.courseRiskRanking(req.params.courseId)))
)

// ---------------- ML gap detection / recommendation ranking (triggered; wire to a scheduler in deployment) ----------------

router.post(
  '/students/:studentId/courses/:courseId/detect-gaps',
  requireAuth,
  requireSelfOrAdmin('studentId'),
  asyncHandler(async (req, res) =>
    ok(res, await detectLearningGapsML(req.params.studentId, req.params.courseId), 'ML gap detection run complete')
  )
)

router.post(
  '/students/:studentId/rank-recommendations',
  requireAuth,
  requireSelfOrAdmin('studentId'),
  asyncHandler(async (req, res) => ok(res, await generateMLRecommendations(req.params.studentId), 'ML recommendation ranking complete'))
)

export default router
