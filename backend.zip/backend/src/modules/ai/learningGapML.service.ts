import { prisma } from '@/config/prisma'
import { GapSeverity } from '@prisma/client'
import { linearRegression, confidenceFromSampleAndFit } from './predictors/stats'

const MIN_POINTS = 4
const DETECTION_SOURCE = 'ml-model:v1'
const DECLINING_SLOPE_THRESHOLD = -2 // score points lost per attempt
const LOW_LEVEL_THRESHOLD = 60 // most recent fitted value below this + declining = flag

// Unlike the Part 2 rule-engine (topic average vs. a fixed threshold), this
// detector looks at TRAJECTORY: a topic where scores are trending down is
// flagged even if the average is still technically passing — catching
// deterioration before it shows up as a low average. Both detectors write
// to the same LearningGap table and are visually distinguished by
// `detectionSource` and a populated `confidence` (the rule-engine leaves
// confidence null because it isn't a statistical estimate).
export async function detectLearningGapsML(studentId: string, courseId: string) {
  const scoredProgress = await prisma.progress.findMany({
    where: { studentId, courseId, score: { not: null }, topicId: { not: null } },
    orderBy: { completedAt: 'asc' },
    include: { topic: true },
  })

  const byTopic = new Map<string, { scores: number[]; topicTitle: string; moduleId: string | null }>()
  for (const p of scoredProgress) {
    if (!p.topicId) continue
    const entry = byTopic.get(p.topicId) ?? { scores: [], topicTitle: p.topic?.title ?? p.topicId, moduleId: p.moduleId }
    entry.scores.push(p.score as number)
    byTopic.set(p.topicId, entry)
  }

  const results = []

  for (const [topicId, data] of byTopic.entries()) {
    if (data.scores.length < MIN_POINTS) continue

    const points = data.scores.map((y, x) => ({ x, y }))
    const fit = linearRegression(points)
    if (!fit) continue

    const latestFittedValue = fit.slope * (points.length - 1) + fit.intercept
    const isDeclining = fit.slope <= DECLINING_SLOPE_THRESHOLD
    const isLow = latestFittedValue < LOW_LEVEL_THRESHOLD

    const existing = await prisma.learningGap.findFirst({
      where: { studentId, courseId, topicId, resolvedAt: null, detectionSource: DETECTION_SOURCE },
    })

    if (!isDeclining || !isLow) {
      // Trend has recovered — resolve our own row if we had previously flagged it.
      if (existing) {
        await prisma.learningGap.update({
          where: { id: existing.id },
          data: { severity: GapSeverity.RESOLVED, resolvedAt: new Date() },
        })
      }
      continue
    }

    const confidence = confidenceFromSampleAndFit(fit.n, fit.rSquared)
    const gapScore = Math.round(Math.max(0, Math.min(100, 100 - latestFittedValue)))
    const severity = latestFittedValue < 40 ? GapSeverity.CRITICAL : GapSeverity.MODERATE
    const description = `Score trend is declining on "${data.topicTitle}" (${Math.round(fit.slope * 10) / 10} pts/attempt), projected around ${Math.round(latestFittedValue)}% — based on ${fit.n} scored attempts.`

    const gap = existing
      ? await prisma.learningGap.update({
          where: { id: existing.id },
          data: { gapScore, severity, description, confidence },
        })
      : await prisma.learningGap.create({
          data: {
            studentId,
            courseId,
            moduleId: data.moduleId ?? undefined,
            topicId,
            concept: data.topicTitle,
            description,
            gapScore,
            severity,
            detectionSource: DETECTION_SOURCE,
            confidence,
          },
        })
    results.push(gap)
  }

  return results
}
