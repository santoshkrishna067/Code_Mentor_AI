import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { ExamStatus, ExamAttemptStatus, ContentType, ProgressStatus, ProctoringSessionStatus } from '@prisma/client'
import { gradeSubmission, shuffle, SubmittedAnswer } from '@/utils/grading'
import { sanitizeQuestionForAttempt, fullQuestionDto } from '@/utils/questionSanitizer'
import { learningService } from '@/modules/learning/learning.service'
import { notificationsService } from '@/modules/notifications/notifications.service'

// Deterministic per-(attempt,question) seed so option display order is
// stable across repeated GETs of the same attempt without persisting it.
function seedFromStrings(...parts: string[]): number {
  const str = parts.join(':')
  let hash = 0
  for (let i = 0; i < str.length; i++) {
    hash = (hash * 31 + str.charCodeAt(i)) | 0
  }
  return hash
}

async function loadAttemptOrThrow(attemptId: string) {
  const attempt = await prisma.examAttempt.findUnique({
    where: { id: attemptId },
    include: { exam: { include: { questions: { include: { question: { include: { options: true } } } } } }, answers: true },
  })
  if (!attempt) throw ApiError.notFound('Exam attempt not found')
  return attempt
}

function elapsedSeconds(startedAt: Date): number {
  return Math.floor((Date.now() - startedAt.getTime()) / 1000)
}

// The ONLY place an attempt transitions out of IN_PROGRESS. Normal student
// submit, reactive/batch auto-submit-on-timeout, and integrity-flag
// termination all call this — so grading, XP, percentile, and proctoring
// session close-out can never drift apart between those three paths.
async function finalizeAttempt(
  attemptId: string,
  finalStatus: 'SUBMITTED' | 'AUTO_SUBMITTED' | 'FLAGGED',
  opts: { flagReason?: string } = {}
) {
  const attempt = await loadAttemptOrThrow(attemptId)
  if (attempt.status !== ExamAttemptStatus.IN_PROGRESS) return attempt // already terminal — no-op, never re-grade

  const exam = attempt.exam
  const questions = exam.questions.map((eq) => ({
    id: eq.question.id,
    correctAnswer: eq.question.correctAnswer,
    marks: eq.question.marks,
    negativeMarks: eq.question.negativeMarks,
  }))
  const submittedAnswers: SubmittedAnswer[] = attempt.answers
    .filter((a) => a.answer !== null && a.answer !== undefined)
    .map((a) => ({ questionId: a.questionId, answer: a.answer as any }))

  const result = gradeSubmission(questions, submittedAnswers, exam.negativeMarking)
  const timeSpent = Math.min(elapsedSeconds(attempt.startedAt), exam.duration * 60)

  // Percentile against every OTHER already-finalized (non-flagged) attempt
  // for this exam, computed from real stored scores — not estimated.
  const priorScores = (
    await prisma.examAttempt.findMany({
      where: { examId: exam.id, status: { in: [ExamAttemptStatus.SUBMITTED, ExamAttemptStatus.AUTO_SUBMITTED] } },
      select: { score: true },
    })
  )
    .map((a) => a.score)
    .filter((s): s is number => s !== null)
  const allScores = finalStatus === 'FLAGGED' ? priorScores : [...priorScores, result.scorePercent]
  const percentile =
    finalStatus === 'FLAGGED' || allScores.length === 0
      ? null
      : Math.round((allScores.filter((s) => s <= result.scorePercent).length / allScores.length) * 100)

  await prisma.$transaction([
    ...result.perQuestion.map((pq) =>
      prisma.examAnswer.updateMany({
        where: { attemptId, questionId: pq.questionId },
        data: { isCorrect: pq.isCorrect, marksAwarded: pq.marksAwarded },
      })
    ),
    prisma.examAttempt.update({
      where: { id: attemptId },
      data: {
        status: finalStatus,
        submittedAt: new Date(),
        score: result.scorePercent,
        percentile,
        timeSpent,
        flaggedReasons: opts.flagReason ? [...((attempt.flaggedReasons as string[] | null) ?? []), opts.flagReason] : (attempt.flaggedReasons as string[] | null) ?? [],
      },
    }),
    prisma.proctoringSession.updateMany({
      where: { examAttemptId: attemptId },
      data: { status: finalStatus === 'FLAGGED' ? ProctoringSessionStatus.FLAGGED : ProctoringSessionStatus.COMPLETED, endedAt: new Date() },
    }),
  ])

  // A flagged (integrity-invalidated) attempt earns no XP and does not count
  // as course progress — it's preserved only for administrative review.
  if (finalStatus !== 'FLAGGED') {
    const { xpEarned } = await learningService.recordProgress({
      studentId: attempt.studentId,
      courseId: exam.courseId,
      moduleId: exam.moduleId ?? undefined,
      contentType: ContentType.EXAM,
      contentId: exam.id,
      status: result.scorePercent >= exam.passingScore ? ProgressStatus.COMPLETED : ProgressStatus.IN_PROGRESS,
      score: result.scorePercent,
    })
    await notificationsService.create({
      userId: attempt.studentId,
      type: result.scorePercent >= exam.passingScore ? 'SUCCESS' : 'INFO',
      title: finalStatus === 'AUTO_SUBMITTED' ? 'Exam auto-submitted (time expired)' : 'Exam submitted',
      message: `"${exam.title}": ${result.scorePercent}% (+${xpEarned} XP)`,
    })
  } else {
    await notificationsService.create({
      userId: attempt.studentId,
      type: 'WARNING',
      title: 'Exam session flagged for review',
      message: `Your attempt on "${exam.title}" was ended and flagged due to proctoring concerns. An admin will review it.`,
    })
  }

  return loadAttemptOrThrow(attemptId)
}

// Reactive time-expiry check — runs on every GET/answer/submit call for a
// given attempt, so a student who returns late (or never comes back) never
// keeps a phantom "still in progress" session merely because no cron fired.
async function autoSubmitIfExpired(attemptId: string) {
  const attempt = await loadAttemptOrThrow(attemptId)
  if (attempt.status !== ExamAttemptStatus.IN_PROGRESS) return attempt
  if (elapsedSeconds(attempt.startedAt) < attempt.exam.duration * 60) return attempt
  return finalizeAttempt(attemptId, 'AUTO_SUBMITTED')
}

function toAttemptStateDto(attempt: any) {
  const remainingSeconds =
    attempt.status === ExamAttemptStatus.IN_PROGRESS
      ? Math.max(0, attempt.exam.duration * 60 - elapsedSeconds(attempt.startedAt))
      : 0

  const questionsById = new Map(attempt.exam.questions.map((eq: any) => [eq.question.id, eq.question]))
  const orderedQuestionIds = attempt.questionOrder as string[]

  const questions = orderedQuestionIds
    .map((qid) => questionsById.get(qid))
    .filter(Boolean)
    .map((q: any) => {
      const sanitized = sanitizeQuestionForAttempt(q)
      if (sanitized.options) {
        sanitized.options = shuffle(sanitized.options, seedFromStrings(attempt.id, q.id))
      }
      return sanitized
    })

  const answersByQuestion = new Map(attempt.answers.map((a: any) => [a.questionId, a]))

  return {
    attemptId: attempt.id,
    examId: attempt.examId,
    status: attempt.status.toLowerCase(),
    startedAt: attempt.startedAt.toISOString(),
    remainingSeconds,
    duration: attempt.exam.duration,
    totalMarks: attempt.exam.totalMarks,
    negativeMarking: attempt.exam.negativeMarking,
    proctoringEnabled: attempt.exam.proctoringEnabled,
    questions,
    answeredQuestionIds: [...answersByQuestion.keys()],
    markedForReviewQuestionIds: attempt.answers.filter((a: any) => a.markedForReview).map((a: any) => a.questionId),
  }
}

export const examAttemptsService = {
  async checkEligibility(studentId: string, examId: string) {
    const exam = await prisma.exam.findUnique({ where: { id: examId } })
    if (!exam) throw ApiError.notFound('Exam not found')

    const reasons: string[] = []
    const now = new Date()

    const enrollment = await prisma.enrollment.findUnique({ where: { studentId_courseId: { studentId, courseId: exam.courseId } } })
    if (!enrollment) reasons.push('You are not enrolled in this course')
    if (exam.status !== ExamStatus.SCHEDULED && exam.status !== ExamStatus.ACTIVE) reasons.push('This exam is not currently open')
    if (now < exam.scheduledStart) reasons.push(`This exam opens at ${exam.scheduledStart.toISOString()}`)
    if (now > exam.scheduledEnd) reasons.push('This exam window has closed')

    const priorAttempts = await prisma.examAttempt.count({ where: { examId, studentId } })
    if (priorAttempts >= exam.maxAttempts) reasons.push(`You have used all ${exam.maxAttempts} attempt(s) for this exam`)

    const anyOtherActive = await prisma.examAttempt.findFirst({
      where: { studentId, status: ExamAttemptStatus.IN_PROGRESS, examId: { not: examId } },
    })
    if (anyOtherActive) reasons.push('You already have another exam in progress')

    const ownActive = await prisma.examAttempt.findFirst({ where: { studentId, examId, status: ExamAttemptStatus.IN_PROGRESS } })

    return { eligible: reasons.length === 0, reasons, attemptsUsed: priorAttempts, maxAttempts: exam.maxAttempts, resumableAttemptId: ownActive?.id }
  },

  async start(studentId: string, examId: string) {
    const { eligible, reasons, resumableAttemptId } = await this.checkEligibility(studentId, examId)
    if (resumableAttemptId) return this.getState(studentId, resumableAttemptId) // idempotent resume, not a new attempt
    if (!eligible) throw ApiError.forbidden(reasons.join('; '))

    const exam = await prisma.exam.findUniqueOrThrow({ where: { id: examId }, include: { questions: { include: { question: true } } } })

    const questionIds = exam.questions.map((eq) => eq.questionId)
    // Server-generated, tamper-evident: computed once here and persisted;
    // the client never supplies or influences this order.
    const orderedQuestionIds = exam.randomizeQuestions ? shuffle(questionIds) : questionIds

    const attempt = await prisma.examAttempt.create({
      data: {
        examId,
        studentId,
        questionOrder: orderedQuestionIds,
        proctoring: exam.proctoringEnabled ? { create: { studentId, cameraEnabled: true } } : undefined,
      },
    })

    if (exam.status === ExamStatus.SCHEDULED) {
      await prisma.exam.update({ where: { id: examId }, data: { status: ExamStatus.ACTIVE } })
    }

    return this.getState(studentId, attempt.id)
  },

  async getState(studentId: string, attemptId: string) {
    const owned = await prisma.examAttempt.findUnique({ where: { id: attemptId }, select: { studentId: true } })
    if (!owned || owned.studentId !== studentId) throw ApiError.notFound('Exam attempt not found')

    await autoSubmitIfExpired(attemptId)
    const attempt = await loadAttemptOrThrow(attemptId)
    return toAttemptStateDto(attempt)
  },

  async saveAnswers(studentId: string, attemptId: string, answers: { questionId: string; answer: string | string[]; timeSpent?: number; markedForReview?: boolean }[]) {
    const owned = await prisma.examAttempt.findUnique({ where: { id: attemptId }, select: { studentId: true } })
    if (!owned || owned.studentId !== studentId) throw ApiError.notFound('Exam attempt not found')

    const afterExpiryCheck = await autoSubmitIfExpired(attemptId)
    if (afterExpiryCheck.status !== ExamAttemptStatus.IN_PROGRESS) {
      throw ApiError.conflict('This exam attempt has already ended and can no longer be edited')
    }

    const validQuestionIds = new Set(afterExpiryCheck.questionOrder as string[])
    for (const a of answers) {
      if (!validQuestionIds.has(a.questionId)) {
        throw ApiError.badRequest(`Question ${a.questionId} does not belong to this attempt`)
      }
    }

    await prisma.$transaction(
      answers.map((a) =>
        prisma.examAnswer.upsert({
          where: { attemptId_questionId: { attemptId, questionId: a.questionId } },
          create: { attemptId, questionId: a.questionId, answer: a.answer, timeSpent: a.timeSpent ?? 0, markedForReview: a.markedForReview ?? false, answeredAt: new Date() },
          update: { answer: a.answer, timeSpent: a.timeSpent ?? undefined, markedForReview: a.markedForReview ?? undefined, answeredAt: new Date() },
        })
      )
    )

    return this.getState(studentId, attemptId)
  },

  async submit(studentId: string, attemptId: string) {
    const owned = await prisma.examAttempt.findUnique({ where: { id: attemptId }, select: { studentId: true, status: true } })
    if (!owned || owned.studentId !== studentId) throw ApiError.notFound('Exam attempt not found')
    if (owned.status !== ExamAttemptStatus.IN_PROGRESS) {
      const already = await autoSubmitIfExpired(attemptId) // in case it just expired concurrently
      if (already.status !== ExamAttemptStatus.IN_PROGRESS) {
        throw ApiError.conflict('This exam attempt has already been submitted')
      }
    }

    const finalized = await finalizeAttempt(attemptId, 'SUBMITTED')
    return {
      attemptId,
      status: finalized.status.toLowerCase(),
      score: finalized.score,
      percentile: finalized.percentile,
      passed: (finalized.score ?? 0) >= finalized.exam.passingScore,
      showResults: finalized.exam.showResults,
    }
  },

  async review(studentId: string, attemptId: string, isAdmin: boolean) {
    const attempt = await loadAttemptOrThrow(attemptId)
    if (!isAdmin && attempt.studentId !== studentId) throw ApiError.forbidden('You may only review your own attempts')
    if (attempt.status === ExamAttemptStatus.IN_PROGRESS) throw ApiError.badRequest('This attempt has not been submitted yet')
    if (!isAdmin && !attempt.exam.showResults) throw ApiError.forbidden('Result review is disabled for this exam')

    const answersByQuestion = new Map(attempt.answers.map((a) => [a.questionId, a]))
    const orderedQuestionIds = attempt.questionOrder as string[]
    const questionsById = new Map(attempt.exam.questions.map((eq) => [eq.question.id, eq.question]))

    const questions = orderedQuestionIds
      .map((qid) => questionsById.get(qid))
      .filter(Boolean)
      .map((q) => {
        const full = fullQuestionDto(q)
        const given = answersByQuestion.get(q!.id)
        return {
          ...full,
          givenAnswer: given?.answer ?? undefined,
          isCorrect: given?.isCorrect ?? false,
          marksAwarded: given?.marksAwarded ?? 0,
        }
      })

    return {
      attemptId: attempt.id,
      examId: attempt.examId,
      status: attempt.status.toLowerCase(),
      score: attempt.score,
      percentile: attempt.percentile,
      timeSpent: attempt.timeSpent,
      questions,
    }
  },

  // Batch reconciliation for attempts nobody ever revisited (so they don't
  // stay open forever without a request touching them). Wire this to a
  // scheduler (cron/setInterval) in production; also exposed as an
  // admin-triggerable endpoint since no scheduler infra exists in this
  // build environment.
  async reconcileExpired() {
    const candidates = await prisma.examAttempt.findMany({
      where: { status: ExamAttemptStatus.IN_PROGRESS },
      include: { exam: true },
    })
    const expired = candidates.filter((a) => elapsedSeconds(a.startedAt) >= a.exam.duration * 60)
    for (const a of expired) {
      await finalizeAttempt(a.id, 'AUTO_SUBMITTED')
    }
    return { reconciledCount: expired.length }
  },

  // Exposed for the proctoring service to call when its escalation policy
  // decides an attempt must be ended for cause.
  async flagAndFinalize(attemptId: string, reason: string) {
    return finalizeAttempt(attemptId, 'FLAGGED', { flagReason: reason })
  },
}
