import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { ExamStatus, ExamAttemptStatus } from '@prisma/client'

function toExamSummary(e: any) {
  return {
    id: e.id,
    title: e.title,
    description: e.description,
    instructions: e.instructions,
    courseId: e.courseId,
    moduleId: e.moduleId ?? undefined,
    duration: e.duration,
    totalMarks: e.totalMarks,
    passingScore: e.passingScore,
    negativeMarking: e.negativeMarking,
    randomizeQuestions: e.randomizeQuestions,
    randomizeOptions: e.randomizeOptions,
    showResults: e.showResults,
    proctoringEnabled: e.proctoringEnabled,
    maxAttempts: e.maxAttempts,
    scheduledStart: e.scheduledStart.toISOString(),
    scheduledEnd: e.scheduledEnd.toISOString(),
    status: e.status.toLowerCase(),
    questionCount: e.questions?.length,
  }
}

export const examsService = {
  async create(courseId: string, input: any) {
    const course = await prisma.course.findUnique({ where: { id: courseId } })
    if (!course) throw ApiError.notFound('Course not found')

    if (input.moduleId) {
      const mod = await prisma.courseModule.findUnique({ where: { id: input.moduleId } })
      if (!mod || mod.courseId !== courseId) throw ApiError.badRequest('moduleId does not belong to this course')
    }

    const start = new Date(input.scheduledStart)
    const end = new Date(input.scheduledEnd)
    if (end <= start) throw ApiError.badRequest('scheduledEnd must be after scheduledStart')

    const foundCount = await prisma.question.count({ where: { id: { in: input.questionIds } } })
    if (foundCount !== input.questionIds.length) throw ApiError.badRequest('One or more questionIds do not exist')

    const exam = await prisma.exam.create({
      data: {
        title: input.title,
        description: input.description,
        instructions: input.instructions ?? [],
        courseId,
        moduleId: input.moduleId,
        duration: input.duration,
        totalMarks: input.totalMarks,
        passingScore: input.passingScore,
        negativeMarking: input.negativeMarking ?? false,
        randomizeQuestions: input.randomizeQuestions ?? true,
        randomizeOptions: input.randomizeOptions ?? true,
        showResults: input.showResults ?? false,
        proctoringEnabled: input.proctoringEnabled ?? true,
        maxAttempts: input.maxAttempts ?? 1,
        scheduledStart: start,
        scheduledEnd: end,
        status: ExamStatus.DRAFT,
        questions: { create: input.questionIds.map((questionId: string, order: number) => ({ questionId, order })) },
      },
      include: { questions: true },
    })
    return toExamSummary(exam)
  },

  async update(examId: string, input: any) {
    const exam = await prisma.exam.findUnique({ where: { id: examId }, include: { attempts: true } })
    if (!exam) throw ApiError.notFound('Exam not found')
    if (exam.attempts.length > 0) {
      throw ApiError.conflict('Cannot modify an exam that already has attempts. Create a new exam instead.')
    }

    const data: any = { ...input }
    if (input.scheduledStart) data.scheduledStart = new Date(input.scheduledStart)
    if (input.scheduledEnd) data.scheduledEnd = new Date(input.scheduledEnd)
    if (data.scheduledStart && data.scheduledEnd && data.scheduledEnd <= data.scheduledStart) {
      throw ApiError.badRequest('scheduledEnd must be after scheduledStart')
    }

    const updated = await prisma.exam.update({ where: { id: examId }, data, include: { questions: true } })
    return toExamSummary(updated)
  },

  // DRAFT -> SCHEDULED. A published exam becomes visible to enrolled
  // students once the schedule window opens; this is a deliberate gate so
  // an exam under construction is never accidentally attemptable.
  async publish(examId: string) {
    const exam = await prisma.exam.findUnique({ where: { id: examId }, include: { questions: true } })
    if (!exam) throw ApiError.notFound('Exam not found')
    if (exam.status !== ExamStatus.DRAFT) throw ApiError.conflict('Only a DRAFT exam can be published')
    if (exam.questions.length === 0) throw ApiError.badRequest('Cannot publish an exam with no questions')
    if (exam.scheduledEnd <= new Date()) throw ApiError.badRequest('Cannot publish an exam whose schedule window has already passed')

    const updated = await prisma.exam.update({ where: { id: examId }, data: { status: ExamStatus.SCHEDULED } })
    return toExamSummary(updated)
  },

  async cancel(examId: string) {
    const exam = await prisma.exam.findUnique({ where: { id: examId } })
    if (!exam) throw ApiError.notFound('Exam not found')
    if (exam.status === ExamStatus.COMPLETED) throw ApiError.conflict('Cannot cancel a completed exam')
    const updated = await prisma.exam.update({ where: { id: examId }, data: { status: ExamStatus.CANCELLED } })
    return toExamSummary(updated)
  },

  async remove(examId: string) {
    const exam = await prisma.exam.findUnique({ where: { id: examId }, include: { attempts: true } })
    if (!exam) throw ApiError.notFound('Exam not found')
    if (exam.attempts.length > 0) throw ApiError.conflict('Cannot delete an exam that has attempts. Cancel it instead.')
    await prisma.exam.delete({ where: { id: examId } })
  },

  // Admin detail view: includes question ids/order (never the answer key by
  // default — use the question-bank endpoints for that).
  async getForAdmin(examId: string) {
    const exam = await prisma.exam.findUnique({
      where: { id: examId },
      include: { questions: { orderBy: { order: 'asc' } } },
    })
    if (!exam) throw ApiError.notFound('Exam not found')
    return toExamSummary(exam)
  },

  // Student-facing list: only exams that are actually reachable right now —
  // published (SCHEDULED/ACTIVE) and within a window that hasn't fully
  // closed. This is a convenience filter; start() re-validates the window
  // server-side regardless, since a list filter is not a security boundary.
  async listForStudent(courseId: string) {
    const exams = await prisma.exam.findMany({
      where: { courseId, status: { in: [ExamStatus.SCHEDULED, ExamStatus.ACTIVE] }, scheduledEnd: { gt: new Date() } },
      include: { questions: true },
      orderBy: { scheduledStart: 'asc' },
    })
    return exams.map(toExamSummary)
  },

  async listForCourseAdmin(courseId: string) {
    const exams = await prisma.exam.findMany({
      where: { courseId },
      include: { questions: true },
      orderBy: { scheduledStart: 'desc' },
    })
    return exams.map(toExamSummary)
  },

  // Real aggregation from actual attempt/warning rows — same principle as
  // the platform Analytics module: nothing here is estimated.
  async report(examId: string) {
    const exam = await prisma.exam.findUnique({ where: { id: examId } })
    if (!exam) throw ApiError.notFound('Exam not found')

    const attempts = await prisma.examAttempt.findMany({
      where: { examId, status: { in: [ExamAttemptStatus.SUBMITTED, ExamAttemptStatus.AUTO_SUBMITTED, ExamAttemptStatus.FLAGGED] } },
      include: { student: { include: { user: true } }, proctoring: { include: { warnings: true } } },
    })

    const scored = attempts.filter((a) => a.score !== null)
    const averageScore = scored.length ? Math.round(scored.reduce((s, a) => s + (a.score ?? 0), 0) / scored.length) : 0
    const passCount = scored.filter((a) => (a.score ?? 0) >= exam.passingScore).length
    const flaggedAttempts = attempts.filter((a) => a.status === ExamAttemptStatus.FLAGGED)
    const autoSubmitted = attempts.filter((a) => a.status === ExamAttemptStatus.AUTO_SUBMITTED)

    return {
      examId,
      title: exam.title,
      totalAttempts: attempts.length,
      averageScore,
      passRate: scored.length ? Math.round((passCount / scored.length) * 100) : 0,
      autoSubmittedCount: autoSubmitted.length,
      flaggedCount: flaggedAttempts.length,
      attempts: attempts.map((a) => ({
        attemptId: a.id,
        studentId: a.studentId,
        studentName: a.student.user.name,
        status: a.status.toLowerCase(),
        score: a.score ?? undefined,
        percentile: a.percentile ?? undefined,
        timeSpent: a.timeSpent,
        submittedAt: a.submittedAt?.toISOString(),
        warningCount: a.proctoring?.warnings.length ?? 0,
        highSeverityWarningCount: a.proctoring?.warnings.filter((w) => w.severity === 'HIGH').length ?? 0,
      })),
    }
  },
}
