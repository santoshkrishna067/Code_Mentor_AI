import { z } from 'zod'

export const createExamSchema = z.object({
  title: z.string().min(1),
  description: z.string().min(1),
  instructions: z.array(z.string()).optional(),
  moduleId: z.string().optional(),
  duration: z.number().int().positive(),
  totalMarks: z.number().int().positive(),
  passingScore: z.number().int().min(0).max(100),
  negativeMarking: z.boolean().optional(),
  randomizeQuestions: z.boolean().optional(),
  randomizeOptions: z.boolean().optional(),
  showResults: z.boolean().optional(),
  proctoringEnabled: z.boolean().optional(),
  maxAttempts: z.number().int().min(1).max(10).optional(),
  scheduledStart: z.string().datetime(),
  scheduledEnd: z.string().datetime(),
  questionIds: z.array(z.string()).min(1),
})

export const updateExamSchema = createExamSchema.partial().omit({ questionIds: true })

export const answerSchema = z.object({
  questionId: z.string(),
  answer: z.union([z.string(), z.array(z.string())]),
  timeSpent: z.number().int().min(0).optional(),
  markedForReview: z.boolean().optional(),
})

export const submitAnswersSchema = z.object({
  answers: z.array(answerSchema).min(0),
})

export const warningSchema = z.object({
  type: z.enum(['MULTIPLE_FACES', 'NO_FACE', 'PHONE_DETECTED', 'LOOKING_AWAY', 'SUSPICIOUS_ACTIVITY', 'TAB_SWITCH']),
  severity: z.enum(['LOW', 'MEDIUM', 'HIGH']),
  message: z.string().min(1),
  evidence: z.string().optional(),
})

export const eventSchema = z.object({
  type: z.string().min(1),
  description: z.string().min(1),
  metadata: z.record(z.unknown()).optional(),
})
