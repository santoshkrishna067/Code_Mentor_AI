import { Router } from 'express'
import { z } from 'zod'
import { examsService } from './exams.service'
import { examAttemptsService } from './attempts.service'
import { proctoringService } from '@/modules/proctoring/proctoring.service'
import { createExamSchema, updateExamSchema, submitAnswersSchema } from './exams.validation'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole } from '@/middleware/rbac.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok } from '@/utils/apiResponse'
import { writeAuditLog } from '@/utils/audit'
import { Role } from '@prisma/client'

const router = Router()

// ---------------- Admin: create / manage / schedule ----------------

router.post(
  '/courses/:courseId',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({ body: createExamSchema }),
  asyncHandler(async (req, res) => {
    const exam = await examsService.create(req.params.courseId, req.body)
    await writeAuditLog(req, 'EXAM_CREATED', 'Exam', exam.id)
    return ok(res, exam, 'Exam created (draft)', 201)
  })
)

router.patch(
  '/:examId',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({ body: updateExamSchema }),
  asyncHandler(async (req, res) => {
    const exam = await examsService.update(req.params.examId, req.body)
    await writeAuditLog(req, 'EXAM_UPDATED', 'Exam', req.params.examId)
    return ok(res, exam, 'Exam updated')
  })
)

router.post(
  '/:examId/publish',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => {
    const exam = await examsService.publish(req.params.examId)
    await writeAuditLog(req, 'EXAM_PUBLISHED', 'Exam', req.params.examId)
    return ok(res, exam, 'Exam published and scheduled')
  })
)

router.post(
  '/:examId/cancel',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => {
    const exam = await examsService.cancel(req.params.examId)
    await writeAuditLog(req, 'EXAM_CANCELLED', 'Exam', req.params.examId)
    return ok(res, exam, 'Exam cancelled')
  })
)

router.delete(
  '/:examId',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => {
    await examsService.remove(req.params.examId)
    await writeAuditLog(req, 'EXAM_DELETED', 'Exam', req.params.examId)
    return ok(res, null, 'Exam deleted')
  })
)

router.get(
  '/:examId/admin',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => ok(res, await examsService.getForAdmin(req.params.examId)))
)

router.get(
  '/courses/:courseId/admin',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => ok(res, await examsService.listForCourseAdmin(req.params.courseId)))
)

router.get(
  '/:examId/report',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => ok(res, await examsService.report(req.params.examId)))
)

router.get(
  '/:examId/warnings',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => ok(res, await proctoringService.listWarningsForExam(req.params.examId)))
)

// System/admin-triggerable batch auto-submit for attempts nobody revisited.
// In production, wire this to a scheduler (cron/setInterval) — see
// attempts.service.ts's reconcileExpired doc comment.
router.post(
  '/reconcile-expired',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => ok(res, await examAttemptsService.reconcileExpired(), 'Reconciliation complete'))
)

// ---------------- Student: discovery + attempt lifecycle ----------------

router.get(
  '/courses/:courseId',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await examsService.listForStudent(req.params.courseId)))
)

router.get(
  '/:examId/eligibility',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await examAttemptsService.checkEligibility(req.user!.id, req.params.examId)))
)

router.post(
  '/:examId/start',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => {
    const state = await examAttemptsService.start(req.user!.id, req.params.examId)
    await writeAuditLog(req, 'EXAM_ATTEMPT_STARTED', 'Exam', req.params.examId, { attemptId: state.attemptId })
    return ok(res, state, 'Exam started', 201)
  })
)

router.get(
  '/attempts/:attemptId',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await examAttemptsService.getState(req.user!.id, req.params.attemptId)))
)

router.patch(
  '/attempts/:attemptId/answers',
  requireAuth,
  requireRole(Role.STUDENT),
  validate({ body: submitAnswersSchema }),
  asyncHandler(async (req, res) => ok(res, await examAttemptsService.saveAnswers(req.user!.id, req.params.attemptId, req.body.answers)))
)

router.post(
  '/attempts/:attemptId/submit',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => {
    const result = await examAttemptsService.submit(req.user!.id, req.params.attemptId)
    await writeAuditLog(req, 'EXAM_ATTEMPT_SUBMITTED', 'ExamAttempt', req.params.attemptId, { score: result.score })
    return ok(res, result, 'Exam submitted')
  })
)

router.get(
  '/attempts/:attemptId/review',
  requireAuth,
  asyncHandler(async (req, res) =>
    ok(res, await examAttemptsService.review(req.user!.id, req.params.attemptId, req.user!.role === Role.ADMIN))
  )
)

export default router
