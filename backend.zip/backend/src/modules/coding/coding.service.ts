import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { ContentType, ProgressStatus, CodeSubmissionStatus } from '@prisma/client'
import { learningService } from '@/modules/learning/learning.service'
import { codeExecutionProvider, SUPPORTED_LANGUAGES } from './codeExecution.provider'

function toProblemSummary(p: any) {
  return {
    id: p.id,
    title: p.title,
    description: p.description,
    constraints: p.constraints,
    hints: p.hints ?? undefined,
    starterCode: p.starterCode,
    difficulty: p.difficulty,
    tags: p.tags,
    estimatedTime: p.estimatedTime,
    marks: p.marks,
    courseId: p.courseId,
    moduleId: p.moduleId ?? undefined,
    topicId: p.topicId ?? undefined,
    examples: p.examples?.map((e: any) => ({
      id: e.id,
      title: e.title,
      description: e.description ?? undefined,
      code: e.code,
      language: e.language,
      output: e.output ?? undefined,
      explanation: e.explanation ?? undefined,
    })),
  }
}

export const codingService = {
  // Every coding problem, with its course, for the student "Coding" browser.
  async listProblems(studentId?: string) {
    const problems = await prisma.codingProblem.findMany({
      include: { course: { select: { name: true, slug: true } } },
      orderBy: { id: 'asc' },
    })
    const solved = new Set<string>()
    if (studentId) {
      const rows = await prisma.codeSubmission.findMany({
        where: { studentId, status: CodeSubmissionStatus.ACCEPTED },
        select: { problemId: true },
      })
      rows.forEach((r) => solved.add(r.problemId))
    }
    return problems.map((p) => ({
      id: p.id,
      title: p.title,
      difficulty: p.difficulty,
      tags: p.tags,
      estimatedTime: p.estimatedTime,
      marks: p.marks,
      courseId: p.courseId,
      courseName: p.course.name,
      courseSlug: p.course.slug,
      solved: solved.has(p.id),
    }))
  },

  // Free-form "playground" run: execute code with optional stdin, no grading.
  async run(input: { code: string; language: string; stdin?: string }) {
    try {
      const r = await codeExecutionProvider.execute({ code: input.code, language: input.language, stdin: input.stdin ?? '' })
      return {
        stdout: r.stdout,
        stderr: r.stderr,
        exitCode: r.exitCode,
        executionTimeMs: r.executionTimeMs,
        timedOut: r.timedOut,
      }
    } catch (err) {
      throw ApiError.badRequest((err as Error).message, { supported: [...SUPPORTED_LANGUAGES] })
    }
  },

  async create(courseId: string, input: any) {
    const course = await prisma.course.findUnique({ where: { id: courseId } })
    if (!course) throw ApiError.notFound('Course not found')
    if (!input.testCases?.length) throw ApiError.badRequest('At least one test case is required')

    const problem = await prisma.codingProblem.create({
      data: {
        courseId,
        moduleId: input.moduleId,
        topicId: input.topicId,
        title: input.title,
        description: input.description,
        constraints: input.constraints ?? [],
        hints: input.hints,
        starterCode: input.starterCode,
        difficulty: input.difficulty,
        tags: input.tags ?? [],
        estimatedTime: input.estimatedTime,
        marks: input.marks,
        examples: input.examples ? { create: input.examples } : undefined,
        testCases: { create: input.testCases },
      },
      include: { examples: true },
    })
    return toProblemSummary(problem)
  },

  // Visible (non-hidden) test cases only, for the student-facing view.
  async getForAttempt(problemId: string) {
    const problem = await prisma.codingProblem.findUnique({
      where: { id: problemId },
      include: { examples: true, testCases: { where: { isHidden: false } } },
    })
    if (!problem) throw ApiError.notFound('Coding problem not found')
    return {
      ...toProblemSummary(problem),
      visibleTestCases: problem.testCases.map((tc) => ({ id: tc.id, input: tc.input, expectedOutput: tc.expectedOutput })),
    }
  },

  async submit(studentId: string, problemId: string, input: { code: string; language: string }) {
    const problem = await prisma.codingProblem.findUnique({
      where: { id: problemId },
      include: { testCases: true },
    })
    if (!problem) throw ApiError.notFound('Coding problem not found')

    const submission = await prisma.codeSubmission.create({
      data: { problemId, studentId, code: input.code, language: input.language, status: CodeSubmissionStatus.RUNNING },
    })

    try {
      const results = []
      let allPassed = true
      let marksEarned = 0
      let totalExecTime = 0

      for (const tc of problem.testCases) {
        const execResult = await codeExecutionProvider.execute({ code: input.code, language: input.language, stdin: tc.input })
        const passed = execResult.stdout.trim() === tc.expectedOutput.trim() && execResult.exitCode === 0
        if (passed) marksEarned += tc.marks
        else allPassed = false
        totalExecTime += execResult.executionTimeMs
        results.push({ testCaseId: tc.id, passed, isHidden: tc.isHidden, stderr: tc.isHidden ? undefined : execResult.stderr })
      }

      const status = allPassed ? CodeSubmissionStatus.ACCEPTED : CodeSubmissionStatus.WRONG_ANSWER
      const updated = await prisma.codeSubmission.update({
        where: { id: submission.id },
        data: { status, testResults: results, executionTime: totalExecTime },
      })

      const scorePercent = problem.marks > 0 ? Math.round((marksEarned / problem.marks) * 100) : 0
      const { xpEarned } = await learningService.recordProgress({
        studentId,
        courseId: problem.courseId,
        moduleId: problem.moduleId ?? undefined,
        topicId: problem.topicId ?? undefined,
        contentType: ContentType.CODING,
        contentId: problem.id,
        status: allPassed ? ProgressStatus.COMPLETED : ProgressStatus.IN_PROGRESS,
        score: scorePercent,
      })

      return { submissionId: updated.id, status: status.toLowerCase(), results, scorePercent, xpEarned }
    } catch (err) {
      // Execution provider not wired up yet, or a genuine runtime failure —
      // fail the submission loudly rather than silently mark it passed.
      await prisma.codeSubmission.update({
        where: { id: submission.id },
        data: { status: CodeSubmissionStatus.RUNTIME_ERROR, testResults: { error: (err as Error).message } },
      })
      throw ApiError.internal(
        'Code execution is currently unavailable. ' + (err as Error).message
      )
    }
  },

  async mySubmissions(studentId: string, problemId: string) {
    const submissions = await prisma.codeSubmission.findMany({
      where: { studentId, problemId },
      orderBy: { submittedAt: 'desc' },
    })
    return submissions.map((s) => ({
      id: s.id,
      status: s.status.toLowerCase(),
      language: s.language,
      submittedAt: s.submittedAt.toISOString(),
      executionTime: s.executionTime ?? undefined,
    }))
  },
}
