import { spawn } from 'child_process'
import fs from 'fs/promises'
import os from 'os'
import path from 'path'
import crypto from 'crypto'

export interface ExecutionInput {
  code: string
  language: string
  stdin: string
}

export interface ExecutionResult {
  stdout: string
  stderr: string
  exitCode: number
  executionTimeMs: number
  memoryKb?: number
  timedOut: boolean
}

export interface CodeExecutionProvider {
  execute(input: ExecutionInput): Promise<ExecutionResult>
}

export const SUPPORTED_LANGUAGES = ['python', 'javascript', 'java', 'c', 'cpp', 'sql'] as const
export type SupportedLanguage = (typeof SUPPORTED_LANGUAGES)[number]

function normaliseLanguage(language: string): SupportedLanguage {
  const l = language.toLowerCase().trim()
  const aliases: Record<string, SupportedLanguage> = {
    python: 'python', python3: 'python', py: 'python',
    javascript: 'javascript', js: 'javascript', node: 'javascript',
    java: 'java',
    c: 'c',
    cpp: 'cpp', 'c++': 'cpp', cxx: 'cpp',
    sql: 'sql', sqlite: 'sql', mysql: 'sql',
  }
  const found = aliases[l]
  if (!found) throw new Error(`Unsupported language "${language}". Supported: ${SUPPORTED_LANGUAGES.join(', ')}`)
  return found
}

const RUN_TIMEOUT_MS = Number(process.env.CODE_RUN_TIMEOUT_MS || 5000)
const COMPILE_TIMEOUT_MS = 20000
const MAX_OUTPUT_BYTES = 64 * 1024

interface ProcResult {
  stdout: string
  stderr: string
  exitCode: number
  timedOut: boolean
  spawnFailed?: boolean
}

function runProcess(cmd: string, args: string[], opts: { cwd: string; stdin?: string; timeoutMs: number }): Promise<ProcResult> {
  return new Promise((resolve) => {
    let stdout = ''
    let stderr = ''
    let timedOut = false
    let settled = false
    const child = spawn(cmd, args, { cwd: opts.cwd, windowsHide: true })

    const finish = (r: ProcResult) => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      resolve(r)
    }

    const timer = setTimeout(() => {
      timedOut = true
      // On Windows, child.kill() does not always stop grandchildren; taskkill /T does.
      if (process.platform === 'win32' && child.pid) {
        spawn('taskkill', ['/pid', String(child.pid), '/t', '/f'], { windowsHide: true })
      } else {
        child.kill('SIGKILL')
      }
    }, opts.timeoutMs)

    child.stdout.on('data', (d) => {
      if (stdout.length < MAX_OUTPUT_BYTES) stdout += d.toString()
    })
    child.stderr.on('data', (d) => {
      if (stderr.length < MAX_OUTPUT_BYTES) stderr += d.toString()
    })
    child.on('error', (err: NodeJS.ErrnoException) => {
      finish({ stdout, stderr: err.code === 'ENOENT' ? `__ENOENT__${cmd}` : err.message, exitCode: -1, timedOut: false, spawnFailed: true })
    })
    child.on('close', (code) => finish({ stdout, stderr, exitCode: code ?? -1, timedOut }))

    child.stdin.on('error', () => {
      /* program exited before reading all stdin — ignore EPIPE */
    })
    child.stdin.end(opts.stdin ?? '')
  })
}


// SQL runner: executes statements against a fresh in-memory SQLite database
// using Node's built-in `node:sqlite` (no install needed). SELECT results are
// printed as a text table, like a database console.
const SQL_RUNNER = `
import { DatabaseSync } from 'node:sqlite'
import fs from 'node:fs'
const db = new DatabaseSync(':memory:')
const text = fs.readFileSync('main.sql', 'utf8')
const stmts = []
let cur = '', q = null
for (let i = 0; i < text.length; i++) {
  const ch = text[i]
  if (q) { cur += ch; if (ch === q) q = null; continue }
  if (ch === "'" || ch === '"') { q = ch; cur += ch; continue }
  if (ch === '-' && text[i + 1] === '-') { while (i < text.length && text[i] !== '\\n') i++; continue }
  if (ch === ';') { if (cur.trim()) stmts.push(cur.trim()); cur = ''; continue }
  cur += ch
}
if (cur.trim()) stmts.push(cur.trim())
const show = (rows) => {
  if (!rows.length) { console.log('(0 rows)'); return }
  const cols = Object.keys(rows[0])
  const w = cols.map((c) => Math.max(c.length, ...rows.map((r) => String(r[c] ?? 'NULL').length)))
  const line = (vals) => vals.map((v, i) => String(v).padEnd(w[i])).join(' | ')
  console.log(line(cols)); console.log(w.map((n) => '-'.repeat(n)).join('-+-'))
  for (const r of rows) console.log(line(cols.map((c) => r[c] ?? 'NULL')))
  console.log('(' + rows.length + ' row' + (rows.length === 1 ? '' : 's') + ')')
}
let failed = false
for (const s of stmts) {
  try {
    if (/^(select|with|pragma|values|explain)\\b/i.test(s)) show(db.prepare(s).all())
    else { const r = db.prepare(s).run(); console.log('OK' + (r.changes ? ' (' + r.changes + ' row(s) affected)' : '')) }
  } catch (e) { console.error('Error: ' + e.message + '\\n  in: ' + s.split('\\n')[0]); failed = true; break }
}
process.exit(failed ? 1 : 0)
`

const commandCache = new Map<string, string | null>()

// Finds the first candidate executable that exists on this machine
// (e.g. "python" on Windows, "python3" on Linux/macOS).
async function resolveCommand(candidates: string[], versionArg: string): Promise<string | null> {
  const key = candidates.join('|')
  if (commandCache.has(key)) return commandCache.get(key)!
  for (const c of candidates) {
    const r = await runProcess(c, [versionArg], { cwd: os.tmpdir(), timeoutMs: 5000 })
    if (!r.spawnFailed) {
      commandCache.set(key, c)
      return c
    }
  }
  commandCache.set(key, null)
  return null
}

const INSTALL_HINT: Record<SupportedLanguage, string> = {
  python: 'Python is not installed or not on PATH. Install it from python.org and tick "Add python.exe to PATH".',
  javascript: 'Node.js is not installed or not on PATH.',
  java: 'The JDK (javac/java) is not installed or not on PATH. Install a JDK (e.g. Temurin 17+).',
  c: 'gcc is not installed or not on PATH. On Windows install MinGW-w64 (or MSYS2) and add its bin folder to PATH.',
  cpp: 'g++ is not installed or not on PATH. On Windows install MinGW-w64 (or MSYS2) and add its bin folder to PATH.',
  sql: 'SQL needs Node.js 22.13 or newer (it uses the built-in SQLite engine).',
}

// ---------------------------------------------------------------------------
// LOCAL provider: compiles/runs code with the compilers already installed on
// the machine running the backend. Great for a single-user/dev setup.
// WARNING: it is NOT a sandbox. Untrusted users could run arbitrary code with
// the backend's OS permissions — for a public deployment use Judge0/Piston
// (set CODE_RUNNER=judge0) or a container-isolated runner instead.
// ---------------------------------------------------------------------------
export class LocalExecutionProvider implements CodeExecutionProvider {
  async execute(input: ExecutionInput): Promise<ExecutionResult> {
    const lang = normaliseLanguage(input.language)
    const dir = await fs.mkdtemp(path.join(os.tmpdir(), `cma-${crypto.randomBytes(4).toString('hex')}-`))
    const started = Date.now()
    const isWin = process.platform === 'win32'

    const done = (r: ProcResult): ExecutionResult => ({
      stdout: r.stdout,
      stderr: r.timedOut ? `${r.stderr}\nTime limit exceeded (${RUN_TIMEOUT_MS / 1000}s)`.trim() : r.stderr,
      exitCode: r.exitCode,
      executionTimeMs: Date.now() - started,
      timedOut: r.timedOut,
    })
    const missing = (): ExecutionResult => ({
      stdout: '',
      stderr: INSTALL_HINT[lang],
      exitCode: 127,
      executionTimeMs: 0,
      timedOut: false,
    })

    try {
      if (lang === 'python') {
        const py = await resolveCommand(isWin ? ['python', 'py', 'python3'] : ['python3', 'python'], '--version')
        if (!py) return missing()
        await fs.writeFile(path.join(dir, 'main.py'), input.code)
        return done(await runProcess(py, ['main.py'], { cwd: dir, stdin: input.stdin, timeoutMs: RUN_TIMEOUT_MS }))
      }

      if (lang === 'javascript') {
        const node = await resolveCommand(['node'], '--version')
        if (!node) return missing()
        await fs.writeFile(path.join(dir, 'main.js'), input.code)
        return done(await runProcess(node, ['main.js'], { cwd: dir, stdin: input.stdin, timeoutMs: RUN_TIMEOUT_MS }))
      }

      if (lang === 'sql') {
        const node = await resolveCommand(['node'], '--version')
        if (!node) return missing()
        await fs.writeFile(path.join(dir, 'main.sql'), input.code)
        await fs.writeFile(path.join(dir, 'run.mjs'), SQL_RUNNER)
        return done(await runProcess(node, ['--no-warnings', 'run.mjs'], { cwd: dir, timeoutMs: RUN_TIMEOUT_MS }))
      }

      if (lang === 'java') {
        const javac = await resolveCommand(['javac'], '-version')
        const java = await resolveCommand(['java'], '-version')
        if (!javac || !java) return missing()
        // The public class must be called Main so the file name matches.
        await fs.writeFile(path.join(dir, 'Main.java'), input.code)
        const compiled = await runProcess(javac, ['Main.java'], { cwd: dir, timeoutMs: COMPILE_TIMEOUT_MS })
        if (compiled.exitCode !== 0) return done({ ...compiled, stderr: compiled.stderr || 'Compilation failed' })
        return done(await runProcess(java, ['-cp', dir, 'Main'], { cwd: dir, stdin: input.stdin, timeoutMs: RUN_TIMEOUT_MS }))
      }

      // c / cpp
      const compiler = await resolveCommand(lang === 'c' ? ['gcc', 'cc'] : ['g++', 'c++'], '--version')
      if (!compiler) return missing()
      const src = lang === 'c' ? 'main.c' : 'main.cpp'
      const exe = isWin ? 'prog.exe' : 'prog'
      await fs.writeFile(path.join(dir, src), input.code)
      const args = lang === 'c' ? [src, '-O2', '-o', exe, '-lm'] : [src, '-O2', '-std=c++17', '-o', exe]
      const compiled = await runProcess(compiler, args, { cwd: dir, timeoutMs: COMPILE_TIMEOUT_MS })
      if (compiled.exitCode !== 0) return done({ ...compiled, stderr: compiled.stderr || 'Compilation failed' })
      return done(await runProcess(path.join(dir, exe), [], { cwd: dir, stdin: input.stdin, timeoutMs: RUN_TIMEOUT_MS }))
    } finally {
      fs.rm(dir, { recursive: true, force: true }).catch(() => undefined)
    }
  }
}

// ---------------------------------------------------------------------------
// JUDGE0 provider: sends code to a Judge0 server (self-hosted or the public
// community edition) so nothing runs on your own machine.
//   CODE_RUNNER=judge0
//   JUDGE0_URL=https://ce.judge0.com        (or your own server)
//   JUDGE0_API_KEY=...                      (optional, only if your server needs one)
// ---------------------------------------------------------------------------
const JUDGE0_LANGUAGE_IDS: Record<SupportedLanguage, number> = { python: 71, javascript: 63, java: 62, c: 50, cpp: 54, sql: 82 }

export class Judge0ExecutionProvider implements CodeExecutionProvider {
  async execute(input: ExecutionInput): Promise<ExecutionResult> {
    const lang = normaliseLanguage(input.language)
    const base = (process.env.JUDGE0_URL || 'https://ce.judge0.com').replace(/\/$/, '')
    const headers: Record<string, string> = { 'content-type': 'application/json' }
    if (process.env.JUDGE0_API_KEY) headers['X-Auth-Token'] = process.env.JUDGE0_API_KEY

    const started = Date.now()
    let res: Response
    try {
      res = await fetch(`${base}/submissions?base64_encoded=false&wait=true`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          source_code: input.code,
          language_id: JUDGE0_LANGUAGE_IDS[lang],
          stdin: input.stdin,
          cpu_time_limit: RUN_TIMEOUT_MS / 1000,
        }),
      })
    } catch (err) {
      throw new Error(`Could not reach the Judge0 server at ${base}: ${(err as Error).message}`)
    }
    if (!res.ok) throw new Error(`Judge0 request failed: ${res.status} ${await res.text()}`)

    const data = (await res.json()) as {
      stdout?: string | null
      stderr?: string | null
      compile_output?: string | null
      message?: string | null
      time?: string | null
      memory?: number | null
      status?: { id: number; description: string }
    }
    const statusId = data.status?.id ?? 0
    const timedOut = statusId === 5
    const failed = statusId !== 3 // 3 = Accepted (ran fine; output compared by our grader)
    return {
      stdout: data.stdout ?? '',
      stderr: [data.stderr, data.compile_output, data.message, failed && !timedOut && statusId !== 4 ? data.status?.description : '']
        .filter(Boolean)
        .join('\n'),
      exitCode: failed && statusId !== 4 ? 1 : 0, // 4 = Wrong Answer vs. an expected_output we did not send
      executionTimeMs: data.time ? Math.round(parseFloat(data.time) * 1000) : Date.now() - started,
      memoryKb: data.memory ?? undefined,
      timedOut,
    }
  }
}

class DisabledExecutionProvider implements CodeExecutionProvider {
  async execute(): Promise<ExecutionResult> {
    throw new Error(
      'Code execution is disabled in production unless CODE_RUNNER=judge0 (or another isolated runner) is configured. The local runner is not a sandbox.'
    )
  }
}

function pickProvider(): CodeExecutionProvider {
  const choice = (process.env.CODE_RUNNER || '').toLowerCase()
  if (choice === 'judge0') return new Judge0ExecutionProvider()
  if (choice === 'local') return new LocalExecutionProvider()
  if (process.env.NODE_ENV === 'production') return new DisabledExecutionProvider()
  return new LocalExecutionProvider()
}

export const codeExecutionProvider: CodeExecutionProvider = pickProvider()
export { normaliseLanguage }
