import { Router } from 'express'
import rateLimit from 'express-rate-limit'
import { z } from 'zod'
import { codingService } from './coding.service'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole } from '@/middleware/rbac.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok } from '@/utils/apiResponse'
import { Role } from '@prisma/client'

const router = Router()

// Playground runs are CPU-heavy; keep one user from hammering the runner.
const runLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Too many runs — wait a moment and try again', code: 'TOO_MANY_REQUESTS' },
})

const testCaseSchema = z.object({
  input: z.string(),
  expectedOutput: z.string(),
  isHidden: z.boolean().optional(),
  marks: z.number().int().min(0).default(1),
})

const exampleSchema = z.object({
  title: z.string(),
  description: z.string().optional(),
  code: z.string(),
  language: z.string(),
  output: z.string().optional(),
  explanation: z.string().optional(),
})

router.post(
  '/courses/:courseId',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({
    body: z.object({
      title: z.string().min(1),
      description: z.string().min(1),
      constraints: z.array(z.string()).optional(),
      hints: z.array(z.string()).optional(),
      starterCode: z.record(z.string()),
      difficulty: z.enum(['BEGINNER', 'INTERMEDIATE', 'ADVANCED', 'EXPERT']),
      tags: z.array(z.string()).optional(),
      estimatedTime: z.number().int().positive(),
      marks: z.number().int().positive(),
      moduleId: z.string().optional(),
      topicId: z.string().optional(),
      examples: z.array(exampleSchema).optional(),
      testCases: z.array(testCaseSchema).min(1),
    }),
  }),
  asyncHandler(async (req, res) => ok(res, await codingService.create(req.params.courseId, req.body), 'Coding problem created', 201))
)

router.get(
  '/',
  requireAuth,
  asyncHandler(async (req, res) => ok(res, await codingService.listProblems(req.user!.role === Role.STUDENT ? req.user!.id : undefined)))
)

router.post(
  '/run',
  requireAuth,
  runLimiter,
  validate({
    body: z.object({
      code: z.string().min(1).max(100_000),
      language: z.string().min(1),
      stdin: z.string().max(100_000).optional(),
    }),
  }),
  asyncHandler(async (req, res) => ok(res, await codingService.run(req.body)))
)

router.get(
  '/:problemId/attempt',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await codingService.getForAttempt(req.params.problemId)))
)

router.post(
  '/:problemId/submit',
  requireAuth,
  requireRole(Role.STUDENT),
  validate({ body: z.object({ code: z.string().min(1), language: z.string().min(1) }) }),
  asyncHandler(async (req, res) => ok(res, await codingService.submit(req.user!.id, req.params.problemId, req.body), 'Submitted'))
)

router.get(
  '/:problemId/submissions',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await codingService.mySubmissions(req.user!.id, req.params.problemId)))
)

export default router
