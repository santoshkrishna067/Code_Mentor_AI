import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { ContentType, ProgressStatus } from '@prisma/client'
import { gradeSubmission, SubmittedAnswer } from '@/utils/grading'
import { sanitizeQuestionForAttempt, fullQuestionDto } from '@/utils/questionSanitizer'
import { learningService } from '@/modules/learning/learning.service'

function toSummary(q: any) {
  return {
    id: q.id,
    title: q.title,
    description: q.description,
    difficulty: q.difficulty,
    estimatedDuration: q.estimatedDuration,
    passingScore: q.passingScore,
    subtopicId: q.subtopicId,
    isTimed: q.isTimed,
  }
}

export const quizzesService = {
  async create(subtopicId: string, input: any) {
    const subtopic = await prisma.subtopic.findUnique({ where: { id: subtopicId } })
    if (!subtopic) throw ApiError.notFound('Subtopic not found')
    const foundCount = await prisma.question.count({ where: { id: { in: input.questionIds } } })
    if (foundCount !== input.questionIds.length) throw ApiError.badRequest('One or more questionIds do not exist')

    const quiz = await prisma.quiz.create({
      data: {
        subtopicId,
        title: input.title,
        description: input.description,
        difficulty: input.difficulty,
        estimatedDuration: input.estimatedDuration,
        passingScore: input.passingScore,
        isTimed: input.isTimed ?? true,
        questions: { create: input.questionIds.map((questionId: string, order: number) => ({ questionId, order })) },
      },
    })
    return toSummary(quiz)
  },

  async getForAttempt(quizId: string) {
    const quiz = await prisma.quiz.findUnique({
      where: { id: quizId },
      include: { questions: { orderBy: { order: 'asc' }, include: { question: { include: { options: true } } } } },
    })
    if (!quiz) throw ApiError.notFound('Quiz not found')
    return { ...toSummary(quiz), questions: quiz.questions.map((qq) => sanitizeQuestionForAttempt(qq.question)) }
  },

  async submit(studentId: string, quizId: string, answers: SubmittedAnswer[]) {
    const quiz = await prisma.quiz.findUnique({
      where: { id: quizId },
      include: {
        questions: { include: { question: true } },
        subtopic: { include: { topic: { include: { module: true } } } },
      },
    })
    if (!quiz) throw ApiError.notFound('Quiz not found')

    const questions = quiz.questions.map((qq) => ({
      id: qq.question.id,
      correctAnswer: qq.question.correctAnswer,
      marks: qq.question.marks,
      negativeMarks: qq.question.negativeMarks,
    }))
    const result = gradeSubmission(questions, answers, false)
    const passed = result.scorePercent >= quiz.passingScore

    const { xpEarned } = await learningService.recordProgress({
      studentId,
      courseId: quiz.subtopic.topic.module.courseId,
      moduleId: quiz.subtopic.topic.moduleId,
      topicId: quiz.subtopic.topicId,
      subtopicId: quiz.subtopicId,
      contentType: ContentType.QUIZ,
      contentId: quiz.id,
      status: passed ? ProgressStatus.COMPLETED : ProgressStatus.IN_PROGRESS,
      score: result.scorePercent,
    })

    return { ...result, passed, xpEarned }
  },

  async review(quizId: string) {
    const quiz = await prisma.quiz.findUnique({
      where: { id: quizId },
      include: { questions: { orderBy: { order: 'asc' }, include: { question: { include: { options: true } } } } },
    })
    if (!quiz) throw ApiError.notFound('Quiz not found')
    return { ...toSummary(quiz), questions: quiz.questions.map((qq) => fullQuestionDto(qq.question)) }
  },
}
