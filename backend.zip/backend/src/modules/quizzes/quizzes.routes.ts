import { Router } from 'express'
import { z } from 'zod'
import { quizzesService } from './quizzes.service'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole } from '@/middleware/rbac.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok } from '@/utils/apiResponse'
import { Role } from '@prisma/client'

const router = Router()

const answerSchema = z.object({ questionId: z.string(), answer: z.union([z.string(), z.array(z.string())]) })

const createSchema = z.object({
  title: z.string().min(1),
  description: z.string().min(1),
  difficulty: z.enum(['BEGINNER', 'INTERMEDIATE', 'ADVANCED', 'EXPERT']),
  estimatedDuration: z.number().int().positive(),
  passingScore: z.number().int().min(0).max(100),
  isTimed: z.boolean().optional(),
  questionIds: z.array(z.string()).min(1),
})

router.post(
  '/subtopics/:subtopicId',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({ body: createSchema }),
  asyncHandler(async (req, res) => ok(res, await quizzesService.create(req.params.subtopicId, req.body), 'Quiz created', 201))
)

router.get(
  '/:quizId/attempt',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await quizzesService.getForAttempt(req.params.quizId)))
)

router.post(
  '/:quizId/submit',
  requireAuth,
  requireRole(Role.STUDENT),
  validate({ body: z.object({ answers: z.array(answerSchema) }) }),
  asyncHandler(async (req, res) => ok(res, await quizzesService.submit(req.user!.id, req.params.quizId, req.body.answers), 'Submitted'))
)

router.get(
  '/:quizId/review',
  requireAuth,
  asyncHandler(async (req, res) => ok(res, await quizzesService.review(req.params.quizId)))
)

export default router
