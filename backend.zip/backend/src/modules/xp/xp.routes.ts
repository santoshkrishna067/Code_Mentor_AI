import { Router } from 'express'
import { xpService } from './xp.service'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole, requireSelfOrAdmin } from '@/middleware/rbac.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok } from '@/utils/apiResponse'
import { Role } from '@prisma/client'

const router = Router()

router.get(
  '/history',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await xpService.history(req.user!.id)))
)

router.get(
  '/streak',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await xpService.streak(req.user!.id)))
)

router.get(
  '/students/:studentId/history',
  requireAuth,
  requireSelfOrAdmin('studentId'),
  asyncHandler(async (req, res) => ok(res, await xpService.history(req.params.studentId)))
)

router.get(
  '/leaderboard',
  requireAuth,
  asyncHandler(async (req, res) => ok(res, await xpService.leaderboard()))
)

export default router
