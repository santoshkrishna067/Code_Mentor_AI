import { prisma } from '@/config/prisma'
import { XPSource } from '@prisma/client'
import { streakBonusXp } from '@/utils/xpRules'

function todayDateOnly(): Date {
  const d = new Date()
  d.setHours(0, 0, 0, 0)
  return d
}

export const xpService = {
  // Awards XP, updates the denormalized User.xp counter, and updates the
  // daily streak — all in one transaction so they never drift apart.
  async award(studentId: string, amount: number, source: XPSource, description: string, sourceId?: string) {
    if (amount <= 0) return { xpAwarded: 0 }

    const today = todayDateOnly()

    const [, , streakDay] = await prisma.$transaction([
      prisma.xPTransaction.create({ data: { studentId, amount, source, sourceId, description } }),
      prisma.user.update({ where: { id: studentId }, data: { xp: { increment: amount }, lastActiveAt: new Date() } }),
      prisma.streakDay.upsert({
        where: { studentId_date: { studentId, date: today } },
        create: { studentId, date: today, xpEarned: amount, activitiesCompleted: 1 },
        update: { xpEarned: { increment: amount }, activitiesCompleted: { increment: 1 } },
      }),
    ])

    await this.recomputeStreak(studentId)

    return { xpAwarded: amount, streakDay }
  },

  // Recomputes current/longest streak from StreakDay history. Run after every
  // award so User.currentStreak/longestStreak are always consistent with the
  // ledger (never trust a purely incremental counter for something a missed
  // day can silently break).
  async recomputeStreak(studentId: string) {
    const days = await prisma.streakDay.findMany({
      where: { studentId },
      orderBy: { date: 'desc' },
      select: { date: true },
    })
    if (days.length === 0) {
      await prisma.user.update({ where: { id: studentId }, data: { currentStreak: 0 } })
      return
    }

    let current = 0
    let cursor = todayDateOnly()
    const dateSet = new Set(days.map((d) => d.date.toISOString().slice(0, 10)))

    // Walk backwards from today; streak breaks on the first missing day
    // (allow "yesterday" as a valid start if today hasn't been logged yet).
    if (!dateSet.has(cursor.toISOString().slice(0, 10))) {
      cursor = new Date(cursor.getTime() - 86400000)
    }
    while (dateSet.has(cursor.toISOString().slice(0, 10))) {
      current += 1
      cursor = new Date(cursor.getTime() - 86400000)
    }

    let longest = 0
    let run = 0
    let prevDate: Date | null = null
    for (const d of [...days].reverse()) {
      if (prevDate && d.date.getTime() - prevDate.getTime() === 86400000) {
        run += 1
      } else {
        run = 1
      }
      longest = Math.max(longest, run)
      prevDate = d.date
    }

    const bonus = streakBonusXp(current)
    await prisma.user.update({
      where: { id: studentId },
      data: { currentStreak: current, longestStreak: Math.max(longest, current) },
    })

    // Streak milestone bonus (7-day, 30-day) is awarded once per crossing —
    // guarded by checking no STREAK transaction exists yet today.
    if (bonus > 0) {
      const alreadyAwardedToday = await prisma.xPTransaction.findFirst({
        where: { studentId, source: XPSource.STREAK, createdAt: { gte: todayDateOnly() } },
      })
      if (!alreadyAwardedToday) {
        await prisma.xPTransaction.create({
          data: { studentId, amount: bonus, source: XPSource.STREAK, description: `${current}-day streak bonus` },
        })
        await prisma.user.update({ where: { id: studentId }, data: { xp: { increment: bonus } } })
      }
    }
  },

  async history(studentId: string, days = 30) {
    const since = new Date(Date.now() - days * 86400000)
    const transactions = await prisma.xPTransaction.findMany({
      where: { studentId, createdAt: { gte: since } },
      orderBy: { createdAt: 'desc' },
    })
    const user = await prisma.user.findUnique({ where: { id: studentId }, select: { xp: true } })

    const earnedToday = transactions
      .filter((t) => t.createdAt >= todayDateOnly())
      .reduce((sum, t) => sum + t.amount, 0)

    return {
      date: new Date().toISOString(),
      totalXP: user?.xp ?? 0,
      earnedToday,
      history: transactions.map((t) => ({
        id: t.id,
        studentId: t.studentId,
        amount: t.amount,
        source: t.source.toLowerCase(),
        sourceId: t.sourceId ?? undefined,
        description: t.description,
        createdAt: t.createdAt.toISOString(),
      })),
    }
  },

  async streak(studentId: string) {
    const user = await prisma.user.findUnique({
      where: { id: studentId },
      select: { currentStreak: true, longestStreak: true, lastActiveAt: true },
    })
    const streakDays = await prisma.streakDay.findMany({
      where: { studentId },
      orderBy: { date: 'desc' },
      take: 90,
    })
    return {
      currentStreak: user?.currentStreak ?? 0,
      longestStreak: user?.longestStreak ?? 0,
      lastActiveDate: (user?.lastActiveAt ?? new Date()).toISOString(),
      streakHistory: streakDays.map((d) => ({
        date: d.date.toISOString().slice(0, 10),
        xpEarned: d.xpEarned,
        activitiesCompleted: d.activitiesCompleted,
      })),
    }
  },

  async leaderboard(limit = 20) {
    const students = await prisma.user.findMany({
      where: { role: 'STUDENT', isActive: true },
      orderBy: { xp: 'desc' },
      take: limit,
      select: { id: true, name: true, avatar: true, xp: true, currentStreak: true },
    })
    return students.map((s, i) => ({ rank: i + 1, ...s }))
  },
}
