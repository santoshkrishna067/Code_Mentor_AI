import { Router } from 'express'
import { z } from 'zod'
import { Role } from '@prisma/client'
import { prisma } from '@/config/prisma'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole } from '@/middleware/rbac.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok, ApiError } from '@/utils/apiResponse'

const router = Router()
router.use(requireAuth, requireRole(Role.STUDENT))

const isObjectId = (v: string) => /^[a-f\d]{24}$/i.test(v)

router.get(
  '/',
  asyncHandler(async (req, res) => {
    const rows = await prisma.bookmark.findMany({ where: { userId: req.user!.id }, orderBy: { createdAt: 'desc' } })
    return ok(res, rows.map((b) => ({ ...b, createdAt: b.createdAt.toISOString() })))
  })
)

// Toggle: bookmarks the lesson if it isn't bookmarked, removes it if it is.
router.post(
  '/toggle',
  validate({ body: z.object({ subtopicId: z.string().refine(isObjectId, 'Invalid subtopic id') }) }),
  asyncHandler(async (req, res) => {
    const userId = req.user!.id
    const { subtopicId } = req.body as { subtopicId: string }

    const existing = await prisma.bookmark.findUnique({ where: { userId_subtopicId: { userId, subtopicId } } })
    if (existing) {
      await prisma.bookmark.delete({ where: { id: existing.id } })
      return ok(res, { bookmarked: false })
    }

    const sub = await prisma.subtopic.findUnique({
      where: { id: subtopicId },
      include: { topic: { include: { module: { include: { course: true } } } } },
    })
    if (!sub) throw ApiError.notFound('Lesson not found')
    const course = sub.topic.module.course

    await prisma.bookmark.create({
      data: { userId, subtopicId, courseId: course.id, courseName: course.name, courseSlug: course.slug, subtopicTitle: sub.title },
    })
    return ok(res, { bookmarked: true }, 'Bookmarked', 201)
  })
)

router.get(
  '/check/:subtopicId',
  asyncHandler(async (req, res) => {
    if (!isObjectId(req.params.subtopicId)) return ok(res, { bookmarked: false })
    const existing = await prisma.bookmark.findUnique({
      where: { userId_subtopicId: { userId: req.user!.id, subtopicId: req.params.subtopicId } },
    })
    return ok(res, { bookmarked: !!existing })
  })
)

export default router
