import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { genaiTutorProvider, TutorMessage } from './tutor.provider'
import { buildSystemPrompt } from './tutor.provider'

const HISTORY_WINDOW = 20 // most recent messages sent to the provider as context

export const tutorService = {
  // Assembles exactly the hierarchy the project requires the AI to
  // understand: Student -> Course -> Module -> Topic -> Progress ->
  // Performance -> LearningGap. Every field is read from the real tables
  // the rest of the platform uses — this is not a separate/shadow context.
  async buildContext(studentId: string, courseId?: string) {
    const user = await prisma.user.findUnique({ where: { id: studentId } })
    if (!user) throw ApiError.notFound('Student not found')

    const profile = await prisma.studentProfile.findUnique({ where: { userId: studentId } })
    const effectiveCourseId = courseId ?? profile?.currentCourseId ?? undefined

    let courseName: string | undefined
    let moduleTitle: string | undefined
    let topicTitle: string | undefined
    let recentScorePercent: number | undefined

    if (effectiveCourseId) {
      const course = await prisma.course.findUnique({ where: { id: effectiveCourseId } })
      courseName = course?.name

      const lastProgress = await prisma.progress.findFirst({
        where: { studentId, courseId: effectiveCourseId, score: { not: null } },
        orderBy: { completedAt: 'desc' },
        include: { module: true, topic: true },
      })
      moduleTitle = lastProgress?.module?.title
      topicTitle = lastProgress?.topic?.title
      recentScorePercent = lastProgress?.score ?? undefined
    }

    const openGaps = await prisma.learningGap.findMany({
      where: { studentId, resolvedAt: null, ...(effectiveCourseId ? { courseId: effectiveCourseId } : {}) },
      orderBy: { severity: 'asc' },
      take: 5,
    })

    return {
      studentName: user.name,
      courseName,
      moduleTitle,
      topicTitle,
      recentScorePercent,
      openLearningGaps: openGaps.map((g) => ({ concept: g.concept, severity: g.severity.toLowerCase() })),
    }
  },

  // NOTE: the exam-lock check (blockDuringActiveExam) already runs as
  // middleware before this is ever called, per-request, server-side. This
  // service does not re-check it — that would be duplicated security logic
  // living in two places, which is exactly what "critical security must be
  // enforced by backend" warns against splitting across layers.
  async sendMessage(studentId: string, input: { message: string; courseId?: string }) {
    const context = await this.buildContext(studentId, input.courseId)

    const recentHistory = await prisma.aIChatMessage.findMany({
      where: { userId: studentId },
      orderBy: { timestamp: 'desc' },
      take: HISTORY_WINDOW,
    })
    const history: TutorMessage[] = [
      { role: 'system', content: buildSystemPrompt(context) },
      ...recentHistory.reverse().map((m) => ({ role: m.role as TutorMessage['role'], content: m.content })),
      { role: 'user', content: input.message },
    ]

    await prisma.aIChatMessage.create({
      data: { userId: studentId, role: 'user', content: input.message, context: context as any },
    })

    let replyText: string
    try {
      replyText = await genaiTutorProvider.chat(history, context)
    } catch (err) {
      throw ApiError.internal('The AI Tutor is temporarily unavailable. ' + (err as Error).message)
    }

    const reply = await prisma.aIChatMessage.create({
      data: { userId: studentId, role: 'assistant', content: replyText, context: context as any },
    })

    return { message: reply.content, timestamp: reply.timestamp.toISOString() }
  },

  async history(studentId: string, limit = 50) {
    const messages = await prisma.aIChatMessage.findMany({
      where: { userId: studentId },
      orderBy: { timestamp: 'desc' },
      take: limit,
    })
    return messages.reverse().map((m) => ({ role: m.role, content: m.content, timestamp: m.timestamp.toISOString() }))
  },

  async clearHistory(studentId: string) {
    await prisma.aIChatMessage.deleteMany({ where: { userId: studentId } })
  },
}
