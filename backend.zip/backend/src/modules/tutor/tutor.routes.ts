import { Router } from 'express'
import { z } from 'zod'
import { tutorService } from './tutor.service'
import { genaiTutorProvider } from './tutor.provider'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole } from '@/middleware/rbac.middleware'
import { blockDuringActiveExam } from '@/middleware/examLock.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok } from '@/utils/apiResponse'
import { Role } from '@prisma/client'

const router = Router()

// CRITICAL: blockDuringActiveExam is applied to every route in this file,
// not just /message. History/clear also touch tutor state, and blocking
// only the "send" endpoint would still leak that the tutor exists / respond
// to non-chat requests during a locked exam. The middleware itself is a
// pure server-side DB check (ExamAttempt.status === IN_PROGRESS) — nothing
// the frontend does or omits can bypass it.
router.use(requireAuth, requireRole(Role.STUDENT), blockDuringActiveExam)

router.post(
  '/message',
  validate({ body: z.object({ message: z.string().min(1).max(4000), courseId: z.string().optional() }) }),
  asyncHandler(async (req, res) => ok(res, await tutorService.sendMessage(req.user!.id, req.body)))
)

router.get(
  '/status',
  asyncHandler(async (_req, res) => ok(res, await genaiTutorProvider.status()))
)

router.get(
  '/history',
  asyncHandler(async (req, res) => ok(res, await tutorService.history(req.user!.id)))
)

router.delete(
  '/history',
  asyncHandler(async (req, res) => {
    await tutorService.clearHistory(req.user!.id)
    return ok(res, null, 'Tutor conversation history cleared')
  })
)

export default router
