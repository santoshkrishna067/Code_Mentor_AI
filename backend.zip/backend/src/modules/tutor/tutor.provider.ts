export interface TutorMessage {
  role: 'user' | 'assistant' | 'system'
  content: string
}

export interface TutorContext {
  studentName: string
  courseName?: string
  moduleTitle?: string
  topicTitle?: string
  recentScorePercent?: number
  openLearningGaps: { concept: string; severity: string }[]
}

export interface TutorStatus {
  provider: string
  ready: boolean
  hint?: string
}

export interface GenAITutorProvider {
  chat(history: TutorMessage[], context: TutorContext): Promise<string>
  status(): Promise<TutorStatus>
}

function buildSystemPrompt(context: TutorContext): string {
  const gapsLine = context.openLearningGaps.length
    ? `Known weak areas to be extra patient about: ${context.openLearningGaps.map((g) => g.concept).join(', ')}.`
    : ''
  return [
    `You are a coding tutor for ${context.studentName}, a student on Code Mentor AI.`,
    context.courseName
      ? `They are currently working on: ${context.courseName}${context.moduleTitle ? ` > ${context.moduleTitle}` : ''}${context.topicTitle ? ` > ${context.topicTitle}` : ''}.`
      : '',
    context.recentScorePercent !== undefined ? `Their most recent recorded score was ${context.recentScorePercent}%.` : '',
    gapsLine,
    'Explain concepts clearly, use short examples, and never simply hand over a full solution to a graded exercise — guide them toward it.',
  ]
    .filter(Boolean)
    .join(' ')
}

// Ollama runs entirely locally — no API key, no external network call, no
// per-token cost. Requires Ollama installed and running on this machine
// (https://ollama.com), with a model pulled ahead of time, e.g.:
//   ollama pull qwen2.5-coder:7b
const OLLAMA_BASE_URL = process.env.OLLAMA_BASE_URL || 'http://localhost:11434'
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'qwen2.5-coder:7b'

export class OllamaTutorProvider implements GenAITutorProvider {
  async status(): Promise<TutorStatus> {
    try {
      const res = await fetch(`${OLLAMA_BASE_URL}/api/tags`)
      if (!res.ok) return { provider: 'ollama', ready: false, hint: `Ollama answered with HTTP ${res.status}.` }
      const data = (await res.json()) as { models?: { name: string }[] }
      const names = (data.models ?? []).map((m) => m.name)
      const has = names.some((n) => n === OLLAMA_MODEL || n.startsWith(`${OLLAMA_MODEL}:`) || OLLAMA_MODEL.startsWith(`${n}:`))
      return has
        ? { provider: 'ollama', ready: true }
        : { provider: 'ollama', ready: false, hint: `Ollama is running but model "${OLLAMA_MODEL}" is not installed. Run: ollama pull ${OLLAMA_MODEL}` }
    } catch {
      return {
        provider: 'ollama',
        ready: false,
        hint: `Ollama is not running at ${OLLAMA_BASE_URL}. Install it from ollama.com, then run: ollama pull ${OLLAMA_MODEL}`,
      }
    }
  }

  async chat(history: TutorMessage[], context: TutorContext): Promise<string> {
    const messages = [{ role: 'system' as const, content: buildSystemPrompt(context) }, ...history.filter((m) => m.role !== 'system')]

    let res: Response
    try {
      res = await fetch(`${OLLAMA_BASE_URL}/api/chat`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ model: OLLAMA_MODEL, messages, stream: false }),
      })
    } catch (err) {
      throw new Error(
        `Could not reach Ollama at ${OLLAMA_BASE_URL}. Is Ollama running? Start it with "ollama serve" (it may already be running as a background service). Original error: ${(err as Error).message}`
      )
    }

    if (!res.ok) {
      const body = await res.text()
      throw new Error(`Ollama request failed: ${res.status} ${body}`)
    }

    const data = (await res.json()) as { message?: { content?: string } }
    const text = data.message?.content
    if (!text) throw new Error('Ollama returned an empty response')
    return text
  }
}

// ---------------------------------------------------------------------------
// Anthropic (Claude) provider — no local install needed, just an API key:
//   TUTOR_PROVIDER=anthropic
//   ANTHROPIC_API_KEY=sk-ant-...
//   ANTHROPIC_MODEL=claude-haiku-4-5-20251001   (optional)
// ---------------------------------------------------------------------------
const ANTHROPIC_MODEL = process.env.ANTHROPIC_MODEL || 'claude-haiku-4-5-20251001'

export class AnthropicTutorProvider implements GenAITutorProvider {
  async status(): Promise<TutorStatus> {
    return process.env.ANTHROPIC_API_KEY
      ? { provider: 'anthropic', ready: true }
      : { provider: 'anthropic', ready: false, hint: 'Set ANTHROPIC_API_KEY in backend/.env and restart the backend.' }
  }

  async chat(history: TutorMessage[], context: TutorContext): Promise<string> {
    const apiKey = process.env.ANTHROPIC_API_KEY
    if (!apiKey) throw new Error('ANTHROPIC_API_KEY is not set in backend/.env.')

    // The API needs strictly alternating roles that start with "user".
    const merged: { role: 'user' | 'assistant'; content: string }[] = []
    for (const m of history) {
      if (m.role === 'system') continue
      const last = merged[merged.length - 1]
      if (last && last.role === m.role) last.content += `\n\n${m.content}`
      else merged.push({ role: m.role, content: m.content })
    }
    while (merged.length && merged[0].role !== 'user') merged.shift()

    let res: Response
    try {
      res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': apiKey, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: ANTHROPIC_MODEL, max_tokens: 1024, system: buildSystemPrompt(context), messages: merged }),
      })
    } catch (err) {
      throw new Error(`Could not reach the Anthropic API: ${(err as Error).message}`)
    }
    if (!res.ok) throw new Error(`Anthropic API error ${res.status}: ${await res.text()}`)

    const data = (await res.json()) as { content?: { type: string; text?: string }[] }
    const text = (data.content ?? []).filter((b) => b.type === 'text').map((b) => b.text).join('\n').trim()
    if (!text) throw new Error('The model returned an empty response')
    return text
  }
}

export const genaiTutorProvider: GenAITutorProvider =
  (process.env.TUTOR_PROVIDER || '').toLowerCase() === 'anthropic' ? new AnthropicTutorProvider() : new OllamaTutorProvider()
export { buildSystemPrompt }
