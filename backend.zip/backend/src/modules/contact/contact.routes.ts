import { Router } from 'express'
import rateLimit from 'express-rate-limit'
import { z } from 'zod'
import { ContactStatus, Role } from '@prisma/client'
import { prisma } from '@/config/prisma'
import { requireAuth, optionalAuth } from '@/middleware/auth.middleware'
import { requireRole } from '@/middleware/rbac.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok, paginated, ApiError } from '@/utils/apiResponse'
import { notificationsService } from '@/modules/notifications/notifications.service'
import { logger } from '@/utils/logger'

const router = Router()

const contactLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Too many messages sent, please try again later', code: 'TOO_MANY_REQUESTS' },
})

// PUBLIC: anyone can send a message from the Contact page. It is stored in
// the database (collection: contact_messages) and every admin gets a
// notification, so there is a real destination for it.
router.post(
  '/',
  contactLimiter,
  optionalAuth,
  validate({
    body: z.object({
      name: z.string().trim().min(1).max(100),
      email: z.string().trim().email().max(200),
      subject: z.string().trim().min(1).max(200),
      message: z.string().trim().min(5).max(5000),
    }),
  }),
  asyncHandler(async (req, res) => {
    const msg = await prisma.contactMessage.create({ data: { ...req.body, userId: req.user?.id } })

    // Best effort: a notification failure must never lose the message itself.
    try {
      const admins = await prisma.user.findMany({ where: { role: Role.ADMIN, isActive: true }, select: { id: true } })
      await Promise.all(
        admins.map((a) =>
          notificationsService.create({
            userId: a.id,
            type: 'INFO',
            title: 'New contact message',
            message: `${req.body.name}: ${req.body.subject}`,
            link: '/admin/messages',
          })
        )
      )
    } catch (err) {
      logger.error({ err }, 'Could not notify admins of contact message')
    }

    return ok(res, { id: msg.id }, 'Message sent. We will get back to you soon.', 201)
  })
)

// ADMIN: inbox
router.get(
  '/',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({
    query: z.object({
      page: z.coerce.number().int().min(1).default(1),
      limit: z.coerce.number().int().min(1).max(100).default(20),
      status: z.nativeEnum(ContactStatus).optional(),
    }),
  }),
  asyncHandler(async (req, res) => {
    const { page, limit, status } = req.query as unknown as { page: number; limit: number; status?: ContactStatus }
    const where = status ? { status } : {}
    const [total, rows] = await Promise.all([
      prisma.contactMessage.count({ where }),
      prisma.contactMessage.findMany({ where, orderBy: { createdAt: 'desc' }, skip: (page - 1) * limit, take: limit }),
    ])
    return paginated(
      res,
      rows.map((m) => ({ ...m, createdAt: m.createdAt.toISOString() })),
      { page, limit, total }
    )
  })
)

router.patch(
  '/:id',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({ body: z.object({ status: z.nativeEnum(ContactStatus) }) }),
  asyncHandler(async (req, res) => {
    const existing = await prisma.contactMessage.findUnique({ where: { id: req.params.id } })
    if (!existing) throw ApiError.notFound('Message not found')
    const updated = await prisma.contactMessage.update({ where: { id: req.params.id }, data: { status: req.body.status } })
    return ok(res, { ...updated, createdAt: updated.createdAt.toISOString() })
  })
)

router.delete(
  '/:id',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => {
    const existing = await prisma.contactMessage.findUnique({ where: { id: req.params.id } })
    if (!existing) throw ApiError.notFound('Message not found')
    await prisma.contactMessage.delete({ where: { id: req.params.id } })
    return ok(res, null, 'Message deleted')
  })
)

export default router
