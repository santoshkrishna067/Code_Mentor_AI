import { Router } from 'express'
import { z } from 'zod'
import { notificationsService } from './notifications.service'
import { requireAuth } from '@/middleware/auth.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok, paginated } from '@/utils/apiResponse'

const router = Router()

const listQuery = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  unreadOnly: z.coerce.boolean().default(false),
})

router.get(
  '/',
  requireAuth,
  validate({ query: listQuery }),
  asyncHandler(async (req, res) => {
    const q = req.query as unknown as z.infer<typeof listQuery>
    const { data, total, unreadCount } = await notificationsService.list(req.user!.id, q)
    res.setHeader('X-Unread-Count', String(unreadCount))
    return paginated(res, data, { page: q.page, limit: q.limit, total })
  })
)

router.patch(
  '/:id/read',
  requireAuth,
  asyncHandler(async (req, res) => ok(res, await notificationsService.markRead(req.user!.id, req.params.id)))
)

router.patch(
  '/read-all',
  requireAuth,
  asyncHandler(async (req, res) => {
    await notificationsService.markAllRead(req.user!.id)
    return ok(res, null, 'All notifications marked as read')
  })
)

router.delete(
  '/:id',
  requireAuth,
  asyncHandler(async (req, res) => {
    await notificationsService.remove(req.user!.id, req.params.id)
    return ok(res, null, 'Notification deleted')
  })
)

export default router
