import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { NotificationType } from '@prisma/client'

function toDto(n: any) {
  return {
    id: n.id,
    userId: n.userId,
    type: n.type.toLowerCase(),
    title: n.title,
    message: n.message,
    link: n.link ?? undefined,
    isRead: n.isRead,
    createdAt: n.createdAt.toISOString(),
    expiresAt: n.expiresAt?.toISOString(),
  }
}

export const notificationsService = {
  async create(input: { userId: string; type: NotificationType; title: string; message: string; link?: string; expiresAt?: Date }) {
    const notification = await prisma.notification.create({ data: input })
    return toDto(notification)
  },

  async createMany(inputs: { userId: string; type: NotificationType; title: string; message: string; link?: string }[]) {
    if (inputs.length === 0) return
    await prisma.notification.createMany({ data: inputs })
  },

  async list(userId: string, opts: { unreadOnly?: boolean; page: number; limit: number }) {
    const where = { userId, ...(opts.unreadOnly ? { isRead: false } : {}) }
    const [total, unreadCount, notifications] = await Promise.all([
      prisma.notification.count({ where }),
      prisma.notification.count({ where: { userId, isRead: false } }),
      prisma.notification.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (opts.page - 1) * opts.limit,
        take: opts.limit,
      }),
    ])
    return { data: notifications.map(toDto), total, unreadCount }
  },

  async markRead(userId: string, notificationId: string) {
    const n = await prisma.notification.findUnique({ where: { id: notificationId } })
    if (!n || n.userId !== userId) throw ApiError.notFound('Notification not found')
    const updated = await prisma.notification.update({ where: { id: notificationId }, data: { isRead: true } })
    return toDto(updated)
  },

  async markAllRead(userId: string) {
    await prisma.notification.updateMany({ where: { userId, isRead: false }, data: { isRead: true } })
  },

  async remove(userId: string, notificationId: string) {
    const n = await prisma.notification.findUnique({ where: { id: notificationId } })
    if (!n || n.userId !== userId) throw ApiError.notFound('Notification not found')
    await prisma.notification.delete({ where: { id: notificationId } })
  },
}
