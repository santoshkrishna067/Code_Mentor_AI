import { Router } from 'express'
import crypto from 'crypto'
import { Role } from '@prisma/client'
import { prisma } from '@/config/prisma'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole } from '@/middleware/rbac.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok, ApiError } from '@/utils/apiResponse'
import { learningService } from '@/modules/learning/learning.service'
import { notificationsService } from '@/modules/notifications/notifications.service'

const router = Router()

const toDto = (c: any) => ({
  id: c.id,
  courseId: c.courseId,
  courseName: c.course?.name,
  courseSlug: c.course?.slug,
  issuedAt: c.issuedAt.toISOString(),
  verificationCode: c.verificationCode,
})

// PUBLIC: anyone with a verification code can confirm a certificate is real.
router.get(
  '/verify/:code',
  asyncHandler(async (req, res) => {
    const cert = await prisma.certificate.findUnique({
      where: { verificationCode: req.params.code },
      include: { course: true, student: { include: { user: true } } },
    })
    if (!cert) throw ApiError.notFound('No certificate found for this code')
    return ok(res, { ...toDto(cert), studentName: cert.student.user.name, valid: true })
  })
)

router.get(
  '/me',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => {
    const rows = await prisma.certificate.findMany({
      where: { studentId: req.user!.id },
      include: { course: true },
      orderBy: { issuedAt: 'desc' },
    })
    return ok(res, rows.map(toDto))
  })
)

// A certificate is issued only when the student has genuinely completed 100%
// of the course's lessons — never on request alone.
router.post(
  '/courses/:courseId/claim',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => {
    const studentId = req.user!.id
    const { courseId } = req.params
    if (!/^[a-f\d]{24}$/i.test(courseId)) throw ApiError.badRequest('Invalid course id')

    const existing = await prisma.certificate.findUnique({ where: { studentId_courseId: { studentId, courseId } }, include: { course: true } })
    if (existing) return ok(res, toDto(existing), 'Certificate already issued')

    const progress = await learningService.getCourseProgress(studentId, courseId)
    if ((progress.overallProgress ?? 0) < 100) {
      throw ApiError.badRequest(`Complete the whole course first — you are at ${progress.overallProgress ?? 0}%.`)
    }

    const code = crypto.randomBytes(8).toString('hex').toUpperCase()
    const cert = await prisma.certificate.create({
      data: { studentId, courseId, verificationCode: code, certificateUrl: `/certificates/verify/${code}` },
      include: { course: true },
    })
    await notificationsService.create({
      userId: studentId,
      type: 'ACHIEVEMENT',
      title: 'Certificate earned',
      message: `You completed ${cert.course.name}.`,
      link: '/certificates',
    })
    return ok(res, toDto(cert), 'Certificate issued', 201)
  })
)

export default router
