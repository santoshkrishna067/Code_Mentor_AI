// Pure decision logic for webcam proctoring: no database, no network, no clock
// of its own (callers pass `now`), so it is fully unit-testable.
//
// The face-analysis service reports what ONE frame looks like. A single frame
// proves nothing — people blink, turn to sneeze, glance at the keyboard — so
// this module only raises a warning when a condition has been true for a
// sustained period, and never raises the same warning more than once per
// cooldown. That keeps the escalation policy in proctoring.service.ts (3 HIGH or
// 8 total warnings ends the attempt) from being tripped by one flickering
// detection.

export type VisionWarningType = 'NO_FACE' | 'MULTIPLE_FACES' | 'PHONE_DETECTED' | 'LOOKING_AWAY'
export type VisionSeverity = 'LOW' | 'MEDIUM' | 'HIGH'
export type VisionStatus = 'ok' | 'calibrating' | 'no_face' | 'multiple_faces' | 'phone' | 'looking_away'

export interface FaceBox {
  x: number
  y: number
  w: number
  h: number
}

/** Shape returned by the Python face-analysis service (see proctoring.vision.schema.ts). */
export interface VisionFrame {
  frame: { width: number; height: number }
  faceCount: number
  faces: FaceBox[]
  head: { yaw: number; pitch: number } | null
  gaze: string | null
  mouthOpen: boolean | null
  blink: boolean | null
  objects: { label: string; confidence: number }[]
}

export interface DecidedWarning {
  type: VisionWarningType
  severity: VisionSeverity
  message: string
  evidence: string
}

export interface DecidedEvent {
  type: string
  description: string
  metadata?: Record<string, unknown>
}

export interface AnnotatedFace extends FaceBox {
  /** false for small background faces (poster, far-away person) that are ignored */
  significant: boolean
}

export interface VisionDecision {
  status: VisionStatus
  faces: AnnotatedFace[]
  warnings: DecidedWarning[]
  events: DecidedEvent[]
}

// ---- Tunable thresholds ---------------------------------------------------

/** How long (ms) a condition must stay true before it becomes a warning. */
export const HOLD_MS: Record<VisionWarningType, number> = {
  NO_FACE: 4_000,
  MULTIPLE_FACES: 2_000,
  PHONE_DETECTED: 2_000,
  LOOKING_AWAY: 5_000,
}

/** Minimum time (ms) between two warnings of the same type. */
export const COOLDOWN_MS = 60_000

export const SEVERITY: Record<VisionWarningType, VisionSeverity> = {
  NO_FACE: 'MEDIUM',
  MULTIPLE_FACES: 'HIGH',
  PHONE_DETECTED: 'HIGH',
  LOOKING_AWAY: 'LOW',
}

/** Head turned this many degrees away from the student's own baseline = looking away. */
export const YAW_LIMIT_DEG = 35
export const PITCH_LIMIT_DEG = 30

/** First N single-face frames define the student's "looking at the screen" baseline. */
export const BASELINE_SAMPLES = 6
/** A baseline further than this from straight-ahead is clamped (guards against a bad start). */
export const BASELINE_CLAMP_DEG = 20

/** A second face counts only if it is at least this fraction of the biggest face's width. */
export const MIN_SECONDARY_FACE_RATIO = 0.45

/** If frames stop for longer than this, "sustained" timers restart instead of spanning the gap. */
export const MAX_FRAME_GAP_MS = 8_000

/** Objects that are only logged for the admin (never a warning by themselves). */
export const WATCHED_OBJECTS = new Set(['laptop', 'book', 'tvmonitor', 'remote'])
export const OBJECT_EVENT_COOLDOWN_MS = 120_000
export const OBJECT_EVENT_MIN_CONFIDENCE = 0.55
export const PHONE_LABEL = 'cell phone'

const MESSAGES: Record<VisionWarningType, string> = {
  NO_FACE: 'Your face was not visible to the camera. Please stay in view.',
  MULTIPLE_FACES: 'More than one person was detected in the camera.',
  PHONE_DETECTED: 'A mobile phone was detected in the camera.',
  LOOKING_AWAY: 'You appear to be looking away from the screen.',
}

// ---- State ----------------------------------------------------------------

export interface VisionState {
  baselineSamples: { yaw: number; pitch: number }[]
  baseline: { yaw: number; pitch: number } | null
  activeSince: Partial<Record<VisionWarningType, number>>
  lastFiredAt: Partial<Record<VisionWarningType, number>>
  lastObjectEventAt: Record<string, number>
  lastFrameAt: number | null
}

export function createVisionState(): VisionState {
  return {
    baselineSamples: [],
    baseline: null,
    activeSince: {},
    lastFiredAt: {},
    lastObjectEventAt: {},
    lastFrameAt: null,
  }
}

function median(values: number[]): number {
  const sorted = [...values].sort((a, b) => a - b)
  const mid = Math.floor(sorted.length / 2)
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2
}

function clamp(v: number, limit: number): number {
  return Math.max(-limit, Math.min(limit, v))
}

export function annotateFaces(faces: FaceBox[]): AnnotatedFace[] {
  const maxW = faces.reduce((m, f) => Math.max(m, f.w), 0)
  return faces.map((f) => ({ ...f, significant: maxW > 0 && f.w >= MIN_SECONDARY_FACE_RATIO * maxW }))
}

// ---- Evaluation -----------------------------------------------------------

export function evaluateFrame(state: VisionState, input: VisionFrame, now: number): VisionDecision {
  if (state.lastFrameAt !== null && now - state.lastFrameAt > MAX_FRAME_GAP_MS) {
    state.activeSince = {}
  }
  state.lastFrameAt = now

  const faces = annotateFaces(input.faces)
  const significantCount = faces.filter((f) => f.significant).length
  const phoneSeen = input.objects.some((o) => o.label === PHONE_LABEL)

  // Collect the baseline from the first few clean single-face frames.
  if (!state.baseline && significantCount === 1 && input.head) {
    state.baselineSamples.push({ yaw: input.head.yaw, pitch: input.head.pitch })
    if (state.baselineSamples.length >= BASELINE_SAMPLES) {
      state.baseline = {
        yaw: clamp(median(state.baselineSamples.map((s) => s.yaw)), BASELINE_CLAMP_DEG),
        pitch: clamp(median(state.baselineSamples.map((s) => s.pitch)), BASELINE_CLAMP_DEG),
      }
    }
  }

  let relYaw = 0
  let relPitch = 0
  let lookingAway = false
  if (state.baseline && significantCount === 1 && input.head) {
    relYaw = input.head.yaw - state.baseline.yaw
    relPitch = input.head.pitch - state.baseline.pitch
    lookingAway = Math.abs(relYaw) >= YAW_LIMIT_DEG || Math.abs(relPitch) >= PITCH_LIMIT_DEG
  }

  const conditions: Record<VisionWarningType, boolean> = {
    NO_FACE: significantCount === 0,
    MULTIPLE_FACES: significantCount >= 2,
    PHONE_DETECTED: phoneSeen,
    LOOKING_AWAY: lookingAway,
  }

  const evidenceFor: Record<VisionWarningType, string> = {
    NO_FACE: 'faces detected: 0',
    MULTIPLE_FACES: `faces detected: ${significantCount}`,
    PHONE_DETECTED: `cell phone confidence ${Math.max(0, ...input.objects.filter((o) => o.label === PHONE_LABEL).map((o) => o.confidence)).toFixed(2)}`,
    LOOKING_AWAY: `head yaw ${relYaw.toFixed(0)} deg, pitch ${relPitch.toFixed(0)} deg (relative to start of exam)`,
  }

  const warnings: DecidedWarning[] = []
  for (const type of Object.keys(conditions) as VisionWarningType[]) {
    if (!conditions[type]) {
      delete state.activeSince[type]
      continue
    }
    const since = state.activeSince[type] ?? now
    state.activeSince[type] = since

    const heldLongEnough = now - since >= HOLD_MS[type]
    const lastFired = state.lastFiredAt[type]
    const cooledDown = lastFired === undefined || now - lastFired >= COOLDOWN_MS
    if (heldLongEnough && cooledDown) {
      warnings.push({ type, severity: SEVERITY[type], message: MESSAGES[type], evidence: evidenceFor[type] })
      state.lastFiredAt[type] = now
      state.activeSince[type] = now
    }
  }

  const events: DecidedEvent[] = []
  for (const obj of input.objects) {
    if (!WATCHED_OBJECTS.has(obj.label) || obj.confidence < OBJECT_EVENT_MIN_CONFIDENCE) continue
    const last = state.lastObjectEventAt[obj.label]
    if (last !== undefined && now - last < OBJECT_EVENT_COOLDOWN_MS) continue
    state.lastObjectEventAt[obj.label] = now
    events.push({
      type: 'OBJECT_SEEN',
      description: `A "${obj.label}" was visible in the camera`,
      metadata: { label: obj.label, confidence: obj.confidence, gaze: input.gaze, mouthOpen: input.mouthOpen },
    })
  }

  let status: VisionStatus = 'ok'
  if (conditions.MULTIPLE_FACES) status = 'multiple_faces'
  else if (conditions.PHONE_DETECTED) status = 'phone'
  else if (conditions.NO_FACE) status = 'no_face'
  else if (conditions.LOOKING_AWAY) status = 'looking_away'
  else if (!state.baseline) status = 'calibrating'

  return { status, faces, warnings, events }
}
