import express, { Router } from 'express'
import rateLimit from 'express-rate-limit'
import { z } from 'zod'
import { proctoringService } from './proctoring.service'
import { proctoringVisionService } from './proctoring.vision.service'
import { warningSchema, eventSchema } from '@/modules/exams/exams.validation'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole } from '@/middleware/rbac.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok } from '@/utils/apiResponse'
import { Role } from '@prisma/client'

const router = Router()

router.get(
  '/sessions/:examAttemptId',
  requireAuth,
  asyncHandler(async (req, res) =>
    ok(res, await proctoringService.getSession(req.user!.id, req.params.examAttemptId, req.user!.role === Role.ADMIN))
  )
)

// Called by the client's webcam-based detection model (e.g. face-api.js /
// MediaPipe running in the browser) for routine telemetry — heartbeats,
// "face detected normally" pings, etc. Does not affect exam state.
router.post(
  '/sessions/:examAttemptId/events',
  requireAuth,
  requireRole(Role.STUDENT),
  validate({ body: eventSchema }),
  asyncHandler(async (req, res) => ok(res, await proctoringService.reportEvent(req.user!.id, req.params.examAttemptId, req.body)))
)

// Called when the client's detection model flags something: no face,
// multiple faces, a phone, sustained looking-away, a tab switch, or other
// suspicious activity. The server applies the escalation policy here — see
// proctoring.service.ts's documented thresholds — and may end the exam
// attempt as a result, reflected in the response's `escalated` field.
router.post(
  '/sessions/:examAttemptId/warnings',
  requireAuth,
  requireRole(Role.STUDENT),
  validate({ body: warningSchema }),
  asyncHandler(async (req, res) => ok(res, await proctoringService.reportWarning(req.user!.id, req.params.examAttemptId, req.body)))
)

// One webcam frame (image/jpeg) from the student's browser, roughly once a
// second. The server runs face analysis on it (Python service), applies the
// sustained-condition rules, and records warnings through the same escalation
// policy as the routes above. Rate-limited per student rather than per IP, so a
// whole classroom behind one network address is not throttled together.
const frameLimiter = rateLimit({
  windowMs: 60_000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.user?.id ?? 'anonymous',
})

router.post(
  '/sessions/:examAttemptId/frame',
  requireAuth,
  requireRole(Role.STUDENT),
  frameLimiter,
  express.raw({ type: 'image/jpeg', limit: '1mb' }),
  asyncHandler(async (req, res) => ok(res, await proctoringVisionService.processFrame(req.user!.id, req.params.examAttemptId, req.body)))
)

router.patch(
  '/warnings/:warningId/review',
  requireAuth,
  requireRole(Role.ADMIN),
  validate({ body: z.object({ notes: z.string().min(1) }) }),
  asyncHandler(async (req, res) => ok(res, await proctoringService.reviewWarning(req.user!.id, req.params.warningId, req.body.notes), 'Warning reviewed'))
)

export default router
