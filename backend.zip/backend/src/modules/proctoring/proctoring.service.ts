import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { ExamAttemptStatus, WarningSeverity } from '@prisma/client'
import { examAttemptsService } from '@/modules/exams/attempts.service'

// Documented escalation policy: this is the ONLY place that decides when a
// proctoring warning trail becomes serious enough to end the exam attempt.
// Thresholds are intentionally conservative (a single false positive from a
// webcam model should never end someone's exam) — termination requires a
// *pattern*, not one flicker.
const HIGH_SEVERITY_TERMINATION_THRESHOLD = 3 // 3+ HIGH severity warnings in one session
const TOTAL_WARNING_TERMINATION_THRESHOLD = 8 // or 8+ warnings of any severity

function escalationReason(highCount: number, totalCount: number): string | null {
  if (highCount >= HIGH_SEVERITY_TERMINATION_THRESHOLD) {
    return `${highCount} high-severity proctoring warnings recorded in this session`
  }
  if (totalCount >= TOTAL_WARNING_TERMINATION_THRESHOLD) {
    return `${totalCount} total proctoring warnings recorded in this session`
  }
  return null
}

async function loadOwnedSession(studentId: string, examAttemptId: string) {
  const session = await prisma.proctoringSession.findUnique({ where: { examAttemptId } })
  if (!session || session.studentId !== studentId) throw ApiError.notFound('Proctoring session not found')
  return session
}

export const proctoringService = {
  async getSession(requesterId: string, examAttemptId: string, isAdmin: boolean) {
    const session = await prisma.proctoringSession.findUnique({
      where: { examAttemptId },
      include: { warnings: { orderBy: { timestamp: 'desc' } }, events: { orderBy: { timestamp: 'desc' }, take: 100 } },
    })
    if (!session) throw ApiError.notFound('Proctoring session not found')
    if (!isAdmin && session.studentId !== requesterId) throw ApiError.forbidden('You may only view your own proctoring session')

    return {
      id: session.id,
      examAttemptId: session.examAttemptId,
      status: session.status.toLowerCase(),
      cameraEnabled: session.cameraEnabled,
      microphoneEnabled: session.microphoneEnabled,
      screenShareEnabled: session.screenShareEnabled,
      startedAt: session.startedAt.toISOString(),
      endedAt: session.endedAt?.toISOString(),
      warnings: session.warnings.map((w) => ({
        id: w.id,
        type: w.type.toLowerCase(),
        severity: w.severity.toLowerCase(),
        message: w.message,
        timestamp: w.timestamp.toISOString(),
        evidence: w.evidence ?? undefined,
        isReviewed: w.isReviewed,
      })),
      events: session.events.map((e) => ({ type: e.type, description: e.description, timestamp: e.timestamp.toISOString() })),
    }
  },

  async reportEvent(studentId: string, examAttemptId: string, input: { type: string; description: string; metadata?: Record<string, unknown> }) {
    const session = await loadOwnedSession(studentId, examAttemptId)
    if (session.status !== 'ACTIVE') throw ApiError.conflict('This proctoring session is no longer active')

    await prisma.proctoringEvent.create({
      data: { sessionId: session.id, type: input.type, description: input.description, metadata: input.metadata as any },
    })
    return { logged: true }
  },

  // Records a warning and applies the escalation policy. Returns whether the
  // attempt was terminated as a result, so the route/client can react
  // immediately (stop the exam UI) instead of waiting for the next poll.
  async reportWarning(
    studentId: string,
    examAttemptId: string,
    input: { type: string; severity: 'LOW' | 'MEDIUM' | 'HIGH'; message: string; evidence?: string }
  ) {
    const session = await loadOwnedSession(studentId, examAttemptId)
    if (session.status !== 'ACTIVE') throw ApiError.conflict('This proctoring session is no longer active')

    await prisma.proctoringWarning.create({
      data: {
        sessionId: session.id,
        type: input.type as any,
        severity: input.severity as WarningSeverity,
        message: input.message,
        evidence: input.evidence,
      },
    })

    const [highCount, totalCount] = await Promise.all([
      prisma.proctoringWarning.count({ where: { sessionId: session.id, severity: WarningSeverity.HIGH } }),
      prisma.proctoringWarning.count({ where: { sessionId: session.id } }),
    ])

    const reason = escalationReason(highCount, totalCount)
    if (!reason) return { escalated: false, highCount, totalCount }

    // Only escalate if the underlying exam attempt is still genuinely in
    // progress — avoids a race where the student already legitimately
    // submitted moments before a queued warning arrives.
    const attempt = await prisma.examAttempt.findUnique({ where: { id: examAttemptId }, select: { status: true } })
    if (attempt?.status !== ExamAttemptStatus.IN_PROGRESS) return { escalated: false, highCount, totalCount }

    await examAttemptsService.flagAndFinalize(examAttemptId, reason)
    return { escalated: true, reason, highCount, totalCount }
  },

  async reviewWarning(adminId: string, warningId: string, notes: string) {
    const warning = await prisma.proctoringWarning.findUnique({ where: { id: warningId } })
    if (!warning) throw ApiError.notFound('Warning not found')
    return prisma.proctoringWarning.update({
      where: { id: warningId },
      data: { isReviewed: true, reviewedById: adminId, reviewNotes: notes },
    })
  },

  // Admin review queue: every warning across every attempt of one exam,
  // newest first, with the student attached.
  async listWarningsForExam(examId: string) {
    const warnings = await prisma.proctoringWarning.findMany({
      where: { session: { examAttempt: { examId } } },
      orderBy: { timestamp: 'desc' },
      include: { session: { include: { examAttempt: { include: { student: { include: { user: true } } } } } } },
    })
    return warnings.map((w) => ({
      id: w.id,
      examAttemptId: w.session.examAttemptId,
      studentId: w.session.studentId,
      studentName: w.session.examAttempt.student.user.name,
      type: w.type.toLowerCase(),
      severity: w.severity.toLowerCase(),
      message: w.message,
      timestamp: w.timestamp.toISOString(),
      isReviewed: w.isReviewed,
    }))
  },
}
