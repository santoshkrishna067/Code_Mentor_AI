import { z } from 'zod'

// Validates what the Python face-analysis service sends back, so a malformed
// or unexpected response can never reach the decision logic.
export const visionFrameSchema = z.object({
  frame: z.object({ width: z.number(), height: z.number() }),
  faceCount: z.number().int().nonnegative(),
  faces: z.array(z.object({ x: z.number(), y: z.number(), w: z.number(), h: z.number() })),
  head: z.object({ yaw: z.number(), pitch: z.number() }).nullable(),
  gaze: z.string().nullable(),
  mouthOpen: z.boolean().nullable(),
  blink: z.boolean().nullable(),
  objects: z.array(z.object({ label: z.string(), confidence: z.number() })),
})
