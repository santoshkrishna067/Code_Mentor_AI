import { prisma } from '@/config/prisma'
import { env } from '@/config/env'
import { logger } from '@/utils/logger'
import { ApiError } from '@/utils/apiResponse'
import { proctoringService } from './proctoring.service'
import { visionFrameSchema } from './proctoring.vision.schema'
import {
  AnnotatedFace,
  VisionFrame,
  VisionState,
  VisionStatus,
  createVisionState,
  evaluateFrame,
} from './proctoring.vision.logic'

// Receives one webcam frame from a logged-in student, asks the Python
// face-analysis service what it shows, applies the sustained-condition rules
// in proctoring.vision.logic.ts, and records any resulting warnings through the
// EXISTING proctoringService.reportWarning — so the escalation policy there
// stays the only thing that can end an attempt.
//
// Per-attempt state (baseline head angle, timers, cooldowns) is kept in memory:
// fine for one backend instance. If you ever run several instances behind a load
// balancer, move this state to Redis or the database.

const MAX_FRAME_BYTES = 1_000_000
const SESSION_RECHECK_MS = 10_000
const STATE_IDLE_TTL_MS = 30 * 60_000
const OUTAGE_EVENT_COOLDOWN_MS = 5 * 60_000

interface AttemptRuntime {
  vision: VisionState
  sessionVerifiedAt: number
  lastSeenAt: number
  lastOutageEventAt: number
}

const runtimes = new Map<string, AttemptRuntime>()
let lastPurgeAt = 0

function purgeIdle(now: number) {
  if (now - lastPurgeAt < 60_000) return
  lastPurgeAt = now
  for (const [id, rt] of runtimes) {
    if (now - rt.lastSeenAt > STATE_IDLE_TTL_MS) runtimes.delete(id)
  }
}

function isJpeg(buf: Buffer): boolean {
  return buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff
}

async function askFaceService(frame: Buffer) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), env.PROCTORING_SERVICE_TIMEOUT_MS)
  try {
    const headers: Record<string, string> = { 'content-type': 'image/jpeg' }
    if (env.PROCTORING_SERVICE_TOKEN) headers['x-proctoring-token'] = env.PROCTORING_SERVICE_TOKEN
    const res = await fetch(`${env.PROCTORING_SERVICE_URL}/analyze`, {
      method: 'POST',
      headers,
      body: frame,
      signal: controller.signal,
    })
    if (!res.ok) throw new Error(`face service answered HTTP ${res.status}`)
    return visionFrameSchema.parse(await res.json())
  } finally {
    clearTimeout(timer)
  }
}

export interface FrameResponse {
  available: boolean
  status: VisionStatus | 'unavailable'
  frame?: { width: number; height: number }
  faces: AnnotatedFace[]
  newWarnings: { type: string; severity: string; message: string }[]
  escalated: boolean
  reason?: string
  totalCount?: number
}

export const proctoringVisionService = {
  async processFrame(studentId: string, examAttemptId: string, body: unknown): Promise<FrameResponse> {
    if (!Buffer.isBuffer(body) || body.length === 0) {
      throw ApiError.badRequest('Send one camera frame as the request body with Content-Type: image/jpeg')
    }
    if (body.length > MAX_FRAME_BYTES) throw ApiError.badRequest('Frame is too large')
    if (!isJpeg(body)) throw ApiError.badRequest('Frame must be a JPEG image')

    const now = Date.now()
    purgeIdle(now)

    let rt = runtimes.get(examAttemptId)
    if (!rt) {
      rt = { vision: createVisionState(), sessionVerifiedAt: 0, lastSeenAt: now, lastOutageEventAt: 0 }
      runtimes.set(examAttemptId, rt)
    }
    rt.lastSeenAt = now

    // Ownership + "is the session still active" — re-checked every few seconds,
    // not on every frame, to keep database load low.
    if (now - rt.sessionVerifiedAt > SESSION_RECHECK_MS) {
      const session = await prisma.proctoringSession.findUnique({
        where: { examAttemptId },
        select: { studentId: true, status: true },
      })
      if (!session || session.studentId !== studentId) {
        runtimes.delete(examAttemptId)
        throw ApiError.notFound('Proctoring session not found')
      }
      if (session.status !== 'ACTIVE') {
        runtimes.delete(examAttemptId)
        throw ApiError.conflict('This proctoring session is no longer active')
      }
      rt.sessionVerifiedAt = now
    }

    let analysis: VisionFrame
    try {
      analysis = await askFaceService(body)
    } catch (err) {
      logger.warn({ err: (err as Error).message, examAttemptId }, 'proctoring face service unavailable')
      // Fail open for the student (their exam continues) but leave a trace for the admin.
      if (now - rt.lastOutageEventAt > OUTAGE_EVENT_COOLDOWN_MS) {
        rt.lastOutageEventAt = now
        await proctoringService
          .reportEvent(studentId, examAttemptId, {
            type: 'SERVICE_UNAVAILABLE',
            description: 'The face-analysis service could not be reached; camera frames were not analysed.',
            metadata: { reason: (err as Error).message },
          })
          .catch(() => undefined)
      }
      return { available: false, status: 'unavailable', faces: [], newWarnings: [], escalated: false }
    }

    const decision = evaluateFrame(rt.vision, analysis, now)

    for (const event of decision.events) {
      await proctoringService.reportEvent(studentId, examAttemptId, event).catch((e) => {
        logger.warn({ err: (e as Error).message }, 'could not record proctoring event')
      })
    }

    let escalated = false
    let reason: string | undefined
    let totalCount: number | undefined
    for (const w of decision.warnings) {
      const res = await proctoringService.reportWarning(studentId, examAttemptId, {
        type: w.type,
        severity: w.severity,
        message: w.message,
        evidence: w.evidence,
      })
      totalCount = res.totalCount
      if (res.escalated) {
        escalated = true
        reason = res.reason
        runtimes.delete(examAttemptId)
        break
      }
    }

    return {
      available: true,
      status: decision.status,
      frame: analysis.frame,
      faces: decision.faces,
      newWarnings: decision.warnings.map((w) => ({ type: w.type, severity: w.severity, message: w.message })),
      escalated,
      reason,
      totalCount,
    }
  },
}
