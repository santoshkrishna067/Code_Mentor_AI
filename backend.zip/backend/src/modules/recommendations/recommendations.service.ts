import { prisma } from '@/config/prisma'
import { RecommendationType, Priority, ContentType } from '@prisma/client'

// Rule-based baseline: turns each open LearningGap into a concrete
// "revise this topic" recommendation, and surfaces the next not-started
// subtopic in the student's current course as a "continue learning" nudge.
// Every recommendation traces back to a real DB row — nothing here is
// invented. Part 4's ML recommender writes to the same table with
// source='ml-model:<version>' and a confidence score.
export const recommendationsService = {
  async generateForStudent(studentId: string) {
    const openGaps = await prisma.learningGap.findMany({
      where: { studentId, resolvedAt: null },
      orderBy: { severity: 'asc' },
      take: 5,
    })

    const created = []
    for (const gap of openGaps) {
      const existing = await prisma.recommendation.findFirst({
        where: { studentId, learningGapId: gap.id, isCompleted: false },
      })
      if (existing) continue

      const priority = gap.severity === 'CRITICAL' ? Priority.HIGH : gap.severity === 'MODERATE' ? Priority.MEDIUM : Priority.LOW

      const rec = await prisma.recommendation.create({
        data: {
          studentId,
          type: RecommendationType.REVISE_TOPIC,
          priority,
          title: `Revisit "${gap.concept}"`,
          description: gap.description,
          courseId: gap.courseId,
          moduleId: gap.moduleId,
          topicId: gap.topicId,
          learningGapId: gap.id,
          reason: `Detected via ${gap.detectionSource}: recent scores on this topic were below the passing threshold.`,
          source: gap.detectionSource,
          confidence: gap.confidence ?? undefined,
        },
      })
      created.push(rec)
    }

    // Continue-learning nudge: next not-started subtopic in the student's current course.
    const profile = await prisma.studentProfile.findUnique({ where: { userId: studentId } })
    if (profile?.currentCourseId) {
      const doneSubtopicIds = new Set(
        (
          await prisma.progress.findMany({
            where: { studentId, courseId: profile.currentCourseId, status: 'COMPLETED', subtopicId: { not: null } },
            select: { subtopicId: true },
          })
        ).map((p) => p.subtopicId)
      )
      const nextSubtopic = await prisma.subtopic.findFirst({
        where: { topic: { module: { courseId: profile.currentCourseId } }, id: { notIn: [...doneSubtopicIds] as string[] } },
        orderBy: [{ topic: { module: { order: 'asc' } } }, { topic: { order: 'asc' } }, { order: 'asc' }],
        include: { topic: { include: { module: true } } },
      })
      if (nextSubtopic) {
        const alreadyExists = await prisma.recommendation.findFirst({
          where: { studentId, contentId: nextSubtopic.id, isCompleted: false, type: RecommendationType.CONTINUE_LEARNING },
        })
        if (!alreadyExists) {
          const rec = await prisma.recommendation.create({
            data: {
              studentId,
              type: RecommendationType.CONTINUE_LEARNING,
              priority: Priority.MEDIUM,
              title: `Continue: ${nextSubtopic.title}`,
              description: `Next up in ${nextSubtopic.topic.module.title}`,
              courseId: profile.currentCourseId,
              moduleId: nextSubtopic.topic.moduleId,
              topicId: nextSubtopic.topicId,
              contentId: nextSubtopic.id,
              contentType: nextSubtopic.contentType ?? undefined,
              estimatedDuration: nextSubtopic.estimatedDuration,
              reason: 'Next item in your enrolled course sequence.',
              source: 'rule-engine',
            },
          })
          created.push(rec)
        }
      }
    }

    // New students (not enrolled anywhere) get concrete "start this course"
    // suggestions so the page is never empty on day one. Beginner courses first.
    const enrollmentCount = await prisma.enrollment.count({ where: { studentId } })
    if (enrollmentCount === 0) {
      const courses = await prisma.course.findMany({ where: { status: 'PUBLISHED' }, orderBy: { name: 'asc' } })
      const rank: Record<string, number> = { BEGINNER: 0, INTERMEDIATE: 1, ADVANCED: 2, EXPERT: 3 }
      const picks = courses.sort((a, b) => (rank[a.difficulty] ?? 9) - (rank[b.difficulty] ?? 9)).slice(0, 3)
      for (const course of picks) {
        const exists = await prisma.recommendation.findFirst({
          where: { studentId, courseId: course.id, type: RecommendationType.START_COURSE, isCompleted: false },
        })
        if (exists) continue
        created.push(
          await prisma.recommendation.create({
            data: {
              studentId,
              type: RecommendationType.START_COURSE,
              priority: course.difficulty === 'BEGINNER' ? Priority.HIGH : Priority.MEDIUM,
              title: `Start: ${course.name}`,
              description: course.description,
              courseId: course.id,
              estimatedDuration: course.estimatedDuration * 60,
              reason: `You are not enrolled in any course yet — ${course.name} is a ${course.difficulty.toLowerCase()}-level course to begin with.`,
              source: 'rule-engine',
            },
          })
        )
      }
    }

    return created
  },

  async listForStudent(studentId: string) {
    const recs = await prisma.recommendation.findMany({
      where: { studentId, isCompleted: false, OR: [{ expiresAt: null }, { expiresAt: { gt: new Date() } }] },
      orderBy: [{ priority: 'asc' }, { createdAt: 'desc' }],
    })
    return recs.map((r) => ({
      id: r.id,
      studentId: r.studentId,
      type: r.type.toLowerCase(),
      priority: r.priority.toLowerCase(),
      title: r.title,
      description: r.description,
      courseId: r.courseId ?? undefined,
      moduleId: r.moduleId ?? undefined,
      topicId: r.topicId ?? undefined,
      contentId: r.contentId ?? undefined,
      contentType: r.contentType?.toLowerCase(),
      estimatedDuration: r.estimatedDuration ?? undefined,
      xpReward: r.xpReward ?? undefined,
      reason: r.reason,
      source: r.source,
      confidence: r.confidence ?? undefined,
      createdAt: r.createdAt.toISOString(),
    }))
  },

  async dismiss(studentId: string, recommendationId: string) {
    await prisma.recommendation.updateMany({
      where: { id: recommendationId, studentId },
      data: { isCompleted: true, completedAt: new Date() },
    })
  },
}
