import { Router } from 'express'
import { recommendationsService } from './recommendations.service'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole, requireSelfOrAdmin } from '@/middleware/rbac.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok } from '@/utils/apiResponse'
import { Role } from '@prisma/client'

const router = Router()

router.get(
  '/me',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => {
    let recs = await recommendationsService.listForStudent(req.user!.id)
    // Nothing yet? Generate the first batch on the fly so the student never sees an empty page.
    if (recs.length === 0) {
      await recommendationsService.generateForStudent(req.user!.id)
      recs = await recommendationsService.listForStudent(req.user!.id)
    }
    return ok(res, recs)
  })
)

router.post(
  '/me/refresh',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await recommendationsService.generateForStudent(req.user!.id), 'Recommendations refreshed'))
)

router.get(
  '/students/:studentId',
  requireAuth,
  requireSelfOrAdmin('studentId'),
  asyncHandler(async (req, res) => ok(res, await recommendationsService.listForStudent(req.params.studentId)))
)

router.patch(
  '/:id/dismiss',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => {
    await recommendationsService.dismiss(req.user!.id, req.params.id)
    return ok(res, null, 'Recommendation dismissed')
  })
)

export default router
