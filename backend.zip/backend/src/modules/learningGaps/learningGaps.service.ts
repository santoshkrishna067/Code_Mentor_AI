import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'
import { GapSeverity } from '@prisma/client'

const LOW_SCORE_THRESHOLD = 50
const MODERATE_SCORE_THRESHOLD = 65
const MIN_ATTEMPTS_TO_FLAG = 1

function scoreToSeverity(avgScore: number): GapSeverity {
  if (avgScore < LOW_SCORE_THRESHOLD) return GapSeverity.CRITICAL
  if (avgScore < MODERATE_SCORE_THRESHOLD) return GapSeverity.MODERATE
  return GapSeverity.MINOR
}

export const learningGapsService = {
  // Deterministic detection: for each topic where the student has graded
  // attempts, if their average score falls below MODERATE_SCORE_THRESHOLD,
  // record/refresh a LearningGap. This never invents a gap without data —
  // a topic with zero attempts is never flagged.
  async detectForStudentCourse(studentId: string, courseId: string) {
    const scoredProgress = await prisma.progress.findMany({
      where: { studentId, courseId, score: { not: null }, topicId: { not: null } },
      include: { topic: true, module: true },
    })

    const byTopic = new Map<string, { total: number; count: number; topicTitle: string; moduleId: string | null }>()
    for (const p of scoredProgress) {
      if (!p.topicId) continue
      const entry = byTopic.get(p.topicId) ?? { total: 0, count: 0, topicTitle: p.topic?.title ?? p.topicId, moduleId: p.moduleId }
      entry.total += p.score ?? 0
      entry.count += 1
      byTopic.set(p.topicId, entry)
    }

    const results = []
    for (const [topicId, data] of byTopic.entries()) {
      if (data.count < MIN_ATTEMPTS_TO_FLAG) continue
      const avgScore = data.total / data.count
      if (avgScore >= MODERATE_SCORE_THRESHOLD) continue // no gap

      const severity = scoreToSeverity(avgScore)
      const gapScore = Math.round(100 - avgScore)

      const existing = await prisma.learningGap.findFirst({
        where: { studentId, courseId, topicId, resolvedAt: null, detectionSource: 'rule-engine' },
      })

      const gap = existing
        ? await prisma.learningGap.update({
            where: { id: existing.id },
            data: { gapScore, severity, description: `Average score of ${Math.round(avgScore)}% across ${data.count} attempt(s) on "${data.topicTitle}"` },
          })
        : await prisma.learningGap.create({
            data: {
              studentId,
              courseId,
              moduleId: data.moduleId ?? undefined,
              topicId,
              concept: data.topicTitle,
              description: `Average score of ${Math.round(avgScore)}% across ${data.count} attempt(s) on "${data.topicTitle}"`,
              gapScore,
              severity,
              detectionSource: 'rule-engine',
            },
          })
      results.push(gap)
    }

    // Mark previously-open RULE-ENGINE gaps as improved if the topic's
    // average score has since risen above threshold. Scoped to
    // detectionSource='rule-engine' so this pass never resolves the ML
    // detector's own gap rows — each detector owns and resolves only its
    // own rows.
    const openGaps = await prisma.learningGap.findMany({
      where: { studentId, courseId, resolvedAt: null, detectionSource: 'rule-engine' },
    })
    for (const gap of openGaps) {
      if (!gap.topicId) continue
      const data = byTopic.get(gap.topicId)
      if (data && data.total / data.count >= MODERATE_SCORE_THRESHOLD) {
        await prisma.learningGap.update({
          where: { id: gap.id },
          data: { severity: GapSeverity.RESOLVED, resolvedAt: new Date() },
        })
      }
    }

    return results
  },

  async listForStudent(studentId: string, includeResolved = false) {
    const gaps = await prisma.learningGap.findMany({
      where: { studentId, ...(includeResolved ? {} : { resolvedAt: null }) },
      orderBy: [{ severity: 'asc' }, { detectedAt: 'desc' }],
      include: { course: true, topic: true },
    })
    return gaps.map((g) => ({
      id: g.id,
      studentId: g.studentId,
      courseId: g.courseId,
      courseName: g.course.name,
      moduleId: g.moduleId ?? undefined,
      topicId: g.topicId ?? undefined,
      topicName: g.topic?.title,
      concept: g.concept,
      description: g.description,
      gapScore: g.gapScore,
      severity: g.severity.toLowerCase(),
      detectedAt: g.detectedAt.toISOString(),
      improvedAt: g.improvedAt?.toISOString(),
      resolvedAt: g.resolvedAt?.toISOString(),
      detectionSource: g.detectionSource,
      confidence: g.confidence ?? undefined, // null for rule-engine gaps: deterministic, not an estimate
    }))
  },

  async listForCourse(courseId: string) {
    const gaps = await prisma.learningGap.findMany({
      where: { courseId, resolvedAt: null },
      orderBy: { severity: 'asc' },
      include: { student: { include: { user: true } }, topic: true },
    })
    return gaps.map((g) => ({
      id: g.id,
      studentId: g.studentId,
      studentName: g.student.user.name,
      topicName: g.topic?.title,
      concept: g.concept,
      severity: g.severity.toLowerCase(),
      gapScore: g.gapScore,
      detectedAt: g.detectedAt.toISOString(),
    }))
  },

  async markReviewed(gapId: string) {
    const gap = await prisma.learningGap.findUnique({ where: { id: gapId } })
    if (!gap) throw ApiError.notFound('Learning gap not found')
    return prisma.learningGap.update({ where: { id: gapId }, data: { improvedAt: new Date() } })
  },
}
