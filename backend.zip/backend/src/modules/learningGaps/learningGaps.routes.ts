import { Router } from 'express'
import { z } from 'zod'
import { learningGapsService } from './learningGaps.service'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole, requireSelfOrAdmin } from '@/middleware/rbac.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok } from '@/utils/apiResponse'
import { Role } from '@prisma/client'

const router = Router()

router.get(
  '/me',
  requireAuth,
  requireRole(Role.STUDENT),
  asyncHandler(async (req, res) => ok(res, await learningGapsService.listForStudent(req.user!.id)))
)

router.get(
  '/students/:studentId',
  requireAuth,
  requireSelfOrAdmin('studentId'),
  asyncHandler(async (req, res) => ok(res, await learningGapsService.listForStudent(req.params.studentId, true)))
)

router.post(
  '/students/:studentId/courses/:courseId/detect',
  requireAuth,
  requireSelfOrAdmin('studentId'),
  asyncHandler(async (req, res) =>
    ok(res, await learningGapsService.detectForStudentCourse(req.params.studentId, req.params.courseId), 'Detection run complete')
  )
)

router.get(
  '/courses/:courseId',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => ok(res, await learningGapsService.listForCourse(req.params.courseId)))
)

router.patch(
  '/:gapId/reviewed',
  requireAuth,
  requireRole(Role.ADMIN),
  asyncHandler(async (req, res) => ok(res, await learningGapsService.markReviewed(req.params.gapId), 'Marked as reviewed'))
)

export default router
