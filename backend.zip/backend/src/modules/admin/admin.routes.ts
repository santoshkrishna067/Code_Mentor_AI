import { Router } from 'express'
import { z } from 'zod'
import { adminService } from './admin.service'
import { requireAuth } from '@/middleware/auth.middleware'
import { requireRole } from '@/middleware/rbac.middleware'
import { validate } from '@/middleware/validate.middleware'
import { asyncHandler } from '@/utils/asyncHandler'
import { ok, paginated } from '@/utils/apiResponse'
import { writeAuditLog } from '@/utils/audit'
import { Role } from '@prisma/client'

const router = Router()

router.use(requireAuth, requireRole(Role.ADMIN))

router.get(
  '/dashboard',
  asyncHandler(async (req, res) => ok(res, await adminService.dashboard()))
)

const auditQuery = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(200).default(50),
  resource: z.string().optional(),
  userId: z.string().optional(),
})

router.get(
  '/audit-logs',
  validate({ query: auditQuery }),
  asyncHandler(async (req, res) => {
    const q = req.query as unknown as z.infer<typeof auditQuery>
    const { data, total } = await adminService.auditLogs(q)
    return paginated(res, data, { page: q.page, limit: q.limit, total })
  })
)

const questionSchema = z.object({
  type: z.enum(['MCQ', 'MULTIPLE_CHOICE', 'CODING', 'OUTPUT_PREDICTION', 'DEBUGGING', 'SQL', 'ALGORITHM', 'DSA', 'SHORT_ANSWER', 'TECHNICAL']),
  subtopicId: z.string().optional(), // put the question straight into this lesson's Practice set
  content: z.string().min(1),
  correctAnswer: z.union([z.string(), z.array(z.string())]),
  explanation: z.string().optional(),
  difficulty: z.enum(['BEGINNER', 'INTERMEDIATE', 'ADVANCED', 'EXPERT']),
  tags: z.array(z.string()).optional(),
  courseId: z.string(),
  moduleId: z.string().optional(),
  topicId: z.string().optional(),
  estimatedTime: z.number().int().positive(),
  marks: z.number().int().positive().default(1),
  negativeMarks: z.number().min(0).optional(),
  options: z.array(z.object({ content: z.string(), isCorrect: z.boolean() })).optional(),
})

router.post(
  '/questions',
  validate({ body: questionSchema }),
  asyncHandler(async (req, res) => {
    const question = await adminService.createQuestion(req.body)
    await writeAuditLog(req, 'QUESTION_CREATED', 'Question', question.id)
    return ok(res, question, 'Question created', 201)
  })
)

const listQuestionsQuery = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  courseId: z.string().optional(),
  topicId: z.string().optional(),
  difficulty: z.enum(['BEGINNER', 'INTERMEDIATE', 'ADVANCED', 'EXPERT']).optional(),
})

router.get(
  '/questions',
  validate({ query: listQuestionsQuery }),
  asyncHandler(async (req, res) => {
    const q = req.query as unknown as z.infer<typeof listQuestionsQuery>
    const { data, total } = await adminService.listQuestions(q)
    return paginated(res, data, { page: q.page, limit: q.limit, total })
  })
)

router.delete(
  '/questions/:id',
  asyncHandler(async (req, res) => {
    await adminService.deleteQuestion(req.params.id)
    await writeAuditLog(req, 'QUESTION_DELETED', 'Question', req.params.id)
    return ok(res, null, 'Question deleted')
  })
)

router.post(
  '/questions/:id/attach',
  validate({ body: z.object({ subtopicId: z.string().min(1) }) }),
  asyncHandler(async (req, res) => {
    const r = await adminService.attachQuestionToLesson(req.params.id, req.body.subtopicId)
    await writeAuditLog(req, 'QUESTION_ATTACHED', 'Question', req.params.id)
    return ok(res, r, 'Question added to the lesson practice')
  })
)

router.get(
  '/courses/:courseId/content-summary',
  asyncHandler(async (req, res) => ok(res, await adminService.courseContentSummary(req.params.courseId)))
)

router.get(
  '/lessons/:subtopicId/practice',
  asyncHandler(async (req, res) => ok(res, await adminService.lessonPractice(req.params.subtopicId)))
)

router.delete(
  '/lessons/:subtopicId/practice/:questionId',
  asyncHandler(async (req, res) => {
    await adminService.removeQuestionFromLesson(req.params.subtopicId, req.params.questionId)
    await writeAuditLog(req, 'QUESTION_REMOVED_FROM_LESSON', 'Question', req.params.questionId)
    return ok(res, null, 'Removed from the lesson')
  })
)

export default router
