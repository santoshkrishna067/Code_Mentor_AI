import { prisma } from '@/config/prisma'
import { ApiError } from '@/utils/apiResponse'

export const adminService = {
  async dashboard() {
    const [studentCount, adminCount, courseCount, publishedCount, pendingEvaluations, openGaps, recentAuditLogs] =
      await Promise.all([
        prisma.user.count({ where: { role: 'STUDENT' } }),
        prisma.user.count({ where: { role: 'ADMIN' } }),
        prisma.course.count(),
        prisma.course.count({ where: { status: 'PUBLISHED' } }),
        prisma.assignmentSubmission.count({ where: { status: 'SUBMITTED' } }),
        prisma.learningGap.count({ where: { resolvedAt: null, severity: 'CRITICAL' } }),
        prisma.auditLog.findMany({ orderBy: { timestamp: 'desc' }, take: 10, include: { user: true } }),
      ])

    return {
      studentCount,
      adminCount,
      courseCount,
      publishedCount,
      pendingEvaluations,
      criticalLearningGaps: openGaps,
      recentActivity: recentAuditLogs.map((l) => ({
        id: l.id,
        action: l.action,
        resource: l.resource,
        resourceId: l.resourceId ?? undefined,
        actor: l.user?.name ?? 'system',
        timestamp: l.timestamp.toISOString(),
      })),
    }
  },

  async auditLogs(query: { page: number; limit: number; resource?: string; userId?: string }) {
    const where = {
      ...(query.resource ? { resource: query.resource } : {}),
      ...(query.userId ? { userId: query.userId } : {}),
    }
    const [total, logs] = await Promise.all([
      prisma.auditLog.count({ where }),
      prisma.auditLog.findMany({
        where,
        orderBy: { timestamp: 'desc' },
        skip: (query.page - 1) * query.limit,
        take: query.limit,
        include: { user: true },
      }),
    ])
    return {
      total,
      data: logs.map((l) => ({
        id: l.id,
        action: l.action,
        resource: l.resource,
        resourceId: l.resourceId ?? undefined,
        actor: l.user ? { id: l.user.id, name: l.user.name, email: l.user.email } : undefined,
        details: l.details ?? undefined,
        ipAddress: l.ipAddress ?? undefined,
        timestamp: l.timestamp.toISOString(),
      })),
    }
  },

  // ---------------- Question bank ----------------

  async createQuestion(input: any) {
    if (input.options && input.type !== 'CODING' && input.type !== 'SHORT_ANSWER') {
      const correctCount = input.options.filter((o: any) => o.isCorrect).length
      if (correctCount === 0) throw ApiError.badRequest('At least one option must be marked correct')
    }
    if (input.type === 'MCQ' || input.type === 'MULTIPLE_CHOICE') {
      if (!input.options || input.options.length < 2) throw ApiError.badRequest('A multiple-choice question needs at least 2 options')
    }
    const created = await prisma.question.create({
      data: {
        type: input.type,
        content: input.content,
        correctAnswer: input.correctAnswer,
        explanation: input.explanation,
        difficulty: input.difficulty,
        tags: input.tags ?? [],
        courseId: input.courseId,
        moduleId: input.moduleId,
        topicId: input.topicId,
        estimatedTime: input.estimatedTime,
        marks: input.marks ?? 1,
        negativeMarks: input.negativeMarks,
        options: input.options ? { create: input.options } : undefined,
      },
      include: { options: true },
    })
    // Questions only reach students once they are attached somewhere. If the
    // admin picked a lesson, put the question in that lesson's Practice set.
    if (input.subtopicId) await adminService.attachQuestionToLesson(created.id, input.subtopicId)
    return created
  },

  // Adds a question to a lesson's Practice set (creating the set if the lesson has none).
  async attachQuestionToLesson(questionId: string, subtopicId: string) {
    const [question, subtopic] = await Promise.all([
      prisma.question.findUnique({ where: { id: questionId } }),
      prisma.subtopic.findUnique({ where: { id: subtopicId }, include: { topic: { include: { module: true } } } }),
    ])
    if (!question) throw ApiError.notFound('Question not found')
    if (!subtopic) throw ApiError.notFound('Lesson not found')
    if (subtopic.topic.module.courseId !== question.courseId) {
      throw ApiError.badRequest('That lesson belongs to a different course than the question')
    }
    let practice = await prisma.practice.findFirst({ where: { subtopicId }, orderBy: { id: 'asc' } })
    if (!practice) {
      practice = await prisma.practice.create({
        data: {
          subtopicId,
          title: `Practice: ${subtopic.title}`,
          description: `Check your understanding of "${subtopic.title}".`,
          difficulty: question.difficulty,
          estimatedDuration: 5,
          passingScore: 60,
        },
      })
    }
    const already = await prisma.practiceQuestion.findFirst({ where: { practiceId: practice.id, questionId } })
    if (!already) {
      const count = await prisma.practiceQuestion.count({ where: { practiceId: practice.id } })
      await prisma.practiceQuestion.create({ data: { practiceId: practice.id, questionId, order: count } })
    }
    return { practiceId: practice.id }
  },

  // Everything a student will see in a lesson's Practice tab, with answers (admin only).
  async lessonPractice(subtopicId: string) {
    const practices = await prisma.practice.findMany({
      where: { subtopicId },
      include: { questions: { orderBy: { order: 'asc' }, include: { question: { include: { options: true } } } } },
    })
    return practices.flatMap((p) =>
      p.questions.map((pq) => ({
        id: pq.question.id,
        type: pq.question.type,
        content: pq.question.content,
        correctAnswer: pq.question.correctAnswer,
        explanation: pq.question.explanation,
        difficulty: pq.question.difficulty,
        options: pq.question.options.map((o) => ({ id: o.id, content: o.content, isCorrect: o.isCorrect })),
      }))
    )
  },

  // Takes a question out of a lesson's Practice set; deletes it entirely if nothing else uses it.
  async removeQuestionFromLesson(subtopicId: string, questionId: string) {
    const practices = await prisma.practice.findMany({ where: { subtopicId }, select: { id: true } })
    await prisma.practiceQuestion.deleteMany({ where: { questionId, practiceId: { in: practices.map((p) => p.id) } } })
    const q = await prisma.question.findUnique({
      where: { id: questionId },
      include: { practiceLinks: true, quizLinks: true, testLinks: true, assessmentLinks: true, examLinks: true },
    })
    if (q && q.practiceLinks.length + q.quizLinks.length + q.testLinks.length + q.assessmentLinks.length + q.examLinks.length === 0) {
      await prisma.question.delete({ where: { id: questionId } })
    }
  },

  // One row per lesson in a course: which kinds of content it already has.
  // Powers the status dots and the coverage summary in Courses -> Manage content.
  async courseContentSummary(courseId: string) {
    const lessons = await prisma.subtopic.findMany({
      where: { topic: { module: { courseId } } },
      select: {
        id: true,
        _count: { select: { notes: true, resources: true, videosPrimary: true, videoCoverage: true } },
        practices: { select: { _count: { select: { questions: true } } } },
      },
    })
    return lessons.map((l) => ({
      id: l.id,
      hasVideo: l._count.videosPrimary + l._count.videoCoverage > 0,
      hasNotes: l._count.notes > 0,
      practiceQuestions: l.practices.reduce((sum, p) => sum + p._count.questions, 0),
      materials: l._count.resources,
    }))
  },

  async listQuestions(query: { page: number; limit: number; courseId?: string; topicId?: string; difficulty?: string }) {
    const where = {
      ...(query.courseId ? { courseId: query.courseId } : {}),
      ...(query.topicId ? { topicId: query.topicId } : {}),
      ...(query.difficulty ? { difficulty: query.difficulty as any } : {}),
    }
    const [total, questions] = await Promise.all([
      prisma.question.count({ where }),
      prisma.question.findMany({
        where,
        include: {
          options: true,
          course: { select: { name: true } },
          practiceLinks: { include: { practice: { select: { subtopic: { select: { title: true } } } } } },
          _count: { select: { quizLinks: true, testLinks: true, assessmentLinks: true, examLinks: true } },
        },
        skip: (query.page - 1) * query.limit,
        take: query.limit,
        orderBy: { createdAt: 'desc' },
      }),
    ])
    const data = questions.map((q) => {
      const usedIn: string[] = q.practiceLinks.map((l) => `Lesson practice: ${l.practice.subtopic.title}`)
      if (q._count.quizLinks) usedIn.push(`${q._count.quizLinks} quiz(zes)`)
      if (q._count.testLinks) usedIn.push(`${q._count.testLinks} test(s)`)
      if (q._count.assessmentLinks) usedIn.push(`${q._count.assessmentLinks} assessment(s)`)
      if (q._count.examLinks) usedIn.push(`${q._count.examLinks} exam(s)`)
      const { practiceLinks: _p, _count: _c, ...rest } = q
      return { ...rest, courseName: q.course.name, usedIn }
    })
    return { total, data }
  },

  async deleteQuestion(questionId: string) {
    const question = await prisma.question.findUnique({
      where: { id: questionId },
      include: {
        practiceLinks: true,
        quizLinks: true,
        testLinks: true,
        assessmentLinks: true,
        examLinks: true,
      },
    })
    if (!question) throw ApiError.notFound('Question not found')
    const usageCount =
      question.quizLinks.length +
      question.testLinks.length +
      question.assessmentLinks.length +
      question.examLinks.length
    if (usageCount > 0) {
      throw ApiError.conflict(`This question is used in ${usageCount} quiz/test/assessment/exam and cannot be deleted.`)
    }
    await prisma.practiceQuestion.deleteMany({ where: { questionId } }) // lesson practice sets simply lose it
    await prisma.question.delete({ where: { id: questionId } })
  },
}
